// SPDX-License-Identifier: AGPL-3.0-or-later

//! LMD-GHOST weight accumulation — what the per-slot subcommittee is *for*.
//!
//! Latest Message Driven: only a validator's most recent attestation counts,
//! so an equivocating or merely reorganising validator cannot vote twice for
//! weight purposes. Weight of a block = total effective stake of validators
//! whose latest message is that block or any of its descendants. The head is
//! found by walking from the justified root, always taking the heaviest child.
//!
//! ## What this store does NOT guarantee (external audit 2026-09-07, O01)
//!
//! [`Store::observe`] keeps ONE message per validator — the latest — and
//! judges equivocation only against that message. That makes the verdict on
//! a same-slot pair order-independent *when nothing later intervenes*, and
//! order-DEPENDENT in general: for A = (slot 1, x), B = (slot 1, y),
//! C = (slot 2, z) from one validator, the arrivals ABC and BAC bar the
//! validator, while ACB, BCA, CAB and CBA retain C and dismiss the second old
//! vote as stale (`prev.slot >= msg.slot`), so the pair is never compared.
//! `observe_alone_misses_a_same_slot_pair_split_by_a_later_vote_in_four_of_six_orders`
//! below pins that count. An earlier doc comment here claimed the discard was
//! order-independent "by construction"; it was not, and the comment is
//! corrected — the history of the 2026-08-11 finding is kept because it is
//! what the single-slot case DOES get right.
//!
//! The fix is not in this file, and `observe` is deliberately unchanged: the
//! node's fork choice (`bloch-pos-node/src/engine.rs`) builds this store from
//! blocks and its pool and must keep compiling and behaving as it does. The
//! committed fold, `CommittedState::accumulate_forkchoice` (transition.rs),
//! is where the verdict becomes consensus state, and from
//! `params::FORKCHOICE_EQUIVOCATION_HORIZON_ACTIVATION_EPOCH` it retains a
//! bounded per-(validator, slot) vote history
//! (`params::FORKCHOICE_EQUIVOCATION_HORIZON_SLOTS`) and judges every vote
//! against THAT before handing it to `observe` — so a same-slot conflict is
//! found whichever of the six orders the blocks carried it in. Below the
//! gate (its value today) the fold is byte-identical to what this file
//! alone computes. Arming it is a founder decision; see the constant's docs.

use std::collections::HashMap;
use std::sync::atomic::{AtomicU64, Ordering};

/// DAG steps the fork choice has walked since the process started.
///
/// Not a metric anyone reads in production — it is the *asymptotics* test's
/// only deterministic handle. `head_step_count_is_linear_in_depth` doubles the
/// chain depth and asserts this counter roughly doubles; before the 2026-08-23
/// rewrite it roughly quadrupled, which is the whole claim in one number and
/// the reason the test could not have passed both before and after.
///
/// Batched: one relaxed add per fork-choice call, never one per step, so it
/// costs nothing on the consensus thread.
#[doc(hidden)]
pub static FORKCHOICE_STEPS: AtomicU64 = AtomicU64::new(0);

/// Per-validator latest vote, as the fork-choice store holds it.
#[derive(Clone, Copy, Debug)]
pub struct LatestMessage {
    pub slot: u64,
    pub root: [u8; 32],
}

/// Minimal block-tree view: every known block and its parent.
///
/// The caller owns the real store; this takes a borrowed view so the fork
/// choice cannot mutate anything, which keeps it a pure function of the inputs
/// (the §5.5 rule again).
pub struct BlockTree<'a> {
    /// child root → parent root.
    pub parents: &'a HashMap<[u8; 32], [u8; 32]>,
}

/// Fork-choice store: latest messages plus the stake behind each validator.
pub struct Store {
    latest: HashMap<u32, LatestMessage>,
    stake: HashMap<u32, u64>,
    /// Validators observed equivocating; excluded from weight forever.
    equivocators: std::collections::HashSet<u32>,
}

impl Store {
    pub fn new() -> Self {
        Store {
            latest: HashMap::new(),
            stake: HashMap::new(),
            equivocators: std::collections::HashSet::new(),
        }
    }

    /// Register a validator's effective stake (as committed by the parent
    /// block's state).
    pub fn set_stake(&mut self, validator: u32, effective_stake: u64) {
        self.stake.insert(validator, effective_stake);
    }

    /// Record a vote. Older messages are ignored, so replaying an old
    /// attestation cannot move the head backwards.
    ///
    /// A validator that signs two different heads in one slot is **equivocating**
    /// and is dropped from fork-choice weight entirely, permanently.
    ///
    /// An earlier version kept the first message seen and claimed that made head
    /// selection independent of arrival order. It did the opposite: with an
    /// equivocating validator, two honest nodes holding the identical message
    /// set each kept whichever arrived first and computed *different heads* —
    /// found by property test, 2026-08-11.
    ///
    /// Discarding the equivocator is order-independent for the case that
    /// finding covered — a conflicting pair at one slot with no later message
    /// from the same validator between the two halves: both halves are
    /// refused whichever arrived first. It also matches the finality gadget,
    /// which drops equivocators from both tallies, and it is the honest
    /// posture — equivocation is slashable (§7.3), so the validator is about
    /// to be ejected regardless. Its votes are evidence, not weight.
    ///
    /// It is NOT order-independent in general (external audit 2026-09-07,
    /// O01). This method compares against the single retained latest message,
    /// so once a LATER-slot vote from the validator has been retained, an
    /// older vote arriving afterwards is dismissed by the `prev.slot >=
    /// msg.slot` arm below without ever being compared to its same-slot
    /// sibling: of the six arrival orders of {A = (s, x), B = (s, y),
    /// C = (s + 1, z)}, only ABC and BAC bar the validator. The claim this
    /// comment used to make — order-independent "by construction" — was
    /// false; the module docs say where the complete, gated check lives.
    pub fn observe(&mut self, validator: u32, msg: LatestMessage) -> bool {
        if self.equivocators.contains(&validator) {
            return false;
        }
        match self.latest.get(&validator) {
            // Same slot, different head: equivocation. Drop the stored message
            // and bar the validator — both halves of the pair are refused, so
            // arrival order cannot matter.
            Some(prev) if prev.slot == msg.slot && prev.root != msg.root => {
                self.latest.remove(&validator);
                self.equivocators.insert(validator);
                false
            }
            Some(prev) if prev.slot >= msg.slot => false,
            _ => {
                self.latest.insert(validator, msg);
                true
            }
        }
    }

    /// Validators barred for equivocating. Feeds the slashing pipeline (§7.3).
    pub fn equivocators(&self) -> impl Iterator<Item = &u32> {
        self.equivocators.iter()
    }

    /// Total stake whose latest message is `root` or a descendant of it.
    pub fn weight(&self, tree: &BlockTree<'_>, root: &[u8; 32]) -> u128 {
        let mut total: u128 = 0;
        for (validator, msg) in &self.latest {
            if is_descendant_or_self(tree, &msg.root, root) {
                total += *self.stake.get(validator).unwrap_or(&0) as u128;
            }
        }
        total
    }

    /// Walk from `justified` to the head, taking the heaviest child at each
    /// step. Ties break on the larger block root — arbitrary, but *identical*
    /// on every node, which is the only property that matters.
    ///
    /// ## Why this is not `weight()` in a loop any more
    ///
    /// It was, until 2026-08-23, and that shape is O(V·D²): the descent visits
    /// D levels, each level called [`Store::weight`] once per sibling, and
    /// every one of those calls walked all V latest messages up their whole
    /// ancestor chain (O(V·D)). MEASURED on the old shape: 477 ms at depth
    /// 256, 2.4 s at 512, 8.8 s at 1024, 107 s at 4096 — a fork choice that
    /// costs more than a slot is a chain that stops.
    ///
    /// This computes the same numbers bottom-up instead. Each validator's
    /// stake is attributed once to the block it voted for, subtree weights
    /// accumulate in one pass from leaves toward the roots (Kahn's algorithm
    /// over child→parent edges), and the descent then reads a precomputed
    /// weight per sibling. O(V + N + D) for N known blocks.
    ///
    /// ## Why the selected head is bit-identical, not merely "equivalent"
    ///
    /// The head is consensus-relevant, so this is not a refactor that may be
    /// approximately right — the 2026-08-08 fork came from exactly that kind
    /// of confidence. Three obligations, and each is discharged here:
    ///
    /// 1. **The weights are the same numbers.** `weight(X)` counts a validator
    ///    iff `is_descendant_or_self(msg.root, X)`, i.e. iff the parent walk
    ///    from its vote reaches X. The walk gives up after `parents.len() + 1`
    ///    steps, and a functional graph (one parent per node) has at most that
    ///    many distinct nodes on any walk, so the cutoff never truncates a
    ///    reachable node: the predicate *is* plain reachability. Accumulating
    ///    `direct[R]` up the parent edges therefore lands the same stake on the
    ///    same blocks, and it does so for unknown roots too — a vote for a root
    ///    this node has never seen contributes to that root alone in both
    ///    implementations, which is why `weights` is seeded from every vote
    ///    root rather than from the known block set.
    ///
    /// 2. **The tie-break is byte-for-byte the one below it.** `best` starts at
    ///    `kids[0]` and a later sibling displaces it on `w > best_w ||
    ///    (w == best_w && *child > best)` — the lexicographic maximum of
    ///    (weight, root). The loop here is character-for-character that loop;
    ///    only the source of `w` changed. A different tie-break is a different
    ///    head is a hard fork, so it was not touched.
    ///
    /// 3. **Cycles cannot make the two disagree.** Kahn's leaves a node inside
    ///    a parent cycle unprocessed, where `weight()` would have credited it.
    ///    That gap is unreachable: a cycle node's parent is in the cycle, so it
    ///    can never be the child of an acyclic block, so the descent can only
    ///    query one after entering the cycle itself — and the descent below
    ///    (in both versions) never leaves a cycle. Whenever the old code
    ///    *terminated*, every block it weighed was acyclic-rooted, its whole
    ///    descendant set was acyclic (a cycle node's parent is in the cycle),
    ///    and Kahn's processed all of it. The step bound on the descent is new
    ///    and only fires where the old loop spun forever; block ids are hashes
    ///    over the header that names the parent, so it is unreachable on any
    ///    chain, not merely unlikely.
    ///
    /// `head_reference` keeps the old algorithm alive as the differential
    /// oracle: `forkchoice_head_matches_the_reference_implementation` in
    /// tests/properties.rs asserts the two agree over randomised DAGs, and
    /// `head_step_count_is_linear_in_depth_and_the_old_one_was_quadratic` in
    /// tests/forkchoice_asymptotics.rs is the test that could not pass before.
    pub fn head(
        &self,
        tree: &BlockTree<'_>,
        justified: [u8; 32],
        children: &HashMap<[u8; 32], Vec<[u8; 32]>>,
    ) -> [u8; 32] {
        let weights = self.subtree_weights(tree);
        let mut steps = 0u64;
        // Bounded for the same reason `is_descendant_or_self` is bounded: a
        // parent/children map with a cycle in it must terminate the node's
        // fork choice, not hang the consensus thread. The bound is a count of
        // LEVELS, and every level moves to a distinct block while the graph is
        // acyclic, so it cannot fire early on any real chain: there are at
        // most this many distinct blocks in the two maps put together.
        let limit = tree.parents.len() + children.len() + 1;
        let mut levels = 0usize;
        let mut current = justified;
        while levels <= limit {
            let kids = match children.get(&current) {
                Some(k) if !k.is_empty() => k,
                _ => break,
            };
            let w_of = |b: &[u8; 32]| weights.get(b).copied().unwrap_or(0);
            let mut best = kids[0];
            let mut best_w = w_of(&best);
            for child in &kids[1..] {
                let w = w_of(child);
                if w > best_w || (w == best_w && *child > best) {
                    best = *child;
                    best_w = w;
                }
            }
            steps += kids.len() as u64;
            levels += 1;
            current = best;
        }
        FORKCHOICE_STEPS.fetch_add(steps, Ordering::Relaxed);
        current
    }

    /// Total stake resting on each block's subtree, every block at once.
    ///
    /// `weights[b]` is exactly `self.weight(tree, &b)` — see the three
    /// obligations on [`Store::head`] — computed for all of them in one pass
    /// instead of one walk per query.
    ///
    /// The accumulation runs over `tree.parents`, never over the caller's
    /// `children` map, because `weight()` reads only `tree.parents`: if the
    /// two ever disagree, matching `weight()` is what keeps the head the same.
    fn subtree_weights(&self, tree: &BlockTree<'_>) -> HashMap<[u8; 32], u128> {
        // One validator, one vote, credited to the block it named. Roots this
        // node has never seen get an entry too: `weight()` counts a vote for
        // an unknown root toward that root itself.
        let mut weights: HashMap<[u8; 32], u128> =
            HashMap::with_capacity(tree.parents.len() + self.latest.len());
        for (validator, msg) in &self.latest {
            *weights.entry(msg.root).or_insert(0) +=
                *self.stake.get(validator).unwrap_or(&0) as u128;
        }
        for id in tree.parents.keys() {
            weights.entry(*id).or_insert(0);
        }

        // Kahn's over child→parent edges: a block's weight is final once every
        // known child has handed its subtree up.
        let mut pending: HashMap<[u8; 32], usize> = HashMap::with_capacity(tree.parents.len());
        for parent in tree.parents.values() {
            *pending.entry(*parent).or_insert(0) += 1;
        }
        let mut ready: Vec<[u8; 32]> = tree
            .parents
            .keys()
            .filter(|id| pending.get(*id).copied().unwrap_or(0) == 0)
            .copied()
            .collect();
        let mut steps = 0u64;
        while let Some(id) = ready.pop() {
            steps += 1;
            let w = weights.get(&id).copied().unwrap_or(0);
            let Some(parent) = tree.parents.get(&id) else {
                continue;
            };
            *weights.entry(*parent).or_insert(0) += w;
            // Only a KNOWN parent can itself be released: an unknown one has
            // no parent edge of its own, so nothing waits on it.
            if let Some(n) = pending.get_mut(parent) {
                *n -= 1;
                if *n == 0 && tree.parents.contains_key(parent) {
                    ready.push(*parent);
                }
            }
        }
        FORKCHOICE_STEPS.fetch_add(steps, Ordering::Relaxed);
        weights
    }

    /// The fork choice exactly as it was before the 2026-08-23 rewrite, kept
    /// as the differential oracle for [`Store::head`] and for nothing else.
    ///
    /// O(V·D²) and unusable on a real chain — it is here so a property test
    /// can assert the fast one agrees with it head-for-head over randomised
    /// DAGs, which is the only evidence that the rewrite was a performance
    /// change and not a consensus change.
    #[doc(hidden)]
    pub fn head_reference(
        &self,
        tree: &BlockTree<'_>,
        justified: [u8; 32],
        children: &HashMap<[u8; 32], Vec<[u8; 32]>>,
    ) -> [u8; 32] {
        let mut current = justified;
        loop {
            let kids = match children.get(&current) {
                Some(k) if !k.is_empty() => k,
                _ => return current,
            };
            let mut best = kids[0];
            let mut best_w = self.weight(tree, &best);
            for child in &kids[1..] {
                let w = self.weight(tree, child);
                if w > best_w || (w == best_w && *child > best) {
                    best = *child;
                    best_w = w;
                }
            }
            current = best;
        }
    }

    /// Number of validators with a recorded vote.
    pub fn voters(&self) -> usize {
        self.latest.len()
    }
}

impl Default for Store {
    fn default() -> Self {
        Self::new()
    }
}

/// Is `node` equal to `ancestor`, or reachable from it by following parents?
///
/// Bounded by the number of known blocks: a corrupt parent map containing a
/// cycle must not hang the node, so the walk counts steps and gives up rather
/// than looping forever.
fn is_descendant_or_self(tree: &BlockTree<'_>, node: &[u8; 32], ancestor: &[u8; 32]) -> bool {
    let mut cur = *node;
    let mut steps = 0usize;
    let limit = tree.parents.len() + 1;
    let verdict = loop {
        if cur == *ancestor {
            break true;
        }
        match tree.parents.get(&cur) {
            Some(p) => {
                cur = *p;
                steps += 1;
                if steps > limit {
                    break false;
                }
            }
            None => break false,
        }
    };
    FORKCHOICE_STEPS.fetch_add(steps as u64, Ordering::Relaxed);
    verdict
}

#[cfg(test)]
mod tests {
    use super::*;

    /// The three votes of the O01 model: A and B conflict at one slot, C is a
    /// later honest-looking vote from the same validator.
    fn abc() -> [LatestMessage; 3] {
        [
            LatestMessage { slot: 1, root: [0xAA; 32] },
            LatestMessage { slot: 1, root: [0xBB; 32] },
            LatestMessage { slot: 2, root: [0xCC; 32] },
        ]
    }

    /// Feed one arrival order into a fresh store; is validator 7 barred after?
    fn barred_after(order: [usize; 3]) -> bool {
        let votes = abc();
        let mut store = Store::new();
        store.set_stake(7, 1);
        for i in order {
            store.observe(7, votes[i]);
        }
        // Bound first: `equivocators()` borrows the store, and a tail
        // expression would outlive it.
        let barred = store.equivocators().any(|v| *v == 7);
        barred
    }

    /// External audit 2026-09-07, O01: the exact count the module docs and
    /// the `observe` docs now state. This is a pin on the DOCUMENTED gap in
    /// the bare store, not a test of the fix — the fix lives in
    /// `transition::CommittedState::accumulate_forkchoice` behind its gate and
    /// is tested there on the real fold. If `observe` is ever changed so that
    /// this goes red, the node's fork choice changed too, and the doc comments
    /// here are stale.
    #[test]
    fn observe_alone_misses_a_same_slot_pair_split_by_a_later_vote_in_four_of_six_orders() {
        // Indices into abc(): 0 = A, 1 = B, 2 = C.
        let bars = [[0, 1, 2], [1, 0, 2]];
        let misses = [[0, 2, 1], [1, 2, 0], [2, 0, 1], [2, 1, 0]];
        for order in bars {
            assert!(barred_after(order), "order {order:?} must bar: the pair meets before C");
        }
        for order in misses {
            assert!(
                !barred_after(order),
                "order {order:?} is documented as a MISS of the bare store; if it now bars, \
                 observe changed and the O01 docs must be rewritten"
            );
        }
    }

    /// What the 2026-08-11 finding DID establish, and what the corrected doc
    /// comment still claims: a same-slot pair with nothing later between its
    /// halves is barred in either order, and neither half keeps weight.
    #[test]
    fn a_same_slot_pair_alone_is_barred_in_either_order() {
        let [a, b, _] = abc();
        for order in [[a, b], [b, a]] {
            let mut store = Store::new();
            store.set_stake(7, 1);
            for msg in order {
                store.observe(7, msg);
            }
            assert!(store.equivocators().any(|v| *v == 7));
            assert_eq!(store.voters(), 0, "a barred validator's message must not remain");
        }
    }
}
