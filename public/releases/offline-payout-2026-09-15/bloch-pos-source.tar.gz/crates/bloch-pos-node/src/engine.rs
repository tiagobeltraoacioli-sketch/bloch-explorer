// SPDX-License-Identifier: AGPL-3.0-or-later

//! Candidate schedule: lifecycle epoch 2884, 2026-09-14 22:35:19 UTC.
//! Scheduling evidence penalties does not establish deployed readiness or
//! an economic settlement guarantee across nodes.
//!
//! The consensus engine: one thread owning all consensus state, driven by the
//! slot timer and by network events — nothing else mutates state
//! (integration plan §1.1). The wall clock enters exactly here, at the timer;
//! every rule below it is the pure crate's.
//!
//! ## Which composition seam this engine binds
//!
//! One, and now there is only one to bind. The pure crate used to ship a
//! second, complete block validator — `derive::validate_block`, over
//! `ParentState`/`ChainState`, with its own frozen error order and no caller.
//! It was deleted on 2026-08-12 (the checklist comparison is in `derive.rs`
//! where it stood); `derive` keeps only the shared derivation functions, which
//! `produce.rs` stamps with and `transition` checks against.
//!
//! This engine binds `Transition`/`CommittedState`: the seam that implements
//! the frozen `StateTransition`/`StateReader` traits, composes finality, and —
//! since 2026-08-12 — judges the header's body/attestation/coherence
//! commitments itself. The two `derive::*` root calls below are an early
//! cheap reject before a state clone, not a second opinion: they are the same
//! functions the transition checks with.
//!
//! ## Producer = validator, structurally
//!
//! The producer fills `state_root` by running `Transition::compute_post_state`
//! — the *same* function `apply_block` is defined as — on the same parent
//! state, then every block (own or peer) passes `apply_block` under the real
//! hybrid verifier before it is stored or broadcast. A node that rejects its
//! own block panics loudly: that is the h28080 seam and it must never be
//! shrugged past.
//!
//! ## Fork choice — LMD-GHOST
//!
//! Canonical is whatever [`forkchoice::Store::head`] selects: walk from the
//! **justified** checkpoint and take the heaviest child at every step, where
//! weight is the total effective stake of validators whose *latest* message is
//! that block or a descendant. `advance` then makes the canonical chain match
//! that head, extending when the head descends from it and reorganising (by
//! replaying from genesis — never trusting an unvalidated branch) when it does
//! not.
//!
//! This replaces longest-valid-chain, which resolved competing forks by whoever
//! extended first. That rule is not merely weaker, it is *wrong under PoS*: it
//! lets a proposer with no attested support drag the chain by building fast,
//! and it gives an attacker who can produce blocks a way to override a branch
//! the honest majority has already voted for. Length is not the security
//! statement in proof of stake; attested stake is.
//!
//! Two properties come from starting the walk at the justified checkpoint
//! rather than at genesis: the walk never proposes a head that conflicts with
//! the justified checkpoint it starts from, and it is bounded by the
//! unfinalised suffix instead of the whole chain.
//!
//! This sentence used to read "finalised history can never be reorganised
//! out". CORRECTED 2026-09-01: that is false as a property of the WALK, and
//! it is false in normal operation, not under attack. The walk starts at the
//! *justified* root, and the state committed there finalises two epochs below
//! the head — so the deepest cut the walk may legitimately propose is itself
//! a finality rewind. It has been measured: finalized epoch 6 -> 4 -> 2 -> 0
//! in three in-rules cuts.
//!
//! CLOSED 2026-09-05 (finding F-03): the walk still proposes such cuts, but
//! the node no longer takes them. `Engine::finalized_latch` is an
//! engine-owned downward ratchet — the highest finalized checkpoint this
//! node has ever adopted — and both `advance` and `do_reorg` refuse any
//! reorg whose fork point sits below it, dropping the demanding branch. The
//! latch is deliberately NOT read from replayed state (a reorg replaces that
//! state; that substitution WAS the bug). `rpc.rs`'s `Finality` doc still
//! carries the slashing-cost retraction an integrator needs: the latch stops
//! THIS node rewinding itself; it is not an economic guarantee across nodes.
//!
//! The store is **rebuilt from scratch on every head computation** rather than
//! carried as mutable node state. That is the §5.5 posture applied where it is
//! cheapest to get wrong: a cached fork-choice store is exactly the kind of
//! node-local mutable state that made two honest nodes disagree in the
//! `expected_bits` incident. Rebuilding is O(blocks x attestations) per call
//! and, on a devnet, free; when it stops being free the fix is an incremental
//! store with a test proving it equals the rebuild, not a cache with a comment.

use std::collections::{BTreeMap, BTreeSet, HashMap, VecDeque};
use std::io;
use std::path::PathBuf;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::mpsc;
use std::sync::Arc;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use bloch_pos_committee::attestation::{Attestation, AttestationData, KeyLookup, SignatureVerifier};
use bloch_pos_committee::beacon::{mix_in, RandaoChain};
use bloch_pos_committee::fee_market;
use bloch_pos_committee::forkchoice::{BlockTree, LatestMessage, Store as FcStore};
use bloch_pos_committee::gossip::{AttestationPool, GossipDecision};
use bloch_pos_committee::header::{BlockEnvelope, BlockHeaderV4, BlockId, Body, VERSION_G4};
use bloch_pos_committee::interfaces::{ProposalEnvelope, StateReader, StateTransition, ValidatorRecord};
use bloch_pos_committee::params::{MAX_ATTESTATIONS_PER_BLOCK, SLOTS_PER_EPOCH};
use bloch_pos_committee::schedule::first_slot_of_epoch;
use bloch_pos_committee::transition::{CommittedState, PosTransaction, Transition};
use bloch_pos_committee::interfaces::TransitionError;
use bloch_pos_committee::{committees, derive, epoch_of, schedule};
use sha3::{Digest, Sha3_256};

mod validator_lifecycle;

use crate::genesis::Manifest;
#[cfg(test)]
use crate::genesis::GENESIS_MIX;
use crate::keys::{HybridVerifier, Keystore, ProbeVerifier};
use crate::net::{self, NetEvent, Origin, Verdict};
use crate::rpc::{self, Admitted, Finality, Json, RpcCall, RpcError, RpcRequest, RpcResult};
use crate::slashprot::SlashingProtection;
use crate::store::Store;

/// Everything that reaches the consensus thread from outside it.
///
/// One channel, three sources now: the two transports both feed `Net`, and the
/// RPC feeds `Rpc`. Answering a query from *inside* the thread that owns the
/// state — rather than from a copy kept alongside it — is why this wrapper
/// exists; see [`crate::rpc::EngineBackend`].
pub enum EngineEvent {
    Net(NetEvent),
    Rpc(RpcCall),
}

/// Which transport the node runs.
///
/// `Devnet` is still the default: a 64-validator devnet across five hosts
/// finalized on it and that result must stay reproducible by running the same
/// command. `Libp2p` is the production stack (see [`crate::p2p`]) and is what
/// anything reachable from outside a firewall must use.
///
/// `Dual` runs both in one process ([`crate::net::Net::Both`]). It exists so
/// that moving a fleet between transports is a rolling change instead of a
/// flag day: today a node speaks one or the other, so the whole fleet must
/// cross at one instant or split into two networks that both look healthy.
/// **It is never selected by default** — `--transport dual` is the only way to
/// reach it, and `None` still means `Devnet`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Transport {
    Devnet,
    Libp2p,
    Dual,
}

pub struct Config {
    pub data_dir: PathBuf,
    pub genesis_path: PathBuf,
    pub transport: Transport,
    /// Devnet transport: the TCP port the full mesh listens on.
    pub listen: u16,
    /// Devnet transport: the address the mesh listener binds. `127.0.0.1`
    /// unless `--listen-addr` says otherwise — see the warning on
    /// [`crate::net::start`] before binding anything routable.
    pub listen_addr: String,
    /// Devnet transport: `host:port` peers.
    pub peers: Vec<String>,
    /// libp2p transport: multiaddrs to listen on.
    pub p2p_listen: Vec<String>,
    /// libp2p transport: multiaddrs to dial (`/ip4/…/tcp/…/p2p/<peer-id>`).
    pub p2p_peers: Vec<String>,
    /// libp2p transport: connection ceiling.
    pub max_peers: usize,
    /// libp2p transport: zero the IP-colocation score penalty.
    pub behind_proxy: bool,
    pub stop_at_slot: Option<u64>,
    pub ws: crate::ws_boot::WsConfig,
    /// The Genesis-3 balance snapshot, when the manifest commits to one. It is
    /// a separate file rather than a manifest field because it is tens of
    /// megabytes and the manifest is the thing every node hashes; the
    /// manifest's `CarryoverCommitment` is what binds the two together.
    /// Required exactly when the manifest carries a commitment — see the
    /// refusals at the top of [`run`].
    pub carryover_path: Option<PathBuf>,
    /// Address the JSON-RPC server binds, and its port. `127.0.0.1` unless
    /// `--rpc-bind` says otherwise: the RPC authenticates nothing, so a
    /// routable bind is an explicit act plus a firewall. `None` port disables
    /// the server entirely.
    pub rpc_bind: String,
    pub rpc_port: Option<u16>,
    /// Address the metrics/health server binds (audit C-R6-2). Same loopback
    /// default and same reasoning as `rpc_bind`; read-only either way.
    pub metrics_bind: String,
    /// Port for `GET /health` + `GET /metrics`. `None` (the default — the
    /// flag is opt-in) starts no listener at all.
    pub metrics_port: Option<u16>,
}

fn now_ms() -> u64 {
    // A host clock before the Unix epoch is a misconfigured machine, not a
    // time. It reads as 0 ms — before any genesis, so every duty and the
    // slot loop simply wait for the clock — where it used to abort the node.
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_or(0, |d| d.as_millis() as u64)
}

const NO_TXS: [PosTransaction; 0] = [];

/// Ceiling on mempool entries. Past this, [`Engine::on_transaction`] evicts
/// the lowest [`tx_tip_rate`] entry rather than refusing outright — see
/// [`MEMPOOL_MAX_PER_SOURCE`] and R7 M6's fixes generally.
const MEMPOOL_MAX: usize = 4_096;

/// Mempool entries one SOURCE (by [`tx_source_hash`] — the first input's
/// spend-authority hash) may occupy at once (R7 M6).
///
/// Without this, one script could fill the ENTIRE mempool: `admissible`
/// checks a spend signature, not that the outpoints it names are distinct
/// from another pending transaction's, so nothing before this stopped one
/// signer from submitting [`MEMPOOL_MAX`] transactions and starving every
/// other sender out of [`Engine::select_transactions`]'s budget regardless
/// of fee rate — the fee-rate fix alone does not help a sender who is
/// willing to pay top rate on every one of its own flood, since the mempool
/// would then be full of ONE source's transactions, all paying well, all
/// ahead of everyone else's.
///
/// 64 is generous headroom over an ordinary wallet's legitimate queue (a
/// consolidation sweep aside — see the founder's own hundred-thousand-output
/// sweep noted elsewhere in this file, which pushes transactions in one at a
/// time as parents confirm, not all at once) while still bounding one
/// source's worst case to 64 / 4,096 ≈ 1.6% of total mempool capacity.
const MEMPOOL_MAX_PER_SOURCE: usize = 64;

/// Doppelgänger protection window (R6 HIGH-8, node half): slots this node
/// observes the network for its OWN validator index attesting or proposing
/// before it will start duties itself.
///
/// **Two epochs**, matching the convention other proof-of-stake clients
/// (e.g. Lighthouse's default doppelganger-protection window) settled on for
/// the same reason: one epoch guarantees this validator would have had
/// exactly one attestation duty if it were live elsewhere — no margin at
/// all against ordinary startup jitter (this node's own boot racing the
/// other instance's shutdown, or simply this being a restart landing
/// mid-epoch). Two epochs guarantees a FULL epoch of margin after the first
/// possible sighting, at the direct cost of this validator missing up to two
/// epochs of its own duties on every boot — the finding's tradeoff, stated
/// plainly: false negatives (a live duplicate that goes undetected) cost
/// this fleet a slashing; false positives (an honest restart delayed by two
/// epochs) cost it nothing but freshness.
///
/// 48/64 fleet validators have ALREADY double-signed historically (HIGH-8's
/// own finding) — this exists because "restart the validator" and "a second
/// copy of the key is still running" were, on this fleet, indistinguishable
/// from outside until now.
const DOPPELGANGER_OBSERVE_SLOTS: u64 = 2 * SLOTS_PER_EPOCH;

/// How long a transaction may sit in the mempool without ever being included
/// before the node drops it, measured in slots of head progress.
///
/// **The defect this closes.** Admission and retention were the same decision:
/// a transaction that passed `admissible` stayed until it was included,
/// explicitly refused by a proposal, or caught by `sweep_mempool`'s
/// spent-input scan. A transaction that is none of those — a stale fee, a
/// sub-dust output, an input a branch this node does not hold has spent —
/// is skipped by the producer block after block and never leaves. Measured on
/// the live chain on 2026-09-05: one transaction held for over 200 blocks
/// while the chain itself was healthy.
///
/// **This is node-local retention policy, not consensus.** No flag day, no
/// activation height, nothing armed. Two nodes running different TTLs cannot
/// fork: the mempool is not a consensus input, and a transaction dropped here
/// is one this node stops offering — the mesh still carries it, and a peer
/// that still holds it can still have it included. The only thing a TTL
/// changes is how long THIS node pays to remember something it has never been
/// able to use.
///
/// 100 slots is ~50 min at the §5.1 cadence: long enough to outlast a chained
/// spend waiting on its parent (which `REJECTION_TTL_SLOTS`, four epochs,
/// already budgets for) and short enough that a wedged entry does not outlive
/// an operator's attention. Deliberately longer than `REJECTION_TTL_SLOTS`,
/// so a transaction the proposer refused gets its ban lifted and a real
/// second chance BEFORE this drops it.
const MEMPOOL_TTL_SLOTS: u64 = 100;

/// How long a transaction the proposer's drop loop refused stays barred from
/// re-admission, in slots. 128 slots is four epochs (~64 min at 30 s slots).
///
/// **Why a ban expires instead of being permanent.** The refusal that sends a
/// transaction here is the transition's, and not every one of those is a
/// property of the transaction alone. `UnknownInput` in particular is a
/// statement about the state at ONE moment: a transfer that spends the output
/// of another transfer still in the mempool is refused today and applies
/// perfectly once its parent lands. Barring it forever would turn a chained
/// spend — a legitimate thing a wallet does — into a coin that can never be
/// moved, and the node would give no sign. A ban that lapses costs such a
/// transaction a delay; a ban that does not costs it everything.
///
/// Four epochs is chosen against what the ban has to outlive: the gossip that
/// keeps re-offering the transaction. It must be long enough that the mesh
/// stops handing it back before the door reopens, and short enough that a
/// wrongly-barred chained spend is not stuck past a user's patience.
const REJECTION_TTL_SLOTS: u64 = 128;

/// Cap on the rejection cache, so remembering refusals cannot itself become
/// the memory exhaustion it prevents. Same order as [`MEMPOOL_MAX`], because
/// the cache can hold at most what passed through the mempool.
///
/// At the cap the entry expiring SOONEST is evicted first: it is the one whose
/// door was about to reopen anyway, so the eviction costs the least protection.
const REJECTION_MAX: usize = 4_096;

/// Transactions a proposal will carry at most, independent of the consensus
/// byte cap it is also checked against.
const MAX_TXS_PER_BLOCK: usize = 256;

/// How far past THIS NODE'S wall-clock slot a gossiped block's `header.slot`
/// may sit before `ingest` refuses it without storing it.
///
/// **This is a local admission rule, not a consensus rule.** It needs no flag
/// day and two nodes disagreeing about it cannot fork: a block refused here is
/// simply not stored by this node, and if it was honest it arrives again from
/// the mesh once the clock catches up — the same shape as the mempool's
/// `admissible` door, and deliberately NOT the shape of a validity rule.
///
/// What it closes is a liveness hole with no lower bound on cost to the
/// attacker: `header.slot` is an untrusted `u64` off the wire, and everything
/// downstream that walks slots or epochs from it is linear in its magnitude.
/// `compute_post_state` rolls `while st.epoch < block_epoch { st.close_epoch()
/// }`, and `close_epoch` clones the whole eUTXO set once per turn, so a single
/// gossiped header naming `u64::MAX` asks every node on the network for
/// ~5.7e17 ledger clones. One free packet, one frozen fleet. The header is
/// signed by nobody the node has checked yet at this point in `ingest`, so
/// there is not even a stake to burn.
///
/// Sixty-four slots — two epochs, ~32 minutes at the manifest's 30s cadence —
/// is chosen against the honest reason a block can legitimately look like it
/// is from the future: THIS node's clock is behind. That is a skew budget, and
/// 32 minutes is far past any NTP-disciplined host's error while still turning
/// an unbounded walk into a bounded one. It costs nothing on the sync path,
/// where every block fetched is in the PAST relative to a correct clock.
///
/// The bound this leaves is the honest one: an attacker can still name a slot
/// up to 64 ahead of wall clock, so the walk is at most two `close_epoch`
/// turns. That is the point — bounded, not zero.
const MAX_FUTURE_SLOTS: u64 = 2 * bloch_pos_committee::params::SLOTS_PER_EPOCH;

/// How many recently-applied canonical post-states are retained so a reorg
/// can start from the fork point instead of from genesis.
///
/// **This is a memory budget, and on this fleet memory is the binding
/// constraint** — the boxes are already one-validator-per-host because they
/// run out of RAM. A `CommittedState` is dominated by its eUTXO set (the
/// Genesis-3 carryover is ~452k outputs) and two states share nothing
/// structurally: MEASURED at 128 MB resident each, `--release`, on a
/// Genesis-3-sized set. That is why this is two and not thirty-two.
///
/// Two costs ONE extra copy, not two. The newest entry is the live state
/// itself — `apply_canonical` files the very `Arc` it just installed, so that
/// slot is shared and free — and the one behind it is the single real copy.
/// A depth-1 reorg needs the head's PARENT, so one retained ancestor is the
/// smallest window that buys anything at all, and this is it.
///
/// Two is chosen against the reorgs that happen — depth 1, occasionally 2 —
/// and NOT as a guess at the worst case. Everything deeper falls back to the
/// replay from genesis this node has always done, which is what makes a small
/// window safe rather than merely cheap: the window is an optimisation with a
/// correct slow path underneath it, never a limit on what can be reorganised.
const REORG_STATE_WINDOW: usize = 2;

/// Ceiling on blocks parked waiting for a parent this node has never seen.
///
/// **The bound is the whole point.** Before this existed, `ingest` stored
/// every structurally-valid envelope in `blocks` — no proposer signature, no
/// slot bound, no requirement that the parent be known — and fork choice was
/// rebuilt over the result on every single one. One unauthenticated peer
/// could therefore grow this node's memory without limit AND make every
/// subsequent ingest more expensive, because `advance`'s loop and
/// `path_to_canonical`'s cycle guard are both bounded by `blocks.len()`.
///
/// 256 is chosen against what a legitimate orphan burst looks like: a node a
/// few slots behind receives the tip before the blocks under it, so the depth
/// that has to be held is the sync gap, not the chain. Anything deeper is
/// recovered by the `get_blocks` request the parking sets `needs_sync` for —
/// which is why evicting here costs a round trip and never a fork.
const ORPHAN_MAX: usize = 256;

/// Cap on [`Engine::parked_refused_finality`] (R3 M-1). Same order as
/// [`ORPHAN_MAX`] and the same FIFO-eviction shape, for the same reason:
/// remembering a refusal must cost this node a bounded amount of memory, not
/// one entry per byte a peer chooses to keep re-sending. 512 rather than 256
/// because a refused BRANCH can be several blocks deep, where an orphan is
/// always exactly one.
const MAX_PARKED_REFUSED_FINALITY: usize = 512;

/// Cap on [`Engine::tx_slot_index`] (R4 F-11, `gettxstatus`). A public chain
/// accumulates transactions without bound over its lifetime; remembering
/// where every one landed, forever, would be an unbounded index by another
/// name. Same order of magnitude as [`MEMPOOL_MAX`], for the same reason —
/// this is the same "have we ever heard of this transaction" question,
/// asked about the canonical chain instead of about pending admission. A
/// `gettxstatus` query for a transaction old enough to have aged out reports
/// `unknown` rather than a fabricated answer — see `Engine::serve_rpc`'s
/// `TxStatus` arm.
const MAX_TX_SLOT_INDEX: usize = 65_536;

/// How far past this node's wall-clock slot a *gossiped* block's slot may sit
/// and still be stored.
///
/// Without it, `blocks` is keyed by a hash the sender chooses and bounded by
/// nothing: one peer signing headers at slot `u64::MAX - k` fills the map with
/// entries that no `advance` will ever consume. With it, a sender can only
/// occupy slots the clock will actually reach.
///
/// It is NOT a consensus rule and is deliberately not applied to boot replay:
/// the log is this node's own history, its slots are by construction in the
/// past, and making replay depend on the wall clock is how a node with a
/// skewed clock refuses to restart. That exemption is carried by
/// [`Source::Replay`] — NOT by `live == false`, which is a separate rule
/// about gossip arriving while this node is still catching up. Tolerance is generous
/// because the cost of being wrong is asymmetric — a dropped block is
/// re-requested by the sync path, and 8 slots is four minutes at the fleet's
/// 30 s cadence, far more skew than NTP ever leaves.
const FUTURE_SLOT_TOLERANCE: u64 = 8;

/// Where an envelope reached `ingest` from. The ONLY thing that reads it is
/// the slot bound, and it exists because that bound is a statement about
/// what a PEER may make this node store, not about what this node may build
/// or what it is reading back out of its own log.
///
/// A producer chose the slot it is proposing for; re-judging its own block
/// against the clock is how a node refuses to produce when the box is loaded
/// enough that the two disagree by a few slots. A block coming off this
/// node's own log was already judged when it first arrived, and the log is
/// the record of what this node COMMITTED to — re-judging it against a clock
/// the log knows nothing about is how a node refuses to restart. Every other
/// gate applies identically to all three: a locally built or replayed block
/// still has to authenticate and still has to connect.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum Source {
    /// Arrived over the network, or was promoted out of the orphan pool
    /// after arriving over the network.
    Gossip,
    /// Built by this node's own `propose`.
    Local,
    /// Read back out of this node's own block log by the boot replay loop.
    ///
    /// Replay is not a second opinion about whether these blocks are
    /// admissible — they were judged when they first arrived, and the log is
    /// what this node already committed to. It is the same transition run
    /// over the same inputs to get back to the same state.
    Replay,
}

impl Source {
    /// Whether an envelope from this source is bounded by this node's WALL
    /// CLOCK (`MAX_FUTURE_SLOTS`, `FUTURE_SLOT_TOLERANCE`).
    ///
    /// Only gossip is. Both clock rules exist to bound what an UNTRUSTED
    /// `slot` off the wire can make this node walk or store; neither the
    /// producer's own proposal nor a block read back out of its own log is
    /// untrusted, and neither has any business depending on the wall clock.
    ///
    /// This is written as an allow-list — one source is bounded, everything
    /// else is not — so that adding a source cannot silently subject it to a
    /// clock rule it was never meant to answer to.
    fn bounded_by_wall_clock(self) -> bool {
        match self {
            Source::Gossip => true,
            Source::Local | Source::Replay => false,
        }
    }
}

/// Decode a block body's transactions.
///
/// A receiver MUST recompute the post-state from the same transactions the
/// proposer committed to. Passing an empty slice here — which is what this
/// node did until now — means every block carrying transactions either
/// diverges or, since the body_root check landed, is rejected outright.
fn body_transactions(env: &BlockEnvelope) -> Result<Vec<PosTransaction>, String> {
    env.body
        .transactions
        .iter()
        .map(|bytes| {
            PosTransaction::from_canonical_bytes(bytes)
                .map_err(|e| format!("undecodable transaction in block body: {e}"))
        })
        .collect()
}

/// This transaction's fee rate, in millisatoshi per gas, for mempool
/// ordering and eviction (R7 M6).
///
/// `tip_millisat_per_gas` is ALREADY a per-gas price — comparing it directly
/// across transactions of different sizes is valid without computing gas at
/// all, the same way comparing two quoted unit prices needs no further
/// division. Staking messages (`Deposit`/`Delegate`/`Exit`/…) carry no such
/// field and report `0`: R7 M1 (a separate, open finding) already names
/// "staking txs pay zero gas", so treating them as lowest-priority here is
/// consistent with the chain's own current pricing, not a new judgement this
/// fix invents.
fn tx_tip_rate(tx: &PosTransaction) -> u128 {
    match tx {
        PosTransaction::Transfer { tip_millisat_per_gas, .. }
        | PosTransaction::TransferV2 { tip_millisat_per_gas, .. } => *tip_millisat_per_gas,
        PosTransaction::FundedDeposit(tx) => tx.tip_millisat_per_gas,
        _ => 0,
    }
}

/// The spend-authority hash of this transaction's FIRST input — its "source"
/// for [`MEMPOOL_MAX_PER_SOURCE`] (R7 M6). `None` for a transaction with no
/// eUTXO inputs (every non-transfer message, and a structurally-empty
/// transfer `admissible` would refuse anyway), which exempts it from the
/// per-source cap entirely rather than grouping every such message under one
/// shared bucket — a bucket that shape would make USELESS as a spam bound
/// the moment two unrelated staking messages arrived close together.
///
/// Hashed exactly like every other script-hash site in this codebase
/// (`Sha3_256::digest(pubkey)`) — see `rpc.rs`'s `validator_json` and this
/// file's own `sweep_fixture_declaring` for the same convention.
fn tx_source_hash(tx: &PosTransaction) -> Option<[u8; 32]> {
    match tx {
        PosTransaction::Transfer { inputs, .. } => {
            let pk = &inputs.first()?.pubkey;
            Some(Sha3_256::digest(pk).into())
        }
        PosTransaction::TransferV2 { keys, inputs, .. } => {
            let key_index = inputs.first()?.key_index as usize;
            let pk = &keys.get(key_index)?.pubkey;
            Some(Sha3_256::digest(pk).into())
        }
        PosTransaction::FundedDeposit(tx) => Some(Sha3_256::digest(&tx.funding_pubkey).into()),
        _ => None,
    }
}

/// The canonical committed state, plus the memo of epoch-rolled copies of it.
///
/// # Why this is a type and not two fields on `Engine`
///
/// The memo is a cache in front of a consensus derivation, which is the class
/// of thing that split this network before: `expected_bits` was node-local
/// state that two honest binaries could disagree about. A rolled state judges
/// attestations against a committee; hand back one rolled from a state that
/// has since moved and the node accepts votes from the wrong committee while
/// its peers reject them. So the invalidation must not be something a future
/// caller can forget.
///
/// It cannot be forgotten here, because `state` is private to this module and
/// the only ways to write it are `StateCell::set` and `StateCell::set_arc` —
/// **two** writers, not one: `set_arc` is how `do_reorg` installs the post-state
/// it already holds behind an `Arc`. Both do identical bookkeeping: replace the
/// state, bump the generation, empty the memo. What the argument needs is not
/// one writer but no writer that does less than these two — the property point
/// 2 below states, and the one to re-check if a third is ever added. Reads go
/// through `Deref`, so every existing `self.state.foo()` still reads the live
/// state and nothing else.
///
/// # The memo key, and why it is complete
///
/// The key is `(generation, epoch)`, and that is exactly the set of inputs:
///
/// 1. `rolled_to(epoch)` is a pure function of `(state, epoch)`. Its whole
///    body is "clone the state, then apply `process_epoch` until the open
///    epoch reaches `epoch`". `Transition::process_epoch` is
///    `Ok(pre.close_epoch())` — it does not touch the injected verifier, reads
///    no clock, opens no file, and `CommittedState` is a plain value with no
///    interior mutability (its own type doc says so). Same state, same epoch,
///    same bytes out, always.
/// 2. `generation` identifies the state value. It starts at zero and is
///    incremented by every writer of `state` — `set` and `set_arc`, and the
///    module has no third — so two different states never share a generation
///    within a process. What the argument needs is not "one writer" but "no
///    writer that skips the bump", which is a property of the two that exist
///    and must be re-checked if a third is ever added.
/// 3. Nothing else is read. Not the chain, not the block store, not the pool,
///    not the wall clock — the function's signature is the proof, since it
///    takes only the epoch and the rolling closure.
///
/// So `(generation, epoch)` determines the result, which is what "sound key"
/// means. The writers clearing the memo is belt AND braces: even the entry
/// that could not be returned is not left lying around.
///
/// This is deliberately NOT the fork-choice store's posture (rebuilt every
/// call, module docs above). The difference is that a fork-choice store
/// accumulates across messages and can therefore *drift*; a rolled state is a
/// deterministic function of one value this type owns and can watch change.
mod state_cell {
    use std::cell::RefCell;
    use std::ops::Deref;
    use std::sync::{Arc, Mutex};

    use bloch_pos_committee::epoch_of;
    use bloch_pos_committee::interfaces::StateReader;
    use bloch_pos_committee::transition::CommittedState;

    /// Rolled epochs retained. `on_attestation` refuses anything outside
    /// `{wall_epoch, wall_epoch + 1}`, and the head is normally in one of
    /// them, so the live working set is one or two entries; four is slack for
    /// a node whose head lags its wall clock. The memo is dropped whole on
    /// every applied block anyway, so this bounds a burst, not a lifetime.
    ///
    /// **It is also a memory budget, and it used to be the larger of the two
    /// this module spends.** Each entry is a whole `CommittedState` — but
    /// since 2026-08-31 a rolled state *shares its eUTXO map* with the state
    /// it was rolled from (`close_epoch` never writes to the ledger, so the
    /// `Arc` in `EutxoSet` is never unshared on this path), and the eUTXO map
    /// was almost all of the 60 MB the measurement below records. A memo
    /// entry now costs the per-epoch fields — registry, participation,
    /// finality view — not the ledger. The figures below predate the sharing
    /// and are kept as the record of what an *unshared* state costs, which is
    /// still what [`REORG_STATE_WINDOW`] holds when blocks move the ledger.
    ///
    /// MEASURED on this tree by `bench::bench_state_footprint` (`--release`,
    /// Genesis-3-sized eUTXO set, RSS delta over four clones, PRE-sharing):
    /// **60 MB per state**, so a full memo was ~240 MB and the two features
    /// together peaked around 300 MB per validator above the pre-change
    /// baseline.
    ///
    /// That 60 MB does NOT match the 128 MB in [`REORG_STATE_WINDOW`]'s doc.
    /// Both are real measurements of the same quantity on different hosts
    /// (this one is macOS/arm64); RSS for a heap this shape is an allocator
    /// artifact as much as a data size. Neither number has been taken on an
    /// Edgevana box, and on a fleet running EIGHT validators per host the
    /// per-host multiple is what matters, so **measure there before trusting
    /// either figure for capacity planning.** Recorded rather than
    /// reconciled, because reconciling them here would mean picking one
    /// without evidence.
    const MEMO_CAP: usize = 4;

    struct Entry {
        generation: u64,
        epoch: u64,
        rolled: Arc<CommittedState>,
    }

    /// The committed head, published for threads that are not the consensus
    /// thread. See [`StateCell::published_head`].
    pub type SharedHead = Arc<Mutex<Arc<CommittedState>>>;

    pub(super) struct StateCell {
        state: Arc<CommittedState>,
        /// The same `Arc` as `state`, in a handle the RPC threads can hold.
        ///
        /// **This is not a second source of truth.** It is not a
        /// state-*shaped* copy maintained alongside the real one — the failure
        /// `EngineBackend`'s doc warns about — it is the identical
        /// `Arc<CommittedState>` value, replaced whole by the same two writers
        /// that replace `state` and by nothing else. A reader either sees the
        /// state before a block or the state after it; there is no
        /// intermediate value to observe, because a `CommittedState` is
        /// immutable once published and the transition builds the next one
        /// beside it rather than editing it.
        ///
        /// The mutex is held for exactly one `Arc::clone` on each side, so a
        /// reader running a long query is not holding anything the consensus
        /// thread needs — which is the whole point: before this, a
        /// `getbalance` over the founder's outputs occupied the slot loop for
        /// its full duration.
        published: SharedHead,
        /// Bumped by every writer of `state`. There are exactly two — `set`
        /// and `set_arc` — and they do identical bookkeeping: replace the
        /// state, bump this, empty the memo. Two entry points because the
        /// reorg path already holds its post-state behind an `Arc` (the
        /// snapshot ring keeps one) and should not pay a copy to install it.
        /// The memo key's soundness rests on there being NO writer that does
        /// less than these two, not on there being only one.
        generation: u64,
        memo: RefCell<Vec<Entry>>,
    }

    impl StateCell {
        pub(super) fn new(state: CommittedState) -> Self {
            let state = Arc::new(state);
            StateCell {
                published: Arc::new(Mutex::new(Arc::clone(&state))),
                state,
                generation: 0,
                memo: RefCell::new(Vec::new()),
            }
        }

        /// Publish the current state to the read handle. Called by both
        /// writers and by nothing else, so the handle cannot lag the cell by
        /// more than the instant between the two assignments — during which
        /// it holds the previous *committed* state, never a partial one.
        fn publish(&self) {
            let mut slot = match self.published.lock() {
                Ok(g) => g,
                // A reader panicking mid-clone cannot have left the value
                // torn, so the state behind the poison is still the state.
                Err(p) => p.into_inner(),
            };
            *slot = Arc::clone(&self.state);
        }

        /// A handle on the committed head for threads that must not touch the
        /// cell — today, the JSON-RPC server's connection threads.
        pub(super) fn published_head(&self) -> SharedHead {
            Arc::clone(&self.published)
        }

        /// Replace the canonical state. One of the two writers — `set_arc` is
        /// the other — and it is why the memo key is sound: it moves the
        /// generation and drops the memo in the same breath, so no caller can
        /// advance the state and leave a rolled copy of the old one reachable.
        pub(super) fn set(&mut self, state: CommittedState) {
            self.state = Arc::new(state);
            self.generation = self.generation.wrapping_add(1);
            self.memo.get_mut().clear();
            self.publish();
        }

        /// Same, for a state that is already shared — the reorg path builds
        /// its post-states behind `Arc` so the snapshot ring can keep one
        /// without a copy. Identical bookkeeping: generation moves, memo
        /// empties. There is no writer that does less.
        pub(super) fn set_arc(&mut self, state: Arc<CommittedState>) {
            self.state = state;
            self.generation = self.generation.wrapping_add(1);
            self.memo.get_mut().clear();
            self.publish();
        }

        /// The live state as a shared handle, for the one caller that must
        /// keep it alive alongside the cell (the reorg snapshot ring).
        /// Ordinary reads go through `Deref` and stay borrows.
        pub(super) fn arc(&self) -> Arc<CommittedState> {
            Arc::clone(&self.state)
        }

        /// Which state this is. Test surface — the memo key's identity half,
        /// exposed so a test can pin that it moves when the state does.
        #[cfg(test)]
        pub(super) fn generation(&self) -> u64 {
            self.generation
        }

        /// How many rolled states the memo holds right now. Test surface —
        /// so a test can pin that a roll of many epochs leaves (and, with the
        /// in-loop eviction, passes through) no more than `MEMO_CAP` entries.
        #[cfg(test)]
        pub(super) fn memo_len(&self) -> usize {
            self.memo.borrow().len()
        }

        /// The eviction bound, for the same test.
        #[cfg(test)]
        pub(super) fn memo_cap() -> usize {
            MEMO_CAP
        }

        /// Plant an entry in the memo by hand. TEST ONLY, and only so a test
        /// can prove the generation half of the key is load-bearing: an entry
        /// planted under a stale generation must never be returned, and the
        /// same entry planted under the live one must be, or the test that
        /// asserts the first is passing vacuously.
        #[cfg(test)]
        pub(super) fn plant(&self, generation: u64, epoch: u64, rolled: CommittedState) {
            self.memo.borrow_mut().push(Entry {
                generation,
                epoch,
                rolled: Arc::new(rolled),
            });
        }

        /// The canonical state with epoch accounting rolled forward to
        /// `epoch`, memoized on `(generation, epoch)`.
        ///
        /// `roll` is `process_epoch`, passed in rather than reached for, so
        /// this module cannot read anything but the state it owns — the
        /// signature IS the argument that the key is complete.
        ///
        /// Returns `Arc` rather than a clone because the callers only read
        /// (duty roster, seed, finality view). On a Genesis-3-sized state the
        /// clone alone was tens of milliseconds, per attestation.
        pub(super) fn rolled_to<F>(&self, epoch: u64, roll: F) -> Arc<CommittedState>
        where
            F: Fn(&CommittedState) -> CommittedState,
        {
            // The canonical state's open epoch is its head's epoch — only
            // `apply_block` advances it, and it rolls exactly there. Asking
            // for that epoch or an earlier one is the identity, which is what
            // the uncached loop did too (its `while cur < epoch` never ran).
            let base_epoch = epoch_of(self.state.slot());
            if epoch <= base_epoch {
                return Arc::clone(&self.state);
            }

            let mut memo = self.memo.borrow_mut();
            if let Some(hit) = memo
                .iter()
                .find(|e| e.generation == self.generation && e.epoch == epoch)
            {
                return Arc::clone(&hit.rolled);
            }

            // Roll from the furthest already-rolled epoch below the target
            // instead of from the state — sound because that is precisely
            // what the loop would have produced on the way there:
            // `rolled(n + 1) == process_epoch(rolled(n))` by construction.
            let mut cur_epoch = base_epoch;
            let mut cur = Arc::clone(&self.state);
            if let Some(best) = memo
                .iter()
                .filter(|e| {
                    e.generation == self.generation && e.epoch > cur_epoch && e.epoch < epoch
                })
                .max_by_key(|e| e.epoch)
            {
                cur_epoch = best.epoch;
                cur = Arc::clone(&best.rolled);
            }
            while cur_epoch < epoch {
                cur = Arc::new(roll(&cur));
                // cannot overflow: cur_epoch < epoch <= u64::MAX.
                #[allow(clippy::arithmetic_side_effects)]
                {
                    cur_epoch += 1;
                }
                memo.push(Entry {
                    generation: self.generation,
                    epoch: cur_epoch,
                    rolled: Arc::clone(&cur),
                });
                // Evict the lowest epochs first: they are the cheapest to
                // rebuild (fewest rolls from the base) and the least likely
                // to be asked for again, since the traffic walks forward.
                //
                // INSIDE the loop, not after it (2026-08-31): evicting after
                // meant a roll of N epochs transiently held N entries, and on
                // a node N epochs behind the wall clock — the one node that
                // rolls far — that was N full states at once. The rolled
                // states now share the eUTXO map, so an entry is small; this
                // keeps the memo's population bounded by MEMO_CAP at every
                // point of the roll rather than only between calls, so the
                // bound does not depend on the sharing to hold.
                while memo.len() > MEMO_CAP {
                    memo.remove(0);
                }
            }
            cur
        }
    }

    impl Deref for StateCell {
        type Target = CommittedState;

        fn deref(&self) -> &CommittedState {
            &self.state
        }
    }
}

use state_cell::StateCell;
pub use state_cell::SharedHead;

/// The end-to-end replay benchmark (`src/engine/replay_bench.rs`).
///
/// A CHILD module of `engine`, and that is the whole reason it can exist:
/// `Engine` and its fields are private to this module, so a benchmark in
/// `tests/` could not drive `ingest`/`advance`/`apply_canonical` at all and
/// would have had to reimplement them — measuring the reimplementation. A
/// child module sees its ancestors' private items, so nothing here has to be
/// widened for it. `cfg(test)`: not in the binary, asserts no consensus
/// property, changes no behaviour.
#[cfg(test)]
mod replay_bench;

struct Engine {
    manifest: Manifest,
    /// Validator indices below this were registered AT GENESIS and are
    /// therefore identical on every branch of every fork; indices at or above
    /// it were (or would be) added by an on-chain `Deposit`, whose
    /// index-to-key mapping is a property of ONE branch. `ingest_judged` uses
    /// the line to decide whether a signature failure against this node's
    /// head registry is a provable forgery (`Reject`) or merely a key this
    /// node may not hold (`Ignore`, parked) — external audit 2026-09-07, O04.
    genesis_validator_count: u32,
    state: StateCell,
    tr: Transition<HybridVerifier>,
    tr_probe: Transition<ProbeVerifier>,
    verifier: HybridVerifier,
    /// The validator this node signs as, or `None` in observer mode.
    ///
    /// An observer follows the chain, applies every block and serves the RPC,
    /// and signs nothing. It exists so the public endpoint does not have to be
    /// a validator: restarting whatever serves the RPC takes minutes — the
    /// node reingests the carryover, pays the cold state-root cost and replays
    /// the chain — and during that window the endpoint is simply down.
    ///
    /// The alternative, pointing the endpoint at a spare copy of a validator's
    /// keystore, is how you equivocate and get slashed. There is no safe
    /// version of that, so there is this.
    keys: Option<Keystore>,
    /// Every block this node has *authenticated and connected*, canonical or
    /// not, by id.
    ///
    /// Three admission rules stand in front of this map, and each closes a
    /// distinct way an unauthenticated peer could grow it (H8):
    ///
    /// 1. **The proposer is authenticated before insertion.** The same call
    ///    the transition makes at its step 7 — `verify_with_key` over
    ///    `proposal_signing_root` — so writing to this map costs a hybrid
    ///    signature only a key-holding validator can pay. A signature that
    ///    fails under a key this node has registered is refused outright; an
    ///    index this node has never registered is parked, not judged, because
    ///    the transition resolves that key from the block's pre-state and
    ///    this gate must never be the thing that forks.
    /// 2. **The parent must already be here or canonical.** A block that
    ///    connects to nothing goes to [`Engine::orphans`], which is bounded;
    ///    it is promoted the moment its parent lands.
    /// 3. **Non-canonical entries below the finalized checkpoint are
    ///    pruned.** Finality is what makes that safe: fork choice descends
    ///    from the justified root, so nothing under the finalized epoch can
    ///    ever be selected or be on the path to something that is.
    ///
    /// Canonical blocks are NOT pruned — `do_reorg` rewrites the block log
    /// from them — so this still grows with the chain. That is the chain's
    /// own size, not an attacker's budget, and it is the honest remaining
    /// limitation.
    blocks: BTreeMap<[u8; 32], BlockEnvelope>,
    observed_proposals: BTreeMap<(u64, u32), ProposalEnvelope>,
    /// Canonical chain, ascending slot, genesis first.
    chain: Vec<(u64, BlockId)>,
    /// Canonical ids (incl. genesis).
    canonical: BTreeSet<[u8; 32]>,
    /// Post-states of the most recently applied canonical blocks, oldest
    /// first, keyed by block id — [`REORG_STATE_WINDOW`] of them.
    ///
    /// Keyed by block id and NOT by height, which is what makes it survive a
    /// reorg without an invalidation rule: a block's post-state is a pure
    /// function of the block and its ancestry, and the id commits to that
    /// ancestry transitively, so an entry can never be "the right height on
    /// the wrong branch". A block that leaves the canonical chain and later
    /// returns has the same post-state both times.
    recent_states: VecDeque<([u8; 32], Arc<CommittedState>)>,
    /// Attestations available to fork choice and to the next proposal, keyed
    /// by content so duplicates collapse. This is the *aggregation* store.
    pool: BTreeMap<(u32, [u8; 32]), Attestation>,
    /// The *admission* gate in front of `pool`:
    /// [`AttestationPool`](bloch_pos_committee::gossip::AttestationPool) from
    /// the pure crate — dedup, the equivocation cap, slashing-pair capture,
    /// and the pending queue for attestations whose block has not landed yet.
    ///
    /// The two are different objects on purpose. `att_pool` decides *whether a
    /// message may be believed and relayed* and answers in the three verbs
    /// gossipsub understands; `pool` holds the attestations that survived, in
    /// the shape fork choice and block production want. Before this was wired
    /// the node did its own ad-hoc dedup-and-verify inline, and the whole
    /// Hold verb — the one that keeps an attestation racing ahead of its block
    /// from being scored as an offence — did not exist here at all.
    att_pool: AttestationPool,
    /// Wall-clock slot, refreshed by the slot loop. `att_pool` never reads a
    /// clock (that is its determinism rule), so the node supplies one.
    wall_slot: u64,
    /// Transactions waiting for a block, keyed by canonical bytes so a
    /// duplicate gossip collapses instead of being included twice.
    ///
    /// **R7 M6 fixed all three gaps this used to describe.** It used to read:
    /// "no fee ordering, no per-sender limit, no eviction beyond
    /// `MEMPOOL_MAX`" — and the container's own natural order made the first
    /// gap actively harmful rather than merely absent: a `BTreeMap` keyed by
    /// canonical bytes, walked with `iter()`, made inclusion order
    /// **lexicographic over the encoded transaction** (A3 I3) — a sender who
    /// re-encoded until the bytes sorted low bought priority for nothing.
    ///
    /// Now: [`Engine::select_transactions`] orders by
    /// [`tx_tip_rate`] descending (breaking ties on canonical bytes, so the
    /// order stays deterministic without reintroducing a grindable primary
    /// key); [`Engine::on_transaction`] refuses a source past
    /// [`MEMPOOL_MAX_PER_SOURCE`] (by [`tx_source_hash`] — the first input's
    /// spend-authority hash); and at [`MEMPOOL_MAX`] capacity, an incoming
    /// transaction that outbids the pool's current lowest [`tx_tip_rate`]
    /// evicts it rather than being refused outright. This is still node-local
    /// devnet policy, not a consensus rule: two nodes with different mempool
    /// contents cannot fork, because a proposal is judged by the transition,
    /// never by what a node's own mempool happened to hold.
    ///
    /// Admission is not "the bytes decode" either. `on_transaction` calls
    /// `admissible`, which refuses deposits, delegations and exits, refuses a
    /// transfer with no inputs or no outputs, and verifies every spend
    /// signature.
    mempool: BTreeMap<Vec<u8>, PosTransaction>,
    /// Head slot at which each live mempool key was admitted, for
    /// [`MEMPOOL_TTL_SLOTS`].
    ///
    /// A parallel map rather than widening `mempool`'s value, because
    /// `mempool`'s value type is what the transition is handed and should not
    /// acquire a retention concern. (Its KEY order no longer decides
    /// selection either, since R7 M6 — `select_transactions` sorts by fee
    /// rate — so there are now two independent reasons not to fold this in.)
    /// The two maps are
    /// reconciled in `evict_stale_mempool`, which is the ONLY place either the
    /// TTL or the bookkeeping is enforced — so the other paths that drop a
    /// transaction (included, refused by the proposal, swept, RPC, and now —
    /// R7 M6 — evicted for a higher-fee arrival at capacity) must each remove
    /// their own entry here too, exactly as `evict_stale_mempool` would have,
    /// or this leaks one entry per drop.
    mempool_admitted_at: BTreeMap<Vec<u8>, u64>,
    /// Transactions dropped for age alone. Counted for `getmempoolinfo`,
    /// because "the mempool is smaller" and "the mempool is working" look
    /// identical from outside without it.
    mempool_expired: u64,
    /// Transactions evicted to make room for a higher-fee arrival at
    /// [`MEMPOOL_MAX`] capacity (R7 M6). Same reasoning as `mempool_expired`:
    /// a mempool under fee pressure and a mempool simply not receiving
    /// transactions both look like "it got smaller" without this.
    mempool_evicted_low_fee: u64,
    /// Transactions the proposer's drop loop refused, keyed exactly like
    /// [`Self::mempool`] and mapping to `(slot the bar lifts at, times it has
    /// barred a re-offer)`.
    ///
    /// The counter exists because the first version of this was UNMEASURABLE
    /// in production: the gossip path discards `on_transaction`'s result on
    /// purpose ("a peer is not waiting on a verdict"), so a bar left no trace
    /// anywhere — no line, no counter, no RPC — and "is the cache working?"
    /// could only be answered by inference from mempool sizes. In a repo whose
    /// rule is that a proof you cannot re-run is a claim, that was the wrong
    /// thing to ship.
    ///
    /// Without this, dropping a refused transaction from the mempool does not
    /// remove it from the NETWORK: the peers still holding it re-offer it, the
    /// thin structural admission check lets it back in, and the next proposal
    /// drops it again. Measured on the live chain 2026-08-30 — a node cleared
    /// its mempool to 0 while proposing at slot 47,878 and was holding 21 of
    /// the same transactions 383 slots later. The mempool self-cleans; the
    /// fleet-wide population does not converge. This is what makes the removal
    /// stick, and it is why the ban is checked BEFORE the re-broadcast: a node
    /// that knows better must stop amplifying.
    ///
    /// It is deliberately node-local and unsigned. Nothing here is gossiped —
    /// a refusal one node reached is not evidence another must accept, and a
    /// shared ban list is a censorship channel that needs a threat model this
    /// does not have. Each node learns from its own proposals, and convergence
    /// is the fleet arriving at the same answer separately.
    rejected: BTreeMap<Vec<u8>, (u64, u64)>,
    /// Total re-offers this node has barred since boot, across all keys.
    rejected_hits: u64,
    /// Transactions the epoch sweep found spending inputs this chain does not
    /// have — on ONE sweep. Eviction takes two.
    ///
    /// The second strike exists for the chained spend: a transfer paying from
    /// the output of another transfer still in the mempool points, at this
    /// instant, at an outpoint the eUTXO set does not have, and becomes
    /// perfectly valid the moment its parent lands. Evicting on the first
    /// sweep would kill a legitimate wallet pattern. Surviving one sweep and
    /// failing the next gives it between one and two epochs (16-32 min) for
    /// the parent to arrive — generous, because parents land in blocks, not
    /// in epochs. A transaction that becomes valid again leaves this set.
    mempool_suspect: BTreeSet<Vec<u8>>,
    /// Epoch of the last sweep, so it runs once per epoch and not once per
    /// block. Starts at `u64::MAX` so the first boundary a node crosses
    /// sweeps, whatever epoch it booted into.
    mempool_swept_epoch: u64,
    store: Store,
    /// Last-signed watermarks, on disk, consulted before EVERY signature this
    /// node makes.
    ///
    /// Present even in observer mode: an observer signs nothing, so the file
    /// simply never moves, and having the field unconditionally means there is
    /// no mode in which a signing path could compile without a guard in front
    /// of it. See [`crate::slashprot`] for the ordering rule.
    slashprot: SlashingProtection,
    net: net::Net,
    head_slot: Arc<AtomicU64>,
    /// False during boot replay: no log appends, no broadcasts, no logs.
    live: bool,
    needs_sync: bool,
    last_applied_ms: u64,
    booted_ms: u64,
    /// The weak-subjectivity anchor this node booted under (epoch, root), and
    /// whether it is the node's ONLY defense (it had no finality of its own).
    /// `None` until `ws_boot::boot` has run.
    ws_anchor: Option<(u64, [u8; 32])>,
    ws_anchor_hard: bool,
    /// A forward WS_CONFLICT is announced once, not every block.
    ws_conflict_reported: bool,
    /// Loose attestations dropped from `pool` because the block that carried
    /// them became canonical — a removal fork choice cannot see, since it also
    /// reads every stored block's body.
    ///
    /// Monotone, and it exists only so [`Engine::forkchoice_inputs`] can tell
    /// that kind of pool shrinkage apart from the epoch `retain`, which fork
    /// choice very much can see. See the argument there.
    fc_covered_removals: u64,
    /// The finality latch (finding F-03): the highest finalized checkpoint
    /// this node has EVER adopted, as `(canonical height, root)`. Ratcheted
    /// forward by [`Engine::ratchet_finalized`], never lowered, and consulted
    /// by [`Engine::cut_below_finalized_latch`] before any reorg.
    ///
    /// This is deliberately NOT `self.state.finality().finalized`: that value
    /// lives in replayed state, so a reorg REPLACES it — which is exactly how
    /// the measured finalized 6 -> 4 -> 2 -> 0 rewind happened. The latch is
    /// engine-owned and survives every state swap. In-memory only: on boot it
    /// is rebuilt by the replay of this node's own log, which re-finalizes
    /// the same checkpoints in the same order.
    finalized_latch: Option<(u64, [u8; 32])>,
    /// Reorgs refused because they would have cut canonical history below
    /// the latch. A rewind an operator cannot see is a rewind that gets
    /// diagnosed as "sync trouble"; this makes it a measurement. Exported at
    /// `/metrics` as `bloch_pos_finality_rewinds_refused_total` and in
    /// `getchaininfo` (finding R3 M-1 — previously neither).
    finality_rewinds_refused: u64,
    /// Blocks refused by the finality latch, PARKED rather than deleted (R3
    /// M-1).
    ///
    /// The pre-fix behaviour deleted a refused branch's blocks from
    /// `self.blocks` outright. If the block(s) ever arrived again — and
    /// nothing stops a peer relaying, or this node's own periodic sync
    /// request, from handing back exactly the branch this node just
    /// refused — deletion meant re-authenticating them from scratch and
    /// running the whole `advance` cycle again, only to refuse and delete
    /// them again: a silent, unbounded-in-time loop with no trace beyond the
    /// refusal counter. Parking them here means [`Engine::ingest_one`] can
    /// recognise a re-offer BEFORE any signature work and drop it at the
    /// door — the refusal becomes a fact this node remembers cheaply,
    /// instead of a verdict it re-derives expensively, forever.
    ///
    /// Bounded FIFO like [`Engine::orphans`] — see
    /// [`MAX_PARKED_REFUSED_FINALITY`] — for the identical reason: unbounded
    /// memory is not an acceptable price for remembering a refusal, and the
    /// oldest one is the least likely to still be re-offered.
    ///
    /// Removed from `self.blocks` regardless (not left there): leaving a
    /// refused branch in the fork-choice input map would make `advance`
    /// re-select and re-refuse it on every subsequent tick even with NO new
    /// bytes arriving, which is exactly the busy-loop deletion was trying to
    /// avoid — parking fixes the re-authentication cost without
    /// reintroducing that one.
    parked_refused_finality: VecDeque<([u8; 32], BlockEnvelope)>,
    /// Set once at boot from `BLOCH_ALLOW_FINALITY_REWIND=1` /
    /// `--allow-finality-rewind` (R3 M-1): an operator's explicit,
    /// deliberate acknowledgement that a rewind below this node's own
    /// finalized checkpoint is expected right now and should be allowed
    /// rather than refused. Every time it actually changes the outcome, this
    /// node logs loudly (`cut_below_finalized_latch`) — the override exists
    /// so a legitimate divergence is not indistinguishable from an attack
    /// from the outside, not so it can be left on quietly.
    finality_rewind_override: bool,
    /// Transaction id -> the slot it was included at, on the CURRENT
    /// canonical chain (R4 F-11 — `gettxstatus`). Maintained by
    /// [`Engine::note_tx_slots`] on every canonical apply (`apply_canonical`,
    /// and `do_reorg`'s winning branch) and cleaned up by
    /// [`Engine::forget_tx_slots_if_stale`] for a block that LEAVES
    /// canonical history in a reorg, so a stale slot from a losing branch is
    /// never reported as "included".
    ///
    /// This is not a transaction archive: it names a SLOT, and
    /// `Engine::serve_rpc`'s `TxStatus` arm still has to compare that slot's
    /// epoch against the justified/finalized checkpoints to answer
    /// `included` vs `justified` vs `finalized`. Bounded FIFO — see
    /// [`MAX_TX_SLOT_INDEX`] — the same shape as `Engine::orphans`.
    tx_slot_index: BTreeMap<[u8; 32], u64>,
    tx_slot_index_order: VecDeque<[u8; 32]>,
    /// Doppelgänger protection (R6 HIGH-8): `Some(deadline wall slot)` while
    /// this node is still observing for its own validator index before
    /// starting duties, set once at boot from `BLOCH_NO_DOPPELGANGER` /
    /// `--no-doppelganger-check`. `None` means "no protection is active" —
    /// either the bypass was set, this is an observer with no keystore (see
    /// [`Engine::run`]), or a test constructed this `Engine` directly, which
    /// must not gain a suppression window it never asked for.
    doppelganger_observe_until: Option<u64>,
    /// Set once, permanently, the instant this node's OWN validator index is
    /// seen attesting or proposing while `doppelganger_observe_until` says it
    /// should not yet be live anywhere. Never cleared without a restart: a
    /// live duplicate having been seen once is a fact about the key, not
    /// about the moment, and the window closing on its own must not un-halt
    /// duties this node has good reason to believe are unsafe.
    doppelganger_halted: bool,
    /// Blocks whose parent this node has never seen, oldest first, with their
    /// ids so a repeat gossip is recognised without re-hashing.
    ///
    /// Bounded by [`ORPHAN_MAX`] with FIFO eviction. FIFO and not
    /// lowest-slot-first on purpose: the oldest entry is the one whose parent
    /// has had the longest to arrive and has not, so it is the one least
    /// likely to ever connect.
    ///
    /// Parking sets `needs_sync`, so the gap the orphan is evidence of is
    /// asked for over the wire. That is what makes eviction cheap: the worst
    /// case is a round trip, never a missed branch.
    orphans: VecDeque<([u8; 32], BlockEnvelope)>,
    /// Orphans dropped at the cap, and orphans later connected. Counted so
    /// "the bound is holding" is a measurement rather than an inference — a
    /// pool with evictions and zero admissions is a node that is not syncing.
    orphans_evicted: u64,
    orphans_admitted: u64,
    /// Non-canonical blocks dropped because they sat below the finalized
    /// checkpoint. Same reason: pruning that never fires is pruning that is
    /// not wired.
    blocks_pruned: u64,
    /// Envelopes turned away at the door, by reason.
    rejected_unsigned: u64,
    rejected_future: u64,
}

/// A fingerprint of the four values `lmd_ghost_head` reads, so `advance` can
/// tell whether recomputing it could possibly return anything new.
///
/// Not a cache across calls — it is rebuilt from scratch inside each
/// `advance`, because the completeness argument on
/// [`Engine::forkchoice_inputs`] only holds for the duration of one.
#[derive(PartialEq, Eq)]
struct ForkChoiceInputs {
    blocks: usize,
    pool: u64,
    justified: [u8; 32],
    validators: Vec<bloch_pos_committee::sample::Validator>,
}

/// Why a transaction was turned away at the door.
///
/// The distinction is load-bearing, not cosmetic: three of these mean "ask me
/// again in a moment" and one means "these bytes will never be admitted,
/// stop sending them". Collapsing them into one RPC code is how an operator
/// ends up growing the mempool to fix a bad signature — or, the way it
/// actually happened, how an exchange told "never resubmit after -32008"
/// writes off transactions that a self-lifting bar would have admitted an
/// hour later.
///
/// The RPC boundary now preserves the variant rather than only its sentence:
/// `AtCapacity` -> `MEMPOOL_FULL`, `PreviouslyRefused` ->
/// `TX_REFUSED_RETRYABLE` (with `error.data.until_slot`), `Invalid` ->
/// `TX_REFUSED`, `TooManyFromSource` -> `TX_REFUSED_SOURCE_CAP`. See
/// `Engine::serve_rpc`.
#[derive(Debug, PartialEq, Eq)]
enum Refusal {
    /// The mempool is full, and the incoming transaction's [`tx_tip_rate`]
    /// did not outbid the pool's current lowest (R7 M6) — otherwise it would
    /// have been admitted by evicting that entry instead of refusing. The
    /// transaction was NOT judged invalid.
    AtCapacity,
    /// `admissible` refused it on its merits. Retrying is pointless.
    Invalid(&'static str),
    /// This node's own proposer already tried to build a block with it and the
    /// transition refused. Distinct from `Invalid`, and the difference is not
    /// cosmetic: `Invalid` is a verdict on the bytes, which no passage of time
    /// changes, while this is a verdict on the bytes AGAINST A STATE — it can
    /// stop being true, so the bar lifts on its own after
    /// [`REJECTION_TTL_SLOTS`]. Carries the slot it lifts at, so a caller with
    /// someone to answer to can say when to try again.
    PreviouslyRefused { until_slot: u64 },
    /// This source (by [`tx_source_hash`]) already has
    /// [`MEMPOOL_MAX_PER_SOURCE`] transactions pending (R7 M6). Distinct from
    /// `AtCapacity`: the MEMPOOL is not full, this ONE source's share of it
    /// is — the correct advice is "wait for one of your own pending
    /// transactions to clear", not "retry later" (which reads as "the whole
    /// network is busy") and not "these bytes are invalid" (they are not).
    TooManyFromSource,
}

impl Refusal {
    /// The human-readable reason, for tests and logs. Callers that need to
    /// ACT on the difference must match the variant, not read this string.
    fn reason(&self) -> &'static str {
        match self {
            Refusal::AtCapacity => "mempool is at capacity",
            Refusal::Invalid(why) => why,
            Refusal::PreviouslyRefused { .. } => {
                "this node's proposer already had the transition refuse this transaction"
            }
            Refusal::TooManyFromSource => {
                "this source already has MEMPOOL_MAX_PER_SOURCE transactions pending"
            }
        }
    }
}


/// Which transaction in the body the transition is accusing, if it says.
///
/// `TransitionError::Transfer(u32, _)` and `Transaction(u32)` both carry "the
/// index into the body list" — the variant docs say it in those words. Every
/// other error names no transaction: a root mismatch, a shielded refusal, a
/// cap breach are properties of the block or of the whole selection.
///
/// A free function, and bounds-checked against the CURRENT length, for two
/// reasons. It is the one decision in the drop loop worth testing on its own —
/// the loop around it needs a proposer slot, a RANDAO chain and a signing key
/// to run at all. And the index came from a transition that judged a list this
/// function may no longer be holding: the loop shrinks `txs` every round, so an
/// index that was valid when the error was raised can be stale by the time it
/// is used. Out of range falls back to `None`, and `None` means "drop the tail
/// and retry", which is the behaviour that keeps the node producing.
fn culprit_index(err: &TransitionError, len: usize) -> Option<usize> {
    match err {
        TransitionError::Transfer(i, _) | TransitionError::Transaction(i) => {
            let i = *i as usize;
            (i < len).then_some(i)
        }
        _ => None,
    }
}

impl Engine {
    // ── Derivations over the canonical chain ────────────────────────────────

    // `chain` always holds genesis at index 0 (built that way in `run`, and
    // `do_reorg` truncates to `cut + 1 >= 1`), so `last()` is `Some`. The
    // fallbacks below are what an empty chain WOULD contain — genesis, at
    // slot 0, height 0 — evaluated lazily, so the invariant costs nothing on
    // the path that always runs and nothing can panic if it ever broke.
    fn head_id(&self) -> BlockId {
        self.chain
            .last()
            .map_or_else(|| self.manifest.genesis_id(), |(_, id)| *id)
    }

    fn head_slot_now(&self) -> u64 {
        self.chain.last().map_or(0, |(slot, _)| *slot)
    }

    /// Canonical height of the head: `chain.len() - 1`, genesis being height 0.
    fn head_height(&self) -> u64 {
        (self.chain.len() as u64).saturating_sub(1)
    }

    /// The committed state root at the head, READ rather than recomputed.
    ///
    /// `getchaininfo` used to call `state.state_root()` here, on the
    /// consensus thread, for every caller — a rebuild of every non-eUTXO
    /// component of the committed state tree, most of it the validator
    /// registry's ~3,749-byte hybrid pubkeys. MEASURED by
    /// `bench_chain_info_json` at Genesis-4's size (452,726 eUTXO leaves, 64
    /// validators): **32.6 ms cold, 3.0 ms warm**, against 0.040 / 0.015 ms
    /// once the root is handed in. Roughly 815x cold, 200x warm.
    ///
    /// **Those are not the 733 ms the incident was reported at, and the gap is
    /// not explained here.** On 2026-08-21 n21 (45.76.89.225) left rotation
    /// with `-32004 consensus thread did not answer within 10s`, answering
    /// after 10.7 s at a box load average of 1.01 — one thread eaten while the
    /// wallet, the explorer and 48 migrated validators polled it. But this
    /// tree already carries `229d95a6`/`22751083`, which keep the eUTXO
    /// subtree inside `CommittedState` and make this call incremental; the
    /// from-scratch rebuild those commits removed measures 80.9 s on the same
    /// box (`perf_state_root_breakdown`). 733 ms is between the two and
    /// matches neither. Whoever owns n21 should check which binary it runs
    /// before crediting this change with that incident: if n21 predates
    /// `229d95a6`, the fix for 733 ms is that commit, not this one.
    ///
    /// It had already hashed it because `apply_block` returns `Ok(post)` on
    /// exactly one condition: `post.compute_root() == header.state_root`
    /// (transition.rs step 12). Every block on this chain passed that, so for
    /// any head this node adopted the header field IS `state.state_root()`,
    /// bit for bit. `apply_canonical`'s log line and `do_reorg`'s take the
    /// same shortcut for the same reason; this is the third.
    ///
    /// That argument covers the header of a block. What it does not cover by
    /// inspection is that `self.state` is always the HEAD's post-state — a
    /// reorg replaces both, a boot has neither — so `head_root_tests` walks
    /// the real block path (ordinary blocks, two epoch boundaries, reorgs on
    /// both sides of the snapshot window, and an empty-branch give-back) and
    /// asserts the equality at every step rather than arguing it.
    ///
    /// # Genesis
    ///
    /// `ingest` returns early on slot 0 — "genesis is synthesized, never
    /// received" — so genesis is canonical, is the head at boot, and is NOT in
    /// `blocks`. The lookup misses, and the answer is the computed root: it is
    /// the ONLY value that keeps this change transport-only, since it is
    /// exactly what the RPC returned there before. `unwrap_or_default()` would
    /// have published 32 zero bytes as an answer, which is the failure this
    /// whole change exists to avoid. The cost is the old cost, paid on a chain
    /// of length one — genesis state, before any block, is small — and it is
    /// paid until the first block arrives and never again.
    fn head_state_root(&self) -> [u8; 32] {
        match self.blocks.get(self.head_id().as_bytes()) {
            Some(env) => env.header.state_root,
            None => self.state.state_root(),
        }
    }

    /// The canonical state with epoch accounting rolled forward to `epoch` —
    /// the exact rolling `apply_block` performs internally, so the duty view
    /// here can never disagree with validation.
    ///
    /// Memoized on `(state generation, epoch)` by [`StateCell`], whose docs
    /// carry the argument that the key is complete. It has to be: this is
    /// called once per ARRIVING ATTESTATION (`judge`), it used to clone a
    /// Genesis-3-sized state and re-run `process_epoch` every time, and most
    /// of those attestations name the same epoch as the one before.
    ///
    /// Shared rather than cloned. Every caller reads — roster, seed, finality
    /// view — and none mutates, which the `Arc` now enforces.
    fn rolled_to(&self, epoch: u64) -> Arc<CommittedState> {
        // Instrumentation only; compiled out without `perf-timing`. This spans
        // the whole call, memo HIT included, so the phase total reads as the
        // effective cost of the duty view — which is the number the memo was
        // built to move. On a hit the span is the lookup and nothing else.
        let _perf = bloch_pos_committee::perf::span(bloch_pos_committee::perf::Phase::RolledTo);
        self.state.rolled_to(epoch, |st| {
            self.tr
                .process_epoch(st)
                .expect("process_epoch is infallible")
        })
    }

    /// The uncached derivation, kept verbatim as the reference the memo is
    /// tested against. Not on any live path — if it ever grows a caller,
    /// something has gone wrong with the one above.
    #[cfg(test)]
    fn rolled_to_uncached(&self, epoch: u64) -> CommittedState {
        let mut st = (*self.state).clone();
        let mut cur = epoch_of(st.slot());
        while cur < epoch {
            st = self
                .tr
                .process_epoch(&st)
                .expect("process_epoch is infallible");
            cur += 1;
        }
        st
    }

    /// The sortition/partition seed for `epoch` — **the transition's own
    /// function**, not a copy of its expression.
    ///
    /// It used to be a re-derivation here:
    /// `if epoch == 0 { GENESIS_MIX } else { rolled.randao_mix_at(epoch - 1)
    /// .unwrap_or(GENESIS_MIX) }`. That is byte-for-byte what
    /// [`CommittedState::seed_for_epoch`] evaluates — `randao_mix_at` is
    /// `boundary_mixes.get`, and `Manifest::genesis_state` passes the very
    /// `GENESIS_MIX` constant in as the state's `genesis_mix` — so this is a
    /// refactor and not a change. It is worth making because the two are the
    /// duty view and the consensus authority for the SAME quantity: a node
    /// that proposes off one and is validated against the other produces
    /// blocks its own transition rejects. The look-ahead lives in that one
    /// function now, so a second copy here would have been a consensus rule
    /// the node silently did not take.
    ///
    /// # The anchor, and when this is the right function to call
    ///
    /// `rolled` is this node's own head rolled forward. That is CORRECT for
    /// the node's own duties — `propose` and `attest` build on the node's
    /// head, so the head IS the parent the transition will evaluate against,
    /// and producer and validator cannot disagree. It is WRONG for judging
    /// somebody else's attestation, which belongs to whatever branch its
    /// author was on. Use [`Self::seed_for_attestation`] there.
    fn seed_for(rolled: &CommittedState, epoch: u64) -> [u8; 32] {
        rolled.seed_for_epoch(epoch)
    }

    /// The committed mix at the close of epoch `epoch - 1`, read off the
    /// ANCESTRY of `from` rather than off this node's head.
    ///
    /// Walks selected-parent from `from` to the last block strictly before
    /// `first_slot_of_epoch(epoch)` and returns that block's
    /// `header.randao_mix`. That field is consensus-checked (the transition
    /// refuses a block whose mix is not `mix_in(parent_mix, reveal)`), and
    /// `close_epoch` records `boundary_mixes[c] = randao_mix` at the instant
    /// `c` closes — so the last block below `first_slot_of(c + 1)` carries
    /// exactly the boundary mix of `c`. No state is cloned and `process_epoch`
    /// is not run.
    ///
    /// `None` means "this node cannot see that far back on that branch" —
    /// the block is missing. That is an UNJUDGEABLE input, never an invalid
    /// one, and the caller must treat it as such.
    fn ancestral_boundary_mix(&self, from: &[u8; 32], epoch: u64) -> Option<[u8; 32]> {
        let first = first_slot_of_epoch(epoch)?;
        let genesis = *self.chain[0].1.as_bytes();
        let mut cur = *from;
        // Bounded by the stored block count: every step moves strictly to a
        // parent, and `blocks` is finite, so a cycle cannot spin forever.
        for _ in 0..=self.blocks.len() {
            if cur == genesis {
                // The manifest's mix, not the constant: under a v2 manifest
                // genesis opens on a mix derived from the carryover digest,
                // and this walk must return the same value
                // `CommittedState::seed_for_epoch` reads out of the state's
                // `genesis_mix` — the duty view and the consensus authority
                // for one quantity (see `seed_for`).
                return Some(self.manifest.genesis_mix());
            }
            let env = self.blocks.get(&cur)?;
            if env.header.slot < first {
                return Some(env.header.randao_mix);
            }
            cur = env.header.parent;
        }
        None
    }

    /// The sortition seed for an attestation, anchored to the ATTESTATION's
    /// own branch instead of this node's head.
    ///
    /// `target_root` is, by this node's own checkpoint convention, the last
    /// block strictly before the first slot of `epoch` on the attester's
    /// branch. So the seed is the boundary mix of `epoch - 1 - L` read from
    /// that block's ancestry, which is precisely what
    /// [`CommittedState::seed_for_epoch`] would compute when the attestation's
    /// slot is validated inside a block on that branch.
    ///
    /// This is the fix for the 2026-08-24 `NotInCommittee` flood. The old code
    /// judged every arriving attestation against a committee derived from how
    /// much of the chain THIS node had downloaded, so an honest vote from a
    /// validator that really was in the committee was answered with a peer
    /// penalty. Two nodes on the same branch now derive the same committee for
    /// the same attestation no matter how far apart their heads are.
    ///
    /// `None` = unjudgeable from what this node holds. The caller must Ignore,
    /// never Reject: `gossip.rs` justifies its `NotInCommittee` Reject with
    /// "both ends compute membership from the same finalized state", and a
    /// node that cannot reach the branch is not in a position to make that
    /// claim about anybody.
    fn seed_for_attestation(&self, target_root: &[u8; 32], epoch: u64) -> Option<[u8; 32]> {
        // GATED, on the SAME constant as `CommittedState::seed_for_epoch`, and
        // this is a correction: until 2026-08-25 the look-ahead here was
        // unconditional while the committed rule was gated, so the two
        // disagreed by exactly one boundary for every epoch below the flag day
        // — which is every epoch this chain has ever had. The node judged
        // arriving attestations against the committee of `mix(E − 2)` while
        // the transition admitted them against `mix(E − 1)`. Anchoring the
        // seed to the attester's branch (the 2026-08-24 fix) is orthogonal to
        // WHICH boundary that branch is read at, and only the anchor was
        // gated.
        //
        // The two must move together or the gate buys nothing: a duty view
        // that disagrees with the consensus authority is the defect the
        // anchor was introduced to remove, one boundary along.
        //
        // # The third definition, which this does NOT fix
        //
        // `derive::sortition_seed` — the producer's inclusion filter and
        // proposer draw — reads `epoch − 1` unconditionally, with no gate.
        // Below the flag day that is the same boundary all three now use, so
        // the fleet is consistent today. **The moment
        // `ANCESTRY_SEED_ACTIVATION_EPOCH` is armed, `sortition_seed` becomes
        // the odd one out** and the producer will filter against a committee
        // the transition does not recognise. It is not gated here because its
        // history lives in `ParentState::chain.randao_mixes`, whose retention
        // is a separate question from `boundary_mixes`'. Arming this flag day
        // is not safe until that is closed.
        let lookahead = if epoch < bloch_pos_committee::params::ANCESTRY_SEED_ACTIVATION_EPOCH {
            0
        } else {
            committees::MIN_SEED_LOOKAHEAD_EPOCHS
        };
        match epoch.checked_sub(lookahead) {
            None => Some(self.manifest.genesis_mix()),
            Some(src) => self.ancestral_boundary_mix(target_root, src),
        }
    }

    /// Checkpoint root of `epoch` on the canonical chain: the latest block
    /// strictly BEFORE the epoch's first slot (genesis for epoch 0/1 starts).
    ///
    /// Strictly-before is load-bearing: attesters attest at slot start, so
    /// the committee of the epoch's first slot cannot yet see that slot's
    /// block. A convention including the first-slot block would make early
    /// and late attesters of the same epoch vote different targets, splitting
    /// the tally below 2/3 — exactly the stall the first devnet run showed
    /// (justification frozen at epoch 1). The pre-boundary block is fixed for
    /// the whole epoch, so every honest attester votes the same root; the
    /// finality gadget only compares roots and does not care which epoch the
    /// checkpoint block itself sits in.
    fn checkpoint_root(&self, epoch: u64) -> [u8; 32] {
        let first = first_slot_of_epoch(epoch).unwrap_or(u64::MAX);
        let mut root = *self.chain[0].1.as_bytes();
        for (slot, id) in &self.chain {
            if *slot >= first {
                break;
            }
            root = *id.as_bytes();
        }
        root
    }

    /// This node's OWN finalized root at `epoch`, or `None` if its finality
    /// has not reached that epoch — exactly the input
    /// [`ws::cross_check`](bloch_pos_committee::ws::cross_check) declares.
    /// "Own" is load-bearing: the root comes from this node's replayed
    /// canonical chain under the same checkpoint convention its attesters
    /// vote, never from anything a peer or a publication asserted.
    fn own_finalized_root_at(&self, epoch: u64) -> Option<[u8; 32]> {
        (epoch <= self.state.finality().finalized.epoch).then(|| self.checkpoint_root(epoch))
    }

    /// Forward enforcement of the boot anchor (§5). Once this node's own
    /// finality reaches the anchor's epoch, the two must agree.
    ///
    /// Two outcomes, and the difference is the whole structural limit on the
    /// signers' power. A node that booted on its OWN finality treats a
    /// contradiction as the WS_CONFLICT alarm and keeps running — a
    /// checkpoint never reorganizes it. A node that had nothing of its own
    /// (`anchor_is_hard`) has only the anchor between it and a forged
    /// history, so a contradiction is fatal: it is following a chain that
    /// disagrees with the one thing it trusted.
    fn enforce_ws_anchor(&mut self) {
        let Some((epoch, root)) = self.ws_anchor else {
            return;
        };
        if self.ws_conflict_reported {
            return;
        }
        let Some(local) = self.own_finalized_root_at(epoch) else {
            return;
        };
        use bloch_pos_committee::ws::{cross_check, WeakSubjectivityCheckpoint, WS_FORMAT_VERSION};
        // Only `epoch`/`block_root` are read by cross_check; the rest of the
        // artifact is not re-litigated here (it was verified at boot).
        let probe = WeakSubjectivityCheckpoint {
            version: WS_FORMAT_VERSION,
            network_id: 0,
            genesis_root: [0u8; 32],
            epoch,
            block_root: root,
            state_root: [0u8; 32],
            validator_set_root: [0u8; 32],
            issued_at: 0,
            signer_set_id: 0,
        };
        if let bloch_pos_committee::ws::CrossCheck::Conflict {
            local_root,
            published_root,
        } = cross_check(Some(local), &probe)
        {
            self.ws_conflict_reported = true;
            eprintln!(
                "WS_CONFLICT at epoch {epoch}: this node finalized {} where its \
                 weak-subjectivity anchor says {}.",
                crate::codec::hex32(&local_root),
                crate::codec::hex32(&published_root),
            );
            if self.ws_anchor_hard {
                eprintln!(
                    "FATAL: this node synced with no finality of its own — the anchor \
                     was its only defense against a forged history, and the chain it \
                     followed contradicts it. Stopping rather than serving a history \
                     nothing vouches for. Re-check the checkpoint digest across \
                     independent publication channels before restarting."
                );
                std::process::exit(1);
            }
            eprintln!(
                "Own finality stands: NOT reorganizing (a checkpoint can never override \
                 a running node's finality). Alert the operator and compare the \
                 published digest across independent channels."
            );
        }
    }

    /// This validator's RANDAO chain, positioned at its committed reveal
    /// count on the CANONICAL chain (= how many canonical blocks it
    /// proposed). Regenerated from the seed on every use: a reorg can drop
    /// our own blocks, so an incrementally-advanced local chain would drift
    /// from what the committed state expects the next reveal to open.
    ///
    /// Only ever called from the proposing path, which an observer never
    /// reaches — the caller hands in the keys it has already resolved, so
    /// there is no key-less state for this function to be in.
    fn randao_positioned(&self, keys: &Keystore) -> RandaoChain {
        // Resolve the key on this branch and use the committed reveal count.
        // A reorganization may assign an auto-index key a different index.
        let count = self.state.validator_index_by_pubkey(&keys.pubkey)
            .and_then(|index| self.state.validator_reveals_used(index)).unwrap_or(0);
        let generation = self.state.validator_index_by_pubkey(&keys.pubkey)
            .map_or(0, |index| self.state.validator_randao_generation(index));
        let network = self.state.admission_network_domain().unwrap_or([0; 32]);
        let mut chain = RandaoChain::generate(keys.randao_seed_for(&network, generation));
        for _ in 0..count {
            chain.next_reveal();
        }
        chain
    }

    // ── Duties ──────────────────────────────────────────────────────────────

    /// This node's validator index, but only if the registry it is judging
    /// against still says that index is *this* key.
    ///
    /// Every duty goes through here rather than reading `keys.index`
    /// directly. The index alone is not identity: indices are handed out as
    /// `registry.keys().next_back() + 1`, so a keystore minted for index 64
    /// before its deposit landed can be beaten to index 64 by somebody else's
    /// deposit. Checking only membership would then pass — the index is
    /// genuinely active — and this node would sign under another validator's
    /// key. Two conflicting messages under one index is the equivocation
    /// `slashing.rs` punishes, so the check that matters is the KEY.
    ///
    /// `None` also covers the ordinary pending-activation case (index not yet
    /// registered), which is why this is a silent early return and not a
    /// warning: for a newcomer it is the expected state of every slot until
    /// its deposit is applied.
    ///
    /// Cost is one registry probe and one ~3.7 KB compare per duty check —
    /// nothing beside the hybrid signature it guards.
    fn duty_index(&self, rolled: &CommittedState) -> Option<u32> {
        let keys = self.keys.as_ref()?;
        if keys.index == crate::keys::AUTO_VALIDATOR_INDEX {
            return rolled.validator_index_by_pubkey(&keys.pubkey);
        }
        let rec = rolled.validator_record(keys.index)?;
        (rec.pubkey == keys.pubkey).then_some(keys.index)
    }

    /// Doppelgänger protection (R6 HIGH-8): true if `attest`/`propose` must
    /// refuse to act right now — either a live duplicate of this key was
    /// actually SEEN (permanent, until a restart), or this node is still
    /// inside its observation window and has not earned the right to find
    /// out yet. `false` the instant either the window has never been armed
    /// (bypassed, or an observer with no keys — see `Engine::run`) or has
    /// closed clean.
    fn doppelganger_blocks_duties(&self, slot: u64) -> bool {
        if self.doppelganger_halted {
            return true;
        }
        matches!(self.doppelganger_observe_until, Some(until) if slot < until)
    }

    fn start_doppelganger_observation(&mut self, wall_slot: u64) {
        self.wall_slot = wall_slot;
        let until = wall_slot.saturating_add(DOPPELGANGER_OBSERVE_SLOTS);
        self.doppelganger_observe_until = Some(until);
        println!(
            "DOPPELGANGER PROTECTION: observing after replay through wall slot {until} \
             ({DOPPELGANGER_OBSERVE_SLOTS} slots) before starting duties."
        );
    }

    /// An accepted, authenticated duty under this key proves a duplicate only
    /// if it was signed during live observation. Check the observation deadline
    /// against our wall clock, and exclude duties predating its start.
    fn note_possible_doppelganger(&mut self, index: u32, duty_slot: u64) {
        let Some(my_index) = self.duty_index(&self.state) else { return };
        if index != my_index || self.doppelganger_halted {
            return;
        }
        let Some(until) = self.doppelganger_observe_until else { return };
        if !self.live || self.wall_slot >= until {
            return; // replay is not evidence of a live duplicate
        }
        // A delayed duty signed before observation began can be this key's
        // own historical work. Its authenticated slot cannot prove a duplicate.
        if duty_slot < until.saturating_sub(DOPPELGANGER_OBSERVE_SLOTS) {
            return;
        }
        self.doppelganger_halted = true;
        eprintln!(
            "DOPPELGANGER DETECTED: validator {index} produced a duty at wall slot {} while \
             this process was still inside its {DOPPELGANGER_OBSERVE_SLOTS}-slot observation \
             window and had not yet started its own duties — another instance of this key is \
             signing on the network right now. REFUSING to start duties. This requires an \
             operator to confirm only one instance of this key is running before restarting; \
             bypass with --no-doppelganger-check or BLOCH_NO_DOPPELGANGER=1 (NOT recommended).",
            self.wall_slot,
        );
    }

    fn attest(&mut self, slot: u64) {
        // An observer holds no key and therefore has no duty. Bound here, once,
        // and used to sign below — nothing between reads `keys` mutably.
        //
        // Borrow shape: `keys` is read inside the signing closure while
        // `slashprot` is borrowed mutably, so the key is resolved to a local
        // rather than through `self`.
        let Some(keys) = self.keys.as_ref() else {
            return;
        };
        if self.doppelganger_blocks_duties(slot) {
            return;
        }
        let e = epoch_of(slot);
        if e == 0 {
            // Epoch 0's checkpoint is genesis — justified by definition;
            // a vote for it would be source==target, which is invalid.
            return;
        }
        let rolled = self.rolled_to(e);
        // Identity re-checked against the same snapshot that draws the
        // committee, before membership is even asked about.
        let Some(index) = self.duty_index(&rolled) else {
            return;
        };
        let roster = rolled.active_validators();
        let seed = Self::seed_for(&rolled, e);
        let committee = committees::committee_for_slot(&seed, slot, &roster);
        if committee.binary_search(&index).is_err() {
            return;
        }
        let fin = rolled.finality();
        let data = AttestationData {
            slot,
            head: *self.head_id().as_bytes(),
            source_epoch: fin.justified.epoch,
            source_root: fin.justified.root,
            target_epoch: e,
            target_root: self.checkpoint_root(e),
        };
        // SLASHING PROTECTION. The duty is settled; the signature is not made
        // until the watermark for it is on disk and fsync-ed. `slot` here is
        // the wall-clock slot — the slot loop derives it from `wall_slot()`
        // and hands it in — so "refuse unless the slot exceeds the watermark"
        // is exactly "refuse unless the wall clock has moved past what we
        // already signed", including after an NTP step backwards or a restart
        // inside the same slot.
        //
        let root = data.signing_root();
        let signature = match self.slashprot.guard_attestation(
            slot,
            data.source_epoch,
            data.target_epoch,
            || keys.sign(&root),
        ) {
            Ok(sig) => sig,
            Err(refusal) => {
                eprintln!("[slot {slot}] {refusal}");
                return;
            }
        };
        let att = Attestation {
            data,
            validator: index,
            signature,
        };
        self.pool
            .insert((att.validator, att.data.signing_root()), att.clone());
        self.net.broadcast(net::att_frame(&att));
        println!(
            "[slot {slot}] attested (epoch {e}, head {}, target {})",
            crate::codec::hex8(&data.head),
            crate::codec::hex8(&data.target_root)
        );
    }

    fn propose(&mut self, slot: u64) {
        if self.keys.is_none() {
            return;
        }
        if self.doppelganger_blocks_duties(slot) {
            return;
        }
        let e = epoch_of(slot);
        let rolled = self.rolled_to(e);
        // Same rule as `attest`: the key, not just the index, and from the
        // same snapshot the schedule is drawn from.
        let Some(index) = self.duty_index(&rolled) else {
            return;
        };
        let roster = rolled.active_validators();
        let seed = Self::seed_for(&rolled, e);
        if schedule::proposer(&seed, slot, &roster) != Some(index) {
            return;
        }

        // Attestations this block may carry: current epoch, not from the
        // future, author in its slot's committee (the same predicate the
        // transition enforces at step 8, applied as the producer's filter so
        // one bad pool entry cannot poison the block — the dust-tx lesson).
        //
        // The epoch partition is drawn ONCE, exactly as the transition's step
        // 8 draws it. `committee_for_slot` inside this filter shuffled the
        // whole active set per pool entry and discarded 31 of the 32 chunks it
        // built; on a full pool that is the same quadratic cost the validator
        // side just shed, paid by the one node that is on the clock. The
        // `epoch_of(..) == e` guard above the lookup is what makes the single
        // draw sound — it is the same guard, in the same order, as step 8.
        let partition = committees::epoch_committees(&seed, e, &roster);
        let mut atts: Vec<Attestation> = self
            .pool
            .values()
            .filter(|a| {
                epoch_of(a.data.slot) == e
                    && a.data.slot <= slot
                    && a.data.source_epoch < a.data.target_epoch
                    && partition
                        .get((a.data.slot % SLOTS_PER_EPOCH) as usize)
                        .is_some_and(|c| c.binary_search(&a.validator).is_ok())
            })
            .cloned()
            .collect();
        // The producer's own half of the block-level bound the transition now
        // enforces (`params::MAX_ATTESTATIONS_PER_BLOCK`). The pool is keyed
        // by `(validator, signing_root)`, so it cannot hold a duplicate and
        // this cannot silently drop one — but it can, in principle, hold more
        // distinct votes than a body may carry, and a producer that built such
        // a body would be building a block every node rejects. The dust-tx
        // lesson: filter at the producer, do not discover it at validation.
        //
        // Sorted before the cut so the truncation is a function of the votes
        // and not of `BTreeMap` iteration happening to be stable — and so two
        // producers holding the same pool would cut the same way.
        atts.sort_by_key(|a| (a.data.slot, a.validator, a.data.signing_root()));
        atts.truncate(MAX_ATTESTATIONS_PER_BLOCK);

        // `keys.is_none()` returned at the top of `propose`, and a duty never
        // writes `keys`, so this arm is unreachable; returning without a
        // block is what an observer does.
        let Some(keys) = self.keys.as_ref() else {
            return;
        };
        let randao = self.randao_positioned(keys);
        let Some(reveal) = randao.peek_reveal() else {
            eprintln!(
                "[slot {slot}] RANDAO chain spent — waiting for an included renewal"
            );
            return;
        };
        let fin = rolled.finality();
        let mut header = BlockHeaderV4 {
            version: VERSION_G4,
            parent: *self.head_id().as_bytes(),
            state_root: [0u8; 32],
            body_root: derive::body_root(&[]),
            slot,
            proposer_index: index,
            randao_reveal: reveal,
            randao_mix: mix_in(&rolled.randao_mix(), &reveal),
            justified_root: fin.justified.root,
            finalized_root: fin.finalized.root,
            attestation_root: derive::attestation_root(&atts),
            // Derived from the parent's committed pool roots, not zeroed. The
            // transition checks this (step 3b) since 2026-08-12; a zeroed field
            // was accepted before only because nothing checked it.
            coherence_root: self.state.coherence_root(),
        };

        // The post-state, from the SAME function validation runs. The probe
        // verifier only skips signature checks (the state does not depend on
        // them); the block still faces the real verifier in apply_block.
        // What this block will carry. Selected before the post-state, because
        // the post-state must be computed over exactly these — the header
        // commits to their body_root and every verifier recomputes from them.
        // Select, then DROP whatever the transition refuses — never abandon
        // the block.
        //
        // # Why this loop exists
        //
        // Until 2026-08-13 a proposer computed the post-state over its whole
        // selection and gave up if the transition said no. One transaction the
        // mempool had admitted but consensus would refuse therefore stopped
        // every proposer that picked it up, and the chain halted. It happened
        // on the live testnet: a zero-input transfer submitted through the
        // public RPC produced `produce refused: Transfer(0, NoInputs)` at
        // proposer after proposer, and production stopped at slot 69 while
        // every node stayed up and kept attesting.
        //
        // That is a denial of service costing one unauthenticated request, and
        // it is the same shape as the Genesis-3 dust transaction that poisoned
        // every block containing it. The mempool should not have admitted it —
        // and admission is being tightened separately — but a proposer must
        // not depend on that. Liveness cannot rest on the mempool being right;
        // a block with fewer transactions is always better than no block.
        //
        // Each refusal drops exactly one transaction and retries, so the loop
        // is bounded by the selection size and terminates: the empty selection
        // always computes.
        let mut txs = self.select_transactions(bloch_pos_committee::epoch_of(slot));
        let (post, tx_bytes) = loop {
            let tx_bytes: Vec<Vec<u8>> = txs.iter().map(PosTransaction::canonical_bytes).collect();
            header.body_root = derive::body_root(&tx_bytes);
            let probe = ProposalEnvelope {
                header: header.clone(),
                proposer_sig: Vec::new(),
            };
            match self
                .tr_probe
                .compute_post_state(&self.state, &probe, &atts, &txs)
            {
                Ok(p) => break (p, tx_bytes),
                Err(err) => {
                    // WHICH transaction, when the transition says which.
                    //
                    // `TransitionError::Transfer(u32, _)` and `Transaction(u32)`
                    // both carry "the index into the body list" — the doc on the
                    // variant says so in those words. Popping the TAIL instead
                    // was a defect with a cost that compounds: if the offender
                    // sits early in the selection, the loop discards every good
                    // transaction behind it one at a time, re-running the whole
                    // transition each round (O(k^2) for k = MAX_TXS_PER_BLOCK),
                    // and — since the rejection cache landed on 2026-08-30 —
                    // BARS each of those innocent transactions for
                    // REJECTION_TTL_SLOTS. One bad transaction could bar up to
                    // 255 legitimate ones for ~64 minutes. The cache did not
                    // create the defect; it turned a wasted slot into an hour
                    // of censorship, which is why the two are fixed together.
                    //
                    // The tail is still the fallback for the errors that name
                    // no index (`Shielded`, root mismatches): dropping SOMEthing
                    // and retrying is what keeps the node producing, and that is
                    // the whole point of this loop.
                    let bad = match culprit_index(&err, txs.len()) {
                        Some(i) => txs.remove(i),
                        None => match txs.pop() {
                            Some(t) => t,
                            None => {
                                // Empty and still refused: the fault is not in
                                // any transaction, so proposing is genuinely
                                // impossible.
                                eprintln!(
                                    "[slot {slot}] produce refused with no transactions: {err:?}"
                                );
                                return;
                            }
                        },
                    };
                    eprintln!(
                        "[slot {slot}] dropping a transaction the transition refuses ({err:?}); \
                         proposing without it"
                    );
                    // Out of the mempool too, or the next proposer inherits the
                    // same halt this loop just avoided.
                    //
                    // And barred from returning: removal alone is not enough,
                    // because the peers that still hold it re-offer it and the
                    // structural admission check has no way to see what the
                    // transition just saw. Without the bar the node cleans
                    // itself and refills — observed on the live chain, mempool
                    // 0 at slot 47,878 and 21 of the same transactions back
                    // 383 slots later.
                    let bad_key = bad.canonical_bytes();
                    self.mempool.remove(&bad_key);
                    self.reject_transaction(bad_key, slot);
                }
            }
        };
        header.state_root = post.state_root();

        // SLASHING PROTECTION, same rule as `attest`: the watermark for this
        // slot is durable before the block is signed. A proposer that signs a
        // second block for a slot it already proposed hands `slashing.rs` a
        // proposer offence, and everything above this line — the post-state,
        // the transaction selection — is discardable work; the signature is
        // not.
        // `keys.is_none()` returned at the top of this function and nothing
        // in between writes `keys`; the arm is unreachable and returning
        // without a block is the observer's behaviour.
        let Some(keys) = self.keys.as_ref() else {
            return;
        };
        let root = header.proposal_signing_root();
        let proposer_sig = match self.slashprot.guard_proposal(slot, || keys.sign(&root)) {
            Ok(sig) => sig,
            Err(refusal) => {
                eprintln!("[slot {slot}] {refusal}");
                return;
            }
        };
        let env = BlockEnvelope {
            header,
            proposer_sig,
            body: Body {
                transactions: tx_bytes,
                attestations: atts,
            },
        };
        let id = env.block_id();
        println!(
            "[slot {slot}] proposing block {} ({} attestations, {} txs, mempool {})",
            crate::codec::hex8(id.as_bytes()),
            env.body.attestations.len(),
            env.body.transactions.len(),
            self.mempool.len()
        );
        // Captured before `env` moves into ingest: if the transition refuses
        // this block, these are the bytes to drop from the mempool.
        let produced_txs: Vec<Vec<u8>> = env.body.transactions.clone();
        let env_tx_count = produced_txs.len();
        self.ingest_from(env, Source::Local);
        // h28080: a producer whose own node did not adopt its block is a
        // producer/validator split inside one process. It must be LOUD — but it
        // must not be fatal.
        //
        // This was `assert_eq!`, and a panic here was remotely reachable: the
        // probe accepts any signature, the real verifier does not, so one
        // transfer with a garbage signature made every proposer kill itself in
        // its own slot. The signature check in `admissible` closes that
        // particular door; this closes the CLASS. Any future divergence between
        // what the probe priced and what the transition accepts now costs one
        // missed slot and a log line, not a node.
        //
        // The transactions go too. Keeping them would rebuild the same block
        // next slot and lose that one as well.
        if self.head_id() != id {
            eprintln!(
                "[slot {slot}] REFUSED OWN BLOCK {} — the transition did not adopt what this \
                 node just produced (h28080 class). Dropping its {} transaction(s) and \
                 continuing; this slot is lost, the node is not.",
                crate::codec::hex8(id.as_bytes()),
                env_tx_count,
            );
            for encoded in &produced_txs {
                self.mempool.remove(encoded);
            }
            return;
        }
        // `head_id() == id` was just checked, and every canonical block is in
        // `blocks` (`prune` never removes a canonical id), so this is `Some`.
        // If it were not, the slot is lost the same way as the case above —
        // loudly, and without killing the node.
        let Some(env) = self.blocks.get(id.as_bytes()).cloned() else {
            eprintln!(
                "[slot {slot}] own block {} adopted as head but not stored — not broadcast",
                crate::codec::hex8(id.as_bytes()),
            );
            return;
        };
        self.net.broadcast(net::block_frame(&env));
    }

    // ── Block ingestion: store, then advance canonical as far as possible ──

    /// Ingest `env` and then everything it unblocks.
    ///
    /// The orphan pool means one arrival can connect a chain of parked
    /// blocks, and that promotion is a WORKLIST rather than recursion on
    /// purpose: `ingest_one` calls `advance`, which calls `apply_block`, and
    /// [`ORPHAN_MAX`] nested copies of that stack is a crash a peer chooses
    /// the depth of. Here the depth is one frame no matter how long the
    /// parked chain is.
    fn ingest(&mut self, env: BlockEnvelope) {
        let _ = self.ingest_judged(env);
    }

    /// `ingest`, plus the gossip verdict the engine — not the p2p edge — has
    /// now earned the right to state.
    ///
    /// The block topic used to `Accept` (and therefore relay) at the edge on
    /// decodability alone, which meant every structurally impossible block was
    /// forwarded once by every node that saw it, at no cost to its author.
    /// Attestations have never worked that way: `p2p.rs` hands them over with
    /// an [`Origin`] and says nothing until `apply_decision` answers. This is
    /// that same shape for blocks, and the mapping is the one `Verdict`'s docs
    /// demand:
    ///
    /// - `Reject` — a *provable* violation, safe to charge to the forwarding
    ///   peer: the header does not commit to the body it carries, the body
    ///   does not decode, the slot is one no honest node could be gossiping
    ///   (0, or past [`MAX_FUTURE_SLOTS`]), or the proposer signature is a
    ///   forgery under a key this node has registered.
    /// - `Accept` — structurally sound; relay it. This is deliberately NOT
    ///   "the transition applied it". A block on a losing branch, or one whose
    ///   parent has not arrived, is honest and must still propagate, so full
    ///   validity cannot be the relay condition without stalling fork choice.
    /// - `Ignore` — no opinion, and no relay: a duplicate, a block held under
    ///   an identity or a parent this node cannot check yet, or one refused by
    ///   a purely local clock policy ([`FUTURE_SLOT_TOLERANCE`]). None of
    ///   those is a violation the forwarding peer can be charged for.
    ///
    /// Note the one asymmetry with `MAX_FUTURE_SLOTS`' own docs: refusing to
    /// STORE the block is the local rule, but `Reject` also charges the peer's
    /// P4 score off this node's clock. That is intentional and bounded — the
    /// same 32-minute skew budget guards both, and gossipsub's penalty is a
    /// score, not a ban. The much tighter [`FUTURE_SLOT_TOLERANCE`] is NOT
    /// charged to anyone, which is why it maps to `Ignore`.
    fn ingest_judged(&mut self, env: BlockEnvelope) -> Verdict {
        self.ingest_from_judged(env, Source::Gossip)
    }

    /// Repair a missing branch ancestor, not just a missing newer block.
    /// Asking only after our head can never retrieve a competing branch
    /// whose missing parent is older than that head. Start a bounded window
    /// before the earliest orphan; successive pages can move that window
    /// backwards until they connect, without rewinding consensus state.
    fn sync_after_slot(&self) -> u64 {
        if !self.needs_sync && self.orphans.is_empty() { return self.state.slot(); }
        let missing_before = self.orphans.iter().map(|(_, env)| env.header.slot.saturating_sub(1))
            .min().unwrap_or(self.state.slot()).min(self.state.slot());
        let finalized = self.state.finality().finalized.root;
        let floor = self.chain.iter().rev().find(|(_, id)| *id.as_bytes() == finalized)
            .map_or(0, |(slot, _)| *slot);
        missing_before.saturating_sub(SLOTS_PER_EPOCH.saturating_mul(2)).max(floor)
    }

    /// Ingest `env` and then everything it unblocks, discarding the verdict.
    ///
    /// The path a block this node produced itself takes: there is no peer to
    /// report to, so `Source::Local` and no verdict.
    fn ingest_from(&mut self, env: BlockEnvelope, src: Source) {
        let _ = self.ingest_from_judged(env, src);
    }

    /// Ingest a block read back out of this node's own log during boot replay.
    ///
    /// **This exists so that replay's exemption from the wall-clock rules is
    /// stated, not inherited.** Replay used to call [`Self::ingest`], which
    /// routes to `Source::Gossip` — so a replayed block was judged against
    /// this node's clock by `MAX_FUTURE_SLOTS` exactly as a stranger's block
    /// is. What kept that from refusing a node its own history was an
    /// accident of ordering: `live` is only set AFTER the replay loop, and
    /// the tighter `FUTURE_SLOT_TOLERANCE` is the only check `live` guards.
    /// The horizon was never guarded by it. Any future edit to the live-flag
    /// logic — or a log whose head slot simply sits ahead of a fresh box's
    /// clock — and a node would refuse to replay its own FINALIZED log.
    ///
    /// There is no peer to report to and nothing to relay, so no verdict:
    /// these blocks are this node's committed history, being re-run through
    /// the same transition to arrive back at the same state.
    fn ingest_replay(&mut self, env: BlockEnvelope) {
        self.ingest_from(env, Source::Replay);
    }

    /// Ingest `env` and then everything it unblocks.
    ///
    /// The orphan pool means one arrival can connect a chain of parked
    /// blocks, and that promotion is a WORKLIST rather than recursion on
    /// purpose: `ingest_one` calls `advance`, which calls `apply_block`, and
    /// [`ORPHAN_MAX`] nested copies of that stack is a crash a peer chooses
    /// the depth of. Here the depth is one frame no matter how long the
    /// parked chain is.
    fn ingest_from_judged(&mut self, env: BlockEnvelope, src: Source) -> Verdict {
        let mut queue: VecDeque<BlockEnvelope> = VecDeque::new();
        queue.push_back(env);
        // The verdict belongs to the envelope the CALLER handed in — the
        // first one out of the queue — and to no other. Blocks promoted out
        // of the orphan pool below arrived on their own gossip message and
        // were judged then; charging their outcome to the peer that relayed
        // the block which merely unblocked them would punish it for the one
        // thing it did right.
        let mut verdict: Option<Verdict> = None;
        // Bounded: every iteration either drops the envelope or takes one
        // entry out of `orphans`, and `orphans` is capped.
        while let Some(next) = queue.pop_front() {
            let (v, landing) = self.ingest_one(next, src);
            verdict.get_or_insert(v);
            let Some((landed, grew_registry)) = landing else {
                continue;
            };
            // Whatever was waiting on the block that just landed can be
            // tried now, in arrival order.
            //
            // `grew_registry` widens that to the WHOLE pool for one reason:
            // a block carrying a `Deposit` registers a validator index, and
            // blocks parked for an unregistered proposer are exactly the ones
            // that identity was missing for. Without this they would sit
            // until eviction even though the node can now check them.
            // Deposits are rare (and gated off entirely today), so the sweep
            // is not on any hot path.
            let mut i = 0;
            while i < self.orphans.len() {
                if grew_registry || self.orphans[i].1.header.parent == landed {
                    // `i < len` (loop guard), so `remove` is `Some`; the
                    // `else` is unreachable and ends the sweep.
                    let Some((_, env)) = self.orphans.remove(i) else {
                        break;
                    };
                    self.orphans_admitted = self.orphans_admitted.saturating_add(1);
                    queue.push_back(env);
                } else {
                    // cannot overflow: i < self.orphans.len().
                    #[allow(clippy::arithmetic_side_effects)]
                    {
                        i += 1;
                    }
                }
            }
        }
        // An empty queue cannot happen — one envelope always goes in — but
        // `Ignore` is the answer that charges nobody if it ever did.
        verdict.unwrap_or(Verdict::Ignore)
    }

    /// One envelope through the door.
    ///
    /// Returns the gossip verdict for THIS envelope, and `Some((id,
    /// grew_registry))` when the block was stored: `id` so the caller can
    /// release what was waiting on it, and `grew_registry` when the block
    /// carried a `Deposit` and therefore may have registered a validator
    /// index some parked block is waiting to be checkable under.
    ///
    /// The order of the checks is load-bearing. Everything that costs only an
    /// integer comparison or a hash of bytes already in hand runs BEFORE the
    /// hybrid signature verify, and every one of them runs before
    /// `self.blocks.insert` — so neither a fork-choice input nor a
    /// post-quantum verification is something an unauthenticated peer can
    /// spend on this node's behalf.
    fn ingest_one(
        &mut self,
        env: BlockEnvelope,
        src: Source,
    ) -> (Verdict, Option<([u8; 32], bool)>) {
        let id = *env.block_id().as_bytes();
        if self.blocks.contains_key(&id) || self.canonical.contains(&id) {
            // Already known: a duplicate is an honest race, not a violation,
            // and it is not this node's job to relay it a second time.
            return (Verdict::Ignore, None);
        }
        // R3 M-1: already judged and refused by the finality latch. Dropped
        // here, before any signature work, so a peer that keeps re-offering
        // an already-refused branch cannot make this node pay to re-derive
        // the same verdict — this is what turns "sync re-fetches and
        // re-refuses forever" into a bounded, cheap no-op. See
        // `Engine::parked_refused_finality`'s doc.
        if self.parked_refused_finality.iter().any(|(seen, _)| *seen == id) {
            return (Verdict::Ignore, None);
        }
        // A cheap early reject before the block reaches the transition, using
        // the same `derive::*` functions the transition checks with — one
        // definition, called twice, not two definitions. The transition is the
        // authority (step 3b); this only avoids paying for a state clone on a
        // block that is obviously mismatched.
        if env.header.attestation_root != derive::attestation_root(&env.body.attestations)
            || env.header.body_root != derive::body_root(&env.body.transactions)
        {
            eprintln!(
                "reject {}: body/attestation commitment mismatch",
                crate::codec::hex8(&id)
            );
            return (Verdict::Reject, None);
        }
        // A block carrying transactions used to be rejected here, because the
        // node had no tx codec and failing closed was the honest response. The
        // codec exists now (`PosTransaction::from_canonical_bytes`), so the
        // check that replaces it is decodability: bytes this build cannot read
        // must not reach the transition, since the proposer's post-state would
        // then be unreproducible.
        if let Err(e) = body_transactions(&env) {
            eprintln!("reject {}: {e}", crate::codec::hex8(&id));
            return (Verdict::Reject, None);
        }
        if env.header.slot == 0 {
            // genesis is synthesized, never received
            return (Verdict::Reject, None);
        }
        // The upper half of the same door. `header.slot` is untrusted `u64`
        // and every slot/epoch walk downstream is linear in it — see
        // [`MAX_FUTURE_SLOTS`]. Refused BEFORE `self.blocks.insert`, so a
        // block naming a far-future slot never reaches `advance()` and never
        // occupies memory; and before any signature work, so the refusal is
        // one integer comparison rather than a hybrid verify.
        //
        // Gossip only, for the same reason the tolerance below is: this bounds
        // what an UNTRUSTED `slot` can make this node walk, and neither the
        // producer's own proposal (`Source::Local`) nor a block read back out
        // of this node's own log (`Source::Replay`) is untrusted. Removing the
        // `Local` exemption would refuse the node's own block on a loaded box
        // — the h28080 shape; removing the `Replay` one would let a skewed
        // clock stop a node from replaying its own FINALIZED log. And the path
        // that skips this door is not unguarded: `params::MAX_EPOCH_ADVANCE`
        // is the CONSENSUS ceiling on the same walk and applies to every
        // source.
        //
        // Both exemptions are carried by `src` and by nothing else. In
        // particular replay does NOT lean on `self.live`: replay happens to
        // run before `live` is set (`run`, after the replay loop), so the
        // tolerance below is skipped for it too — but that is an ordering
        // coincidence, not the rule, and it never covered THIS check at all.
        // Boot replay routes through `ingest` -> `ingest_judged`, which used
        // to hand it `Source::Gossip`, so a replayed block was subject to this
        // horizon and only the wall clock's usual agreement with the log kept
        // that from mattering.
        //
        // It is also not shadowed by the much tighter `FUTURE_SLOT_TOLERANCE`
        // below, which is skipped entirely while `!self.live` — during boot
        // and sync this horizon is the only thing bounding a gossiped slot.
        let horizon = self.wall_slot().saturating_add(MAX_FUTURE_SLOTS);
        if src.bounded_by_wall_clock() && env.header.slot > horizon {
            eprintln!(
                "reject {}: slot {} is past this node's horizon {} (wall {} + {})",
                crate::codec::hex8(&id),
                env.header.slot,
                horizon,
                self.wall_slot(),
                MAX_FUTURE_SLOTS,
            );
            return (Verdict::Reject, None);
        }
        // A slot the clock will never reach is a write into `blocks` that no
        // `advance` will ever consume. Gossip only — boot replay reads this
        // node's own log and must not depend on the wall clock, which is why
        // it is `Source::Replay` and exempt by SOURCE here, exactly as it is
        // at the horizon above (see [`FUTURE_SLOT_TOLERANCE`]).
        //
        // `self.live` stays, and it is a rule about GOSSIP during sync, not
        // about replay: a node catching up is fetching blocks that are in the
        // past by construction, and the horizon above is what bounds them.
        //
        // `Ignore`, not `Reject`: this tolerance is orders of magnitude
        // tighter than [`MAX_FUTURE_SLOTS`] and a peer one slot ahead of this
        // node's clock has proved nothing about itself.
        if src.bounded_by_wall_clock()
            && self.live
            && env.header.slot > self.wall_slot().saturating_add(FUTURE_SLOT_TOLERANCE)
        {
            self.rejected_future = self.rejected_future.saturating_add(1);
            eprintln!(
                "reject {}: slot {} is more than {FUTURE_SLOT_TOLERANCE} ahead of wall slot {}",
                crate::codec::hex8(&id),
                env.header.slot,
                self.wall_slot(),
            );
            return (Verdict::Ignore, None);
        }
        // The proposer is authenticated BEFORE the block takes a byte of
        // `blocks`, and the three outcomes are deliberately not two.
        //
        // The check itself is the transition's step 7 —
        // `verify_with_key(registered key, proposal_signing_root, sig)` —
        // moved in front of storage, so that a write into a fork-choice input
        // costs a hybrid signature only a key-holder can produce.
        //
        // **The registry read here is this node's HEAD, and the transition's
        // is the block's PRE-state.** That difference is why an unregistered
        // index is not a rejection. The transition resolves the key from the
        // parent's post-state deliberately (its step 7 says why: deriving a
        // consensus verdict from node-local state is the 2026-08-08
        // `expected_bits` fork), and a validator registered by a `Deposit` on
        // a branch this node has not applied is genuinely absent from this
        // registry. Refusing its blocks here would be that same fork in
        // miniature.
        //
        // So:
        //   * GENESIS index (`i < genesis_validator_count`), signature fails
        //     → REFUSED, and `Reject`: the genesis registry is in the manifest
        //     every node booted from, records are append-only per index
        //     (transition step 7's note: "records never removed"), so the key
        //     this node holds at `i` is the key EVERY branch holds at `i`, and
        //     this is a forgery the transition would have rejected too —
        //     provable, and safe to charge to the peer that relayed it.
        //   * DEPOSIT-ADDED index (`i >= genesis_validator_count`), signature
        //     fails against the HEAD's key → PARKED, `Ignore`, never `Reject`
        //     (external audit 2026-09-07, O04). "Append-only per index" is a
        //     fact about one branch: two branches that each admit a different
        //     `Deposit` as their next registration assign the same index to
        //     two different keys. A block signed with the other branch's key
        //     is not a forgery, and refusing it — worse, charging the relaying
        //     peer for it — would partition this node from a branch it has
        //     simply not applied yet. The transition judges it against the
        //     parent-derived registry when the branch is applied; until then
        //     it may not weigh on fork choice, which is exactly what parking
        //     buys. Today `genesis_validator_count` is the whole registry
        //     (`DEPOSIT_ACTIVATION_EPOCH` is `u64::MAX`, so no index above it
        //     exists on any branch) and this arm is unreachable; it is here so
        //     that opening deposits does not silently turn the head-registry
        //     shortcut into a fork.
        //   * unregistered index → PARKED, never stored, `Ignore`. No verdict
        //     is passed on it: it simply may not weigh on fork choice under an
        //     identity this node cannot check, and the orphan pool is
        //     bounded, so holding it costs nothing unbounded.
        //   * registered index, signature verifies → through to the parent
        //     rule.
        //
        // The middle case is the one that closes the actual leak. Refusing
        // only forgeries would leave "unknown index, KNOWN parent" free to
        // accumulate: such blocks enter `blocks`, all but one lose the
        // fork-choice tie, and `advance` — which only ever removes the block
        // it tried to apply — never touches the rest.
        let authenticated = match KeyLookup::pubkey(&*self.state, env.header.proposer_index) {
            Some(pk) => self.verifier.verify_with_key(
                pk,
                &env.header.proposal_signing_root(),
                &env.proposer_sig,
            ),
            None => {
                // Unknown identity: hold it, ask for the gap, decide nothing.
                self.park_orphan(id, env);
                return (Verdict::Ignore, None);
            }
        };
        if !authenticated {
            if env.header.proposer_index >= self.genesis_validator_count {
                // O04: a deposit-added identity whose key this branch may not
                // hold. Not a verdict on the block, and not a charge on the
                // peer — hold it and let the transition judge it in context.
                self.park_orphan(id, env);
                return (Verdict::Ignore, None);
            }
            self.rejected_unsigned = self.rejected_unsigned.saturating_add(1);
            eprintln!(
                "reject {}: proposer {} signature does not verify",
                crate::codec::hex8(&id),
                env.header.proposer_index,
            );
            return (Verdict::Reject, None);
        }
        // A block that connects to nothing cannot be judged, so it is parked
        // rather than stored: `blocks` is a fork-choice input and an entry
        // hanging off an unknown root is weight this node cannot validate.
        if !self.canonical.contains(&env.header.parent)
            && !self.blocks.contains_key(&env.header.parent)
        {
            self.park_orphan(id, env);
            return (Verdict::Ignore, None);
        }
        // Read before `env` moves: whether this block could have registered a
        // validator index. Decoding already succeeded above, so this is a
        // scan of a decoded list, not a second parse.
        let grew_registry = body_transactions(&env)
            .map(|txs| {
                txs.iter()
                    .any(|tx| matches!(tx, PosTransaction::Deposit { .. } | PosTransaction::FundedDeposit(_)))
            })
            .unwrap_or(false);
        // Read before `env` moves — R6 HIGH-8: an authenticated (this door's
        // signature check already ran, above) proposal by `proposer_index`
        // is exactly the class of sighting doppelgänger protection exists to
        // catch, symmetric with the attestation hook in `apply_decision`.
        let proposer_index = env.header.proposer_index;
        let proposer_slot = env.header.slot;
        self.observe_proposer_equivocation(&env);
        self.blocks.insert(id, env);
        if src.bounded_by_wall_clock() {
            self.note_possible_doppelganger(proposer_index, proposer_slot);
        }
        self.advance();
        // The block is queryable now, so attestations parked on it can be
        // re-run. `advance()` first: an attestation released here votes on
        // fork choice, and it should see the chain the block already moved.
        self.release_held(id);
        // After `advance`, because that is what can have moved finality.
        self.prune_below_finalized();
        (Verdict::Accept, Some((id, grew_registry)))
    }

    /// Park a block whose parent is unknown, and ask the mesh for the gap.
    ///
    /// Deduplicated by id, so a mesh that hands the same orphan back on every
    /// heartbeat occupies one slot rather than the whole pool.
    fn park_orphan(&mut self, id: [u8; 32], env: BlockEnvelope) {
        if self.orphans.iter().any(|(seen, _)| *seen == id) {
            return;
        }
        // FIFO: at the cap the OLDEST goes, since its parent has had the
        // longest to arrive and has not.
        while self.orphans.len() >= ORPHAN_MAX {
            if self.orphans.pop_front().is_some() {
                self.orphans_evicted = self.orphans_evicted.saturating_add(1);
            }
        }
        self.orphans.push_back((id, env));
        // The gap is real and the sync loop is the thing that closes it.
        self.needs_sync = true;
    }

    /// Drop non-canonical blocks — stored and parked — that sit below the
    /// finalized checkpoint.
    ///
    /// **Why this cannot lose a branch.** `lmd_ghost_head` starts its descent
    /// at the justified root and only ever walks to children, so the head is
    /// always a descendant of justified, and justified is at or above
    /// finalized. `path_to_canonical` walks from that head down to the first
    /// canonical ancestor, which it therefore reaches at or above justified
    /// too. Nothing removed here is on either walk.
    ///
    /// Canonical blocks stay: `do_reorg` rebuilds the block log out of
    /// `self.blocks` for the whole canonical chain, and pruning them would
    /// turn its `expect("stored")` into a panic a reorg reaches.
    fn prune_below_finalized(&mut self) {
        let finalized_epoch = self.state.finality().finalized.epoch;
        if finalized_epoch == 0 {
            return; // nothing is final yet; there is no floor to prune under
        }
        // `None` only on an epoch whose first slot overflows `u64` — no such
        // chain exists, and pruning nothing is the right answer if one did.
        let Some(floor) = first_slot_of_epoch(finalized_epoch) else {
            return;
        };
        let doomed: Vec<[u8; 32]> = self
            .blocks
            .iter()
            .filter(|(id, env)| env.header.slot < floor && !self.canonical.contains(*id))
            .map(|(id, _)| *id)
            .collect();
        for id in doomed {
            self.blocks.remove(&id);
            self.blocks_pruned = self.blocks_pruned.saturating_add(1);
        }
        // Parked blocks under the floor can never connect to a branch that
        // could win, so holding them only costs slots other orphans need.
        let before = self.orphans.len();
        self.orphans.retain(|(_, env)| env.header.slot >= floor);
        // `retain` only shrinks, so `before - len` is the eviction count; both
        // are counters, saturating by design.
        self.orphans_evicted = self
            .orphans_evicted
            .saturating_add(before.saturating_sub(self.orphans.len()) as u64);
    }

    // ── Transaction-status index (R4 F-11, `gettxstatus`) ───────────────────

    /// Record `txid -> slot` for every transaction `txs` carries, called once
    /// per block from the canonical-apply paths (`apply_canonical`,
    /// `do_reorg`'s winning branch). Overwrites any earlier entry for the
    /// same txid — a transaction included again at a new slot on a winning
    /// branch is exactly the case where the newer slot is the true answer.
    fn note_tx_slots(&mut self, slot: u64, txs: &[PosTransaction]) {
        for tx in txs {
            let id = tx.txid();
            if self.tx_slot_index.insert(id, slot).is_none() {
                self.tx_slot_index_order.push_back(id);
            }
        }
        while self.tx_slot_index_order.len() > MAX_TX_SLOT_INDEX {
            if let Some(oldest) = self.tx_slot_index_order.pop_front() {
                self.tx_slot_index.remove(&oldest);
            }
        }
    }

    /// A block at `slot` carrying `txs` just left canonical history (the
    /// losing side of a reorg). Remove any index entry that STILL points at
    /// `slot` — one that does not has already been overwritten by
    /// `note_tx_slots` for the same txid re-included on the winning branch,
    /// and must not be clobbered back to a slot that is no longer canonical.
    fn forget_tx_slots_if_stale(&mut self, slot: u64, txs: &[PosTransaction]) {
        for tx in txs {
            let id = tx.txid();
            if self.tx_slot_index.get(&id) == Some(&slot) {
                self.tx_slot_index.remove(&id);
                // Left in `tx_slot_index_order`: the FIFO eviction loop in
                // `note_tx_slots` tolerates a stale id there (it is simply a
                // no-op removal when its turn comes), and the order queue's
                // OWN length is what bounds memory, so this costs nothing
                // beyond one wasted future eviction slot.
            }
        }
    }

    /// `pending | included | justified | finalized | unknown` for `txid`
    /// (R4 F-11). Cheapest check first: the bounded index (`O(log n)`
    /// lookup) before the mempool (`O(mempool_len)` scan, since the mempool
    /// is keyed by canonical bytes, not by txid).
    fn tx_status(&self, txid: &[u8; 32]) -> &'static str {
        if let Some(&slot) = self.tx_slot_index.get(txid) {
            let fin = self.state.finality();
            let e = epoch_of(slot);
            return if e <= fin.finalized.epoch {
                "finalized"
            } else if e <= fin.justified.epoch {
                "justified"
            } else {
                "included"
            };
        }
        if self.mempool.values().any(|tx| &tx.txid() == txid) {
            return "pending";
        }
        "unknown"
    }

    // ── Fork choice: LMD-GHOST ──────────────────────────────────────────────

    /// The LMD-GHOST head over every block this node has seen, canonical or
    /// not.
    ///
    /// Rebuilt from scratch each call (see the module docs on why there is no
    /// cached store). Deterministic despite the map iteration: `Store::observe`
    /// keeps the highest-slot message per validator and bars any validator that
    /// signed two different heads in one slot, so the resulting store is a
    /// function of the message *set*, never of arrival order — the property
    /// that was found violated in `forkchoice.rs` on 2026-08-11 and fixed
    /// there. Sibling lists are sorted so the tie-break is stable too.
    /// Everything [`lmd_ghost_head`] reads, in a form cheap enough to compare
    /// on every turn of `advance`'s loop.
    ///
    /// The two state inputs are compared by value. The two collection inputs
    /// are compared by COUNT, and that is a complete comparison only because
    /// of an invariant that holds inside `advance` and nowhere else: **within
    /// one `advance` call, `blocks` and `pool` can only shrink.** Nothing on
    /// that path inserts — `ingest` inserts the block before calling in,
    /// `on_attestation` runs on a different event — so `apply_canonical`,
    /// `do_reorg` and the invalid-block removal only ever take entries out. A
    /// set that only loses elements is unchanged exactly when its size is.
    ///
    /// `fc_covered_removals` is added back to the pool count for the one kind
    /// of shrinkage fork choice cannot observe: an attestation dropped because
    /// the block carrying it became canonical is still counted, from that
    /// block's body. Adding the running total keeps the sum invariant across
    /// those and lets it fall — forcing a recompute — for the epoch `retain`,
    /// which drops attestations no stored block carries.
    ///
    /// If a future edit inserts into either collection inside `advance`, this
    /// stops being sound. That is why the invariant is written down here
    /// rather than assumed. The neutrality half of the claim is pinned by
    /// `an_attestation_its_block_carries_is_free_to_leave_the_pool`, which
    /// also carries the control showing the epoch `retain` is NOT neutral.
    fn forkchoice_inputs(&self) -> ForkChoiceInputs {
        ForkChoiceInputs {
            blocks: self.blocks.len(),
            // A memo key over two counters; saturating like the counters are.
            pool: (self.pool.len() as u64).saturating_add(self.fc_covered_removals),
            justified: self.state.finality().justified.root,
            validators: self.state.active_validators(),
        }
    }

    fn forkchoice_head(&self) -> [u8; 32] {
        // Instrumentation only; compiled out without `perf-timing`.
        let _perf = bloch_pos_committee::perf::span(bloch_pos_committee::perf::Phase::ForkChoice);
        lmd_ghost_head(
            &self.blocks,
            self.pool.values(),
            &self.state.active_validators(),
            self.state.finality().justified.root,
        )
    }

    /// The chain of stored blocks from `target` down to the nearest canonical
    /// ancestor, ancestor-child first, together with that ancestor.
    ///
    /// `None` means the lineage is incomplete — the node is missing blocks and
    /// must sync before it can judge the branch. Returning `None` rather than
    /// guessing is the fail-closed half of the rule: a branch is adopted only
    /// after being replayed and validated in full.
    fn path_to_canonical(&self, target: [u8; 32]) -> Option<([u8; 32], Vec<BlockEnvelope>)> {
        if self.canonical.contains(&target) {
            return Some((target, Vec::new()));
        }
        let mut branch = Vec::new();
        let mut cur = target;
        // Bounded by the number of stored blocks: a cycle (which a malicious
        // peer could otherwise induce) terminates instead of hanging.
        for _ in 0..=self.blocks.len() {
            match self.blocks.get(&cur) {
                Some(env) => {
                    branch.push(env.clone());
                    cur = env.header.parent;
                    if self.canonical.contains(&cur) {
                        branch.reverse();
                        return Some((cur, branch));
                    }
                }
                None => return None,
            }
        }
        None
    }

    /// Make the canonical chain equal the LMD-GHOST head.
    ///
    /// Three cases, and the third is the one longest-chain could not express:
    /// the head descends from the current head (extend), the head is on another
    /// branch (reorg), or the head is an *ancestor* of the current head —
    /// weight moved to a sibling and the chain must give blocks back. That last
    /// case is a legitimate LMD-GHOST outcome and is handled by reorganising to
    /// an empty branch.
    fn advance(&mut self) {
        // Fork choice is recomputed at the top of every iteration, and the
        // last iteration exists only to confirm the head stopped moving. That
        // confirmation is NOT free and it is NOT redundant: `apply_canonical`
        // advances `self.state`, which moves the justified root and can move
        // the active validator set, and it prunes `self.pool`. All three are
        // fork-choice inputs, so the value really can change and the loop
        // really is the convergence.
        //
        // What is skippable is the case where none of them moved, and
        // `forkchoice_inputs` is what decides that. Reusing the previous
        // answer there is not an approximation — `lmd_ghost_head` is a pure
        // function of exactly those inputs (that is why §5.5 made it a free
        // function), so equal inputs mean an equal head, bit for bit.
        let mut memo: Option<(ForkChoiceInputs, [u8; 32])> = None;
        // Bounded: every iteration either advances the canonical head or
        // deletes an invalid block, and both are finite.
        for _ in 0..=self.blocks.len().saturating_mul(2).saturating_add(2) {
            let inputs = self.forkchoice_inputs();
            let target = match &memo {
                Some((seen, head)) if *seen == inputs => *head,
                _ => self.forkchoice_head(),
            };
            memo = Some((inputs, target));
            let head = *self.head_id().as_bytes();
            if target == head {
                return;
            }
            let Some((ancestor, branch)) = self.path_to_canonical(target) else {
                // Missing lineage: ask the mesh, and keep the chain we have
                // rather than adopting something we cannot validate.
                self.needs_sync = true;
                return;
            };
            if ancestor == head && !branch.is_empty() {
                // Pure extension: apply in order, no replay needed.
                let mut progressed = false;
                for env in &branch {
                    if !self.apply_canonical(env) {
                        self.blocks.remove(env.block_id().as_bytes());
                        break;
                    }
                    progressed = true;
                }
                if !progressed {
                    continue;
                }
            } else if let Some(latch) = self.cut_below_finalized_latch(&ancestor) {
                // Finality latch (F-03): the heaviest branch demands cutting
                // below this node's finalized checkpoint. Refuse it, drop the
                // branch, and stop here — the canonical chain this node has
                // already finalized is the answer, not the branch. Ending the
                // loop (rather than `continue`) matters for the empty-branch
                // give-back case, where there is nothing to drop and retrying
                // would spin against the same refusal until the bound.
                self.refuse_finality_rewind(latch, &branch);
                return;
            } else if !self.do_reorg(ancestor, branch) {
                continue; // offending block removed; recompute
            }
        }
    }


    /// Outpoints a transaction spends, when it spends any.
    ///
    /// `None` for everything that is not a transfer: staking messages consume
    /// no eUTXO today (that is precisely the gap the validator-opening wave
    /// closes), so "spends nothing" and "spends something absent" must not be
    /// the same answer — the sweep may only ever judge transactions that
    /// actually name outpoints.
    fn spent_outpoints(tx: &PosTransaction) -> Option<Vec<([u8; 32], u32)>> {
        match tx {
            PosTransaction::Transfer { inputs, .. } => {
                Some(inputs.iter().map(|i| (i.txid, i.vout)).collect())
            }
            PosTransaction::TransferV2 { inputs, .. } => {
                Some(inputs.iter().map(|i| (i.txid, i.vout)).collect())
            }
            PosTransaction::FundedDeposit(tx) => Some(tx.inputs.iter().map(|i| (i.txid, i.vout)).collect()),
            _ => None,
        }
    }

    /// Evict mempool transactions that spend outputs this chain does not have.
    ///
    /// # Why this exists, and why the proposer's drop loop was not enough
    ///
    /// The drop loop is the ONLY path that removed an inapplicable
    /// transaction, and it runs exactly when this node PROPOSES. A node that
    /// never proposes therefore never drops anything: its mempool is a
    /// one-way sink that fills to `MEMPOOL_MAX` and stays there.
    ///
    /// That is not hypothetical. Measured on the live fleet, 2026-08-30:
    /// the two archival nodes and the public RPC node — none of which holds a
    /// validator key, all three with `proposing block` count of exactly zero —
    /// were sitting on 63, 63 and **190** transactions (5 MB) while the
    /// validators around them had drained from 91 to 9 by proposing. The
    /// public explorer reads one of those observers, so the number the world
    /// saw was a figure no validator held any more.
    ///
    /// The rejection cache (see [`Self::reject_transaction`]) does not help
    /// them either: it is written by the drop loop, so on an observer it is
    /// never written at all. This sweep is the half that works without
    /// proposing.
    ///
    /// # What it checks, and what it deliberately does not
    ///
    /// Only outpoint existence. That is a lookup per input against committed
    /// state, and it catches the class that actually accumulates
    /// (`UnknownInput` — a transfer built against a divergent node's UTXO
    /// view, or one whose inputs were spent by someone else). It does NOT
    /// re-run the transition: conservation, signatures and script matching
    /// stay where they are, because a full answer needs a candidate header
    /// this path has no reason to build. Two checks, neither trusting the
    /// other — the same posture `admissible` documents for itself.
    ///
    /// Once per epoch, not once per block: every RPC call already competes
    /// with consensus on this thread, and an observer accumulates over days,
    /// so 16 minutes of latency costs nothing and 32 sweeps per epoch would
    /// be waste.
    /// Drop mempool entries that have watched [`MEMPOOL_TTL_SLOTS`] of head
    /// progress go by without ever being included, and reconcile the
    /// admission-time bookkeeping with the mempool itself.
    ///
    /// Runs once per applied block, which is the only clock that matters here:
    /// the entries this exists for are the ones a proposer skipped, and a
    /// proposer only skips inside a block.
    ///
    /// Retention only. Admission is untouched — a transaction dropped for age
    /// is not refused, not remembered in `rejected`, and not barred: if the
    /// mesh offers it again it is admitted again, with a fresh clock. That is
    /// the difference between this and `reject_transaction`, and it is why
    /// this needs no flag day: the set of blocks this node will accept is
    /// exactly the same before and after.
    fn evict_stale_mempool(&mut self) {
        let now = self.head_slot_now();
        let pool = &mut self.mempool;
        let suspect = &mut self.mempool_suspect;
        let mut expired = 0u64;
        self.mempool_admitted_at.retain(|key, at| {
            if !pool.contains_key(key) {
                // Included, refused, swept or replaced: its clock leaves with
                // it. Doing this here — rather than at each of those four
                // sites — is what keeps this map from being a slower leak
                // than the one the TTL closes.
                return false;
            }
            // `saturating_sub`: a reorg can move the head backwards, and the
            // honest answer to "negative age" is zero, not eviction.
            if now.saturating_sub(*at) <= MEMPOOL_TTL_SLOTS {
                return true;
            }
            pool.remove(key);
            suspect.remove(key);
            expired = expired.saturating_add(1); // counter
            false
        });
        if expired > 0 {
            self.mempool_expired = self.mempool_expired.saturating_add(expired);
            eprintln!(
                "[slot {now}] mempool TTL: dropped {expired} transaction(s) unincluded for \
                 more than {MEMPOOL_TTL_SLOTS} slots ({} left, {} dropped for age so far)",
                self.mempool.len(),
                self.mempool_expired,
            );
        }
    }

    fn sweep_mempool(&mut self, epoch: u64) {
        if self.mempool_swept_epoch == epoch {
            return;
        }
        self.mempool_swept_epoch = epoch;

        let mut evict: Vec<Vec<u8>> = Vec::new();
        let mut suspect: Vec<Vec<u8>> = Vec::new();
        let mut cleared: Vec<Vec<u8>> = Vec::new();
        for (key, tx) in &self.mempool {
            let Some(outpoints) = Self::spent_outpoints(tx) else {
                continue;
            };
            let missing = outpoints
                .iter()
                .any(|(txid, vout)| self.state.utxo(txid, *vout).is_none());
            if !missing {
                if self.mempool_suspect.contains(key) {
                    cleared.push(key.clone());
                }
                continue;
            }
            if self.mempool_suspect.contains(key) {
                evict.push(key.clone());
            } else {
                suspect.push(key.clone());
            }
        }

        for key in cleared {
            self.mempool_suspect.remove(&key);
        }
        for key in suspect {
            self.mempool_suspect.insert(key);
        }
        if evict.is_empty() {
            return;
        }
        let n = evict.len();
        // The WALL slot, not the head's.
        //
        // `is_rejected` is checked against `wall_slot()` on the admission
        // path, so a bar minted against the committed head is born already
        // expired on exactly the node this sweep exists for: an observer
        // catching up sits thousands of slots behind the clock, and
        // `head + TTL` is then far in the past. Same clock on both sides or
        // the TTL means nothing. (The proposer's drop loop is not exposed to
        // this: it bars with the slot it is building for, which IS the wall.)
        let slot = self.wall_slot();
        for key in evict {
            self.mempool.remove(&key);
            self.mempool_suspect.remove(&key);
            // Barred as well, and for the same reason the drop loop bars: the
            // peers still holding it re-offer it, and structural admission
            // cannot see what this sweep just saw.
            self.reject_transaction(key, slot);
        }
        if self.live {
            eprintln!(
                "[epoch {epoch}] mempool sweep: evicted {n} transaction(s) spending outputs \
                 this chain does not have; {} left, {} barred",
                self.mempool.len(),
                self.rejected.len()
            );
        }
    }

    /// Bar a transaction the transition refused from coming back, and expire
    /// whatever is due to expire while we are here.
    ///
    /// Purging lazily on write rather than on a timer keeps the cache free of
    /// its own upkeep loop: nothing has to run for entries to lapse, they are
    /// simply not honoured past their slot (see [`Self::is_rejected`]), and
    /// this call reclaims the space. A node that stops proposing therefore
    /// stops growing this, which is the correct shape — it also stops learning.
    fn reject_transaction(&mut self, key: Vec<u8>, slot: u64) {
        self.rejected.retain(|_, (until, _)| *until > slot);
        while self.rejected.len() >= REJECTION_MAX {
            // Evict the soonest to lapse: it is the entry closest to being
            // worthless anyway. `BTreeMap` is ordered by KEY, not by value, so
            // the minimum has to be found rather than popped.
            let Some(victim) = self
                .rejected
                .iter()
                .min_by_key(|(_, (until, _))| *until)
                .map(|(k, _)| k.clone())
            else {
                break;
            };
            self.rejected.remove(&victim);
        }
        self.rejected.insert(key, (slot.saturating_add(REJECTION_TTL_SLOTS), 0));
    }

    /// Whether `key` is barred as of `slot`, without mutating anything.
    ///
    /// Reads the expiry rather than assuming the purge has run, so a stale
    /// entry can never bar a transaction one slot longer than it should.
    fn is_rejected(&self, key: &[u8], slot: u64) -> Option<u64> {
        self.rejected.get(key).map(|(until, _)| *until).filter(|until| *until > slot)
    }

    /// Record that a bar just refused a re-offer, and say so ONCE per
    /// transaction.
    ///
    /// Once, not every time: the gossip mesh re-offers, and this node's log
    /// already carries 18,912 lines of `attestation REJECTED: NotInCommittee`
    /// — a message that repeats is a message nobody reads. The first refusal
    /// per key is the event worth seeing (it proves the bar met a real
    /// re-offer, which is the whole claim); the rest is a number, and the
    /// number is `rejected_hits`, readable from outside through
    /// `getmempoolinfo` so measuring the cache needs no shell on the box.
    fn note_bar(&mut self, key: &[u8], until_slot: u64) {
        self.rejected_hits = self.rejected_hits.saturating_add(1);
        let first = match self.rejected.get_mut(key) {
            Some((_, hits)) => {
                *hits = hits.saturating_add(1);
                *hits == 1
            }
            None => false,
        };
        if first && self.live {
            eprintln!(
                "barred a re-offered transaction the transition had refused \
                 (bar lifts at slot {until_slot}); total barred since boot: {}",
                self.rejected_hits
            );
        }
    }

    /// Admit a transaction to the mempool and pass it on.
    ///
    /// Admission is thin, but it is not "the bytes decoded at the network edge
    /// and that is the whole check": `admissible`, called below, refuses
    /// deposits, delegations and exits, refuses a transfer with no inputs or no
    /// outputs, and verifies every spend signature. What is missing is the
    /// fee-market half — no fee floor, no per-sender accounting, no replacement
    /// policy — and that is named in the `mempool` field's doc rather than
    /// half-built. Re-broadcast only on first sight, so a transaction traverses
    /// the mesh once instead of echoing between every pair of peers.
    ///
    /// Returns what became of the transaction, so a caller that has someone to
    /// answer to — the RPC — can say. The gossip path ignores the result: a
    /// peer is not waiting on a verdict, and a duplicate arriving twice over a
    /// full mesh is the normal case rather than a fault.
    fn on_transaction(&mut self, tx: PosTransaction) -> Result<Admitted, Refusal> {
        let key = tx.canonical_bytes();
        if self.mempool.contains_key(&key) {
            return Ok(Admitted::Duplicate);
        }
        // Before capacity, and before the structural check: a transaction this
        // node's own proposer already watched the transition refuse must not
        // take a mempool slot, and must not be re-broadcast. Ahead of the
        // capacity test on purpose — otherwise a mempool filled by refused
        // transactions answers `AtCapacity`, which tells the sender to retry
        // and is exactly the wrong advice.
        if let Some(until_slot) = self.is_rejected(&key, self.wall_slot()) {
            self.note_bar(&key, until_slot);
            return Err(Refusal::PreviouslyRefused { until_slot });
        }
        // R7 M6: per-source cap, before capacity — a source at its own cap
        // must be refused as such even when the mempool overall has room,
        // and must not instead be told to look at the (irrelevant) overall
        // capacity.
        if let Some(source) = tx_source_hash(&tx) {
            let from_source =
                self.mempool.values().filter(|t| tx_source_hash(t) == Some(source)).count();
            if from_source >= MEMPOOL_MAX_PER_SOURCE {
                return Err(Refusal::TooManyFromSource);
            }
        }
        // R7 M6: at capacity, decide WHETHER an eviction is even possible —
        // read-only, cheap, no crypto paid — but do not COMMIT it yet. The
        // incoming transaction must still pass `admissible` below before any
        // real entry is actually removed: otherwise a transaction that
        // CLAIMS a high `tip_millisat_per_gas` but carries a garbage
        // signature would evict a real, paying transaction for free and
        // then itself be refused as `Invalid` — a targeted eviction that
        // costs the attacker nothing, since `tip_millisat_per_gas` sits
        // inside the signed root and checking it against the signature is
        // exactly the expensive step this ordering must not skip.
        let evict_at_capacity: Option<Vec<u8>> = if self.mempool.len() >= MEMPOOL_MAX {
            // `min_by_key` breaks ties by iteration order (`BTreeMap`,
            // ascending canonical bytes) — deterministic, and irrelevant to
            // security: a tie for LOWEST fee is the one place grinding buys
            // nothing, since every tied candidate is equally eligible for
            // eviction regardless of which one this picks.
            let lowest = self
                .mempool
                .iter()
                .min_by_key(|(_, t)| tx_tip_rate(t))
                .map(|(k, t)| (k.clone(), tx_tip_rate(t)));
            match lowest {
                // Strictly greater, not `>=`: a flood of minimum-fee
                // transactions must not be able to evict a real payer merely
                // by arriving. Today's `AtCapacity` at least costs such a
                // flood nothing extra; letting a TIE evict would make it
                // actively clear out everyone who already paid, which is
                // strictly worse than the refusal it replaces.
                Some((lowest_key, lowest_rate)) if tx_tip_rate(&tx) > lowest_rate => {
                    Some(lowest_key)
                }
                _ => return Err(Refusal::AtCapacity),
            }
        } else {
            None
        };
        // Refuse the shapes consensus can never apply.
        //
        // Admission used to check duplicate-and-capacity only, so anything
        // that decoded got in. One transaction consensus would never apply
        // halted the live testnet: every proposer that selected it failed to
        // produce, and the chain stopped at slot 69 with every node up and
        // still attesting. Cost of the attack: one unauthenticated request.
        //
        // This is deliberately a STRUCTURAL check, not a full validity check.
        // A complete answer means running the transition, which needs a
        // candidate header this path has no reason to build. What it catches
        // is the class that was actually exploited — a transfer that spends
        // nothing or pays no one, which no state can make applicable.
        //
        // The signature IS caught here — `admissible`'s Transfer arm verifies
        // every input's spend signature, under a comment in capitals saying
        // why, and refusing at the mempool door is what stops a garbage
        // signature propagating. What this does NOT catch is a transfer whose
        // inputs do not exist, or which fails conservation. Those still reach
        // the mempool and are dropped by the proposer, which is why the
        // proposer's guard is the one that carries liveness and this one only
        // reduces waste. Two checks, neither trusting the other.
        //
        // The epoch handed down is the WALL-CLOCK epoch, read here through
        // the `wall_slot()` METHOD (the clock against the manifest's genesis)
        // and never the `wall_slot` FIELD: the field is refreshed by the slot
        // loop, and on the RPC path — which converges here through
        // `serve_rpc`'s SendRawTransaction arm — nothing guarantees the loop
        // has run this tick. Why wall and not the head's epoch is argued at
        // the TransferV2 arm of `admissible` itself, next to the gate it
        // feeds. Gossip (`NetEvent::Transaction`) and RPC both land in this
        // one call, so one call site carries the whole decision.
        if let PosTransaction::FundedDeposit(deposit) = &tx {
            if self.state.admission_network_domain() != Some(deposit.network_domain) {
                return Err(Refusal::Invalid("funded deposit belongs to a different genesis manifest"));
            }
        }
        admissible(&tx, epoch_of(self.wall_slot())).map_err(Refusal::Invalid)?;
        if self.funded_mempool_conflict(&tx) {
            return Err(Refusal::Invalid("funded deposit conflicts with a pending input or validator key"));
        }
        self.validate_lifecycle_admission(&tx)?;
        // R7 M6: only now, with the incoming transaction confirmed
        // admissible, actually commit the eviction decided above.
        if let Some(lowest_key) = evict_at_capacity {
            self.mempool.remove(&lowest_key);
            self.mempool_admitted_at.remove(&lowest_key);
            self.mempool_evicted_low_fee = self.mempool_evicted_low_fee.saturating_add(1);
        }
        let mut frame = vec![net::FRAME_TX];
        frame.extend_from_slice(&key);
        // The retention clock starts at the head this node is on, not at the
        // wall slot: the TTL is "this many blocks of chain went by and never
        // took it", and a node whose clock runs ahead of its head must not
        // expire transactions it never had a chance to include.
        self.mempool_admitted_at
            .insert(key.clone(), self.head_slot_now());
        self.mempool.insert(key, tx);
        self.net.broadcast(frame);
        Ok(Admitted::New)
    }

    /// Transactions for the block this node is about to propose.
    ///
    /// Bounded by both [`MAX_TXS_PER_BLOCK`] and the consensus byte cap, and
    /// ordered by [`tx_tip_rate`] DESCENDING (R7 M6), ties broken on
    /// canonical bytes ascending.
    ///
    /// **This used to be the mempool's own key order** — lexicographic over
    /// the canonical transaction bytes, because the mempool is a `BTreeMap`
    /// keyed by exactly those bytes — which was not a fee market and was not
    /// neutral either: a sender who re-encoded until the bytes sorted low was
    /// included first, for free (A3 I3). The material for a real ordering
    /// was already on the wire the whole time: a `Transfer` carries `outputs`
    /// with values and a `tip_millisat_per_gas`, which `submit-tx` sets on
    /// every transaction it builds (main.rs).
    ///
    /// `epoch` is the epoch of the slot being produced, because the byte cap
    /// is flag-day gated. Packing against the wrong era is not symmetric: the
    /// old cap after activation only wastes capacity, but the new cap before
    /// it builds a block every other node rejects — so the epoch comes from
    /// the slot this proposer is building for, not from anything ambient.
    fn select_transactions(&self, epoch: u64) -> Vec<PosTransaction> {
        let cap = bloch_pos_committee::fee_market::max_block_tx_bytes(epoch);
        let mut out = Vec::new();
        let mut bytes = 0u64;
        // R7 M6: ordered by `tx_tip_rate` DESCENDING — not the mempool's
        // natural `BTreeMap` order (ascending canonical bytes), which made
        // inclusion order lexicographic over the encoded transaction and
        // therefore grindable for free (A3 I3: re-encode until the bytes
        // sort low, buy priority for nothing). Ties broken on canonical
        // bytes ascending — the SAME tie-break the old order used
        // exclusively — so the result is still fully deterministic and a
        // tie at the lowest-value end of the ordering (where grinding could
        // matter) is exactly where two proposers can disagree for free
        // without it costing security: candidates tied on fee are
        // interchangeable by construction.
        let mut ordered: Vec<(&Vec<u8>, &PosTransaction)> = self.mempool.iter().collect();
        ordered.sort_by(|(ka, ta), (kb, tb)| {
            tx_tip_rate(tb).cmp(&tx_tip_rate(ta)).then_with(|| ka.cmp(kb))
        });
        for (encoded, tx) in ordered {
            if out.len() >= MAX_TXS_PER_BLOCK {
                break;
            }
            // Budget by what CONSENSUS will count, not by wire length (audit
            // H-R7-2, 2026-09-05). The transition's byte cap (step 10b) sums
            // each transfer's DECLARED `tx_bytes` — `charge.tx_bytes`, never
            // `encoded.len()` — so packing by wire length let one small
            // transfer declaring a block's worth of bytes make every
            // selection carrying it over-cap. The probe loop then popped and
            // barred the innocent tail one transaction at a time
            // (`REJECTION_TTL_SLOTS` each): a censorship machine costing the
            // attacker one fee. The `max` keeps the wire length as the floor
            // — consensus refuses under-declaration (`UnderdeclaredSize`),
            // and a non-transfer charges zero declared bytes, so the floor
            // only ever over-budgets, and an over-budgeted block is merely
            // smaller, never invalid.
            let declared = match tx {
                PosTransaction::Transfer { tx_bytes, .. }
                | PosTransaction::TransferV2 { tx_bytes, .. } => *tx_bytes,
                PosTransaction::FundedDeposit(tx) => tx.tx_bytes,
                _ => 0,
            };
            let n = (encoded.len() as u64).max(declared);
            if bytes.saturating_add(n) > cap {
                break;
            }
            bytes = bytes.saturating_add(n); // checked against `cap` just above
            out.push(tx.clone());
        }
        out
    }

    /// Apply one block that extends the current head. True on success.
    fn apply_canonical(&mut self, env: &BlockEnvelope) -> bool {
        let id = env.block_id();
        let envelope = ProposalEnvelope {
            header: env.header.clone(),
            proposer_sig: env.proposer_sig.clone(),
        };
        let before = self.state.finality();
        let txs = match body_transactions(env) {
            Ok(t) => t,
            Err(e) => {
                eprintln!("apply refused: {e}");
                return false;
            }
        };
        match self
            .tr
            .apply_block(&self.state, &envelope, &env.body.attestations, &txs)
        {
            Ok(post) => {
                self.state.set(post);
                // Snapshot for the reorg path. Free: this is the state that
                // was just built, kept by handle, not copied.
                let snapshot = self.state.arc();
                self.remember_state(*id.as_bytes(), snapshot);
                self.canonical.insert(*id.as_bytes());
                self.chain.push((env.header.slot, id));
                self.head_slot.store(env.header.slot, Ordering::Relaxed);
                self.last_applied_ms = now_ms();
                // Finality latch (F-03): arm/raise the floor the moment the
                // adopted state finalizes something new. Outside `if live` on
                // purpose — boot replay must rebuild the latch too.
                self.ratchet_finalized();
                // Counted, because `advance` needs to tell this shrinkage
                // apart from the `retain` four lines down. These attestations
                // leave the loose pool and stay visible to fork choice, which
                // observes every stored block's body as well as the pool, and
                // `env` is one of the stored blocks. The `retain` below drops
                // attestations nothing else carries — that one fork choice
                // does see.
                for a in &env.body.attestations {
                    if self
                        .pool
                        .remove(&(a.validator, a.data.signing_root()))
                        .is_some()
                    {
                        self.fc_covered_removals = self.fc_covered_removals.saturating_add(1);
                    }
                }
                // Included is included — drop them from the mempool by the
                // same bytes they were keyed under.
                for encoded in &env.body.transactions {
                    self.mempool.remove(encoded);
                }
                // R4 F-11: record where each transaction landed, for
                // `gettxstatus`. After the mempool drop (a transaction is
                // "included", not "pending", the instant this runs) and
                // before anything below could return early.
                self.note_tx_slots(env.header.slot, &txs);
                // AFTER the inclusion drop above and BEFORE the epoch
                // sweep: the head has just moved, so this is the moment the
                // TTL is measured against, and anything this block carried is
                // already out of the pool and must not be counted as expired.
                self.revalidate_lifecycle_mempool();
                self.evict_stale_mempool();
                let cur_e = epoch_of(self.state.slot());
                self.pool.retain(|_, a| epoch_of(a.data.slot) >= cur_e);
                // Once per epoch: drop what can no longer apply. On a
                // validator this only anticipates the drop loop; on an
                // observer it is the ONLY thing that ever empties the pool.
                self.sweep_mempool(cur_e);

                crate::metrics::NodeMetrics::inc(&crate::metrics::NODE.blocks_applied_total);
                if self.live {
                    if let Err(e) = self.store.append(env) {
                        // Counted before the exit: a scrape racing the
                        // shutdown, or the operator curl-ing /metrics from
                        // the crash loop, sees WHY (ENOSPC = disk full).
                        crate::metrics::NodeMetrics::inc(
                            &crate::metrics::NODE.store_append_failures_total,
                        );
                        eprintln!("FATAL: block log append failed: {e}");
                        std::process::exit(1);
                    }
                    let after = self.state.finality();
                    // The head root is FREE here, and it used to cost a whole
                    // state-root computation.
                    //
                    // `apply_block` returns `Ok(post)` on exactly one
                    // condition: `post.compute_root() == header.state_root`
                    // (transition.rs step 12). `self.state` IS that `post`.
                    // So the header field printed here is bit-for-bit the
                    // value `self.state.state_root()` recomputed — the same
                    // number, from the check that already ran, instead of a
                    // second full walk of the state tree for a log line.
                    //
                    // A proposer paid this three times a slot: once stamping
                    // its own header, once inside `apply_block`'s check, and
                    // once here. This is the third one, deleted. The other
                    // two are the producer=validator seam and must both stay.
                    println!(
                        "[slot {}] applied {} by v{} — head root {}, justified e{}, finalized e{}",
                        env.header.slot,
                        crate::codec::hex8(id.as_bytes()),
                        env.header.proposer_index,
                        crate::codec::hex8(&env.header.state_root),
                        after.justified.epoch,
                        after.finalized.epoch,
                    );
                    if after.justified.epoch > before.justified.epoch {
                        println!(
                            "*** JUSTIFIED epoch {} ({})",
                            after.justified.epoch,
                            crate::codec::hex8(&after.justified.root)
                        );
                    }
                    if after.finalized.epoch > before.finalized.epoch {
                        crate::metrics::NodeMetrics::set(
                            &crate::metrics::NODE.last_finality_advance_unix,
                            crate::metrics::now_unix(),
                        );
                        println!(
                            "*** FINALIZED epoch {} ({})",
                            after.finalized.epoch,
                            crate::codec::hex8(&after.finalized.root)
                        );
                        // New own finality may now reach the anchor's epoch.
                        self.enforce_ws_anchor();
                    }
                }
                true
            }
            Err(err) => {
                crate::metrics::NodeMetrics::inc(&crate::metrics::NODE.blocks_rejected_total);
                if self.live {
                    eprintln!(
                        "reject {} at slot {}: {err:?}",
                        crate::codec::hex8(id.as_bytes()),
                        env.header.slot
                    );
                }
                false
            }
        }
    }

    /// Keep a canonical block's post-state for the reorg path. Oldest out
    /// first; see [`REORG_STATE_WINDOW`] for why the window is small.
    fn remember_state(&mut self, id: [u8; 32], state: Arc<CommittedState>) {
        self.recent_states.push_back((id, state));
        while self.recent_states.len() > REORG_STATE_WINDOW {
            self.recent_states.pop_front();
        }
    }

    /// The committed post-state of a canonical block: from the snapshot ring
    /// if it is still retained, otherwise by replaying to it.
    ///
    /// The two are the same value, and that is not an assumption — a block's
    /// post-state is `apply_block` folded over its ancestry from genesis, the
    /// fold is deterministic (the pure crate's whole posture), and both
    /// branches here name the same block. The snapshot is that answer already
    /// computed once; the replay recomputes it. Retention is therefore a
    /// speed decision with no consensus content, which is exactly the
    /// property `reorg_state_tests` pins.
    fn state_at_canonical(&self, id: [u8; 32]) -> Arc<CommittedState> {
        if let Some((_, st)) = self.recent_states.iter().find(|(bid, _)| *bid == id) {
            return Arc::clone(st);
        }
        Arc::new(self.replay_to(id))
    }

    /// Rebuild a canonical block's post-state from genesis, re-executing the
    /// whole prefix through the same transition.
    ///
    /// This is what `do_reorg` used to do unconditionally, kept whole. It is
    /// now the fallback for a reorg deeper than [`REORG_STATE_WINDOW`], and
    /// it is also the reference the snapshot path is tested against — the
    /// slow path staying correct is what lets the fast path be small.
    // The four `expect`s below each name a canonical-chain invariant — the
    // target is canonical, canonical blocks are stored (`prune` skips them),
    // their bodies decoded and applied when they were adopted — and there is
    // no state to fall back to when replaying a prefix that already applied.
    // They stay COUNTED by the hardened ratchet on purpose: a panic site with
    // a hand proof is exactly what the ratchet exists to keep in view.
    fn replay_to(&self, id: [u8; 32]) -> CommittedState {
        let cut = self
            .chain
            .iter()
            .position(|(_, cid)| cid.as_bytes() == &id)
            .expect("replay target is canonical");
        let prefix: Vec<BlockEnvelope> = self.chain[1..=cut]
            .iter()
            .map(|(_, cid)| {
                self.blocks
                    .get(cid.as_bytes())
                    .expect("canonical block stored")
                    .clone()
            })
            .collect();
        let mut st = self.manifest.genesis_state();
        for env in &prefix {
            let envelope = ProposalEnvelope {
                header: env.header.clone(),
                proposer_sig: env.proposer_sig.clone(),
            };
            let txs = body_transactions(env)
                .expect("a canonical block's body decoded when it was applied");
            st = self
                .tr
                .apply_block(&st, &envelope, &env.body.attestations, &txs)
                .expect("canonical prefix replay cannot fail (it applied before)");
        }
        st
    }

    // ── The finality latch (finding F-03) ───────────────────────────────────

    /// Ratchet [`Engine::finalized_latch`] up to the state's current
    /// finalized checkpoint. Called after every canonical adoption — apply
    /// and reorg — and it only ever moves the latch UP: a branch whose
    /// replayed state reports a lower finalized epoch (every reorg's state
    /// does, transiently) leaves the latch where it was. That asymmetry is
    /// the entire fix for the finalized 6 -> 4 -> 2 -> 0 rewind.
    fn ratchet_finalized(&mut self) {
        let fin = self.state.finality().finalized;
        // Genesis is trivially final and imposes no floor; and a root this
        // node cannot place on its canonical chain cannot define one either.
        let Some(h) = self.height_of(&fin.root) else {
            return;
        };
        if h == 0 {
            return;
        }
        match self.finalized_latch {
            Some((floor, _)) if floor >= h => {}
            _ => self.finalized_latch = Some((h, fin.root)),
        }
    }

    /// Would truncating the canonical chain at `ancestor` cut below the
    /// latch? `ancestor` at the latch height itself is fine — the finalized
    /// block stays canonical — so the comparison is strict.
    ///
    /// R3 M-1: `finality_rewind_override` does not silently disable the
    /// latch — it is checked here, once, and every instant it actually
    /// changes the answer (a cut that WOULD have been refused is instead
    /// allowed) is logged loudly, naming the exact condition. An operator who
    /// set the override sees, in the log, exactly when and why it fired —
    /// which is the difference between "an acknowledged flag day" and "a
    /// silent hole in the safety property the latch exists for".
    ///
    /// Returns the latch `(height, root)` the cut would violate — `Some` is
    /// "refuse", and it carries exactly what `refuse_finality_rewind` needs
    /// to say so, which is why no caller ever has to re-read the latch.
    fn cut_below_finalized_latch(&self, ancestor: &[u8; 32]) -> Option<(u64, [u8; 32])> {
        let (floor, root) = self.finalized_latch?;
        let would_cut = self.height_of(ancestor).is_some_and(|h| h < floor);
        if would_cut && self.finality_rewind_override {
            if self.live {
                eprintln!(
                    "FINALITY_LATCH: BLOCH_ALLOW_FINALITY_REWIND is set — ALLOWING a reorg \
                     below this node's finalized checkpoint (height {floor}, {}) that would \
                     otherwise have been refused. This must only happen with a human \
                     operator's deliberate, informed consent.",
                    crate::codec::hex8(&root),
                );
            }
            return None;
        }
        would_cut.then_some((floor, root))
    }

    /// Refuse a reorg that would rewind this node below its own finalized
    /// checkpoint, and park the branch that demanded it (R3 M-1).
    ///
    /// The branch is removed from `self.blocks` — the fork-choice input map —
    /// regardless: a branch that conflicts with this node's finality can
    /// never legitimately be adopted later (adopting it IS the rewind), so
    /// leaving it there would let the heaviest-branch walk keep re-selecting
    /// and re-refusing the same head on every tick, forever, even with no new
    /// bytes arriving. That much is unchanged from before this fix.
    ///
    /// What changes is that the blocks are not simply dropped: they are
    /// parked in [`Engine::parked_refused_finality`], bounded and FIFO, so a
    /// re-offer of the SAME branch is recognised and refused at the door
    /// (`ingest_one`) before any signature work — never re-authenticated,
    /// never re-run through a whole `advance` cycle, never silently
    /// re-refused in a way this node cannot distinguish from the first time.
    fn refuse_finality_rewind(&mut self, latch: (u64, [u8; 32]), branch: &[BlockEnvelope]) {
        self.finality_rewinds_refused = self.finality_rewinds_refused.saturating_add(1);
        let (floor, root) = latch;
        if self.live {
            eprintln!(
                "FINALITY_LATCH: refused a reorg below this node's finalized checkpoint \
                 (height {floor}, {}); parking the {} conflicting block(s) (cap {}, {} \
                 currently parked) instead of deleting them, so a re-offer is refused at \
                 the door rather than re-judged from scratch. Refusals so far: {}. If this \
                 rewind is EXPECTED, restart with --allow-finality-rewind or \
                 BLOCH_ALLOW_FINALITY_REWIND=1.",
                crate::codec::hex8(&root),
                branch.len(),
                MAX_PARKED_REFUSED_FINALITY,
                self.parked_refused_finality.len(),
                self.finality_rewinds_refused,
            );
        }
        for env in branch {
            let id = *env.block_id().as_bytes();
            self.blocks.remove(&id);
            if self.parked_refused_finality.iter().any(|(seen, _)| *seen == id) {
                continue;
            }
            while self.parked_refused_finality.len() >= MAX_PARKED_REFUSED_FINALITY {
                self.parked_refused_finality.pop_front();
            }
            self.parked_refused_finality.push_back((id, env.clone()));
        }
    }

    /// Adopt `branch`, attached at canonical `ancestor`. True if adopted;
    /// false if a branch block failed validation (it is removed).
    ///
    /// **From the fork point, not from genesis.** This used to rebuild the
    /// genesis state and re-execute the entire canonical prefix on every
    /// reorg at any depth, so giving one block back and taking one cost a
    /// full replay of the chain. The branch is still validated block by block
    /// through the real `apply_block` — nothing about what gets adopted
    /// changes; only where the fold starts does.
    fn do_reorg(&mut self, ancestor: [u8; 32], branch: Vec<BlockEnvelope>) -> bool {
        // Instrumentation only; compiled out without `perf-timing`. Self time
        // only — the `apply_block` calls below are attributed to their own
        // phases, so this reads as "reorg overhead beyond re-execution". Note
        // that since the fold now starts at the fork point, the replay this
        // used to charge here is mostly gone rather than moved.
        let _perf = bloch_pos_committee::perf::span(bloch_pos_committee::perf::Phase::Reorg);
        // `ancestor` was found by walking the canonical chain, so it is on it.
        // The `else` is unreachable; it refuses the reorg (the caller's
        // "invalid branch" answer) instead of killing the node.
        let Some(cut) = self.chain.iter().position(|(_, id)| id.as_bytes() == &ancestor) else {
            eprintln!(
                "reorg refused: ancestor {} is not on the canonical chain",
                crate::codec::hex8(&ancestor)
            );
            return false;
        };
        // cannot overflow: cut < chain.len() (it is a position in it).
        #[allow(clippy::arithmetic_side_effects)]
        let after_cut = cut + 1;

        // Finality latch (F-03): `finalized` is a downward ratchet. A reorg
        // whose fork point sits below this node's own highest finalized
        // checkpoint would truncate finalized history, so it is refused
        // BEFORE any replay is paid for it — however heavy the branch, and
        // whatever the branch's own state claims about finality. `advance`
        // screens the same predicate earlier; this is the authoritative check
        // on the only path that can truncate `self.chain`.
        if let Some(latch) = self.cut_below_finalized_latch(&ancestor) {
            self.refuse_finality_rewind(latch, &branch);
            return false;
        }

        let base = self.state_at_canonical(ancestor);
        // Post-states of the branch, so the ring is refilled for the branch
        // that just won without recomputing anything.
        let mut applied: Vec<([u8; 32], Arc<CommittedState>)> = Vec::with_capacity(branch.len());
        for env in &branch {
            let envelope = ProposalEnvelope {
                header: env.header.clone(),
                proposer_sig: env.proposer_sig.clone(),
            };
            let txs = match body_transactions(env) {
                Ok(t) => t,
                Err(e) => {
                    eprintln!("reorg candidate rejected at slot {}: {e}", env.header.slot);
                    return false;
                }
            };
            let pre: &CommittedState = applied.last().map_or(&*base, |(_, st)| st);
            match self
                .tr
                .apply_block(pre, &envelope, &env.body.attestations, &txs)
            {
                Ok(post) => {
                    // R4 F-11: the whole branch is guaranteed adopted from
                    // here — every remaining block in it either validates
                    // too or this function returns `false` before any of
                    // this is observable — so recording now, rather than in
                    // a second pass after `self.chain` is rebuilt below, does
                    // not risk indexing a branch that never lands.
                    self.note_tx_slots(env.header.slot, &txs);
                    applied.push((*env.block_id().as_bytes(), Arc::new(post)));
                }
                Err(err) => {
                    eprintln!(
                        "reorg candidate {} invalid at slot {}: {err:?}",
                        crate::codec::hex8(env.block_id().as_bytes()),
                        env.header.slot
                    );
                    self.blocks.remove(env.block_id().as_bytes());
                    return false;
                }
            }
        }
        // R4 F-11: the OLD canonical tail is about to leave canonical
        // history (below). Any transaction it included that is NOT
        // re-included by the winning branch above must stop being reported
        // as "included" at a slot this node's chain no longer contains —
        // BEFORE the truncate, while these blocks are still reachable by id.
        let stale: Vec<(u64, Vec<PosTransaction>)> = self.chain[after_cut..]
            .iter()
            .filter_map(|(_, id)| self.blocks.get(id.as_bytes()))
            .filter_map(|env| body_transactions(env).ok().map(|txs| (env.header.slot, txs)))
            .collect();
        for (slot, txs) in stale {
            self.forget_tx_slots_if_stale(slot, &txs);
        }
        let st = applied
            .last()
            .map_or_else(|| Arc::clone(&base), |(_, st)| Arc::clone(st));

        // Adopt.
        let old_head = self.head_slot_now();
        self.state.set_arc(st);
        // The ring described the branch that just lost. Rebuild it from the
        // one that won: `ancestor` is canonical again by construction, and
        // the branch's post-states were just computed above.
        self.recent_states.clear();
        self.remember_state(ancestor, base);
        for (id, post) in applied {
            self.remember_state(id, post);
        }
        self.chain.truncate(after_cut);
        let mut canonical: BTreeSet<[u8; 32]> =
            self.chain.iter().map(|(_, id)| *id.as_bytes()).collect();
        for env in &branch {
            let id = env.block_id();
            canonical.insert(*id.as_bytes());
            self.chain.push((env.header.slot, id));
        }
        self.canonical = canonical;
        self.head_slot
            .store(self.head_slot_now(), Ordering::Relaxed);
        self.last_applied_ms = now_ms();
        // Finality latch (F-03): the adopted branch's state may finalize
        // FURTHER than the old branch did — ratchet up if so. It may equally
        // report LESS (a fork-point state always does); the ratchet ignores
        // that, which is what keeps the latch monotone across reorgs.
        self.ratchet_finalized();
        let cur_e = epoch_of(self.state.slot());
        self.pool.retain(|_, a| epoch_of(a.data.slot) >= cur_e);
        self.revalidate_lifecycle_mempool();
        if self.live {
            let canonical_envs: Vec<BlockEnvelope> = self.chain[1..]
                .iter()
                .map(|(_, id)| self.blocks.get(id.as_bytes()).expect("stored").clone())
                .collect();
            if let Err(e) = self.store.rewrite(&canonical_envs) {
                eprintln!("FATAL: block log rewrite failed: {e}");
                std::process::exit(1);
            }
            // Free for the same reason as `apply_canonical`'s: every block
            // in `branch` passed `apply_block`, so the adopted head's header
            // carries the post-state root already checked against it. Only a
            // reorg to an EMPTY branch has no header to read it from, and
            // only when the ancestor is genesis is it not in `blocks`.
            let head_root = match branch.last() {
                Some(env) => env.header.state_root,
                None => self
                    .blocks
                    .get(&ancestor)
                    .map(|env| env.header.state_root)
                    .unwrap_or_else(|| self.state.state_root()),
            };
            println!(
                "REORG: adopted branch of {} blocks at ancestor {} (head slot {} -> {}), root {}",
                branch.len(),
                crate::codec::hex8(&ancestor),
                old_head,
                self.head_slot_now(),
                crate::codec::hex8(&head_root),
            );
            // A reorg can move the finalized root at the anchor's epoch.
            self.enforce_ws_anchor();
        }
        true
    }

    // ── Attestation admission, through the pure crate's gossip policy ───────

    /// Run one arriving attestation through
    /// [`AttestationPool`](bloch_pos_committee::gossip::AttestationPool) and
    /// report the resulting verdict to the transport.
    ///
    /// The mapping is the one `gossip.rs` states, and the type split is what
    /// enforces it: `Accept` relays and feeds consensus, `Ignore` and `Hold`
    /// drop in silence, and **only `Reject` may reach a peer penalty**. That
    /// distinction is not a nicety — the 2026-08-07 mesh collapsed twice from
    /// scoring honest peers, and the commonest honest event on this network
    /// (an attestation arriving milliseconds before the block it votes for) is
    /// precisely the one a naive implementation calls invalid.
    fn on_attestation(&mut self, att: Attestation, origin: Origin, wall_epoch: u64) {
        let e = epoch_of(att.data.slot);
        // Narrower than `gossip.rs`'s own two-epoch window, and for a reason
        // that belongs to the node, not the policy: committee membership must
        // come from committed state, and this node can only roll its canonical
        // state *forward* (`rolled_to`). It therefore cannot derive the
        // committee of an epoch already behind its head, so an attestation
        // from one is unjudgeable rather than invalid — Ignore, never Reject.
        // Reconstructing past-epoch committees (the pool would then accept the
        // full 64-slot window) needs per-epoch seed/roster history, which is
        // storage work, not policy work.
        if e != wall_epoch && e != wall_epoch.saturating_add(1) {
            self.net.report(&origin, Verdict::Ignore);
            return;
        }
        // `att_pool` is moved out for the call so the lookups below can borrow
        // the chain immutably; it is put back before returning.
        let mut pool = std::mem::take(&mut self.att_pool);
        let decision = self.judge(&mut pool, att.clone(), e);
        self.att_pool = pool;
        self.apply_decision(att, decision, &origin);
    }

    /// One pass of the pure pipeline: window → checkpoint sanity → dedup and
    /// equivocation cap → committee membership → blocks known → signature.
    fn judge(&self, pool: &mut AttestationPool, att: Attestation, epoch: u64) -> GossipDecision {
        let rolled = self.rolled_to(epoch);
        let roster = rolled.active_validators();
        // THE SEED COMES FROM THE ATTESTATION'S BRANCH, not from this node's
        // head. If we cannot reach that branch we cannot derive the committee,
        // and an attestation we cannot judge is Ignored — never Rejected, and
        // therefore never scored against the peer that relayed it. A syncing
        // node used to Reject its way through every attestation on the network
        // and graylist the very peers feeding it blocks.
        //
        // TWO different "no seed" cases, and collapsing them loses votes:
        //
        //   * the target block is one we simply have not received yet. That is
        //     the ORDINARY epoch-boundary race the pool already handles by
        //     PARKING the attestation (`gossip.rs` step 5) and replaying it
        //     when the block lands. Ignoring it instead silently drops the
        //     first slots' votes of every epoch — the very fork-choice weight
        //     the anchor exists to preserve. So we let the pool reach step 5
        //     and hold, with a membership lookup that ADMITS rather than
        //     rejects: we do not know the committee, and "do not know" must
        //     not read as "not a member". The real committee check runs on
        //     release, off the real seed.
        //
        //   * the target block IS known but its ancestry is not reachable from
        //     what this node stores (a pruned or partially-synced view).
        //     Nothing will arrive to unpark it, so parking would only burn one
        //     of the pending slots. Ignore, and score nobody.
        //
        // The cost of the first case is that a non-member can occupy a pending
        // slot until its target arrives. The pool is hard-bounded with FIFO
        // eviction and per-peer token buckets upstream, so that is bounded
        // churn, not unbounded memory — a strictly better trade than dropping
        // every boundary vote.
        let known_root =
            |root: &[u8; 32]| self.canonical.contains(root) || self.blocks.contains_key(root);
        let seed = match self.seed_for_attestation(&att.data.target_root, epoch) {
            Some(seed) => Some(seed),
            None if !known_root(&att.data.target_root) => None,
            None => {
                return GossipDecision::Ignore(
                    bloch_pos_committee::gossip::IgnoreReason::Unjudgeable,
                )
            }
        };
        let committees_at = |slot: u64| match seed {
            Some(seed) => committees::committee_for_slot(&seed, slot, &roster),
            // Unjudgeable-but-parkable: admit, so step 5 parks on the missing
            // target instead of step 4 rejecting on a committee we cannot
            // compute. Every index in the roster, ascending — `committee` is
            // consumed by `binary_search`, so it must stay sorted.
            None => {
                let mut all: Vec<u32> = roster.iter().map(|v| v.index).collect();
                all.sort_unstable();
                all
            }
        };
        // "Do we have this block?" — canonical ids include genesis, which is
        // synthesized and never stored as an envelope; `blocks` holds every
        // structurally-valid block seen, canonical or not. A vote for a block
        // on a losing branch is still a vote we can verify.
        let known =
            |root: &[u8; 32]| self.canonical.contains(root) || self.blocks.contains_key(root);
        // Keys from `rolled`, the SAME projection that produced `roster` and
        // therefore `committees_at`. Membership and key must come from one
        // snapshot; the old code took membership from here and the key from a
        // boot-time genesis table, which is the inconsistency being removed.
        pool.process(att, self.wall_slot, &committees_at, &known, &self.verifier, &*rolled)
    }

    fn apply_decision(&mut self, att: Attestation, decision: GossipDecision, origin: &Origin) {
        match decision {
            GossipDecision::Accept { slashing_candidate } => {
                if let Some(ev) = slashing_candidate {
                    self.report_equivocation((*ev).into());
                }
                // R6 HIGH-8: an accepted attestation is a real, signature-
                // checked duty by `att.validator` — exactly the class of
                // sighting doppelgänger protection exists to catch.
                self.note_possible_doppelganger(att.validator, att.data.slot);
                self.pool
                    .insert((att.validator, att.data.signing_root()), att);
                self.net.report(origin, Verdict::Accept);
            }
            GossipDecision::Ignore(_) => self.net.report(origin, Verdict::Ignore),
            GossipDecision::Hold { .. } => {
                // Parked. NOT relayed: this node does not forward what it
                // cannot yet validate. It is replayed by `release_held` when
                // the block lands, and relayed then.
                self.net.report(origin, Verdict::Ignore);
            }
            GossipDecision::Reject(reason) => {
                eprintln!("attestation from v{} REJECTED: {reason:?}", att.validator);
                self.net.report(origin, Verdict::Reject);
            }
        }
    }

    /// A block landed: replay every attestation that was waiting on it.
    ///
    /// Called after the block is queryable, which is what
    /// [`AttestationPool::on_block`] requires — earlier and the waiters would
    /// simply be re-held. Released Accepts are relayed here, since they were
    /// deliberately not relayed while parked.
    fn release_held(&mut self, root: [u8; 32]) {
        if self.att_pool.pending_len() == 0 {
            return;
        }
        let mut pool = std::mem::take(&mut self.att_pool);
        let released = {
            let rolled_epoch = epoch_of(self.wall_slot);
            let rolled = self.rolled_to(rolled_epoch);
            let roster = rolled.active_validators();
            // Anchored to the BLOCK THAT JUST ARRIVED, not to this node's
            // head. Everything released by this call was parked waiting for
            // `root`, so `root` is on the released attestation's own branch
            // (it is either its head or its target, and the target is an
            // ancestor of the head), and the boundary mix read off `root`'s
            // ancestry is the one that branch's transition will use. Judging
            // the release against this node's head is the same defect the
            // ingest path was fixed for on 2026-08-24, left standing on the
            // path that decides whether a parked vote is ever counted.
            //
            // KNOWN GAP, deliberately not papered over: `on_block` re-runs the
            // whole pipeline through ONE `CommitteeLookup` closure that sees
            // only a slot, so a single seed serves every attestation released
            // in this batch. That is right whenever they are on one branch,
            // which is the case that actually occurs (they were all waiting on
            // the same root); it is wrong if a future caller batches roots.
            // Fixing it properly means letting the lookup see the attestation,
            // which is a `gossip.rs` signature change.
            let seed = self
                .seed_for_attestation(&root, rolled_epoch)
                .unwrap_or_else(|| Self::seed_for(&rolled, rolled_epoch));
            let committees_at = |slot: u64| committees::committee_for_slot(&seed, slot, &roster);
            let known = |r: &[u8; 32]| self.canonical.contains(r) || self.blocks.contains_key(r);
            pool.on_block(
                &root,
                self.wall_slot,
                &committees_at,
                &known,
                &self.verifier,
                // Same snapshot `roster` and the seed came from.
                &*rolled,
            )
        };
        self.att_pool = pool;
        for (att, decision) in released {
            if let GossipDecision::Accept { .. } = decision {
                let frame = net::att_frame(&att);
                self.pool
                    .insert((att.validator, att.data.signing_root()), att);
                if self.live {
                    // Relay now: it was held, so nobody downstream got it from
                    // us. A duplicate publish is refused locally and costs
                    // nothing.
                    self.net.broadcast(frame);
                }
            }
        }
    }

    // ── RPC service ─────────────────────────────────────────────────────────
    //
    // Answered on the consensus thread, between duties. Every method reads the
    // committed state this thread owns, so no query can observe a half-applied
    // block and no reader can be served a stale copy. The formatting lives in
    // `rpc.rs` as free functions of their inputs; what is here is only the
    // lookup — which block, which record, which outputs.

    /// The slot the wall clock is in, by the manifest's own cadence.
    ///
    /// `max(1)` on the divisor because a zero `slot_ms` in a hand-edited
    /// manifest must not turn a query into a division-by-zero panic. The slot
    /// loop would reach the same division first, but "would panic elsewhere" is
    /// not a reason for this path to panic here.
    // cannot divide by zero: the divisor is `.max(1)`.
    #[allow(clippy::arithmetic_side_effects)]
    fn wall_slot(&self) -> u64 {
        #[cfg(test)]
        if let Some(slot) = validator_lifecycle::test_wall_slot() { return slot; }
        now_ms().saturating_sub(self.manifest.genesis_time_ms) / self.manifest.slot_ms.max(1)
    }

    /// Wall-clock seconds a slot corresponds to. Display only — derived from
    /// the manifest's cadence, never a consensus field (the header has no time).
    fn slot_timestamp_secs(&self, slot: u64) -> u64 {
        self.manifest
            .genesis_time_ms
            .saturating_add(slot.saturating_mul(self.manifest.slot_ms))
            / 1000
    }

    /// Canonical height of a block id — its position on the canonical chain,
    /// genesis at 0. `None` for a block this node has stored but not adopted.
    fn height_of(&self, id: &[u8; 32]) -> Option<u64> {
        self.chain
            .iter()
            .position(|(_, cid)| cid.as_bytes() == id)
            .map(|p| p as u64)
    }

    /// Slot of a canonical block named by root, if this node has it canonical.
    fn slot_of_canonical_root(&self, root: &[u8; 32]) -> Option<u64> {
        self.chain
            .iter()
            .find(|(_, id)| id.as_bytes() == root)
            .map(|(s, _)| *s)
    }

    /// Where a block stands against this node's own checkpoints.
    ///
    /// The comparison is by slot against the checkpoint blocks' slots, not by
    /// epoch: the checkpoint convention this node attests under puts the
    /// checkpoint at the last block strictly *before* an epoch's first slot, so
    /// "in a finalized epoch" and "at or below the finalized checkpoint" are
    /// different sets and only the second is what finality actually covers.
    fn finality_of(&self, slot: u64, canonical: bool) -> Finality {
        if !canonical {
            return Finality::NotCanonical;
        }
        let fin = self.state.finality();
        if self
            .slot_of_canonical_root(&fin.finalized.root)
            .is_some_and(|s| slot <= s)
        {
            Finality::Finalized
        } else if self
            .slot_of_canonical_root(&fin.justified.root)
            .is_some_and(|s| slot <= s)
        {
            Finality::Justified
        } else {
            Finality::Canonical
        }
    }

    /// Canonical height of the finalized checkpoint — the height below which
    /// this node's history is settled.
    fn finalized_height(&self) -> Option<u64> {
        self.height_of(&self.state.finality().finalized.root)
    }

    /// The genesis block as an envelope.
    ///
    /// Genesis is synthesised from the manifest and never stored in `blocks`
    /// (`ingest` refuses slot 0), so a lookup that lands on it has nothing to
    /// return. Rebuilding it from `Manifest::genesis_header` — the same
    /// function `genesis_id` derives identity from — lets height 0 answer in
    /// the ordinary block shape instead of being a special case clients must
    /// handle.
    fn genesis_envelope(&self) -> BlockEnvelope {
        BlockEnvelope {
            header: self.manifest.genesis_header(),
            proposer_sig: Vec::new(),
            body: Body {
                transactions: Vec::new(),
                attestations: Vec::new(),
            },
        }
    }

    /// Look up one block by id, genesis included.
    fn envelope_by_id(&self, id: &[u8; 32]) -> Option<BlockEnvelope> {
        if self.chain[0].1.as_bytes() == id {
            return Some(self.genesis_envelope());
        }
        self.blocks.get(id).cloned()
    }

    fn block_reply(&self, env: &BlockEnvelope) -> Json {
        let id = *env.block_id().as_bytes();
        let canonical = self.canonical.contains(&id);
        rpc::block_json(
            env,
            self.height_of(&id),
            self.finality_of(env.header.slot, canonical),
            self.slot_timestamp_secs(env.header.slot),
        )
    }

    fn serve_rpc(&mut self, req: RpcRequest) -> RpcResult {
        match req {
            RpcRequest::ChainInfo => Ok(rpc::chain_info_json(
                &self.state,
                &self.head_id(),
                self.head_state_root(),
                self.head_height(),
                self.finalized_height(),
                self.wall_slot(),
                self.state.validator_count(),
                self.mempool.len(),
                self.blocks.len(),
                // Which transport this process is on, and how many peers each
                // of its stacks has. Read from the live `Net`, not from the
                // config, so it cannot disagree with what is bound.
                self.net.transport_name(),
                self.net.peer_counts(),
            )),

            RpcRequest::BlockCount => {
                let fin = self.state.finality();
                Ok(rpc::block_count_json(
                    self.head_height(),
                    self.head_slot_now(),
                    self.finalized_height(),
                    fin.justified.epoch,
                    fin.finalized.epoch,
                ))
            }

            RpcRequest::BlockBySlot(slot) => {
                let Some((_, id)) = self.chain.iter().find(|(s, _)| *s == slot) else {
                    // A slot with no canonical block is the ordinary PoS case —
                    // a proposer missed its turn — and is reported as its own
                    // code so a scanner advances instead of alerting.
                    return Err(RpcError::new(
                        rpc::SLOT_EMPTY,
                        format!(
                            "no canonical block at slot {slot} (head is at slot {}); \
                             a slot with no block is a missed proposal, not an error",
                            self.head_slot_now()
                        ),
                    ));
                };
                let id = *id.as_bytes();
                let env = self.envelope_by_id(&id).ok_or_else(|| {
                    RpcError::new(
                        rpc::BLOCK_NOT_FOUND,
                        format!("slot {slot} names a block this node no longer stores"),
                    )
                })?;
                Ok(self.block_reply(&env))
            }

            RpcRequest::BlockById(id) => {
                let env = self.envelope_by_id(&id).ok_or_else(|| {
                    RpcError::new(
                        rpc::BLOCK_NOT_FOUND,
                        format!(
                            "no block {} is known to this node",
                            crate::codec::hex32(&id)
                        ),
                    )
                })?;
                Ok(self.block_reply(&env))
            }

            RpcRequest::ValidatorByKey(hash) => {
                let index = self.state.validator_index_by_hash(&hash).ok_or_else(||
                    RpcError::new(rpc::VALIDATOR_NOT_FOUND, "validator public-key hash is not registered"))?;
                self.serve_rpc(RpcRequest::Validator(index))
            }
            RpcRequest::ValidatorAdmission => Ok(rpc::validator_admission_json(&self.state)),
            RpcRequest::Validator(index) => {
                let rec = self.state.validator_record(index).ok_or_else(|| {
                    RpcError::new(
                        rpc::VALIDATOR_NOT_FOUND,
                        format!(
                            "validator {index} is not in the committed registry ({} registered)",
                            self.state.validator_count()
                        ),
                    )
                })?;
                let effective = self
                    .state
                    .active_validators()
                    .iter()
                    .find(|v| v.index == index)
                    .map(|v| v.effective_stake);
                Ok(rpc::validator_lifecycle_json(&self.state, &rec, effective))
            }

            RpcRequest::ValidatorCount => Ok(Json::obj(vec![
                ("total", Json::u(self.state.validator_count() as u64)),
                (
                    "active",
                    Json::u(self.state.active_validators().len() as u64),
                ),
                (
                    "total_active_stake_sat",
                    Json::sat(self.state.total_active_stake_sat()),
                ),
            ])),

            RpcRequest::Balance(script_hash) => Ok(rpc::balance_json(&self.state, &script_hash)),

            RpcRequest::Utxos { script_hash, limit } => {
                Ok(rpc::utxos_json(&self.state, &script_hash, limit))
            }

            RpcRequest::TxOut { txid, vout } => Ok(rpc::txout_json(&self.state, &txid, vout)),

            RpcRequest::SendRawTransaction(tx) => match self.on_transaction(tx.clone()) {
                Ok(outcome) => Ok(rpc::submitted_json(&tx, outcome)),
                // The three refusals are not the same fact and must not
                // carry the same advice, and each has its own code:
                // MEMPOOL_FULL (-32003), TX_REFUSED_RETRYABLE (-32009),
                // TX_REFUSED (-32008). "Retry later" is correct for a full
                // mempool and actively harmful for a refused transaction:
                // the founder's consolidation sweep submits hundreds of
                // thousands of transfers through this method, and an
                // operator told to retry bytes that can NEVER be admitted
                // chases capacity while the real fault — an unverifiable
                // signature, an empty witness table — goes unread. Before
                // this, every refusal returned MEMPOOL_FULL with the words
                // "the transaction was not judged invalid" appended, which
                // for an invalid transaction was simply false.
                Err(Refusal::AtCapacity) => Err(RpcError::new(
                    rpc::MEMPOOL_FULL,
                    format!(
                        "mempool is at capacity ({MEMPOOL_MAX} entries); retry later — \
                         the transaction was not judged invalid"
                    ),
                )),
                //
                // And the two REFUSALS are not the same fact either, which is
                // the split this arm exists for. `PreviouslyRefused` is a
                // verdict on the bytes AGAINST A STATE: the bar lifts by
                // itself after REJECTION_TTL_SLOTS, so the correct advice is
                // "resubmit after slot N". `Invalid` is a verdict on the bytes
                // and the correct advice is "stop". They shared TX_REFUSED
                // until now, distinguishable only by reading the English —
                // and the `Refusal` enum's own doc says a caller that must act
                // on the difference has to match the variant, which is exactly
                // what this boundary was throwing away. An exchange following
                // our published "-32008 means never resubmit" guidance
                // permanently abandoned transactions this node would have
                // taken ~64 minutes later.
                //
                // The deadline goes in `error.data.until_slot` as well as in
                // the sentence: the codes are stable, the wording is not.
                Err(Refusal::PreviouslyRefused { until_slot }) => {
                    Err(RpcError::tx_refused_retryable(
                        until_slot,
                        format!(
                            "this node's proposer already had the transition refuse this \
                             transaction, so it is barred until slot {until_slot}. The usual \
                             cause is that it spends an output this chain does not have — \
                             either it was built against a node on a different branch, or its \
                             parent transaction has not landed yet. This bar lifts on its own: \
                             resubmit the same bytes from slot {until_slot}, or sooner once \
                             the parent confirms. See `error.data.until_slot`."
                        ),
                    ))
                }
                Err(Refusal::Invalid(why)) => Err(RpcError::new(
                    rpc::TX_REFUSED,
                    format!("{why} — this transaction cannot be admitted; retrying \
                             the same bytes will not help"),
                )),
                // R7 M6: a third, distinct shape — see `rpc::TX_REFUSED_SOURCE_CAP`'s
                // own doc for why this is neither `MEMPOOL_FULL` nor `TX_REFUSED`.
                Err(Refusal::TooManyFromSource) => Err(RpcError::new(
                    rpc::TX_REFUSED_SOURCE_CAP,
                    format!(
                        "{} pending transactions already sharing this source \
                         (MEMPOOL_MAX_PER_SOURCE); wait for one to clear before \
                         submitting another",
                        MEMPOOL_MAX_PER_SOURCE,
                    ),
                )),
            },

            // Identity of the binary, not of the chain: no state read, no
            // lock taken, constant cost at any height.
            RpcRequest::BuildInfo => Ok(rpc::build_info_json()),
            RpcRequest::MempoolInfo => Ok(rpc::mempool_info_json(
                self.mempool.len(),
                MEMPOOL_MAX,
                self.mempool.keys().map(Vec::len).sum(),
                self.state.next_base_fee(),
                self.rejected.len(),
                self.rejected_hits,
                self.mempool_expired,
                self.mempool_evicted_low_fee,
            )),

            // R4 F-11.
            RpcRequest::Validators => {
                let active = self.state.active_validators();
                let current_epoch = epoch_of(self.state.slot());
                let entries: Vec<(ValidatorRecord, Option<u64>)> = (0..self.state.validator_count()
                    as u32)
                    .filter_map(|i| {
                        let rec = self.state.validator_record(i)?;
                        let effective = active.iter().find(|v| v.index == i).map(|v| v.effective_stake);
                        Some((rec, effective))
                    })
                    .collect();
                Ok(rpc::validators_json(&entries, current_epoch))
            }

            RpcRequest::TxStatus(txid) => Ok(rpc::tx_status_json(self.tx_status(&txid))),
        }
    }
}

// ── Entry point ─────────────────────────────────────────────────────────────

/// How often replay reports progress. Ten seconds is short enough that an
/// operator watching a stalled fleet gets an answer quickly, and long enough
/// that the log of a multi-hour replay stays readable.
const REPLAY_PROGRESS_INTERVAL: std::time::Duration = std::time::Duration::from_secs(10);

/// Verdict of the boot-time keystore identity gate ("gate 3").
#[derive(Debug, PartialEq, Eq)]
pub(crate) enum KeystoreIdentity {
    /// The keystore is the manifest's validator at that index, and its local
    /// RANDAO chain opens the committed head.
    Ok,
    /// No manifest validator carries this (index, pubkey) pair.
    NotInGenesisSet,
    /// The validator is in the manifest, but the local RANDAO seed does not
    /// regenerate the committed commitment.
    RandaoMismatch,
}

/// The boot-time identity gate, extracted from `run` so it can be tested.
///
/// # This gate is the third thing blocking an open network, and it is
/// # independent of the verifier
///
/// A validator added by an on-chain deposit is, by construction, NOT in the
/// genesis manifest. So even once the verifier reads the registry and the
/// network can *count* a newcomer's votes, the newcomer's own node still
/// refuses to boot with `keystore does not match the genesis manifest's
/// validator set`. Fixing the verifier alone gets you a validator everyone
/// else can verify and that cannot start.
///
/// The root cause is the same one the verifier had: **identity is being read
/// from the genesis manifest instead of from the committed registry.** A
/// validator's index, key and RANDAO commitment are all committed state
/// (`ValidatorRecord`), and a deposit writes all three. The manifest is only
/// the registry's value at height 0.
///
/// **That fix is now made, in [`check_registry_identity`] below, and this
/// function is no longer authoritative.** It survives as a *fast pre-pass*
/// only: the registry is not reachable here (the store is not open, the log
/// is not read, and `CommittedState` has no on-disk form — boot is a full
/// replay), so the authoritative check cannot run until replay finishes,
/// which on the live fleet is ~21 minutes of silence. Keeping a cheap
/// manifest look first means a genesis operator who mistyped a seed still
/// learns it in a second instead of after a replay.
///
/// What changed is which verdicts are fatal. `NotInGenesisSet` is no longer
/// an error at all — it is the *normal and expected* state of every validator
/// the network will ever add by deposit, and refusing to boot on it is
/// precisely the wall that kept a deposit-added validator off the network.
/// It is now advisory, and [`check_registry_identity`] decides.
///
/// # One latent defect fixed in the extraction
///
/// The original read the RANDAO commitment as
/// `manifest.validators[keys.index as usize]` — indexing by POSITION after
/// having found the record by its `index` FIELD. Those coincide only while
/// the manifest is dense and sorted; otherwise it compares against another
/// validator's commitment, or panics out of bounds. This version uses the
/// record it already found. On the live fleet's dense manifest the two are
/// identical; everywhere else this one is correct and the old one was not.
/// (`Manifest::pubkeys()` carries the same position-vs-index assumption and
/// silently yields an EMPTY key for an out-of-range index — see
/// `genesis::tests::the_manifest_table_silently_empties_sparse_indices`.)
pub(crate) fn check_keystore_identity(
    manifest: &crate::genesis::Manifest,
    index: u32,
    pubkey: &[u8],
    randao_seed: [u8; 32],
) -> KeystoreIdentity {
    let Some(v) = manifest.validators.iter().find(|v| v.index == index) else {
        return KeystoreIdentity::NotInGenesisSet;
    };
    if v.pubkey != pubkey {
        return KeystoreIdentity::NotInGenesisSet;
    }
    if RandaoChain::generate(randao_seed).commitment() != v.randao_commitment {
        return KeystoreIdentity::RandaoMismatch;
    }
    KeystoreIdentity::Ok
}

/// Verdict of the authoritative, registry-backed identity gate.
#[derive(Debug, PartialEq, Eq)]
pub(crate) enum RegistryIdentity {
    /// The committed registry holds this index, it carries exactly this
    /// keystore's key, and the local RANDAO chain opens its committed
    /// commitment. Duties are armed.
    Active,
    /// Registered identity, but its exit has taken effect. Keep following
    /// the chain so automatic withdrawal can run when the lock matures.
    Inactive,
    /// The registry has no such index *yet*. Not an error: it is what a
    /// deposit-added validator looks like before its deposit is applied.
    /// Boot, follow the chain, sign nothing, re-check every slot.
    PendingActivation,
    /// The registry holds this index and it belongs to a DIFFERENT key.
    /// Fatal — see the double-signing note on [`check_registry_identity`].
    WrongValidator,
    /// The right key at the right index, but the local RANDAO seed does not
    /// regenerate the committed commitment. Fatal: this node cannot produce a
    /// reveal the network will accept, so every block it proposes is refused.
    RandaoMismatch,
}

/// The identity gate that actually decides, read from the **committed
/// registry** rather than from the genesis manifest.
///
/// # Why this had to move past replay
///
/// `CommittedState` has no serialized form; the node persists its *inputs*
/// (manifest digest + every block envelope) and rebuilds state by replaying
/// them. So at the point `run` loads the keystore there is no registry to
/// consult — no `Store`, no log, no `Engine`. The only registry that exists
/// before replay is the manifest's, i.e. the height-0 one, which by
/// construction cannot contain anyone added since height 0. Any gate placed
/// there can only ever ask "were you in the genesis set?", which is the wrong
/// question. This one runs after replay, where `engine.state` is the registry
/// as of the node's own head. The weak-subjectivity gate already sets that
/// precedent for the same reason.
///
/// # Why absence must not be fatal, and why a mismatch must be
///
/// The two cases were one branch before, and collapsing them is what closed
/// the network:
///
/// - **Absent** means "your deposit has not been applied on this node's head
///   yet" — a newcomer that has just deposited, or one still replaying. It is
///   a temporary, self-healing condition, and the honest response is to
///   follow the chain and keep checking.
/// - **Present but a different key** means another validator already owns
///   this index. Signing there is signing *as them*: two conflicting messages
///   under one index is exactly the equivocation `slashing.rs` exists to
///   punish. This must refuse to boot, and it is the real safety value the
///   old gate was providing — preserved here, and now aimed at the case that
///   actually warrants it.
///
/// # The re-check is a safety requirement, not a convenience
///
/// It is tempting to conclude that pending-activation needs no machinery,
/// because `attest` and `propose` already return early when the index is not
/// in the roster they derive from committed state. That is true and it is not
/// sufficient. Indices are allocated `keys().next_back() + 1`, so an operator
/// whose keystore was minted for index 64 *before* depositing can be beaten
/// to index 64 by somebody else's deposit. The roster check would then pass —
/// the index is active — and this node would sign under a key that is not
/// its own. So the duty path re-checks the *key*, not just the index, every
/// time it is about to sign: see `Engine::duty_index`.
pub(crate) fn check_registry_identity(
    state: &dyn StateReader,
    index: u32,
    pubkey: &[u8],
    randao_seed: [u8; 32],
) -> RegistryIdentity {
    let Some(rec) = state.validator_record(index) else {
        return RegistryIdentity::PendingActivation;
    };
    if rec.pubkey != pubkey {
        return RegistryIdentity::WrongValidator;
    }
    if RandaoChain::generate(randao_seed).commitment() != rec.randao_commitment {
        return RegistryIdentity::RandaoMismatch;
    }
    RegistryIdentity::Active
}

/// Start the devnet TCP mesh. Called by the `Devnet` and `Dual` arms of
/// [`run`] with identical arguments.
fn check_joining_registry_identity(
    state: &CommittedState, index: u32, pubkey: &[u8], randao_seed: [u8; 32],
) -> RegistryIdentity {
    let Some(rec) = state.validator_record(index) else { return RegistryIdentity::PendingActivation };
    if rec.pubkey != pubkey { return RegistryIdentity::WrongValidator; }
    let mut chain = RandaoChain::generate(randao_seed);
    let mut commitment = chain.commitment();
    for _ in 0..state.validator_reveals_used(index).unwrap_or(0) {
        let Some(reveal) = chain.next_reveal() else { return RegistryIdentity::RandaoMismatch };
        commitment = reveal;
    }
    if commitment != rec.randao_commitment { return RegistryIdentity::RandaoMismatch; }
    if rec.activation_epoch > epoch_of(state.slot()) { return RegistryIdentity::PendingActivation; }
    if epoch_of(state.slot()) >= rec.exit_epoch { return RegistryIdentity::Inactive; }
    RegistryIdentity::Active
}

fn start_devnet(
    cfg: &Config,
    tx: mpsc::Sender<EngineEvent>,
    head_slot: &Arc<AtomicU64>,
    inflight: &Arc<net::QueueBudget>,
) -> io::Result<net::DevnetMesh> {
    net::start(
        &cfg.listen_addr,
        cfg.listen,
        cfg.peers.clone(),
        tx,
        cfg.data_dir.clone(),
        head_slot.clone(),
        inflight.clone(),
    )
}

/// Start the libp2p stack. Called by the `Libp2p` and `Dual` arms of [`run`]
/// with identical arguments.
///
/// The `p2p: node identity …` line stays here rather than at the call site so
/// that both arms print it, in the same place, with the same wording — an
/// operator reading a dual node's boot log sees exactly what a libp2p node's
/// log says.
fn start_libp2p(
    cfg: &Config,
    net_tx: mpsc::Sender<NetEvent>,
    head_slot: &Arc<AtomicU64>,
) -> io::Result<crate::p2p::Handle> {
    let parse = |s: &str, what: &str| -> io::Result<crate::p2p::Multiaddr> {
        s.parse().map_err(|e| {
            io::Error::new(
                io::ErrorKind::InvalidInput,
                format!("{what} `{s}` is not a multiaddr: {e}"),
            )
        })
    };
    let mut listen = Vec::new();
    for a in &cfg.p2p_listen {
        listen.push(parse(a, "--p2p-listen")?);
    }
    let mut peers = Vec::new();
    for a in &cfg.p2p_peers {
        peers.push(parse(a, "--p2p-peer")?);
    }
    let handle = crate::p2p::start(
        crate::p2p::Config {
            listen,
            peers,
            data_dir: cfg.data_dir.clone(),
            max_peers: cfg.max_peers,
            behind_proxy: cfg.behind_proxy,
        },
        net_tx,
        head_slot.clone(),
    )?;
    println!("p2p: node identity {}", handle.peer_id);
    Ok(handle)
}

pub fn run(cfg: Config) -> io::Result<()> {
    // Metrics FIRST, before the manifest is even read (audit C-R6-2): the
    // replay window is the one stretch where the node is alive, mute, and
    // indistinguishable from wedged (2026-08-21), so the health endpoint must
    // exist before replay starts. Until the slot loop stamps its first
    // heartbeat, `/health` answers `503 {"status":"starting"}` — visible
    // progress where there used to be silence.
    {
        use crate::metrics::{NodeMetrics, NODE};
        NodeMetrics::inc(&NODE.process_starts_total);
        NodeMetrics::set(&NODE.process_start_unix, crate::metrics::now_unix());
        NodeMetrics::set(&NODE.data_dir_fs_free_bytes, crate::metrics::fs_free_bytes(&cfg.data_dir));
        if let Some(port) = cfg.metrics_port {
            match crate::metrics::serve(&cfg.metrics_bind, port, &NODE) {
                Ok(addr) => println!("metrics: /health and /metrics on http://{addr}"),
                Err(e) => {
                    // Same rule as the RPC bind below: an operator who asked
                    // for observability must not silently run without it.
                    return Err(io::Error::new(
                        e.kind(),
                        format!("cannot bind the metrics server to {}:{port}: {e}", cfg.metrics_bind),
                    ));
                }
            }
        }
    }
    let (mut manifest, digest) = Manifest::load(&cfg.genesis_path)?;

    // The opening ledger, before anything else touches the manifest. A
    // manifest that commits to a carryover is not usable until the snapshot
    // is in hand, and a snapshot offered to a manifest that commits to none
    // is a category error — both are refusals rather than warnings, because
    // the failure they prevent is a chain that starts, runs, and is wrong.
    match (&manifest.carryover, &cfg.carryover_path) {
        (Some(c), Some(path)) => {
            let entries = c.entry_count;
            let snap = manifest.ingest_carryover(path)?;
            println!(
                "carryover: {entries} outputs, {} sat carried (x100/21 of {} G3 sat, \
                 {} sat of split remainder to the largest output); set root {}",
                snap.total_sat,
                snap.g3_total_sat,
                snap.dust_sat,
                crate::codec::hex8(&snap.set_root),
            );
        }
        (Some(c), None) => {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                format!(
                    "this genesis commits to a carryover of {} outputs ({} sat) but no \
                     --carryover <snapshot.tsv> was given; starting without it would open \
                     the chain with a zero balance for every holder",
                    c.entry_count, c.total_sat,
                ),
            ));
        }
        (None, Some(_)) => {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "--carryover was given but this genesis commits to no carryover; \
                 the manifest's digest says nothing about that file, so nothing would \
                 hold the balances it contains to anything",
            ));
        }
        (None, None) => {}
    }

    // No keystore in the data dir is not a misconfiguration — it selects
    // observer mode. Anything else is a misconfiguration and stops the boot.
    //
    // The decision is `load_optional`'s, not this match's, and that is the
    // whole point: `Ok(None)` there means the FILE IS ABSENT and nothing
    // else. This site used to ask `e.kind() == NotFound` instead, which also
    // caught a missing `BLOCH_KEYSTORE_PASSPHRASE_FILE` — so a validator with
    // a good sealed key and an unprovisioned credential path restarted as a
    // silent observer, printing the reassuring line below and attesting
    // nothing. There is no error kind left here to misread.
    let keys = match Keystore::load_optional(&cfg.data_dir)? {
        Some(k) => Some(k),
        None => {
            println!(
                "observer mode: no keystore in {}. This node follows the chain, applies \
                 every block and serves the RPC. It does not propose and does not attest.",
                cfg.data_dir.display()
            );
            None
        }
    };
    // Metrics gap (R3): `keystore_sealed`. Peeked from the raw file's magic
    // rather than a new API on `Keystore` — that module is owned by a
    // parallel workstream, and the magic bytes are the whole of what "sealed"
    // means (`BPOSKEY2` vs the plaintext `BPOSKEY1`). 0 on an observer too:
    // there is nothing to seal. This matters ahead of the `LEAK_RECOVERY`
    // flag day, which refuses a plaintext keystore outright — an operator
    // needs to see "still plaintext" BEFORE that day, not discover it as a
    // boot failure on it.
    crate::metrics::NodeMetrics::set(
        &crate::metrics::NODE.keystore_sealed,
        u64::from(
            std::fs::read(cfg.data_dir.join("validator.key"))
                .is_ok_and(|bytes| bytes.starts_with(b"BPOSKEY2")),
        ),
    );
    // Stateless now: it holds no key table. Keys are resolved per call from
    // the committed registry by whichever consensus site is asking.
    let verifier = HybridVerifier::new();

    // Identity, pre-pass. Advisory only — the authoritative gate is
    // `check_registry_identity`, and it cannot run until replay has rebuilt
    // the registry. This exists so that the one failure a genesis operator
    // can cause locally (a RANDAO seed that does not open the committed
    // commitment) is reported in a second rather than after a full replay.
    //
    // `NotInGenesisSet` is deliberately NOT an error here. Every validator
    // this network ever adds by deposit is outside the genesis manifest by
    // construction; refusing to boot on that fact is the wall that kept
    // deposit-added validators off the chain entirely.
    if let Some(keys) = keys.as_ref() {
        match check_keystore_identity(&manifest, keys.index, &keys.pubkey, keys.randao_seed) {
            KeystoreIdentity::Ok => {}
            KeystoreIdentity::NotInGenesisSet => {
                println!(
                    "validator {} is not in the genesis manifest — expected for a \
                     deposit-added validator. Identity will be settled against the \
                     committed registry once replay finishes.",
                    keys.index
                );
            }
            KeystoreIdentity::RandaoMismatch => {
                return Err(io::Error::new(
                    io::ErrorKind::InvalidData,
                    "local RANDAO chain does not open the manifest's committed head",
                ))
            }
        }
    }

    let store = Store::open(&cfg.data_dir, &digest)?;
    // Loaded before anything can sign. A corrupt watermark file stops the node
    // here, on purpose: a validator that cannot prove which duties it already
    // signed must not sign.
    //
    // Bound to THIS validator key on THIS network when a keystore is present
    // (audit round 3, M-8): a watermark file restored from another
    // validator's backup, or carried across a network reset, is refused at
    // boot naming the mismatch instead of admitting a duty this key already
    // signed. An observer has nothing to bind and opens unbound.
    let slashprot = match keys.as_ref() {
        Some(k) => {
            let pkh: [u8; 32] = <sha3::Sha3_256 as sha3::Digest>::digest(&k.pubkey).into();
            SlashingProtection::open_bound(
                &cfg.data_dir,
                crate::slashprot::Binding { validator_pubkey_sha3: pkh, genesis_digest: digest },
            )?
        }
        None => SlashingProtection::open(&cfg.data_dir)?,
    };
    if let Some(wm) = slashprot.watermarks().attestation_slot {
        println!(
            "slashing protection: last attested slot {wm}, last proposed slot {}",
            match slashprot.watermarks().proposal_slot {
                Some(p) => p.to_string(),
                None => "none".to_string(),
            }
        );
    }
    let genesis_state = manifest.genesis_state();
    let genesis_id = manifest.genesis_id();
    println!(
        "bloch-pos node — {}, genesis {} (state root {}), network digest {}",
        match keys.as_ref() {
            Some(k) => format!("validator {}", k.index),
            None => "observer (no keystore, signs nothing)".to_string(),
        },
        crate::codec::hex8(genesis_id.as_bytes()),
        crate::codec::hex8(&genesis_state.state_root()),
        crate::codec::hex8(&digest),
    );

    let logged = store.read_all()?;
    let head_slot = Arc::new(AtomicU64::new(0));
    // Network events queued but not yet handled. The transport reads it to
    // decide when to shed rather than queue — see `net::send_to_engine`. It is
    // decremented below, after each event is actually processed, so "in flight"
    // means exactly that and not "ever sent".
    let inflight = net::QueueBudget::new();
    let (tx, rx) = mpsc::channel::<EngineEvent>();
    // The transports speak NetEvent and know nothing about the RPC; the engine
    // consumes one channel. Rather than teach both transports the engine's
    // event type — coupling the network layer to a queue it has no business
    // knowing about — a forwarder wraps their events on the way in. One thread
    // and one hop, and each side keeps the shape it was designed with.
    let (net_tx, net_rx) = mpsc::channel::<NetEvent>();
    {
        let tx = tx.clone();
        let inflight = inflight.clone();
        std::thread::spawn(move || {
            for ev in net_rx {
                // COUNT IT IN, exactly as `net::send_to_engine` does on the
                // devnet path.
                //
                // The engine loop below decrements `inflight` for every
                // `EngineEvent::Net` it handles, unconditionally. This
                // forwarder is the libp2p path's only way in and it did not
                // increment, so on `--transport libp2p` an `AtomicUsize` at
                // zero was decremented on the first network event and wrapped
                // to `usize::MAX`.
                //
                // That was invisible while the two transports could not
                // coexist: nothing reads `inflight` on the libp2p path. It is
                // fatal the moment they share a process. `net::send_to_engine`
                // sheds when `inflight >= ENGINE_QUEUE_CAP`, so a wrapped
                // counter means a dual node silently drops EVERY devnet frame
                // for the life of the process — a node that looks connected,
                // logs nothing, and receives nothing.
                //
                // Since the 2026-09-07 audit (O06) the libp2p path is
                // admitted through the SAME byte-weighted budget as the
                // devnet path. It used to stay unbounded on purpose (the
                // `p2p` module header's argument: a syncing node that stalls
                // is worse than a fat one). The budget answers that argument
                // rather than ignoring it: blocks — the class sync progress
                // consists of — may use the whole 64 MiB, so a block is shed
                // only when the engine already holds four epochs of maximal
                // blocks it has not applied, i.e. when it is replaying and
                // would not have applied a fifth for hours anyway; and every
                // shed event is re-requested or re-gossiped. What the budget
                // removes is the unbounded case: a consumer that is asleep
                // can no longer be handed memory without limit.
                if !inflight.try_reserve(&ev) {
                    continue; // shed and counted; the transport stays healthy
                }
                let size = net::queued_bytes(&ev);
                if tx.send(EngineEvent::Net(ev)).is_err() {
                    inflight.release_raw(size);
                    return; // engine gone; nothing left to deliver to
                }
            }
        });
    }
    // The two transports are started by two helpers rather than inline, so the
    // `Dual` arm calls exactly the same code with exactly the same arguments
    // as the single-transport arms. A dual node is not a third transport; it
    // is the other two, unmodified, in one process.
    let net = match cfg.transport {
        Transport::Devnet => {
            net::Net::Devnet(start_devnet(&cfg, tx.clone(), &head_slot, &inflight)?)
        }
        Transport::Libp2p => net::Net::Libp2p(start_libp2p(&cfg, net_tx, &head_slot)?),
        Transport::Dual => {
            // Devnet FIRST. Binding its `TcpListener` is the cheap synchronous
            // failure — a port already in use — and a node that cannot bind
            // both must not come up holding one: half a dual node is a node
            // that looks like it is bridging two populations and is not.
            // `?` on either line aborts the whole start.
            let mesh = start_devnet(&cfg, tx.clone(), &head_slot, &inflight)?;
            let handle = start_libp2p(&cfg, net_tx, &head_slot)?;
            net::Net::Both(mesh, handle)
        }
    };
    // THE SECOND HALF OF THE STARTUP DECISION, AND THE AUTHORITATIVE ONE.
    //
    // `main::run_cmd` prints the plan before anything binds; this line prints
    // what is bound, from the `Net` value the engine is actually holding.
    // Two lines rather than one on purpose: a `dual` node whose libp2p half
    // failed never reaches here at all (`?` above aborts the start), so
    // "bound" appearing after "plan" is the operator's proof that both
    // sockets exist. `getchaininfo`'s `transport` block then reports, from the
    // same `Net`, how many peers each stack has found.
    println!(
        "transport: {} bound — {}",
        net.transport_name(),
        match &net {
            net::Net::Devnet(_) => format!("devnet mesh on {}:{}", cfg.listen_addr, cfg.listen),
            net::Net::Libp2p(_) => format!("libp2p swarm on {}", cfg.p2p_listen.join(", ")),
            net::Net::Both(..) => format!(
                "devnet mesh on {}:{} AND libp2p swarm on {}",
                cfg.listen_addr,
                cfg.listen,
                cfg.p2p_listen.join(", ")
            ),
        }
    );

    // R3 M-1: read once, at boot — env is fixed for the life of a process,
    // so there is no correctness reason to re-read it per reorg, and caching
    // means a value that could not change mid-run is not treated as though
    // it might. Logged loudly HERE too (not only when it fires): an operator
    // who set this should see it confirmed immediately, not only discover it
    // was armed the first time a rewind actually happens.
    let allow_finality_rewind = std::env::var_os("BLOCH_ALLOW_FINALITY_REWIND")
        .is_some_and(|v| v == "1" || v == "true");
    if allow_finality_rewind {
        println!(
            "FINALITY_LATCH: BLOCH_ALLOW_FINALITY_REWIND is set — this node will ALLOW a \
             reorg below its own finalized checkpoint if one is ever offered, instead of \
             refusing it. This should only be set with a human operator's deliberate, \
             informed consent."
        );
    }

    // Read the opt-out once, but arm observation only after replay and the
    // weak-subjectivity gate. Time spent reading disk is not live observation.
    let no_doppelganger_check = std::env::var_os("BLOCH_NO_DOPPELGANGER").is_some();

    let mut engine = Engine {
        state: StateCell::new(genesis_state),
        tr: Transition::new(verifier.clone()),
        tr_probe: Transition::new(ProbeVerifier),
        verifier,
        keys,
        blocks: BTreeMap::new(),
            observed_proposals: BTreeMap::new(),
        chain: vec![(0, genesis_id)],
        canonical: BTreeSet::from([*genesis_id.as_bytes()]),
        recent_states: VecDeque::new(),
        pool: BTreeMap::new(),
        att_pool: AttestationPool::new(),
        wall_slot: 0,
        mempool: BTreeMap::new(),
        mempool_admitted_at: BTreeMap::new(),
        mempool_expired: 0,
        mempool_evicted_low_fee: 0,
        rejected: BTreeMap::new(),
        rejected_hits: 0,
        mempool_suspect: BTreeSet::new(),
        mempool_swept_epoch: u64::MAX,
        store,
        slashprot,
        net,
        head_slot,
        live: false,
        needs_sync: false,
        orphans: VecDeque::new(),
        orphans_evicted: 0,
        orphans_admitted: 0,
        blocks_pruned: 0,
        rejected_unsigned: 0,
        rejected_future: 0,
        last_applied_ms: now_ms(),
        booted_ms: now_ms(),
        ws_anchor: None,
        ws_anchor_hard: false,
        ws_conflict_reported: false,
        fc_covered_removals: 0,
        finalized_latch: None,
        finality_rewinds_refused: 0,
        parked_refused_finality: VecDeque::new(),
        finality_rewind_override: allow_finality_rewind,
        tx_slot_index: BTreeMap::new(),
        tx_slot_index_order: VecDeque::new(),
        doppelganger_observe_until: None,
        doppelganger_halted: false,
        genesis_validator_count: manifest.validators.len() as u32,
        manifest,
    };

    // ── Replay: restart returns to the same state, by re-running the same
    // transition over the same inputs. ──
    //
    // Progress is reported while this runs, and that is not a nicety. Replay
    // re-applies the whole chain, and every block re-derives the state root
    // over the full committed state — 0.59s per block at Genesis-4's carryover
    // size, so a 12,200-block chain is hours. Throughout, the RPC does not
    // answer and the node logs nothing, which makes "still working" and
    // "wedged" indistinguishable from the outside. That ambiguity cost real
    // hours of investigation on 2026-08-21: a validator was down and there was
    // no way to tell whether it was progressing, stuck, or minutes from
    // finishing. An operator needs a rate and a remainder to decide whether to
    // wait or intervene, and neither existed.
    let n_logged = logged.len();
    if n_logged > 0 {
        println!(
            "replaying {n_logged} blocks from the log — the RPC stays silent until this finishes"
        );
    }
    let replay_started = std::time::Instant::now();
    let mut last_report = replay_started;
    for (i, env) in logged.into_iter().enumerate() {
        // `ingest_replay`, not `ingest`: these blocks are this node's own
        // committed log, and must not be judged against a wall clock the log
        // knows nothing about. See `Engine::ingest_replay`.
        engine.ingest_replay(env);
        // Time-based, not every-N-blocks: block cost varies by an order of
        // magnitude with how many transactions a block carries, so a fixed
        // count reports in bursts and then goes quiet exactly when the work is
        // heaviest — the opposite of what an operator needs.
        if last_report.elapsed() >= REPLAY_PROGRESS_INTERVAL {
            // Progress display only: `i < n_logged`, so neither saturates.
            let done = i.saturating_add(1);
            let elapsed = replay_started.elapsed().as_secs_f64();
            let rate = if elapsed > 0.0 { done as f64 / elapsed } else { 0.0 };
            let left = n_logged.saturating_sub(done);
            println!(
                "replay {done}/{n_logged} ({:.1}%) — head slot {}, {rate:.1} blocks/s, ~{} min left",
                100.0 * done as f64 / n_logged as f64,
                engine.state.slot(),
                if rate > 0.0 { (left as f64 / rate / 60.0).ceil() as u64 } else { 0 },
            );
            last_report = std::time::Instant::now();
        }
    }
    engine.live = true;
    if n_logged > 0 {
        println!(
            "replayed {} blocks: head slot {}, state root {}, justified e{}, finalized e{}",
            n_logged,
            engine.state.slot(),
            crate::codec::hex8(&engine.state.state_root()),
            engine.state.finality().justified.epoch,
            engine.state.finality().finalized.epoch,
        );
    }
    engine
        .head_slot
        .store(engine.state.slot(), Ordering::Relaxed);

    // ── Identity, authoritative: the committed registry, not the manifest ──
    //
    // Here and not before, because the registry only exists once replay has
    // rebuilt it. `PendingActivation` is a normal boot state, not a failure:
    // it is every deposit-added validator until its deposit is applied, and
    // the duty path (`Engine::duty_index`) re-checks the key each slot, so
    // the node arms itself the moment the registry says it may.
    if let Some(keys) = engine.keys.as_ref() {
        let registered_index = if keys.index == crate::keys::AUTO_VALIDATOR_INDEX {
            engine.state.validator_index_by_pubkey(&keys.pubkey)
        } else { Some(keys.index) };
        let identity = match registered_index {
            Some(index) => check_joining_registry_identity(&engine.state, index, &keys.pubkey,
                keys.randao_seed_for(&engine.state.admission_network_domain().unwrap_or([0; 32]),
                    engine.state.validator_randao_generation(index))),
            None => RegistryIdentity::PendingActivation,
        };
        match identity {
            RegistryIdentity::Active => {
                crate::metrics::NodeMetrics::set(&crate::metrics::NODE.validator_active, 1);
                println!(
                    "validator {} is registered and its key matches the committed \
                     registry at head slot {}",
                    registered_index.unwrap_or(keys.index),
                    engine.state.slot()
                );
            }
            RegistryIdentity::Inactive => {
                crate::metrics::NodeMetrics::set(&crate::metrics::NODE.validator_active, 0);
                println!("validator {} has exited; following the chain for withdrawal", registered_index.unwrap_or(keys.index));
            }
            RegistryIdentity::PendingActivation => {
                // The "validator was down and nothing said so" incident, as a
                // counter: a keystore is present but this node will sign
                // nothing. `validator_active` stays 0.
                crate::metrics::NodeMetrics::inc(
                    &crate::metrics::NODE.validator_not_started_total,
                );
                println!(
                    "validator key (local index hint {}) is unregistered or queued at head slot {}. \
                     This node follows the chain and waits for registration and activation; \
                     no restart is needed.",
                    keys.index,
                    engine.state.slot()
                );
            }
            RegistryIdentity::WrongValidator => {
                // Fatal, and this is the case the old manifest gate was really
                // protecting against: another validator owns this index, so
                // signing here would be equivocating under their identity.
                return Err(io::Error::new(
                    io::ErrorKind::InvalidData,
                    format!(
                        "validator index {} is registered to a DIFFERENT public key — \
                         refusing to start, because signing under it would equivocate \
                         as that validator",
                        keys.index
                    ),
                ));
            }
            RegistryIdentity::RandaoMismatch => {
                return Err(io::Error::new(
                    io::ErrorKind::InvalidData,
                    format!(
                        "validator {}'s local RANDAO chain does not open the \
                         commitment in the committed registry — every block this node \
                         proposed would be refused",
                        keys.index
                    ),
                ));
            }
        }
    }

    // ── Weak subjectivity: may the node sync at all? (§4.2) ──
    //
    // Runs AFTER replay, because the question the boot decision asks — how old
    // is this node's own finalized knowledge — is only answerable once the
    // database has been replayed. Before this point the node has done nothing
    // but read its own disk; it performs no duty and follows no peer until the
    // gate says it may.
    //
    // The wall-clock epoch comes from the MANIFEST's slot clock, not from
    // `ws::wallclock_epoch` (which assumes the mainnet 30 s cadence): a devnet
    // running 500 ms slots would otherwise be judged 60× younger than it is,
    // and the age compared against the window must be measured on the same
    // clock the node's own epochs are numbered by. The NTP caveat of §1
    // applies here verbatim — a clock set backward makes a stale node look
    // fresh.
    {
        let genesis_ms = engine.manifest.genesis_time_ms;
        let slot_ms = engine.manifest.slot_ms;
        // cannot divide by zero: `Manifest::decode` refuses `slot_ms == 0`.
        #[allow(clippy::arithmetic_side_effects)]
        let wall_slot = now_ms().saturating_sub(genesis_ms) / slot_ms;
        let wall_epoch = epoch_of(wall_slot);
        let fin = engine.state.finality().finalized;
        // Genesis is "finalized by definition", not knowledge this node
        // witnessed. Only a finalized epoch above 0 is own finality — treating
        // the genesis checkpoint as own finality would let every fresh node
        // skip the gate, which is the whole point of the gate.
        let has_local_finality = fin.epoch > 0;
        let network_id = crate::ws_boot::network_id_of(&digest);
        let genesis_root = *genesis_id.as_bytes();
        // The genesis block IS the first weak-subjectivity anchor: trusting it
        // is trusting the manifest this node already loaded to exist at all.
        // This is what keeps a fresh devnet booting with no ceremony.
        let g_anchor = bloch_pos_committee::ws::genesis_anchor(
            network_id,
            genesis_root,
            engine.manifest.genesis_state().state_root(),
            [0u8; 32], // no validator-set SMT root exposed at this milestone
            genesis_ms / 1000,
        );
        let canonical = engine.canonical.clone();
        let local_at: Vec<(u64, [u8; 32])> = (0..=fin.epoch)
            .filter_map(|e| engine.own_finalized_root_at(e).map(|r| (e, r)))
            .collect();
        let outcome = crate::ws_boot::boot(
            &cfg.ws,
            &cfg.data_dir,
            network_id,
            &genesis_root,
            &g_anchor,
            wall_epoch,
            has_local_finality,
            (fin.epoch, fin.root),
            |e| local_at.iter().find(|(k, _)| *k == e).map(|(_, r)| *r),
            |root| canonical.contains(root),
        )?;
        match outcome {
            Ok(ws) => {
                for w in &ws.warnings {
                    println!("{w}");
                }
                println!(
                    "weak subjectivity: anchored at epoch {} ({}), {} own finality",
                    ws.anchor_epoch,
                    crate::codec::hex8(&ws.anchor_root),
                    if ws.anchor_is_hard { "WITHOUT" } else { "with" },
                );
                engine.ws_anchor = Some((ws.anchor_epoch, ws.anchor_root));
                engine.ws_anchor_hard = ws.anchor_is_hard;
                engine.enforce_ws_anchor();
            }
            Err(msg) => return Err(io::Error::new(io::ErrorKind::PermissionDenied, msg)),
        }
    }

    if engine.keys.is_some() {
        if no_doppelganger_check {
            println!("DOPPELGANGER PROTECTION: DISABLED (BLOCH_NO_DOPPELGANGER is set).");
        } else {
            #[allow(clippy::arithmetic_side_effects)]
            let observation_start = now_ms().saturating_sub(engine.manifest.genesis_time_ms)
                / engine.manifest.slot_ms.max(1);
            engine.start_doppelganger_observation(observation_start);
        }
    }

    // ── The JSON-RPC server ──
    //
    // Started HERE, after replay and after the weak-subjectivity gate, and the
    // order is the point: until this line the engine is not reading its event
    // channel, so a request arriving earlier would block a client for the whole
    // of boot. It also means the node never answers a query before it has
    // decided it is allowed to follow this chain at all — a node that served
    // `getchaininfo` during boot would be publishing a head it had not yet
    // earned the right to have.
    if let Some(port) = cfg.rpc_port {
        // The reads that are bounded by the size of the ledger rather than by
        // the size of the answer (`getbalance`, `getutxos`) are served from
        // this handle, off the slot loop. Everything else still goes through
        // the loop, which is where anything touching the mempool or the chain
        // store belongs.
        let backend = Arc::new(crate::rpc::EngineBackend::with_head(
            tx.clone(),
            engine.state.published_head(),
        ));
        match crate::rpc::serve(&cfg.rpc_bind, port, backend) {
            Ok(addr) => {
                println!("JSON-RPC listening on http://{addr}");
                if !addr.ip().is_loopback() {
                    // Not a log line among log lines: this port has no
                    // authentication and `sendrawtransaction` is a write.
                    eprintln!(
                        "WARNING: the RPC is bound to {}, which is not loopback. It has \
                         NO authentication, NO rate limiting and NO authorisation — \
                         anything that can reach this port can read the node's full \
                         state and submit transactions. Restrict it at the firewall to \
                         the clients that are meant to reach it.",
                        addr.ip()
                    );
                }
            }
            Err(e) => {
                // A node that was asked for an RPC and could not bind must not
                // quietly run without one: the operator would find out from a
                // client's timeouts.
                return Err(io::Error::new(
                    e.kind(),
                    format!("cannot bind the RPC to {}:{port}: {e}", cfg.rpc_bind),
                ));
            }
        }
    }

    // ── The slot loop ──
    let genesis_ms = engine.manifest.genesis_time_ms;
    let slot_ms = engine.manifest.slot_ms;
    let mut last_attested: u64 = engine.state.slot();
    let mut last_built: u64 = engine.state.slot();
    let mut last_sync_req: u64 = 0;

    // Metrics baseline (C-R6-2). The finality clock starts NOW: replay stamps
    // nothing (it re-finalizes the past), and a `last_finality_advance_unix`
    // of 0 would read as an eternal stall on every fresh boot. The stall
    // window is wall time for 4 epochs — long enough that one missed
    // justification round is not an incident, short enough that the
    // 2026-08-25 class of stall fires well before an operator's patience.
    crate::metrics::NodeMetrics::set(
        &crate::metrics::NODE.last_finality_advance_unix,
        crate::metrics::now_unix(),
    );
    // A threshold: saturating on an absurd slot_ms is still a threshold.
    let finality_stall_secs: u64 = ((4 * SLOTS_PER_EPOCH).saturating_mul(slot_ms) / 1000).max(60);
    // Two slots of wall time, the grace/sync/rate-limit window used below.
    let two_slots_ms = slot_ms.saturating_mul(2);
    let mut finality_stalled = false;
    let mut metrics_sampled_slot: u64 = 0;

    loop {
        let now = now_ms();
        if now < genesis_ms {
            // cannot underflow: now < genesis_ms.
            #[allow(clippy::arithmetic_side_effects)]
            let wait = (genesis_ms - now).min(200);
            std::thread::sleep(Duration::from_millis(wait));
            continue;
        }
        // cannot underflow: now >= genesis_ms; cannot divide by zero:
        // `Manifest::decode` refuses `slot_ms == 0`; and
        // `genesis_ms + slot * slot_ms <= now` by the division that made `slot`.
        #[allow(clippy::arithmetic_side_effects)]
        let (slot, slot_start) = {
            let slot = (now - genesis_ms) / slot_ms;
            (slot, genesis_ms + slot * slot_ms)
        };
        let wall_epoch = epoch_of(slot);
        if slot != engine.wall_slot {
            engine.wall_slot = slot;
            // Drop everything the acceptance window has moved past. The pool
            // reads no clock of its own, so this is the only thing that bounds
            // it — without the call its `seen` map grows with uptime.
            engine.att_pool.prune(slot);
        }

        if let Some(stop) = cfg.stop_at_slot {
            if slot >= stop {
                let fin = engine.state.finality();
                println!(
                    "STOP at slot {stop}: head slot {}, {} blocks, state root {}, justified e{} ({}), finalized e{} ({})",
                    engine.state.slot(),
                    engine.head_height(),
                    crate::codec::hex32(&engine.state.state_root()),
                    fin.justified.epoch,
                    crate::codec::hex8(&fin.justified.root),
                    fin.finalized.epoch,
                    crate::codec::hex8(&fin.finalized.root),
                );
                return Ok(());
            }
        }

        // Boot grace: give the mesh one round of sync before performing
        // duties, so a restarted proposer does not build on a stale head.
        let in_grace = now.saturating_sub(engine.booted_ms) < two_slots_ms;

        // `slot` here IS `wall_slot()` — same expression, computed once per
        // turn above. It is what reaches the slashing-protection watermark, so
        // "refuse unless the slot exceeds the watermark" is literally "refuse
        // unless the wall clock has passed what this node already signed".
        //
        // `last_attested`/`last_built` are NOT that protection: they start at
        // `engine.state.slot()`, which is the head of the chain this node
        // adopted, not a record of what this node signed, and they live in
        // this function's stack — a restart forgets them entirely. They stop
        // duplicate work within one run; `slashprot` is what stops a second
        // signature across runs and across processes.
        if !in_grace && slot > last_attested {
            engine.maintain_validator_lifecycle(wall_epoch);
            engine.attest(slot);
            last_attested = slot;
        }
        let propose_at = slot_start.saturating_add(slot_ms / 3); // a deadline
        if !in_grace && now >= propose_at && slot > last_built {
            engine.propose(slot);
            last_built = slot;
        }

        // Sync when behind or when a stored branch has holes. Rate-limited;
        // idempotent on the receiving side (dedup discards repeats).
        let behind = engine.state.slot().saturating_add(1) < slot
            && now.saturating_sub(engine.last_applied_ms) > two_slots_ms;
        if (behind || engine.needs_sync) && now.saturating_sub(last_sync_req) > two_slots_ms {
            engine
                .net
                .broadcast(net::get_blocks_frame(engine.sync_after_slot()));
            engine.needs_sync = false;
            last_sync_req = now;
        }

        // ── Metrics turn (C-R6-2): pure exports of state already computed ──
        // Every turn is bounded (`recv_timeout` ≤ 500 ms below), so the
        // heartbeat is the liveness proof `/health` runs on. Nothing here is
        // read back by consensus.
        {
            use crate::metrics::{NodeMetrics, NODE};
            let head = engine.state.slot();
            NodeMetrics::set(&NODE.heartbeat_unix, crate::metrics::now_unix());
            NodeMetrics::set(&NODE.head_slot, head);
            NodeMetrics::set(&NODE.wall_slot, slot);
            NodeMetrics::set(&NODE.behind_by_slots, slot.saturating_sub(head));
            let fin = engine.state.finality();
            NodeMetrics::set(&NODE.finalized_epoch, fin.finalized.epoch);
            NodeMetrics::set(&NODE.justified_epoch, fin.justified.epoch);
            NodeMetrics::set(&NODE.mempool_size, engine.mempool.len() as u64);
            NodeMetrics::set(&NODE.is_syncing, u64::from(behind || engine.needs_sync));
            let (devnet_peers, p2p_peers) = engine.net.peer_counts();
            NodeMetrics::set(
                &NODE.peer_count,
                devnet_peers.unwrap_or(0).saturating_add(p2p_peers.unwrap_or(0)) as u64,
            );
            // Per-transport (metrics gap): `None` (transport not running) and
            // `Some(0)` (running, no peers) both read as 0 here — a gauge has
            // no absent state — but `getchaininfo`'s `transport` block still
            // carries the distinction for an operator who needs it.
            NodeMetrics::set(&NODE.peer_count_devnet, devnet_peers.unwrap_or(0) as u64);
            NodeMetrics::set(&NODE.peer_count_p2p, p2p_peers.unwrap_or(0) as u64);
            // R3 M-1: mirrors `Engine::finality_rewinds_refused` every turn —
            // cheap (one more atomic store) and correct either way, since the
            // counter only ever goes up.
            NodeMetrics::set(&NODE.finality_rewinds_refused_total, engine.finality_rewinds_refused);
            // R3 M-5: the slot-progress signal `/health` corroborates the
            // heartbeat with. `genesis_unix`/`slot_secs` are effectively
            // constants of this manifest; setting them every turn costs one
            // more atomic store each and keeps this block free of a
            // "set only once" special case.
            NodeMetrics::set(&NODE.genesis_unix, engine.manifest.genesis_time_ms / 1000);
            NodeMetrics::set(&NODE.slot_secs, (engine.manifest.slot_ms / 1000).max(1));
            NodeMetrics::set(&NODE.last_applied_unix, engine.last_applied_ms / 1000);
            // Blocks parked rather than admitted: orphans waiting on a
            // missing parent, plus branches the finality latch refused (R3
            // M-1) rather than deleted.
            NodeMetrics::set(
                &NODE.blocks_parked,
                engine.orphans.len().saturating_add(engine.parked_refused_finality.len()) as u64,
            );
            // Once per slot, not per turn: `peer_counts` is cheap but
            // `statvfs` is a syscall against the data volume.
            if slot != metrics_sampled_slot {
                metrics_sampled_slot = slot;
                NodeMetrics::set(
                    &NODE.data_dir_fs_free_bytes,
                    crate::metrics::fs_free_bytes(&cfg.data_dir),
                );
            }
            // Finality stall: count the EDGE into the stalled condition, so a
            // three-hour stall is one incident, not ten thousand scrapes.
            let advance_age = crate::metrics::now_unix()
                .saturating_sub(NODE.last_finality_advance_unix.load(std::sync::atomic::Ordering::Relaxed));
            let stalled_now = advance_age > finality_stall_secs;
            if stalled_now && !finality_stalled {
                NodeMetrics::inc(&NODE.finality_stalls_total);
                eprintln!(
                    "WARNING: finalized epoch has not advanced for {advance_age}s \
                     (threshold {finality_stall_secs}s) — finality stall"
                );
            }
            finality_stalled = stalled_now;
        }

        let next_deadline = if slot > last_built && now < propose_at {
            propose_at
        } else {
            slot_start.saturating_add(slot_ms) // a deadline
        };
        let wait = next_deadline.saturating_sub(now_ms()).clamp(1, 500);
        match rx.recv_timeout(Duration::from_millis(wait)) {
            Ok(ev) => {
                let mut pending = vec![ev];
                while let Ok(more) = rx.try_recv() {
                    pending.push(more);
                }
                // Queue telemetry, before the batch is worked: what the
                // transports hold for this engine right now, and what they
                // have shed since start (O06).
                {
                    use crate::metrics::{NodeMetrics, NODE};
                    NodeMetrics::set(&NODE.net_queue_inflight, inflight.inflight() as u64);
                    NodeMetrics::set(&NODE.net_queue_bytes, inflight.inflight_bytes() as u64);
                    let (sb, sa, st) = inflight.shed();
                    NodeMetrics::set(&NODE.net_shed_blocks_total, sb);
                    NodeMetrics::set(&NODE.net_shed_attestations_total, sa);
                    NodeMetrics::set(&NODE.net_shed_transactions_total, st);
                }
                for ev in pending {
                    // Every `EngineEvent::Net` was reserved in the budget by
                    // the transport; releasing it here — after handling, not
                    // on dequeue — is what makes the cap mean "work the engine
                    // has not done yet". The release charges the same pure
                    // size function the reservation did, so the two cancel
                    // exactly (see `net::queued_bytes`).
                    if let EngineEvent::Net(ref net_ev) = ev {
                        inflight.release(net_ev);
                    }
                    match ev {
                        EngineEvent::Net(NetEvent::Block(env, origin)) => {
                            // Judge first, THEN speak. Nothing is relayed
                            // until the engine has an answer — the same
                            // contract the attestation arm below runs on.
                            let verdict = engine.ingest_judged(env);
                            engine.net.report(&origin, verdict);
                        }
                        EngineEvent::Net(NetEvent::Attestation(att, origin)) => {
                            engine.on_attestation(att, origin, wall_epoch)
                        }
                        EngineEvent::Net(NetEvent::Transaction(tx, origin)) => {
                            let verdict = match engine.on_transaction(tx) {
                                Ok(_) => Verdict::Accept,
                                // A peer may have a different head, fee, epoch
                                // or pending input. Refuse relay without scoring
                                // that local-state difference as misconduct.
                                Err(_) => Verdict::Ignore,
                            };
                            engine.net.report(&origin, verdict);
                        }
                        EngineEvent::Rpc(call) => {
                            let result = engine.serve_rpc(call.req);
                            // A client that hung up between asking and being
                            // answered is normal, not an error worth logging.
                            let _ = call.reply.send(result);
                        }
                    }
                }
            }
            Err(mpsc::RecvTimeoutError::Timeout) => {}
            Err(mpsc::RecvTimeoutError::Disconnected) => {
                return Err(io::Error::new(
                    io::ErrorKind::BrokenPipe,
                    "network channel closed",
                ));
            }
        }
    }
}

/// LMD-GHOST head over `blocks`, given the loose attestations in `pool`, the
/// stake-weighted `validators`, and the `justified` root the walk starts from.
///
/// A free function of its inputs, not a method over node state, for the reason
/// §5.5 gives: a consensus-relevant value must be derivable from arguments so
/// it can be reasoned about and tested without standing up a node. It is also
/// what makes the divergence from longest-chain testable at all — see
/// `forkchoice_tests::weight_beats_length` at the bottom of this file.
pub fn lmd_ghost_head<'a>(
    blocks: &BTreeMap<[u8; 32], BlockEnvelope>,
    pool: impl Iterator<Item = &'a Attestation>,
    validators: &[bloch_pos_committee::sample::Validator],
    justified: [u8; 32],
) -> [u8; 32] {
    let (fc, parents, children) = forkchoice_store(blocks, pool, validators);
    let tree = BlockTree { parents: &parents };
    fc.head(&tree, justified, &children)
}

/// [`lmd_ghost_head`] through the pre-2026-08-23 O(V·D²) fork choice.
///
/// The differential oracle, and nothing else:
/// `head_matches_the_reference_implementation` feeds both this and
/// [`lmd_ghost_head`] the same randomised
/// DAGs and asserts the selected head is identical. Without it the rewrite of
/// `Store::head` would be a claim about a consensus-relevant value rather than
/// a tested property — and the 2026-08-08 fork is what that costs.
/// Test-only: the binary must not carry an O(V·D²) fork choice it can reach.
#[cfg(test)]
pub fn lmd_ghost_head_reference<'a>(
    blocks: &BTreeMap<[u8; 32], BlockEnvelope>,
    pool: impl Iterator<Item = &'a Attestation>,
    validators: &[bloch_pos_committee::sample::Validator],
    justified: [u8; 32],
) -> [u8; 32] {
    let (fc, parents, children) = forkchoice_store(blocks, pool, validators);
    let tree = BlockTree { parents: &parents };
    fc.head_reference(&tree, justified, &children)
}

/// The fork-choice inputs, assembled: the store of latest messages, the parent
/// map and the sibling lists. Shared by the two entry points above so they
/// cannot drift — a differential test whose two sides observe different
/// message sets proves nothing.
#[allow(clippy::type_complexity)]
fn forkchoice_store<'a>(
    blocks: &BTreeMap<[u8; 32], BlockEnvelope>,
    pool: impl Iterator<Item = &'a Attestation>,
    validators: &[bloch_pos_committee::sample::Validator],
) -> (
    FcStore,
    HashMap<[u8; 32], [u8; 32]>,
    HashMap<[u8; 32], Vec<[u8; 32]>>,
) {
    let mut parents: HashMap<[u8; 32], [u8; 32]> = HashMap::new();
    let mut children: HashMap<[u8; 32], Vec<[u8; 32]>> = HashMap::new();
    for (id, env) in blocks {
        parents.insert(*id, env.header.parent);
        children.entry(env.header.parent).or_default().push(*id);
    }
    for kids in children.values_mut() {
        kids.sort_unstable();
    }

    let mut fc = FcStore::new();
    // Weight is the stake the CANONICAL state committed. A competing branch may
    // commit a different validator set; using its numbers would let a branch
    // vote itself heavier, so the fork choice reads one set — the one this node
    // has validated — exactly as Ethereum weights by the justified state.
    for v in validators {
        fc.set_stake(v.index, v.effective_stake);
    }
    for env in blocks.values() {
        for att in &env.body.attestations {
            fc.observe(
                att.validator,
                LatestMessage {
                    slot: att.data.slot,
                    root: att.data.head,
                },
            );
        }
    }
    // Attestations seen on the wire but not yet in any block count too: that is
    // what makes the head responsive within a slot instead of one block behind.
    for att in pool {
        fc.observe(
            att.validator,
            LatestMessage {
                slot: att.data.slot,
                root: att.data.head,
            },
        );
    }

    (fc, parents, children)
}

/// Whether the mempool will hold `tx` at all.
///
/// A free function, not a method, so it can be tested without standing up an
/// engine — the checks are a pure function of the transaction and the
/// caller's `wall_epoch`, nothing else, and a rule that needs a running node
/// to exercise is a rule that stops being exercised.
///
/// `wall_epoch` is the admitting node's WALL-CLOCK epoch
/// (`epoch_of(self.wall_slot())` at the call site in `on_transaction`), and
/// it exists for exactly one arm: the `TransferV2` flag-day gate below. It is
/// in EPOCHS, not slots — `bloch_pos_committee::params`'s
/// `TRANSFER_WITNESS_DEDUP_ACTIVATION_EPOCH` is an epoch (cited by symbol, not
/// by line: the line number it used to give had already rotted), and a caller
/// passing a raw slot would be
/// early by `SLOTS_PER_EPOCH` (32×). The boundary test pins the unit by
/// deriving both sides of the flag day from slots via `epoch_of`.
///
/// Deliberately STRUCTURAL, not a validity check. A complete answer means
/// running the transition, which needs a candidate header this path has no
/// reason to build. What it catches is the class that has actually been
/// exploited or is currently exploitable.
/// The mempool's mirror of the two bounds `apply_transfer`/`apply_transfer_v2`
/// put in front of the fee multiplication (`fee_market::MAX_TIP_MILLISAT_PER_GAS`
/// and `fee_market::MAX_TX_GAS`).
///
/// Consensus is where these bounds LIVE — this is the door that stops the
/// transaction propagating, and the distinction is the `admissible`
/// deposit lesson written above: a rule that exists only here is a rule one
/// patched producer lifts for the whole network. But a rule that exists only
/// in consensus still lets an attacker fill every mempool on the network with
/// transactions no block can carry, and this pair is free to check.
///
/// H1 (2026-09-04): the transfer these refuse used to reach `charge` and
/// overflow `u128` there, which a consensus build turns into a panic. The
/// mempool held it, gossip spread it, and every proposer that selected it
/// died pricing its own block.
fn price_bounds(
    class: fee_market::TxClass,
    tx_bytes: u64,
    tip_millisat_per_gas: u128,
) -> Result<(), &'static str> {
    if tip_millisat_per_gas > fee_market::MAX_TIP_MILLISAT_PER_GAS {
        return Err(
            "transfer names a tip above the consensus ceiling — no block could carry it",
        );
    }
    if fee_market::intrinsic_gas(class, tx_bytes) > fee_market::MAX_TX_GAS {
        return Err(
            "transfer declares more gas than a whole block may spend — no block could carry it",
        );
    }
    Ok(())
}

/// The mempool's mirror of the declared-size ceiling (audit H-R7-2): a
/// transfer whose declared `tx_bytes` exceeds its own canonical encoding by
/// more than `fee_market::TX_BYTES_DECLARE_SLACK` is refused at the door.
///
/// Node-local POLICY, live today — unlike the consensus half
/// (`TransferReject::OverdeclaredSize`), which ships gated behind the inert
/// `params::TX_BYTES_BOUND_ACTIVATION_EPOCH` because it tightens transfer
/// validity. The two are not redundant, per the `admissible` deposit lesson
/// above: this door stops the transaction propagating and being SELECTED —
/// the declared size is what the block byte cap counts, so an unbounded
/// declaration is a whole block's byte budget consumed by one small, cheap
/// transaction, and (before `select_transactions` learned to budget by
/// declared size) an hour of innocent transactions barred by the probe-drop
/// loop — while the consensus rule is what will stop a patched producer
/// lifting it for the whole network once armed.
///
/// The encode costs one linear pass over bytes the caller already holds,
/// placed with the free structural checks and long before the hybrid
/// signature verifications.
fn declared_size_bound(tx: &PosTransaction, declared: u64) -> Result<(), &'static str> {
    let encoded = tx.canonical_bytes().len() as u64;
    if declared > encoded.saturating_add(fee_market::TX_BYTES_DECLARE_SLACK) {
        return Err(
            "transfer declares far more bytes than its encoding carries — the declared \
             size is what the block byte cap counts, so this would crowd honest \
             transactions out of blocks without carrying anything",
        );
    }
    Ok(())
}

pub(crate) fn admissible(tx: &PosTransaction, wall_epoch: u64) -> Result<(), &'static str> {
    match tx {
        PosTransaction::FundedDeposit(deposit) => {
            if !bloch_pos_committee::params::funded_validator_admission_active(wall_epoch) {
                return Err("funded validator admission is not active: FUNDED_VALIDATOR_ADMISSION_ACTIVATION_EPOCH is unarmed or not reached");
            }
            if wall_epoch > deposit.valid_until_epoch { return Err("funded deposit has expired"); }
            deposit.verify_authorizations(&HybridVerifier::new())
                .map_err(|_| "invalid funded deposit shape or hybrid PQ authorization")
        }

        // Staking messages are refused outright until bonding is funded from
        // the eUTXO set.
        //
        // `Deposit` carries no signature and spends no output: it names an
        // `amount_sat` and the transition registers a validator holding it.
        // `transition.rs` documents the gap ("a deposit creates bonded stake
        // without destroying spendable coins"), which was tolerable while the
        // two pools only ever met on a devnet. On a live chain behind a public
        // endpoint it is stake minted from nothing — measured on 2026-08-13 at
        // 25,000 BLOCH per unauthenticated request, roughly forty-six requests
        // to a third of the active stake and stop finality, a hundred and
        // eighty to two thirds and take the chain.
        //
        // THIS IS NO LONGER THE ONLY THING STANDING HERE, and the sentence
        // that used to be at this spot is the reason the gap was found: "this
        // is a node-side refusal, not a consensus rule: a block that already
        // carries a deposit still applies it." That was true and it was the
        // whole defect. `admissible` has exactly one non-test caller — the
        // mempool door below — so a single producer that patched it out lifted
        // the rule for all sixty-four nodes, because every one of them judged
        // the block with `bloch-pos-committee`, and that crate applied the
        // deposit unconditionally.
        //
        // The rule now lives where it belongs:
        // `params::DEPOSIT_ACTIVATION_EPOCH`, read at the transition by
        // `apply_transaction` off the block's own committed epoch, refusing
        // with `TxReject::StakingNotActive`. `Delegate` is gated by the same
        // constant, because it reaches `effective_stake` a full activation
        // delay sooner.
        //
        // What is left here is what it should always have been: an early,
        // cheap rejection that keeps a transaction consensus will never apply
        // out of the mempool and off the wire. It is not load-bearing. The
        // real closure — giving deposits and withdrawals eUTXO inputs and
        // outputs, authenticated — is still a wire-format change and still
        // needs a tag and a flag day of its own; see the constant's docs for
        // why arming `DEPOSIT_ACTIVATION_EPOCH` is NOT that change.
        PosTransaction::Deposit { .. } => Err(
            "deposits are not accepted: bonding is not yet funded from the UTXO set, \
             so a deposit would create stake without spending coins",
        ),
        PosTransaction::Delegate { .. } => Err(
            "delegations are not accepted: bonding is not yet funded from the UTXO set, \
             so a delegation would create stake without spending coins",
        ),
        // One transaction consensus would never apply halted the live testnet:
        // every proposer that selected it failed to produce, and the chain
        // stopped at slot 69 with every node up and still attesting. Cost of
        // the attack: one unauthenticated request.
        PosTransaction::Transfer {
            inputs,
            outputs,
            tx_bytes,
            tip_millisat_per_gas,
        } => {
            if inputs.is_empty() {
                return Err("transfer has no inputs — it spends nothing and cannot apply");
            }
            if outputs.is_empty() {
                return Err("transfer has no outputs — it pays no one and cannot apply");
            }
            // H-R7-3, the mempool half — NODE-LOCAL POLICY, live ungated.
            // Every output is a permanent ~76-byte `EutxoEntry` on every
            // node, priced only by the one-time fee on its bytes (~6.4 sat
            // per output at the floor): dust and zero-value outputs are
            // unbounded state growth sold for nothing, and this door is
            // what stops NEW ones propagating. The consensus half of the
            // same rule lives in `apply_transfer`/`apply_transfer_v2`
            // behind `params::DUST_RULE_ACTIVATION_EPOCH` (inert,
            // u64::MAX — arming it is a founder decision), because there
            // the refusal changes the verdict on bodies that are valid
            // today. Here it changes only what this node relays, which no
            // block's validity depends on — the deposit lesson's inverse.
            if outputs.len() > bloch_pos_committee::params::MAX_TRANSFER_OUTPUTS {
                return Err(
                    "transfer creates more outputs than the per-transaction cap —                      each output is a permanent ledger entry on every node",
                );
            }
            if outputs
                .iter()
                .any(|o| o.value < bloch_pos_committee::params::MIN_TRANSFER_OUTPUT_SAT)
            {
                return Err(
                    "transfer creates a dust or zero-value output — below the minimum                      output value, it grows the permanent ledger for (almost) nothing",
                );
            }
            price_bounds(
                fee_market::TxClass::Eutxo {
                    inputs: inputs.len() as u32,
                },
                *tx_bytes,
                *tip_millisat_per_gas,
            )?;
            declared_size_bound(tx, *tx_bytes)?;
            // THE SIGNATURE IS CHECKED HERE, BEFORE THE MEMPOOL, AND THIS IS WHY.
            //
            // The producer prices its own block with `ProbeVerifier`, whose
            // verify_with_key returns true for anything (keys.rs). A Transfer's spend
            // signature is checked THROUGH that injected verifier
            // (transition.rs, "Authorisation: the expensive check, last"), so a
            // transfer with a valid shape and a garbage signature passes the probe,
            // goes into a proposed block, and is then refused by the real
            // HybridVerifier during ingest. The head does not move, and the
            // assert below used to turn that into a panic — one transaction, and
            // every node that proposed it died in its own slot.
            //
            // Refusing at the mempool door is what stops it PROPAGATING. The
            // signature is the expensive check and it is deliberately last, after
            // the two free ones above.
            let signing_root = tx.spend_signing_root();
            for i in inputs {
                if !bloch_crypto::crypto::verify(&i.pubkey, &signing_root, &i.signature) {
                    return Err("transfer carries a signature that does not verify");
                }
            }
            Ok(())
        }
        // TransferV2 (tag 0x06): admitted from its flag day, refused before
        // it — the era decides, and WHICH era to read differs on the two
        // sides of the mempool door.
        //
        // Consensus gates this format on COMMITTED state rolled to the
        // block's own epoch (`apply_transaction`'s FormatNotActive arm,
        // transition.rs:1706–1718) and must: deriving a consensus verdict
        // from anything node-local is how the 2026-08-08 `expected_bits`
        // fork happened. Admission is NOT consensus — it is node-local
        // policy, and it answers a different question: "can some FUTURE
        // block apply this?". Every block is proposed for a wall-clock slot
        // (the slot loop, `run`), so every block that could carry this
        // transaction has an epoch >= the admitting node's wall epoch; from
        // wall epoch 800 onward no future block answers FormatNotActive.
        // Reading the HEAD's epoch here instead would strand exactly the
        // nodes the post-flag-day carryover sweep (426,194 inputs) must
        // relay through: a syncing or lagging node has a head epochs behind
        // the wall and would refuse the format after activation — the
        // "admitted too late, never propagates" failure. The residue of the
        // wall-clock choice is only boundary skew: a fast clock admits and
        // gossips seconds before its peers activate. Peers refuse without
        // penalty (the gossip path answers to nobody — `on_transaction`'s
        // caller ignores the verdict), and a still-799 proposer that
        // selects it probe-drops it from the mempool one transaction at a
        // time instead of stalling (the drop-and-retry loop in `propose`,
        // the slot-69 lesson). Early side costs one ejected, resendable
        // transaction; late side costs the sweep. The asymmetry decides.
        PosTransaction::TransferV2 {
            keys,
            inputs,
            outputs,
            tx_bytes,
            tip_millisat_per_gas,
        } => {
            // The gate first, and pre-activation the refusal is today's,
            // byte for byte: before epoch 800 this arm's behaviour is the
            // CONTROL and must not move.
            if wall_epoch < bloch_pos_committee::params::TRANSFER_WITNESS_DEDUP_ACTIVATION_EPOCH {
                return Err(
                    "deduplicated transfers (tag 0x06) are not active: the format ships \
                     behind a flag day (TRANSFER_WITNESS_DEDUP_ACTIVATION_EPOCH) that this \
                     chain has not reached",
                );
            }
            // Cheap-first from here, mirroring the Transfer arm above and
            // the consensus arm this one fronts for (`apply_transfer_v2`,
            // transition.rs:2017–2130): structure, then table discipline,
            // then — last and only then — signatures. This path is
            // unauthenticated, so an invalid shape must cost zero hybrid
            // verifications (~145 µs each, measured 2026-08-21).
            if inputs.is_empty() {
                return Err("transfer has no inputs — it spends nothing and cannot apply");
            }
            if outputs.is_empty() {
                return Err("transfer has no outputs — it pays no one and cannot apply");
            }
            // H-R7-3, the mempool half — NODE-LOCAL POLICY, live ungated.
            // Every output is a permanent ~76-byte `EutxoEntry` on every
            // node, priced only by the one-time fee on its bytes (~6.4 sat
            // per output at the floor): dust and zero-value outputs are
            // unbounded state growth sold for nothing, and this door is
            // what stops NEW ones propagating. The consensus half of the
            // same rule lives in `apply_transfer`/`apply_transfer_v2`
            // behind `params::DUST_RULE_ACTIVATION_EPOCH` (inert,
            // u64::MAX — arming it is a founder decision), because there
            // the refusal changes the verdict on bodies that are valid
            // today. Here it changes only what this node relays, which no
            // block's validity depends on — the deposit lesson's inverse.
            if outputs.len() > bloch_pos_committee::params::MAX_TRANSFER_OUTPUTS {
                return Err(
                    "transfer creates more outputs than the per-transaction cap —                      each output is a permanent ledger entry on every node",
                );
            }
            if outputs
                .iter()
                .any(|o| o.value < bloch_pos_committee::params::MIN_TRANSFER_OUTPUT_SAT)
            {
                return Err(
                    "transfer creates a dust or zero-value output — below the minimum                      output value, it grows the permanent ledger for (almost) nothing",
                );
            }
            // An empty witness table would make the signature loop below
            // pass VACUOUSLY — zero verifications, admitted, gossiped — so a
            // shape consensus can never apply (every input must index into
            // the table) would traverse the mesh for free. That is the
            // mempool-stuffing class this function exists to refuse, and
            // the check is load-bearing, not defensive.
            if keys.is_empty() {
                return Err(
                    "deduplicated transfer carries no witness keys — nothing authorises it",
                );
            }
            // The two price bounds, on the V2 class term (one verification
            // per TABLE entry) — mirroring `apply_transfer_v2`.
            price_bounds(
                fee_market::TxClass::Eutxo {
                    inputs: keys.len() as u32,
                },
                *tx_bytes,
                *tip_millisat_per_gas,
            )?;
            declared_size_bound(tx, *tx_bytes)?;
            // Stateless mirror of the table disciplines consensus enforces
            // and has mutation-proven (transition.rs:2043–2094 —
            // DuplicateWitnessKey, BadKeyIndex, WitnessKeyUnused). The one
            // V2 consensus check that CANNOT run here is ScriptMismatch: it
            // reads the spent outputs' committed `script_hash`
            // (transition.rs:2077), and this function is deliberately
            // stateless. Like V1's unknown-input case, that class reaches
            // the mempool and dies in the proposer's probe.
            let mut distinct: BTreeSet<&[u8]> = BTreeSet::new();
            for k in keys {
                if !distinct.insert(k.pubkey.as_slice()) {
                    return Err(
                        "deduplicated transfer repeats a witness key — one entry per owner",
                    );
                }
            }
            let mut used = vec![false; keys.len()];
            for i in inputs {
                let Some(slot) = used.get_mut(i.key_index as usize) else {
                    return Err("transfer input names a witness index outside the table");
                };
                *slot = true;
            }
            if used.iter().any(|u| !*u) {
                return Err(
                    "witness table carries an entry no input references — unpaid padding",
                );
            }
            // THE SIGNATURES, LAST — same placement and same reason as the
            // Transfer arm above, but ONE verification per TABLE ENTRY,
            // never per input. That is the format's entire point and the
            // exact economy consensus runs (`apply_transfer_v2`,
            // "Authorisation: the expensive check, last — ONCE PER OWNER"):
            // the signing root covers every spend point, so one signature
            // per key authorises all of that key's inputs. Admitting an
            // unverified table would hand an attacker free propagation of
            // garbage that every proposer then pays to drop.
            let signing_root = tx.spend_signing_root();
            for k in keys {
                if !bloch_crypto::crypto::verify(&k.pubkey, &signing_root, &k.signature) {
                    return Err("transfer carries a signature that does not verify");
                }
            }
            Ok(())
        }
        // Exit is UNAUTHENTICATED: its arm in transition.rs checks registry
        // state and never touches a verifier, and this catch-all used to admit
        // it. Sixty-four Exit messages would set exit_epoch on all sixty-four
        // validators, and an exit cannot be revoked (`exit_epoch != u64::MAX`
        // is refused), so the roster would empty and every bond lock for
        // `staking::WITHDRAWAL_DELAY_EPOCHS` = 2,048 epochs. Refused until the
        // message carries a signature that
        // binds it to the validator's own key.
        PosTransaction::Exit { .. } => Err(
            "exits are not accepted: the Exit message is not authenticated, \
             so anyone could retire any validator irreversibly",
        ),
        // The AUTHENTICATED replacement. Named explicitly rather than left to
        // the catch-all below, which returns `Ok(())`: a variant that reaches
        // `_` is a variant the mempool admits, and admitting a shape consensus
        // refuses is how a proposer builds a block nobody accepts.
        //
        // The gate first, and pre-activation the refusal is unconditional —
        // exactly the `TransferV2` arm's discipline. `EXIT_AUTH_ACTIVATION_EPOCH`
        // is `u64::MAX`, so this refuses at every epoch any chain can reach,
        // which is what keeps this node's mempool in step with the transition
        // arm it fronts for (`apply_exit_v2`).
        //
        // What this arm CANNOT do, stated rather than left to be discovered:
        // verify the hybrid signature. The signature is over the validator's
        // REGISTERED key, resolved from `pubkey_hash` through the committed
        // `pubkey_index`, and this function is deliberately stateless (see its
        // doc comment) — it holds no registry to resolve against. The
        // authorisation check therefore lives in consensus and only in
        // consensus, which is the right place for it: a mempool verdict is
        // relay policy, re-judged by the transition against the block's
        // pre-state. Post-activation this arm's job is the structural half —
        // an exit carrying no signature bytes at all can never verify, so
        // relaying one is free propagation of garbage every proposer then pays
        // to drop.
        PosTransaction::ExitV2 { epoch, signature, .. } => {
            if !bloch_pos_committee::params::epoch_gate_active(wall_epoch, bloch_pos_committee::params::EXIT_AUTH_ACTIVATION_EPOCH) {
                return Err(
                    "authenticated exits (tag 0x0C) are not active: the format ships \
                     behind a flag day (EXIT_AUTH_ACTIVATION_EPOCH) that this chain has \
                     not reached, and lifecycle activation remains disabled",
                );
            }
            exit_v2_structural_rules(*epoch, signature, wall_epoch)
        }
        // Slashing evidence (tag 0x05) became DECODABLE on 2026-09-05 (F-02),
        // which is exactly when it started being able to reach this catch-all
        // — before that the wire decoder refused it and no gossip or RPC
        // ingress could construct one. Named explicitly for the reason the
        // `ExitV2` arm states: a variant that reaches `_` is a variant the
        // mempool admits, and consensus refuses this one at every epoch below
        // the INERT `SLASHING_EVIDENCE_ACTIVATION_EPOCH`
        // (`TxReject::EvidenceNotActive`), so admitting it pre-gate would
        // relay transactions no block can carry — the mempool-stuffing class.
        //
        // Post-gate this arm admits: the pair's two hybrid signatures need
        // the offender's REGISTERED key, resolved through the committed
        // registry, and this function is deliberately stateless — the
        // verification lives in consensus (`apply_slashing_evidence`), which
        // re-judges every included evidence against the block's pre-state and
        // makes garbage evidence forfeit the whole block. Wall-clock epoch on
        // the mempool side, committed epoch on the consensus side — the
        // TransferV2 arm's asymmetry argument, unchanged.
        PosTransaction::Withdraw { .. } => {
            if !bloch_pos_committee::params::epoch_gate_active(wall_epoch, bloch_pos_committee::params::WITHDRAWAL_ACTIVATION_EPOCH) {
                return Err("validator withdrawals (tag 0x0D) are not active");
            }
            Ok(())
        }
        PosTransaction::SlashingEvidence(_) => {
            if !bloch_pos_committee::params::epoch_gate_active(wall_epoch, bloch_pos_committee::params::SLASHING_EVIDENCE_ACTIVATION_EPOCH) {
                return Err(
                    "slashing evidence (tag 0x05) is not active: the transaction ships \
                     behind a flag day (SLASHING_EVIDENCE_ACTIVATION_EPOCH) that this \
                     chain has not reached, so no block could carry it",
                );
            }
            Ok(())
        }
        // The RANDAO re-commit (H-R7-1) — named explicitly for the same
        // reason ExitV2 is: a variant that reaches `_` is a variant the
        // mempool ADMITS, and this shape is consensus-refused at every epoch
        // (`RANDAO_RECOMMIT_ACTIVATION_EPOCH` is `u64::MAX`) with its wire
        // byte (0x0A) unassigned besides. Pre-activation the refusal is
        // unconditional; post-activation the signature half still belongs to
        // consensus alone (this function is stateless — no registry to
        // resolve the validator's committed key against).
        PosTransaction::RandaoRecommit { .. } => {
            if !bloch_pos_committee::params::epoch_gate_active(wall_epoch, bloch_pos_committee::params::RANDAO_RECOMMIT_ACTIVATION_EPOCH) {
                return Err(
                    "RANDAO re-commits (tag 0x0A) are not active: the format ships                      behind a flag day (RANDAO_RECOMMIT_ACTIVATION_EPOCH) that this                      chain has not reached, and lifecycle activation remains disabled",
                );
            }
            Ok(())
        }
    }
}

/// The structural half of admitting an [`PosTransaction::ExitV2`], split out
/// of `admissible` so it can be TESTED.
///
/// It cannot be tested through `admissible` itself, and that is not an
/// oversight in the test: `EXIT_AUTH_ACTIVATION_EPOCH` is `u64::MAX`, so the
/// flag-day check in front of these rules refuses at every epoch any chain can
/// reach, and no argument to `admissible` ever gets past it. Rules that only
/// run after a flag day are exactly the rules that get to the flag day
/// unexercised. Extracting them makes them a pure function of three values and
/// therefore checkable today, on the tree the fleet runs, without arming
/// anything.
///
/// Both rules mirror consensus (`CommittedState::apply_exit_v2`) rather than
/// inventing relay policy:
///
/// - an exit with no signature bytes authorises nothing and can never verify,
///   so relaying it is free propagation of garbage every proposer pays to drop;
/// - the signed epoch must EQUAL the caller's epoch, because consensus binds
///   the signed epoch to the inclusion epoch. Without this, a captured exit —
///   and an exit is public the moment it is gossiped — would circulate for
///   every future proposer to try, forever.
///
/// What it deliberately does NOT do is check the signature. That needs the
/// validator's REGISTERED key, resolved through the committed `pubkey_index`,
/// and this path is stateless by design (see `admissible`'s docs). The
/// authorisation lives in consensus and only in consensus, which is the right
/// place for it: a mempool verdict is relay policy, re-judged by the
/// transition against the block's pre-state.
fn exit_v2_structural_rules(
    epoch: u64,
    signature: &[u8],
    wall_epoch: u64,
) -> Result<(), &'static str> {
    if signature.is_empty() {
        return Err("authenticated exit carries no signature — nothing authorises it");
    }
    // Equality, matching consensus exactly, and NOT a window: a one-epoch
    // grace here would relay messages consensus refuses, which is the
    // mempool/consensus mismatch this arm exists to avoid. A sender caught by
    // an epoch boundary re-signs for the epoch it is now in; an exit is not
    // time-critical and the signature is the sender's to reissue.
    if epoch != wall_epoch {
        return Err(
            "authenticated exit is signed for a different epoch than the one it would be \
             included in; consensus binds the two, so this can never apply",
        );
    }
    Ok(())
}

#[cfg(test)]
mod forkchoice_tests {
    use super::*;
    use bloch_pos_committee::sample::Validator;

    fn header(parent: [u8; 32], slot: u64, marker: u8) -> BlockHeaderV4 {
        BlockHeaderV4 {
            version: VERSION_G4,
            parent,
            state_root: [marker; 32],
            body_root: [0u8; 32],
            slot,
            proposer_index: 0,
            randao_reveal: [0u8; 32],
            randao_mix: [0u8; 32],
            justified_root: [0u8; 32],
            finalized_root: [0u8; 32],
            attestation_root: [0u8; 32],
            coherence_root: [0u8; 32],
        }
    }

    fn attest(validator: u32, slot: u64, head: [u8; 32]) -> Attestation {
        Attestation {
            validator,
            data: AttestationData {
                slot,
                head,
                source_epoch: 0,
                source_root: [0u8; 32],
                target_epoch: 0,
                target_root: head,
            },
            signature: Vec::new(),
        }
    }

    /// Build `blocks` from `(parent, slot, marker, attestations)` tuples,
    /// returning the map and each block's id in order.
    fn chain_of(
        specs: Vec<([u8; 32], u64, u8, Vec<Attestation>)>,
    ) -> (BTreeMap<[u8; 32], BlockEnvelope>, Vec<[u8; 32]>) {
        let mut blocks = BTreeMap::new();
        let mut ids = Vec::new();
        for (parent, slot, marker, atts) in specs {
            let h = header(parent, slot, marker);
            let id = *BlockId::of(&h).as_bytes();
            blocks.insert(
                id,
                BlockEnvelope {
                    header: h,
                    proposer_sig: Vec::new(),
                    body: Body {
                        transactions: Vec::new(),
                        attestations: atts,
                    },
                },
            );
            ids.push(id);
        }
        (blocks, ids)
    }

    fn vals(n: u32) -> Vec<Validator> {
        (0..n)
            .map(|index| Validator {
                index,
                effective_stake: 100,
            })
            .collect()
    }

    /// The exposure this closes: a `Deposit` names an amount and spends no
    /// output. Until bonding is funded from the eUTXO set, admitting one is
    /// admitting stake minted from nothing.
    ///
    /// It does now carry a signature — a proof of possession over its own
    /// fields, checked by the transition (`staking::validate_wire_deposit`)
    /// so that the key the state root commits is one its depositor can
    /// actually sign under. That proves who owns the KEY; it proves nothing
    /// about where the STAKE came from, which is the separate hole this
    /// refusal covers and which only funded bonding closes.
    #[test]
    fn staking_messages_are_refused_until_bonding_is_funded() {
        let deposit = PosTransaction::Deposit {
            pubkey: vec![0u8; 32],
            amount_sat: 25_000 * 100_000_000,
            randao_commitment: [7u8; 32],
            withdrawal_credentials: vec![1u8; 20],
            commission_bps: 0,
            proof_of_possession: Vec::new(),
        };
        let err = admissible(&deposit, 0).expect_err("a deposit must not be admitted");
        assert!(
            err.contains("not yet funded"),
            "the refusal must say why: {err}"
        );

        let delegate = PosTransaction::Delegate {
            delegator: 0,
            validator: 0,
            amount_sat: 1,
            eligible: true,
        };
        assert!(
            admissible(&delegate, 0).is_err(),
            "a delegation must not be admitted either"
        );
    }

    /// The transfer guard that already existed, pinned so the refactor into a
    /// free function cannot quietly drop it — this is the check that stopped
    /// the one-request halt at slot 69.
    #[test]
    fn a_transfer_that_spends_nothing_is_refused() {
        let empty = PosTransaction::Transfer {
            inputs: vec![],
            outputs: vec![bloch_pos_committee::transition::TransferOutput {
                value: 1,
                script_hash: [0u8; 32],
            }],
            tx_bytes: 0,
            tip_millisat_per_gas: 0,
        };
        assert!(
            admissible(&empty, 0).is_err(),
            "a transfer with no inputs must not be admitted"
        );
    }

    /// Tag 0x05 decodes since 2026-09-05 (F-02), so it can now arrive at the
    /// mempool door — and below the scheduled flag day consensus refuses it
    /// (`TxReject::EvidenceNotActive`), so admission would relay a
    /// transaction no block can carry. Goes red if the arm falls back into
    /// the `_ => Ok(())` catch-all, and goes red at any wall epoch below the
    /// gate if someone arms the constant without revisiting this door.
    #[test]
    fn slashing_evidence_is_refused_at_the_door_below_its_flag_day() {
        let attest = |head: u8| bloch_pos_committee::Attestation {
            data: bloch_pos_committee::AttestationData {
                slot: 32,
                head: [head; 32],
                source_epoch: 0,
                source_root: [1; 32],
                target_epoch: 1,
                target_root: [head; 32],
            },
            validator: 2,
            signature: vec![0u8; 8],
        };
        let ev = PosTransaction::SlashingEvidence(
            bloch_pos_committee::interfaces::SlashingEvidence::AttestationOffence {
                first: attest(0xAA),
                second: attest(0xBB),
            },
        );
        for wall_epoch in [0u64, 2_700, bloch_pos_committee::params::SLASHING_EVIDENCE_ACTIVATION_EPOCH.saturating_sub(1)] {
            let err = admissible(&ev, wall_epoch)
                .expect_err("evidence must not be admitted below its flag day");
            assert!(
                err.contains("SLASHING_EVIDENCE_ACTIVATION_EPOCH"),
                "the refusal must name the gate: {err}"
            );
        }
    }

    /// **The reason this fork choice was changed.** A branch three blocks long
    /// with one attester loses to a branch one block long with three.
    ///
    /// Under longest-valid-chain — what the node ran until now — the head is
    /// the tip of the long branch, and a proposer who can produce blocks fast
    /// overrides whatever the honest majority has voted for. Length is not the
    /// security statement in proof of stake; attested stake is. Without this
    /// test, swapping the implementations would be a claim rather than a
    /// change: the cooperative devnet passes either way, because on a chain
    /// with no forks the two rules agree.
    #[test]
    fn weight_beats_length() {
        let g = [0x99u8; 32]; // the justified root the walk starts from

        // Long branch: three blocks, one attester on the tip.
        // Short branch: one block, three attesters.
        let (mut blocks, long_ids) = chain_of(vec![(g, 1, 1, vec![])]);
        let a1 = long_ids[0];
        let (more, a_rest) = chain_of(vec![(a1, 2, 2, vec![])]);
        blocks.extend(more);
        let a2 = a_rest[0];
        let (more, a_rest) = chain_of(vec![(a2, 3, 3, vec![])]);
        blocks.extend(more);
        let a3 = a_rest[0];

        let (short, short_ids) = chain_of(vec![(g, 1, 9, vec![])]);
        blocks.extend(short);
        let b1 = short_ids[0];
        assert_ne!(a1, b1, "the two branches must actually be siblings");

        let validators = vals(4);
        // Validator 0 attests the long tip; 1, 2 and 3 attest the short one.
        let pool = vec![
            attest(0, 3, a3),
            attest(1, 1, b1),
            attest(2, 1, b1),
            attest(3, 1, b1),
        ];

        let head = lmd_ghost_head(&blocks, pool.iter(), &validators, g);
        assert_eq!(
            head, b1,
            "fork choice followed length instead of attested weight — LMD-GHOST is not wired"
        );

        // And the converse, so the assertion above is not passing for some
        // incidental reason: move the weight and the head moves with it.
        let pool_flipped = vec![
            attest(0, 3, a3),
            attest(1, 3, a3),
            attest(2, 3, a3),
            attest(3, 1, b1),
        ];
        assert_eq!(
            lmd_ghost_head(&blocks, pool_flipped.iter(), &validators, g),
            a3
        );
    }

    /// The head is a function of the message *set*. Feeding the same
    /// attestations in a different order must not move it — the property whose
    /// violation in `Store::observe` made two honest nodes with identical
    /// inputs compute different heads (found 2026-08-11).
    #[test]
    fn head_is_independent_of_attestation_order() {
        let g = [0x99u8; 32];
        let (mut blocks, ids) = chain_of(vec![(g, 1, 1, vec![])]);
        let a1 = ids[0];
        let (short, sids) = chain_of(vec![(g, 1, 9, vec![])]);
        blocks.extend(short);
        let b1 = sids[0];

        let validators = vals(4);
        let mut pool = vec![attest(0, 1, a1), attest(1, 1, b1), attest(2, 1, b1)];
        let first = lmd_ghost_head(&blocks, pool.iter(), &validators, g);
        pool.reverse();
        let second = lmd_ghost_head(&blocks, pool.iter(), &validators, g);
        assert_eq!(first, second);
    }

    /// Attestations from validators the canonical state does not know carry no
    /// weight. Otherwise a branch could invent voters — the fork choice reads
    /// one validator set, not the one each branch commits.
    #[test]
    fn unknown_validators_carry_no_weight() {
        let g = [0x99u8; 32];
        let (mut blocks, ids) = chain_of(vec![(g, 1, 1, vec![])]);
        let a1 = ids[0];
        let (short, sids) = chain_of(vec![(g, 1, 9, vec![])]);
        blocks.extend(short);
        let b1 = sids[0];

        // Only validator 0 exists; it votes the long-branch block. Fifty
        // invented voters back the other one.
        let validators = vals(1);
        let mut pool = vec![attest(0, 1, a1)];
        pool.extend((100..150u32).map(|v| attest(v, 1, b1)));
        assert_eq!(lmd_ghost_head(&blocks, pool.iter(), &validators, g), a1);
    }

    /// An equivocator is barred entirely, not counted for either side. With the
    /// remaining honest stake tied, the tie-break is the larger root — the only
    /// property that matters being that every node breaks it the same way.
    #[test]
    fn equivocator_weight_is_discarded() {
        let g = [0x99u8; 32];
        let (mut blocks, ids) = chain_of(vec![(g, 1, 1, vec![])]);
        let a1 = ids[0];
        let (short, sids) = chain_of(vec![(g, 1, 9, vec![])]);
        blocks.extend(short);
        let b1 = sids[0];

        let validators = vals(2);
        // Validator 1 signs both heads in the same slot; validator 0 backs a1.
        let pool = vec![attest(0, 1, a1), attest(1, 1, a1), attest(1, 1, b1)];
        let head = lmd_ghost_head(&blocks, pool.iter(), &validators, g);
        assert_eq!(
            head, a1,
            "the equivocator was counted, or the honest vote was dropped"
        );
    }

    // ── The 2026-08-23 rewrite, checked from the node's own entry point ─────

    /// splitmix64, so the randomised DAG below is reproducible and adds no
    /// dependency (the committee crate's property suite uses the same one).
    struct Rng(u64);

    impl Rng {
        fn next_u64(&mut self) -> u64 {
            self.0 = self.0.wrapping_add(0x9E37_79B9_7F4A_7C15);
            let mut z = self.0;
            z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
            z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
            z ^ (z >> 31)
        }

        fn below(&mut self, n: u64) -> u64 {
            ((self.next_u64() as u128 * n as u128) >> 64) as u64
        }
    }

    /// **The differential test at the node's boundary.** `Store::head` was
    /// rewritten from O(V·D²) to a bottom-up accumulation; the committee
    /// crate's `forkchoice_head_matches_the_reference_implementation` pins the
    /// two against each other on synthetic parent maps, and this pins them on
    /// what the node actually feeds it — real `BlockEnvelope`s, attestations
    /// carried in block bodies as well as loose in the pool, and the parent
    /// map and sibling lists built by `forkchoice_store`.
    ///
    /// Fork choice selects the head. If these two ever disagree the change is
    /// a hard fork rather than a speed-up, which is the whole reason the old
    /// algorithm was kept as `lmd_ghost_head_reference` instead of deleted.
    #[test]
    fn head_matches_the_reference_implementation() {
        let mut rng = Rng(0x0806_2308_5EED_5EED);
        let g = [0x99u8; 32];
        for round in 0..120u64 {
            // A random forest over genesis: every block picks an earlier block
            // or genesis as its parent, so forks, long branches and single
            // blocks all occur.
            let n = 1 + rng.below(24) as usize;
            let mut blocks: BTreeMap<[u8; 32], BlockEnvelope> = BTreeMap::new();
            let mut ids: Vec<[u8; 32]> = Vec::new();
            for i in 0..n {
                let parent = if i == 0 || rng.below(4) == 0 {
                    g
                } else {
                    ids[rng.below(i as u64) as usize]
                };
                // Some blocks carry attestations in the body — the half of the
                // message set that never passes through the pool.
                let n_atts = rng.below(3) as usize;
                let atts: Vec<Attestation> = (0..n_atts)
                    .map(|_| {
                        let v = rng.below(8) as u32;
                        let slot = 1 + rng.below(4);
                        let head = if ids.is_empty() || rng.below(4) == 0 {
                            g
                        } else {
                            ids[rng.below(ids.len() as u64) as usize]
                        };
                        attest(v, slot, head)
                    })
                    .collect();
                let (one, one_id) = chain_of(vec![(parent, i as u64 + 1, i as u8, atts)]);
                blocks.extend(one);
                ids.push(one_id[0]);
            }

            // Loose attestations, including votes for blocks that do not
            // exist and same-slot pairs that make a validator an equivocator.
            let n_loose = rng.below(12) as usize;
            let pool: Vec<Attestation> = (0..n_loose)
                .map(|_| {
                    let v = rng.below(8) as u32;
                    let slot = 1 + rng.below(4);
                    let head = match rng.below(6) {
                        0 => [rng.next_u64() as u8; 32], // never seen
                        1 => g,
                        _ => ids[rng.below(ids.len() as u64) as usize],
                    };
                    attest(v, slot, head)
                })
                .collect();

            // Uniform stake on half the rounds so sibling weights tie and the
            // tie-break — not the arithmetic — decides the head.
            let validators: Vec<Validator> = if round % 2 == 0 {
                vals(8)
            } else {
                (0..8u32)
                    .map(|index| Validator {
                        index,
                        effective_stake: 1 + rng.below(1_000_000),
                    })
                    .collect()
            };

            for justified in [g, ids[rng.below(ids.len() as u64) as usize]] {
                assert_eq!(
                    lmd_ghost_head(&blocks, pool.iter(), &validators, justified),
                    lmd_ghost_head_reference(&blocks, pool.iter(), &validators, justified),
                    "round {round}: the rewritten fork choice selected a \
                     different head than the one it replaced"
                );
            }
        }
    }

    /// **Why `apply_canonical` may drop an attestation from the pool without
    /// forcing `advance` to recompute.** Fork choice observes every stored
    /// block's body *and* the loose pool. An attestation that leaves the pool
    /// because the block carrying it became canonical is therefore still
    /// observed, from that block — the head cannot move.
    ///
    /// That is the entire justification for `fc_covered_removals` in
    /// `Engine::forkchoice_inputs`. The second half of the test is the
    /// control: an attestation no stored block carries is NOT free to drop,
    /// which is why the epoch `retain` on the next line still invalidates the
    /// memo.
    #[test]
    fn an_attestation_its_block_carries_is_free_to_leave_the_pool() {
        let g = [0x99u8; 32];
        let validators = vals(4);

        // Two siblings. Validators 0 and 1 back `heavy`; validator 2 backs
        // `light`. The attestations for `heavy` ride inside `heavy`'s body.
        let (blocks_a, a_ids) = chain_of(vec![(g, 1, 1, Vec::new())]);
        let light = a_ids[0];
        let carried = vec![attest(0, 1, light), attest(1, 1, light)];
        let (blocks_b, b_ids) = chain_of(vec![(g, 1, 9, carried.clone())]);
        let mut blocks = blocks_a;
        blocks.extend(blocks_b);
        let carrier = b_ids[0];
        // The carried votes name `light`, so `light` wins while they count.
        let with_pool: Vec<Attestation> = carried.clone();
        let without_pool: Vec<Attestation> = Vec::new();
        assert_eq!(
            lmd_ghost_head(&blocks, with_pool.iter(), &validators, g),
            lmd_ghost_head(&blocks, without_pool.iter(), &validators, g),
            "dropping from the pool an attestation the stored block {} still \
             carries moved the head — `fc_covered_removals` would be unsound",
            crate::codec::hex8(&carrier)
        );

        // Control, on a block set with NOTHING in any body: two siblings and
        // one loose vote for the lexicographically smaller of them. With the
        // vote it wins on weight; without it the pair is a zero-zero tie and
        // the tie-break hands the head to the other one. So an attestation no
        // stored block carries is emphatically NOT free to drop — which is why
        // the epoch `retain` in `apply_canonical` still invalidates the memo.
        let (mut bare, x_ids) = chain_of(vec![(g, 1, 0x11, Vec::new())]);
        let (bare_b, y_ids) = chain_of(vec![(g, 1, 0x22, Vec::new())]);
        bare.extend(bare_b);
        let (smaller, larger) = if x_ids[0] < y_ids[0] {
            (x_ids[0], y_ids[0])
        } else {
            (y_ids[0], x_ids[0])
        };
        let loose = vec![attest(0, 1, smaller)];
        assert_eq!(
            lmd_ghost_head(&bare, loose.iter(), &validators, g),
            smaller,
            "the loose vote did not carry its block"
        );
        assert_eq!(
            lmd_ghost_head(&bare, [].iter(), &validators, g),
            larger,
            "the control is not controlling: dropping an uncarried \
             attestation must be able to move the head, or the epoch `retain` \
             would need no invalidation"
        );
    }

    /// Wall-clock cost of one `lmd_ghost_head`, old shape against new, at the
    /// depths the problem was measured at. `#[ignore]`d — it is a measurement,
    /// not an assertion, and the reference takes minutes at depth 4,096.
    ///
    ///   cargo test --release -p bloch-pos-node -- --ignored --nocapture \
    ///       perf_lmd_ghost_head_by_depth
    #[test]
    #[ignore]
    fn perf_lmd_ghost_head_by_depth() {
        use std::time::Instant;
        let g = [0x99u8; 32];
        let n_validators = 64u32;
        let validators = vals(n_validators);

        for depth in [256u64, 512, 1024, 4096] {
            // A spine with a childless sibling at every level, so the descent
            // runs the full depth and has a comparison to make each step.
            let mut blocks: BTreeMap<[u8; 32], BlockEnvelope> = BTreeMap::new();
            let mut spine: Vec<[u8; 32]> = Vec::new();
            let mut parent = g;
            for d in 0..depth {
                let (two, ids) = chain_of(vec![
                    (parent, d + 1, 0, Vec::new()),
                    (parent, d + 1, 1, Vec::new()),
                ]);
                blocks.extend(two);
                // The lexicographically larger sibling is the spine, so the
                // tie-break cannot short-circuit the descent.
                let (hi, _lo) = if ids[0] > ids[1] {
                    (ids[0], ids[1])
                } else {
                    (ids[1], ids[0])
                };
                spine.push(hi);
                parent = hi;
            }
            // Votes spread down the spine.
            let pool: Vec<Attestation> = (0..n_validators)
                .map(|v| {
                    let d = (v as u64 * depth / n_validators as u64) as usize;
                    attest(v, 1, spine[d.min(spine.len() - 1)])
                })
                .collect();

            let t = Instant::now();
            let new_head = lmd_ghost_head(&blocks, pool.iter(), &validators, g);
            let new_ms = t.elapsed().as_secs_f64() * 1000.0;

            let t = Instant::now();
            let old_head = lmd_ghost_head_reference(&blocks, pool.iter(), &validators, g);
            let old_ms = t.elapsed().as_secs_f64() * 1000.0;

            // Split the surviving cost, because there are two of them and only
            // one was rewritten: `forkchoice_store` rebuilds the parent map,
            // the sibling lists and the whole message set on every call (O(N)
            // in stored blocks, and it is what makes a REPLAY quadratic in
            // chain length), and `Store::head` then walks it. Reporting the
            // total alone would hide which one is left.
            let t = Instant::now();
            let (fc, parents, children) = forkchoice_store(&blocks, pool.iter(), &validators);
            let build_ms = t.elapsed().as_secs_f64() * 1000.0;
            let tree = BlockTree { parents: &parents };
            let t = Instant::now();
            let split_head = fc.head(&tree, g, &children);
            let descend_ms = t.elapsed().as_secs_f64() * 1000.0;

            assert_eq!(new_head, old_head, "depth {depth}: heads differ");
            assert_eq!(new_head, split_head, "depth {depth}: split path differs");
            println!(
                "depth {depth:5}  blocks {:6}  old {old_ms:10.2} ms   new {new_ms:8.3} ms   \
                 speedup {:6.0}x   [of new: store-rebuild {build_ms:7.3} ms, \
                 descent {descend_ms:7.3} ms]",
                blocks.len(),
                old_ms / new_ms.max(1e-9),
            );
        }
    }
}

#[cfg(test)]
mod admission_authorisation {
    use super::*;
    use bloch_pos_committee::transition::{TransferInput, TransferOutput};

    /// A transfer signed for real, and the same transfer with the signature
    /// corrupted. Both must reach `admissible` — one accepted, one refused.
    fn signed_transfer() -> (PosTransaction, Vec<u8>) {
        let (pk, sk) = bloch_crypto::crypto::generate_keypair_from_seed(&[9u8; 32])
            .expect("hybrid keypair from a fixed seed");
        let mut tx = PosTransaction::Transfer {
            inputs: vec![TransferInput {
                txid: [0x11u8; 32],
                vout: 0,
                pubkey: pk.clone(),
                signature: Vec::new(),
            }],
            outputs: vec![TransferOutput {
                value: 1_000,
                script_hash: [0x22u8; 32],
            }],
            tx_bytes: 0,
            tip_millisat_per_gas: 0,
        };
        let root = tx.spend_signing_root();
        let sig = bloch_crypto::crypto::sign(&sk, &root).expect("sign the spend root");
        if let PosTransaction::Transfer { inputs, .. } = &mut tx {
            inputs[0].signature = sig.clone();
        }
        (tx, sig)
    }

    #[test]
    fn a_correctly_signed_transfer_is_still_admitted() {
        // THE REGRESSION THAT WOULD MATTER MOST. A signature check that refuses
        // everything stops the chain accepting any transfer at all — worse than
        // the hole it closes.
        let (tx, _) = signed_transfer();
        assert!(
            admissible(&tx, 0).is_ok(),
            "a validly signed transfer must still reach the mempool"
        );
        // V1 is EPOCH-INDEPENDENT, on both sides of the TransferV2 flag day
        // (`params::TRANSFER_WITNESS_DEDUP_ACTIVATION_EPOCH`). Part of the
        // pre-activation control: teaching the
        // epoch to `admissible` must change nothing about the format the
        // chain already runs on.
        assert!(
            admissible(
                &tx,
                bloch_pos_committee::params::TRANSFER_WITNESS_DEDUP_ACTIVATION_EPOCH
            )
            .is_ok(),
            "a V1 transfer must be admitted identically after the V2 flag day"
        );
    }

    /// **H1, at the mempool door.** A transfer whose tip or declared gas is
    /// outside the fee market's consensus bounds must not be admitted, must
    /// not be gossiped, and must never reach a proposer that would price it.
    ///
    /// Pricing it is what used to happen: `charge` multiplied gas by the
    /// sender's `u128` tip, the product overflowed, and `overflow-checks =
    /// true` — mandatory in a consensus build — turned that into a panic.
    /// The mempool relayed the transaction to every node first.
    ///
    /// Sabotage (2026-09-04): with `price_bounds` returning `Ok(())`, this
    /// test fails on the first case. The real bound lives in consensus
    /// (`transition::tests::an_attacker_chosen_tip_cannot_panic_the_transition`);
    /// this is the door that stops the propagation.
    #[test]
    fn a_transfer_priced_outside_the_market_is_refused_before_the_mempool() {
        // Signed FOR EACH price, never re-used: the tip and `tx_bytes` are
        // both inside `spend_signing_root`, so a transfer carrying a stale
        // signature would be refused for the wrong reason and this test would
        // prove nothing.
        let (pk, sk) = bloch_crypto::crypto::generate_keypair_from_seed(&[9u8; 32])
            .expect("hybrid keypair from a fixed seed");
        let priced = |tx_bytes: u64, tip: u128| -> PosTransaction {
            let mut tx = PosTransaction::Transfer {
                inputs: vec![TransferInput {
                    txid: [0x11u8; 32],
                    vout: 0,
                    pubkey: pk.clone(),
                    signature: Vec::new(),
                }],
                outputs: vec![TransferOutput {
                    value: 1_000,
                    script_hash: [0x22u8; 32],
                }],
                tx_bytes,
                tip_millisat_per_gas: tip,
            };
            let root = tx.spend_signing_root();
            let sig = bloch_crypto::crypto::sign(&sk, &root).expect("sign the spend root");
            if let PosTransaction::Transfer { inputs, .. } = &mut tx {
                inputs[0].signature = sig;
            }
            tx
        };

        // The tip: the one price term the sender writes.
        for tip in [
            u128::MAX,
            u128::MAX - 1,
            fee_market::MAX_TIP_MILLISAT_PER_GAS + 1,
        ] {
            let err = admissible(&priced(0, tip), 0)
                .expect_err("an unpriceable tip must not be admitted");
            assert!(
                err.contains("tip"),
                "the refusal must name the bound that causes it, got: {err}"
            );
        }

        // The gas: `tx_bytes` is a sender-declared u64 and `intrinsic_gas`
        // saturates, so it is the other factor of the same product.
        for bytes in [
            fee_market::MAX_TX_GAS / fee_market::GAS_PER_BYTE + 1,
            u64::MAX,
        ] {
            let err = admissible(&priced(bytes, 0), 0)
                .expect_err("more gas than a block holds must not be admitted");
            assert!(
                err.contains("gas"),
                "the refusal must name the bound that causes it, got: {err}"
            );
        }

        // THE CONTROL, and the one that would matter most: an honestly priced
        // transfer is untouched — including one at the largest payload any
        // block can carry.
        assert!(
            admissible(&priced(0, 0), 0).is_ok(),
            "a normally priced transfer must still reach the mempool"
        );
        // ...including at the LARGEST declaration the door now allows. This
        // control used to declare `MAX_BLOCK_TX_BYTES_V2` over a few hundred
        // wire bytes — which is the exact H-R7-2 censorship shape
        // (`declared_size_bound` refuses it since 2026-09-05): a declaration
        // the block byte cap counts but no encoding backs. A genuinely
        // block-sized transfer is one whose BYTES are block-sized, not one
        // that merely says so; the honest ceiling for THIS transfer is its
        // own encoding plus the declared-size slack. Probed 1,024 bytes
        // inside it because Falcon-1024 signatures are variable-length, so
        // each `priced` call's encoding can differ by a few bytes.
        let encoded = priced(0, 0).canonical_bytes().len() as u64;
        assert!(
            admissible(
                &priced(encoded + fee_market::TX_BYTES_DECLARE_SLACK - 1_024, 1_000),
                0
            )
            .is_ok(),
            "a fully-backed, normally tipped declaration must still reach the mempool"
        );
    }

    /// Before the scheduled lifecycle epoch, the mempool refuses ExitV2 by
    /// naming the gate. After the boundary the signature and state rules still
    /// apply; enabling the format is not permission to accept an invalid exit.
    #[test]
    fn authenticated_exits_are_refused_until_the_flag_day() {
        let tx = PosTransaction::ExitV2 {
            pubkey_hash: [9u8; 32],
            epoch: 0,
            signature: vec![1u8; 64],
        };
        for epoch in [0u64, 1, 800, 1400, bloch_pos_committee::params::EXIT_AUTH_ACTIVATION_EPOCH.saturating_sub(1)] {
            let err = admissible(&tx, epoch)
                .expect_err("ExitV2 is consensus-invalid below the lifecycle boundary");
            assert!(
                err.contains("EXIT_AUTH_ACTIVATION_EPOCH"),
                "the refusal must name the gate that causes it, got: {err}"
            );
        }
        // And the legacy message stays refused beside it — closing one door
        // must not open the other.
        assert!(
            admissible(&PosTransaction::Exit { validator: 0 }, 0).is_err(),
            "the unauthenticated Exit must remain refused"
        );
    }

    /// The rules BEHIND the flag day, exercised today.
    ///
    /// `authenticated_exits_are_refused_until_the_flag_day` proves the gate
    /// shuts the door; it cannot prove anything about what is on the other
    /// side of it, because nothing gets there. That is the standing hazard
    /// with a gated feature: the code that only runs after a flag day is the
    /// code that arrives at the flag day never having run. So the structural
    /// rules are a pure function and are tested as one.
    ///
    /// The epoch case is the load-bearing one. Consensus binds the signed
    /// epoch to the inclusion epoch (`apply_exit_v2`), so an exit signed for
    /// any other epoch is dead on arrival — and relaying it keeps a captured,
    /// publicly gossiped retirement circulating for every future proposer to
    /// try. Both directions are pinned: stale and premature.
    #[test]
    fn the_structural_exit_rules_bind_the_signature_and_the_epoch() {
        let sig = vec![1u8; 64];

        assert_eq!(exit_v2_structural_rules(7, &sig, 7), Ok(()), "the genuine shape is admitted");

        assert!(
            exit_v2_structural_rules(7, &[], 7).is_err(),
            "an exit with no signature bytes authorises nothing and can never verify",
        );

        for (signed_for, wall) in [(6u64, 7u64), (8, 7), (0, 1_400), (u64::MAX, 7)] {
            let err = exit_v2_structural_rules(signed_for, &sig, wall)
                .expect_err("only the inclusion epoch's own signature may be relayed");
            assert!(
                err.contains("epoch"),
                "the refusal must name the binding that causes it, got: {err}",
            );
        }
    }

    #[test]
    fn a_garbage_signature_is_refused_before_the_mempool() {
        let (mut tx, sig) = signed_transfer();
        if let PosTransaction::Transfer { inputs, .. } = &mut tx {
            // One flipped byte: the shape stays valid, the signature does not.
            let mut bad = sig;
            bad[0] ^= 0xFF;
            inputs[0].signature = bad;
        }
        let err = admissible(&tx, 0).expect_err("a bad signature must not be admitted");
        assert!(
            err.contains("signature"),
            "the refusal must name the reason, got: {err}"
        );
    }

    #[test]
    fn an_unauthenticated_exit_is_refused() {
        let err = admissible(&PosTransaction::Exit { validator: 0 }, 0)
            .expect_err("Exit carries no signature and must not be admitted");
        assert!(err.contains("not authenticated"), "got: {err}");
    }

    /// **H-R7-3, the mempool half — node-local policy, live ungated.** A
    /// zero-value, sub-minimum, or over-fan-out transfer must be refused at
    /// the door: every output it would create is a permanent `EutxoEntry`
    /// on every node (~76 bytes, forever, ~6.4 sat each at the old floor),
    /// and this door is what stops NEW dust propagating while the consensus
    /// half waits for its flag day
    /// (`params::DUST_RULE_ACTIVATION_EPOCH`, inert at `u64::MAX`).
    ///
    /// The dust checks run BEFORE the signature loop (cheap-first), so the
    /// mutated transfers below need no re-signing — and the refusal costs
    /// an attacker zero hybrid verifications.
    ///
    /// Mutation: delete the two output checks from the Transfer arm of
    /// `admissible` and every case here is admitted — the dust and count
    /// halves die on their message assertions independently.
    #[test]
    fn dust_and_overcount_transfers_are_refused_at_the_mempool_door() {
        use bloch_pos_committee::params::{MAX_TRANSFER_OUTPUTS, MIN_TRANSFER_OUTPUT_SAT};

        // CONTROL: the fixture's output is exactly the minimum value, and
        // it is admitted — the floor is a floor, not a step.
        let (good, _) = signed_transfer();
        if let PosTransaction::Transfer { outputs, .. } = &good {
            assert_eq!(
                outputs[0].value, MIN_TRANSFER_OUTPUT_SAT,
                "fixture premise: the control sits exactly on the floor"
            );
        }
        assert!(
            admissible(&good, 0).is_ok(),
            "control: an output at exactly the minimum must be admitted"
        );

        // Zero, one sat, and one-below-the-floor: all refused, by name.
        for v in [0u64, 1, MIN_TRANSFER_OUTPUT_SAT - 1] {
            let mut dusty = good.clone();
            if let PosTransaction::Transfer { outputs, .. } = &mut dusty {
                outputs[0].value = v;
            }
            let err = admissible(&dusty, 0)
                .expect_err("a dust output must not reach the mempool");
            assert!(
                err.contains("dust"),
                "the refusal must name the rule, got: {err}"
            );
        }

        // One output past the cap: refused, by name; at the cap: past the
        // dust checks (it dies later, on the signature made stale by the
        // added outputs — proving the count rule itself let it through).
        let fan_out = |n: usize| -> PosTransaction {
            let mut tx = good.clone();
            if let PosTransaction::Transfer { outputs, .. } = &mut tx {
                let o = outputs[0].clone();
                outputs.extend(std::iter::repeat(o).take(n - 1));
            }
            tx
        };
        let err = admissible(&fan_out(MAX_TRANSFER_OUTPUTS + 1), 0)
            .expect_err("more outputs than the cap must not reach the mempool");
        assert!(
            err.contains("cap"),
            "the refusal must name the rule, got: {err}"
        );
        let err = admissible(&fan_out(MAX_TRANSFER_OUTPUTS), 0)
            .expect_err("the stale signature is the expected later refusal");
        assert!(
            err.contains("signature"),
            "exactly at the cap the output rules must be silent, got: {err}"
        );
    }

    /// The V2 arm shares the mempool dust rule — a bound on one encoding of
    /// a transfer is not a bound on the transfer. Same before-the-signature
    /// placement, so the mutation needs no re-signing.
    ///
    /// Mutation: delete the two output checks from the TransferV2 arm alone
    /// and this dies while the V1 test above stays green.
    #[test]
    fn v2_shares_the_mempool_dust_rule() {
        let good = signed_transfer_v2(2);
        assert!(
            admissible(&good, V2_FLAG_DAY).is_ok(),
            "control: the untouched V2 transfer is admitted"
        );
        let mut dusty = good.clone();
        if let PosTransaction::TransferV2 { outputs, .. } = &mut dusty {
            outputs[0].value = 0;
        }
        let err = admissible(&dusty, V2_FLAG_DAY)
            .expect_err("a zero-value V2 output must not reach the mempool");
        assert!(
            err.contains("dust"),
            "the refusal must name the rule, got: {err}"
        );
    }

    // ── TransferV2 admission: the flag-day arm ──────────────────────────────
    //
    // Every rule below carries its control half in the same test, and each
    // was proven by mutation on 2026-08-22 (session logged per test): the
    // rule under test was disabled in `admissible`'s TransferV2 arm, the
    // named test failed, the mutation was reverted, and the suite went green
    // again. A test that survives the disabling of its own rule is
    // decorative, and decorative tests are how this codebase already shipped
    // one consensus regression.

    use bloch_pos_committee::params::TRANSFER_WITNESS_DEDUP_ACTIVATION_EPOCH as V2_FLAG_DAY;
    use bloch_pos_committee::transition::{TransferInputV2, WitnessKey};

    /// A `TransferV2` signed for real: `n` inputs owned by ONE key, one
    /// witness-table entry — the single-owner many-input shape the format
    /// exists for. The signing root covers spend points, outputs and the two
    /// fee terms only (`fold_spend`, transition.rs), NOT the table — the
    /// table is witness — so tests below may mutate the table afterwards
    /// without invalidating the signature, which is exactly what the
    /// discipline tests need (and mirrors what a malicious relay can do).
    fn signed_transfer_v2(n: u32) -> PosTransaction {
        let (pk, sk) = bloch_crypto::crypto::generate_keypair_from_seed(&[9u8; 32])
            .expect("hybrid keypair from a fixed seed");
        let inputs: Vec<TransferInputV2> = (0..n)
            .map(|vout| TransferInputV2 {
                txid: [0x11u8; 32],
                vout,
                key_index: 0,
            })
            .collect();
        let mut tx = PosTransaction::TransferV2 {
            keys: vec![WitnessKey {
                pubkey: pk,
                signature: Vec::new(),
            }],
            inputs,
            outputs: vec![TransferOutput {
                value: 1_000,
                script_hash: [0x22u8; 32],
            }],
            tx_bytes: 0,
            tip_millisat_per_gas: 0,
        };
        let root = tx.spend_signing_root();
        let sig = bloch_crypto::crypto::sign(&sk, &root).expect("sign the spend root");
        if let PosTransaction::TransferV2 { keys, .. } = &mut tx {
            keys[0].signature = sig;
        }
        tx
    }

    /// The flag day itself, with the unit pinned: both epochs are DERIVED
    /// FROM SLOTS via `epoch_of`, because the gate compares EPOCHS against
    /// `params::TRANSFER_WITNESS_DEDUP_ACTIVATION_EPOCH` and a call
    /// site that handed it a raw wall SLOT would activate 32× early —
    /// silently, since both are bare u64s.
    ///
    /// Mutation log (2026-08-22): gate `<` → `<=` — the admit half dies;
    /// arm reverted to the old unconditional Err — the admit half dies;
    /// gate deleted — the refuse half dies.
    #[test]
    fn v2_is_refused_the_epoch_before_the_flag_day_and_admitted_at_it() {
        use bloch_pos_committee::SLOTS_PER_EPOCH;
        let last_slot_before = V2_FLAG_DAY * SLOTS_PER_EPOCH - 1;
        let first_slot_at = V2_FLAG_DAY * SLOTS_PER_EPOCH;
        assert_eq!(epoch_of(last_slot_before), V2_FLAG_DAY - 1);
        assert_eq!(epoch_of(first_slot_at), V2_FLAG_DAY);

        let tx = signed_transfer_v2(4);
        // CONTROL half — pre-activation IS today's behaviour, and today's
        // refusal string, on the same transaction bytes.
        let err = admissible(&tx, epoch_of(last_slot_before))
            .expect_err("one epoch before the flag day the format must still be refused");
        assert!(
            err.contains("not active"),
            "the pre-activation refusal must be today's, got: {err}"
        );
        // The change under test: the same bytes cross the door at 800.
        assert!(
            admissible(&tx, epoch_of(first_slot_at)).is_ok(),
            "at the flag-day epoch a validly signed V2 must be admitted"
        );
    }

    /// (b) of the task: the table signatures are verified AT ADMISSION, the
    /// way the Transfer arm verifies per-input ones — otherwise an attacker
    /// fills every mempool on the mesh with garbage for free after the flag
    /// day, and every proposer pays to probe-drop it.
    ///
    /// Mutation log (2026-08-22): verify loop deleted from the V2 arm —
    /// this test dies (the good-signature control half survives, proving
    /// the death is the loop's).
    #[test]
    fn v2_signature_is_checked_before_the_mempool() {
        let good = signed_transfer_v2(4);
        assert!(
            admissible(&good, V2_FLAG_DAY).is_ok(),
            "control: the correctly signed sweep must be admitted"
        );
        let mut bad = good.clone();
        if let PosTransaction::TransferV2 { keys, .. } = &mut bad {
            // One flipped byte: shape and table stay valid, signature not.
            keys[0].signature[0] ^= 0xFF;
        }
        let err = admissible(&bad, V2_FLAG_DAY)
            .expect_err("a bad table signature must not be admitted");
        assert!(err.contains("signature"), "got: {err}");
    }

    /// An empty witness table must be refused BY NAME. The signature loop
    /// alone passes vacuously over `keys = []` (zero verifications); the
    /// index-bounds check below it would still catch the shape (any input's
    /// `key_index` misses an empty table), which is why this test pins the
    /// REFUSAL MESSAGE and not just the refusal: it proves the dedicated
    /// check fired, and keeps the two rules independent instead of one
    /// silently load-bearing for the other.
    ///
    /// Mutation log (2026-08-22): `keys.is_empty()` check deleted — this
    /// test dies on the message assertion (the shape is then refused as a
    /// bad index, which is the wrong reason told to the wrong sender).
    #[test]
    fn v2_empty_witness_table_is_refused_not_vacuously_passed() {
        let good = signed_transfer_v2(2);
        assert!(
            admissible(&good, V2_FLAG_DAY).is_ok(),
            "control: the same transaction with its table populated is admitted"
        );
        let mut empty = good.clone();
        if let PosTransaction::TransferV2 { keys, .. } = &mut empty {
            keys.clear();
        }
        let err = admissible(&empty, V2_FLAG_DAY)
            .expect_err("an empty witness table must not be admitted");
        assert!(err.contains("no witness keys"), "got: {err}");
    }

    /// Stateless mirror of consensus's `DuplicateWitnessKey`
    /// (transition.rs:2043–2052). The duplicate entry carries the SAME valid
    /// signature and every entry is referenced, so only the duplicate rule
    /// can be what refuses it — the control is the identical transaction
    /// before the table was doubled.
    ///
    /// Mutation log (2026-08-22): duplicate check deleted — this test dies
    /// (the doubled table verifies twice and is admitted).
    #[test]
    fn v2_duplicate_witness_key_is_refused() {
        let good = signed_transfer_v2(2);
        assert!(admissible(&good, V2_FLAG_DAY).is_ok(), "control");
        let mut dup = good.clone();
        if let PosTransaction::TransferV2 { keys, inputs, .. } = &mut dup {
            let copy = keys[0].clone();
            keys.push(copy);
            // Both entries referenced, so WitnessKeyUnused cannot be the
            // refusal; both signatures valid, so neither can the verify loop.
            inputs[1].key_index = 1;
        }
        let err = admissible(&dup, V2_FLAG_DAY)
            .expect_err("a repeated witness key must not be admitted");
        assert!(err.contains("repeats a witness key"), "got: {err}");
    }

    /// Stateless mirror of consensus's `BadKeyIndex` (transition.rs:2071).
    ///
    /// Mutation log (2026-08-22): bounds refusal weakened to ignore
    /// out-of-range indices — this test dies (entry 0 is still referenced by
    /// input 0, coverage passes, the signature passes, admitted).
    #[test]
    fn v2_out_of_table_key_index_is_refused() {
        let good = signed_transfer_v2(2);
        assert!(admissible(&good, V2_FLAG_DAY).is_ok(), "control");
        let mut bad = good.clone();
        if let PosTransaction::TransferV2 { inputs, .. } = &mut bad {
            // key_index is witness data outside the signing root
            // (transition.rs, `TransferInputV2::key_index` doc), so this is
            // a mutation a relay can make without touching the signature.
            inputs[1].key_index = 7;
        }
        let err = admissible(&bad, V2_FLAG_DAY)
            .expect_err("an input pointing outside the table must not be admitted");
        assert!(err.contains("outside the table"), "got: {err}");
    }

    /// Stateless mirror of consensus's `WitnessKeyUnused`
    /// (transition.rs:2088–2094): an unreferenced entry is relay-stuffable
    /// padding. The control half re-points an input at the second entry —
    /// same two keys, both signatures valid over the same root — and IS
    /// admitted, proving the refusal was about the dangling entry and not
    /// about carrying a second owner at all.
    ///
    /// Mutation log (2026-08-22): coverage check deleted — the refuse half
    /// dies (both signatures verify and the padded table is admitted).
    #[test]
    fn v2_unreferenced_table_entry_is_refused() {
        let good = signed_transfer_v2(2);
        let root = good.spend_signing_root();
        let (pk2, sk2) = bloch_crypto::crypto::generate_keypair_from_seed(&[10u8; 32])
            .expect("second hybrid keypair");
        let sig2 = bloch_crypto::crypto::sign(&sk2, &root).expect("second signature");

        let mut padded = good.clone();
        if let PosTransaction::TransferV2 { keys, .. } = &mut padded {
            keys.push(WitnessKey {
                pubkey: pk2,
                signature: sig2,
            });
        }
        let err = admissible(&padded, V2_FLAG_DAY)
            .expect_err("a table entry no input references must not be admitted");
        assert!(err.contains("no input references"), "got: {err}");

        // CONTROL: reference the second entry and the same table passes.
        // (Admission cannot know whose script_hash each input commits to —
        // that is consensus's ScriptMismatch, which needs state; see the
        // arm's comment.)
        let mut both = padded.clone();
        if let PosTransaction::TransferV2 { inputs, .. } = &mut both {
            inputs[1].key_index = 1;
        }
        assert!(
            admissible(&both, V2_FLAG_DAY).is_ok(),
            "the identical table with every entry referenced must be admitted"
        );
    }

    /// The V1 structural floor, carried over: a V2 that spends nothing or
    /// pays no one is refused post-activation too, before any signature is
    /// bought. Control is the untouched fixture.
    ///
    /// Mutation log (2026-08-22): `inputs.is_empty()` deleted — the
    /// no-inputs half dies; `outputs.is_empty()` deleted — the no-outputs
    /// half dies.
    #[test]
    fn v2_empty_inputs_or_outputs_are_refused() {
        let good = signed_transfer_v2(2);
        assert!(admissible(&good, V2_FLAG_DAY).is_ok(), "control");

        let mut no_in = good.clone();
        if let PosTransaction::TransferV2 { inputs, .. } = &mut no_in {
            inputs.clear();
        }
        let err = admissible(&no_in, V2_FLAG_DAY)
            .expect_err("a V2 with no inputs must not be admitted");
        assert!(err.contains("no inputs"), "got: {err}");

        let mut no_out = good.clone();
        if let PosTransaction::TransferV2 { outputs, .. } = &mut no_out {
            outputs.clear();
        }
        let err = admissible(&no_out, V2_FLAG_DAY)
            .expect_err("a V2 with no outputs must not be admitted");
        assert!(err.contains("no outputs"), "got: {err}");
    }
}

/// (c) and (d) of the flag-day task, end to end on a REAL `Engine`: the
/// single-owner many-input sweep enters by BOTH real entry paths — the RPC
/// (`serve_rpc`'s SendRawTransaction arm, after the exact
/// `from_canonical_bytes(canonical_bytes())` round-trip rpc.rs performs) and
/// gossip (`on_transaction`, the body of the `NetEvent::Transaction` arm;
/// both paths converge on that one function) — survives the mempool, and
/// comes out of `select_transactions`, which IS the content of a proposal
/// (`propose` packs exactly its return). Application at epoch ≥ 800 is
/// proven by the transition suite (transition.rs, "TransferV2: deduplicated
/// witnesses behind their own flag day"), which this harness deliberately
/// does not duplicate: standing up a proposing validator here would re-test
/// consensus to prove an admission property.
///
/// No mocked clock anywhere: the wall epoch is real `now_ms()` against a
/// manifest whose `genesis_time_ms` is placed in the past — the same knob
/// production uses — so `wall_slot()`/`epoch_of` run the very code the live
/// node runs.
#[cfg(test)]
mod transfer_v2_end_to_end {
    use super::*;
    use bloch_pos_committee::params::TRANSFER_WITNESS_DEDUP_ACTIVATION_EPOCH as V2_FLAG_DAY;
    use bloch_pos_committee::state_root::{EutxoEntry, EvmCommitment};
    use bloch_pos_committee::transition::{TransferInputV2, TransferOutput, WitnessKey};
    use bloch_pos_committee::SLOTS_PER_EPOCH;
    use sha3::{Digest, Sha3_256};

    /// A real `Engine`: real `Store` on disk, real devnet transport bound to
    /// an ephemeral port with zero peers (broadcast walks an empty peer
    /// list, so gossiping an admitted transaction is a no-op instead of a
    /// hang), observer mode (no keystore), and a genesis state that actually
    /// HOLDS `entries` — the outputs the sweep spends. `epochs_past` places
    /// `genesis_time_ms` so the node's real wall epoch is at least that
    /// (+2 slots of margin so the epoch cannot regress mid-test).
    fn engine_at_wall_epoch(epochs_past: u64, entries: &[EutxoEntry]) -> Engine {
        let slot_ms = 500u64;
        let back_ms = epochs_past
            .saturating_mul(SLOTS_PER_EPOCH)
            .saturating_add(2)
            .saturating_mul(slot_ms);
        let manifest = Manifest {
            genesis_time_ms: now_ms().saturating_sub(back_ms),
            slot_ms,
            validators: Vec::new(),
            cohort: Vec::new(),
            carryover: None,
            allocations: Vec::new(),
            carryover_entries: Vec::new(),
            format: crate::genesis::ManifestFormat::V1Unbound,
            pre_state_root: std::sync::OnceLock::new(),
        };
        let genesis_id = manifest.genesis_id();
        // `CommittedState::genesis` directly rather than
        // `manifest.genesis_state()`: the opening balances are the test's
        // fixture, not a carryover snapshot with a commitment to honour.
        let state = CommittedState::genesis(
            genesis_id,
            GENESIS_MIX,
            &[],
            &[],
            [0u8; 32],
            [0u8; 32],
            [0u8; 32],
            EvmCommitment {
                account_root: [0u8; 32],
                receipts_root: [0u8; 32],
                gas_used: 0,
                base_fee_per_gas: 0,
            },
            entries,
        );
        // Unique throwaway data dir per engine — two engines in one test
        // must never share a store.
        static DIR_SEQ: AtomicU64 = AtomicU64::new(0);
        let dir = std::env::temp_dir().join(format!(
            "bloch-pos-v2-e2e-{}-{}",
            std::process::id(),
            DIR_SEQ.fetch_add(1, Ordering::Relaxed),
        ));
        std::fs::create_dir_all(&dir).expect("create the test data dir");
        let store = Store::open(&dir, &[0u8; 32]).expect("open the test store");
        let (events, _rx) = mpsc::channel::<EngineEvent>();
        // `_rx` drops here: nothing dials this node, and the accept loop
        // exits quietly on a closed channel.
        let head_slot = Arc::new(AtomicU64::new(0));
        let inflight = net::QueueBudget::new();
        let net = net::Net::Devnet(
            net::start(
                "127.0.0.1",
                0, // ephemeral port: bind for real, listen to nobody
                Vec::new(),
                events,
                dir.clone(),
                head_slot.clone(),
                inflight,
            )
            .expect("bind the devnet transport on an ephemeral port"),
        );
        let verifier = HybridVerifier::new();
        Engine {
            genesis_validator_count: manifest.validators.len() as u32,
            manifest,
            state: StateCell::new(state),
            tr: Transition::new(verifier.clone()),
            tr_probe: Transition::new(ProbeVerifier),
            verifier,
            keys: None,
            blocks: BTreeMap::new(),
            observed_proposals: BTreeMap::new(),
            chain: vec![(0, genesis_id)],
            canonical: BTreeSet::from([*genesis_id.as_bytes()]),
            recent_states: VecDeque::new(),
            pool: BTreeMap::new(),
            att_pool: AttestationPool::new(),
            wall_slot: 0,
            mempool: BTreeMap::new(),
            mempool_admitted_at: BTreeMap::new(),
            mempool_expired: 0,
            mempool_evicted_low_fee: 0,
            rejected: BTreeMap::new(),
        rejected_hits: 0,
        mempool_suspect: BTreeSet::new(),
        mempool_swept_epoch: u64::MAX,
            store,
            slashprot: SlashingProtection::open(&dir).expect("open slashing protection"),
            net,
            head_slot,
            live: true,
            needs_sync: false,
            orphans: VecDeque::new(),
            orphans_evicted: 0,
            orphans_admitted: 0,
            blocks_pruned: 0,
            rejected_unsigned: 0,
            rejected_future: 0,
            last_applied_ms: now_ms(),
            booted_ms: now_ms(),
            ws_anchor: None,
            ws_anchor_hard: false,
            ws_conflict_reported: false,
            fc_covered_removals: 0,
            finalized_latch: None,
            finality_rewinds_refused: 0,
            parked_refused_finality: VecDeque::new(),
            finality_rewind_override: false,
            tx_slot_index: BTreeMap::new(),
            tx_slot_index_order: VecDeque::new(),
            doppelganger_observe_until: None,
            doppelganger_halted: false,
        }
    }

    /// The motivating shape, funded: `n` outputs of 8,400 BLCH (the
    /// carryover denomination) under ONE key, and the V2 sweep spending all
    /// of them through a ONE-entry witness table with one real hybrid
    /// signature — the whole economy of the format. Returns the entries so
    /// the engine's genesis can hold the very outputs being swept.
    fn sweep_fixture(n: u32) -> (Vec<EutxoEntry>, PosTransaction) {
        sweep_fixture_declaring(n, 0)
    }

    /// [`sweep_fixture`] with the declared `tx_bytes` as a knob — the
    /// declared size sits inside the signing root, so it has to be fixed
    /// BEFORE the hybrid signature is produced, exactly as a wallet does it.
    fn sweep_fixture_declaring(n: u32, declared: u64) -> (Vec<EutxoEntry>, PosTransaction) {
        let (pk, sk) = bloch_crypto::crypto::generate_keypair_from_seed(&[42u8; 32])
            .expect("hybrid keypair from a fixed seed");
        let script_hash: [u8; 32] = Sha3_256::digest(&pk).into();
        let entries: Vec<EutxoEntry> = (0..n)
            .map(|vout| EutxoEntry {
                txid: [0x33u8; 32],
                vout,
                value: 8_400 * 100_000_000, // 8,400 BLCH at 8 decimals
                script_hash,
            })
            .collect();
        let inputs: Vec<TransferInputV2> = entries
            .iter()
            .map(|e| TransferInputV2 {
                txid: e.txid,
                vout: e.vout,
                key_index: 0,
            })
            .collect();
        let mut tx = PosTransaction::TransferV2 {
            keys: vec![WitnessKey {
                pubkey: pk,
                signature: Vec::new(),
            }],
            inputs,
            outputs: vec![TransferOutput {
                value: 1_000,
                script_hash,
            }],
            // Admission polices only the declared size's CEILING
            // (`declared_size_bound`, audit H-R7-2); the floor is
            // consensus's UnderdeclaredSize, exercised by the transition
            // suite.
            tx_bytes: declared,
            tip_millisat_per_gas: 0,
        };
        let root = tx.spend_signing_root();
        let sig = bloch_crypto::crypto::sign(&sk, &root).expect("sign the spend root");
        if let PosTransaction::TransferV2 { keys, .. } = &mut tx {
            keys[0].signature = sig;
        }
        (entries, tx)
    }

    /// (c): after the flag day the sweep enters by RPC AND by gossip,
    /// survives the mempool, and is what selection hands the proposer.
    ///
    /// Mutation log (2026-08-22): arm reverted to unconditional Err — dies
    /// on every assertion below; call site handed `epoch_of(head)` instead
    /// of the wall epoch — dies too, but only because this harness's head
    /// sits at genesis; a cheap lagging-NODE test does not exist and that
    /// limit is recorded at the arm's comment, not papered over here.
    #[test]
    fn v2_sweep_enters_by_rpc_and_gossip_and_comes_out_in_selection() {
        let (entries, tx) = sweep_fixture(16);

        // ── RPC path ────────────────────────────────────────────────────────
        let mut rpc_node = engine_at_wall_epoch(V2_FLAG_DAY + 1, &entries);
        let wall_epoch = epoch_of(rpc_node.wall_slot());
        assert!(
            wall_epoch >= V2_FLAG_DAY,
            "harness: wall epoch must be past the flag day, got {wall_epoch}"
        );
        // The exact decode rpc.rs performs on `sendrawtransaction` bytes.
        let bytes = tx.canonical_bytes();
        let decoded = PosTransaction::from_canonical_bytes(&bytes)
            .expect("the V2 canonical encoding must round-trip (the rpc.rs decode)");
        assert_eq!(decoded, tx, "round-trip must reproduce the transaction");
        let out = rpc_node.serve_rpc(RpcRequest::SendRawTransaction(decoded));
        assert!(out.is_ok(), "sendrawtransaction must admit the sweep: {out:?}");
        assert_eq!(rpc_node.mempool.len(), 1, "the sweep must sit in the mempool");

        // ── Gossip path, on a FRESH engine ──────────────────────────────────
        let mut gossip_node = engine_at_wall_epoch(V2_FLAG_DAY + 1, &entries);
        assert_eq!(
            gossip_node.on_transaction(tx.clone()),
            Ok(Admitted::New),
            "the gossip path must admit the sweep"
        );
        // Surviving the mempool: a second delivery collapses to Duplicate
        // instead of being refused or double-inserted.
        assert_eq!(
            gossip_node.on_transaction(tx.clone()),
            Ok(Admitted::Duplicate),
            "a re-gossiped sweep must be a duplicate, not a refusal"
        );
        assert_eq!(gossip_node.mempool.len(), 1);

        // ── ...and out into a proposal ──────────────────────────────────────
        // `select_transactions(epoch)` is the proposal's content — `propose`
        // packs exactly its return — and the epoch passed is the epoch of
        // the slot being produced for, which for a live proposer is a wall
        // slot: the same era admission just judged by.
        let selected = gossip_node.select_transactions(epoch_of(gossip_node.wall_slot()));
        assert_eq!(
            selected,
            vec![tx.clone()],
            "the admitted sweep must be selected into the next proposal"
        );
        let selected_rpc = rpc_node.select_transactions(epoch_of(rpc_node.wall_slot()));
        assert_eq!(selected_rpc, vec![tx]);
    }

    /// **H-R7-2, the mempool door**: a validly-signed transfer declaring far
    /// more bytes than its encoding carries is refused by `admissible` — the
    /// declared size is what the block byte cap counts, so admitting it hands
    /// the sender a block's worth of byte budget for a few real KB.
    ///
    /// The signature is REAL (the fixture signs over the inflated
    /// declaration), which is what makes this a mutation test: remove
    /// `declared_size_bound` from the arm and the transaction sails through
    /// every remaining check to `Ok(())`, and the first assertion goes red
    /// (verified 2026-09-05). The second assertion is the door's other edge:
    /// an honest wallet declaring inside the slack must still get in.
    #[test]
    fn admission_refuses_a_declaration_no_encoding_backs() {
        // Measure a reference encoding first: the declared size is a
        // fixed-width field, so the length does not depend on the value
        // declared — but each fixture build signs afresh and Falcon-1024
        // signatures are VARIABLE-length, so two builds can differ by a few
        // bytes. The probes below therefore sit 1,024 bytes clear of the
        // exact boundary on each side, far past that variance; the
        // byte-exact edge is pinned by the transition suite
        // (`a_transfer_cannot_declare_a_blocks_worth_of_bytes_it_does_not_carry`),
        // whose toy signatures have fixed length.
        let (_e0, probe) = sweep_fixture_declaring(4, 0);
        let encoded = probe.canonical_bytes().len() as u64;
        let slack = fee_market::TX_BYTES_DECLARE_SLACK;

        let (_e1, over) = sweep_fixture_declaring(4, encoded + slack + 1_024);
        assert!(
            admissible(&over, V2_FLAG_DAY + 1).is_err(),
            "a transfer declaring ~{} bytes over its own encoding must be refused \
             at the mempool door",
            slack + 1_024,
        );

        let (_e2, within) = sweep_fixture_declaring(4, encoded + slack - 1_024);
        assert_eq!(
            admissible(&within, V2_FLAG_DAY + 1),
            Ok(()),
            "a declaration inside the slack must still be admitted — the slack \
             exists for wallets that fix tx_bytes before their Falcon signatures \
             exist",
        );
    }

    /// **H-R7-2, the proposer**: `select_transactions` must budget by the
    /// size CONSENSUS will count — each transfer's declared `tx_bytes` — not
    /// by wire length. Packing by wire length selected one tiny transfer
    /// declaring the whole byte cap PLUS the honest mempool behind it; the
    /// transition then refused the block (`BlockByteLimitExceeded`, a
    /// no-index error), and the probe loop popped and barred the innocent
    /// tail one transaction at a time for `REJECTION_TTL_SLOTS` each — the
    /// hour of censorship the audit measured at one ~85 k-sat fee.
    ///
    /// Mutation: restore `let n = encoded.len() as u64;` in
    /// `select_transactions` and the weight assertion below goes red
    /// (verified 2026-09-05).
    #[test]
    fn selection_budgets_by_declared_bytes_not_wire_bytes() {
        let epoch = V2_FLAG_DAY + 1; // V2-era byte cap, the live one
        let cap = fee_market::max_block_tx_bytes(epoch);
        let mut node = engine_at_wall_epoch(epoch, &[]);

        // The attacker: a few hundred wire bytes declaring the ENTIRE cap —
        // legal today (it clears MAX_TX_GAS by the fee-market const assert)
        // and fully paid for. Inserted straight into the mempool: the door
        // now refuses this shape, but a proposer must not depend on every
        // peer's mempool having been right (the slot-69 lesson).
        let attacker = PosTransaction::Transfer {
            inputs: vec![bloch_pos_committee::transition::TransferInput {
                txid: [0xAAu8; 32],
                vout: 0,
                pubkey: vec![1, 2, 3],
                signature: vec![4, 5, 6],
            }],
            outputs: vec![TransferOutput { value: 1, script_hash: [0xBBu8; 32] }],
            tx_bytes: cap,
            tip_millisat_per_gas: 0,
        };
        // Ten honest transfers, declaring no more than they carry.
        let mut txs = vec![attacker];
        for i in 0..10u8 {
            txs.push(PosTransaction::Transfer {
                inputs: vec![bloch_pos_committee::transition::TransferInput {
                    txid: [i; 32],
                    vout: 0,
                    pubkey: vec![7],
                    signature: vec![8],
                }],
                outputs: vec![TransferOutput { value: 1, script_hash: [i; 32] }],
                tx_bytes: 0,
                tip_millisat_per_gas: 0,
            });
        }
        for tx in &txs {
            node.mempool.insert(tx.canonical_bytes(), tx.clone());
        }
        assert_eq!(node.mempool.len(), 11, "fixture: all eleven must be distinct");

        let selected = node.select_transactions(epoch);
        assert!(!selected.is_empty(), "an empty selection would prove nothing");
        // The property the transition enforces at step 10b: the sum of the
        // sizes consensus counts must fit the cap. `max` mirrors the packer:
        // declared for transfers, and never less than the wire bytes.
        let consensus_weight: u64 = selected
            .iter()
            .map(|tx| {
                let declared = match tx {
                    PosTransaction::Transfer { tx_bytes, .. }
                    | PosTransaction::TransferV2 { tx_bytes, .. } => *tx_bytes,
                    _ => 0,
                };
                (tx.canonical_bytes().len() as u64).max(declared)
            })
            .sum();
        assert!(
            consensus_weight <= cap,
            "the proposer packed {consensus_weight} consensus-counted bytes into a \
             {cap}-byte cap — that block is BlockByteLimitExceeded on every node, \
             and the probe loop turns it into an hour of censorship",
        );
    }

    /// **A varredura esta LIGADA no caminho de aplicacao.**
    ///
    /// Os tres testes abaixo chamam `sweep_mempool` diretamente: provam a
    /// logica e NAO provam a fiacao. Rodei a mutacao — removi a chamada de
    /// `apply_canonical` — e os tres continuaram verdes. Um teste que nao
    /// pode ficar vermelho nao esta testando nada, que e literalmente o
    /// defeito que o arnes `prova` carregou por seis dias.
    ///
    /// Dirigir `apply_canonical` daqui exigiria bloco, proponente e cadeia
    /// RANDAO — o harness disso vive nos testes de integracao. Entao a fiacao
    /// e presa no fonte, o mesmo idioma dos tripwires de
    /// `coherence_replay_identity.rs` e de `prova.rs`: e a diferenca entre
    /// "a funcao funciona" e "a funcao e chamada".
    #[test]
    fn the_sweep_is_wired_into_the_apply_path() {
        let src = include_str!("engine.rs");
        // A agulha e montada em pedacos: escrita inteira, ela apareceria no
        // fonte DENTRO deste proprio teste, e o scan casaria consigo mesmo —
        // um tripwire que nao pode ficar vermelho. Cai nessa duas vezes hoje.
        let chamada = concat!("self.sweep_", "mempool(cur_e);");
        assert!(
            src.contains(chamada),
            "a chamada de sweep_mempool sumiu de apply_canonical. Sem ela a \
             varredura e codigo morto e um no observador volta a ser \
             sorvedouro de mao unica — 190 transacoes num deles em 2026-08-30."
        );
        // E na fronteira de epoca, nao a cada bloco: `cur_e` e a epoca, e a
        // propria funcao retorna cedo se ja varreu nesta epoca.
        assert!(
            src.contains(concat!("let cur_e = epoch_of(self.", "state.slot());")),
            "o argumento da varredura deixou de ser a epoca da cabeca"
        );
    }

    /// **A varredura de epoca e a UNICA coisa que limpa um observador.**
    ///
    /// O laco de descarte do proponente so roda quando o no propoe. Um no sem
    /// chave de validador nunca propoe, entao nunca descarta — e o mempool
    /// dele vira sorvedouro de mao unica ate o teto de 4.096. Medido na frota
    /// viva em 2026-08-30: dois archivals e o no de RPC publico, todos com
    /// `proposing block` igual a ZERO, seguravam 63, 63 e 190 transacoes
    /// enquanto os validadores em volta drenaram de 91 para 9 propondo. O
    /// explorer publico le um desses observadores, entao o numero que o mundo
    /// via era um que nenhum validador tinha mais.
    ///
    /// E o cache de recusa nao os ajuda: ele e ESCRITO pelo laco de descarte,
    /// que num observador nunca roda.
    #[test]
    fn the_epoch_sweep_evicts_what_can_no_longer_apply() {
        let (entries, good) = sweep_fixture(16);
        let mut node = engine_at_wall_epoch(V2_FLAG_DAY + 1, &entries);

        // Uma transacao gastando um outpoint que esta cadeia NAO tem: o txid
        // do fixture e [0x33; 32], este e outro. Inserida direto no mempool
        // porque `admissible` conferiria a assinatura — e o que se testa aqui
        // e o que acontece DEPOIS da admissao.
        let bad = match good.clone() {
            PosTransaction::TransferV2 { keys, mut inputs, outputs, tx_bytes, tip_millisat_per_gas } => {
                for i in inputs.iter_mut() {
                    i.txid = [0x99u8; 32];
                }
                PosTransaction::TransferV2 { keys, inputs, outputs, tx_bytes, tip_millisat_per_gas }
            }
            other => other,
        };
        let bad_key = bad.canonical_bytes();
        let good_key = good.canonical_bytes();
        node.mempool.insert(bad_key.clone(), bad);
        node.mempool.insert(good_key.clone(), good);
        assert_eq!(node.mempool.len(), 2);

        // PRIMEIRA varredura: a ruim vira suspeita, ninguem e despejado. O
        // segundo tempo existe para o gasto encadeado — uma transferencia que
        // paga da saida de outra ainda no mempool aponta, neste instante,
        // para um outpoint ausente e fica valida quando a mae entra.
        node.sweep_mempool(10);
        assert_eq!(
            node.mempool.len(),
            2,
            "a primeira varredura NAO pode despejar: seria matar gasto encadeado"
        );
        assert!(node.mempool_suspect.contains(&bad_key), "a ruim tem que ficar suspeita");
        assert!(!node.mempool_suspect.contains(&good_key), "a boa nao pode ficar suspeita");

        // A varredura roda UMA VEZ POR EPOCA: repetir a mesma epoca e no-op.
        node.sweep_mempool(10);
        assert_eq!(node.mempool.len(), 2, "duas chamadas na mesma epoca sao uma varredura");

        // SEGUNDA epoca: agora despeja, e barra.
        node.sweep_mempool(11);
        assert_eq!(node.mempool.len(), 1, "a ruim tem que sair na segunda varredura");
        assert!(node.mempool.contains_key(&good_key), "a boa tem que permanecer");
        assert!(
            node.is_rejected(&bad_key, node.wall_slot()).is_some(),
            "despejar sem barrar e enxugar gelo: os pares reoferecem"
        );
    }

    /// **Uma transacao que volta a ser valida sai da suspeita.** O caso do
    /// gasto encadeado, do outro lado: a mae entrou, o outpoint existe, e a
    /// filha nao pode carregar a marca para a varredura seguinte.
    #[test]
    fn becoming_valid_again_clears_the_suspicion() {
        let (entries, good) = sweep_fixture(16);
        let mut node = engine_at_wall_epoch(V2_FLAG_DAY + 1, &entries);
        let key = good.canonical_bytes();
        node.mempool.insert(key.clone(), good);

        // Marcada a mao, como se uma varredura anterior a tivesse reprovado
        // enquanto a mae ainda nao tinha entrado.
        node.mempool_suspect.insert(key.clone());
        node.sweep_mempool(20);

        assert!(
            !node.mempool_suspect.contains(&key),
            "os inputs existem: a marca tem que ser apagada, senao a proxima \
             varredura despeja uma transacao perfeitamente valida"
        );
        assert_eq!(node.mempool.len(), 1);
    }

    /// Mensagens que nao gastam eUTXO nao sao julgadas pela varredura.
    ///
    /// Hoje `Deposit` e `Delegate` nao consomem output nenhum — e exatamente a
    /// lacuna que a onda de abertura fecha. Ate la, "nao gasta nada" e "gasta
    /// algo ausente" precisam ser respostas diferentes, ou a varredura despeja
    /// staking por engano.
    #[test]
    fn the_sweep_does_not_judge_transactions_that_spend_nothing() {
        let (entries, _) = sweep_fixture(16);
        let mut node = engine_at_wall_epoch(V2_FLAG_DAY + 1, &entries);
        let dep = PosTransaction::Deposit {
            pubkey: vec![0x77; 32],
            amount_sat: 25_000 * 100_000_000,
            randao_commitment: [0x78; 32],
            withdrawal_credentials: vec![0x79; 32],
            commission_bps: 0,
            proof_of_possession: Vec::new(),
        };
        node.mempool.insert(dep.canonical_bytes(), dep);
        node.sweep_mempool(30);
        node.sweep_mempool(31);
        assert_eq!(
            node.mempool.len(),
            1,
            "uma mensagem que nao nomeia outpoint nenhum nao pode ser despejada \
             por 'gastar algo ausente'"
        );
    }

    /// **A transição diz QUAL transação, e o laço tem que acreditar nela.**
    ///
    /// O laço de descarte tirava a ÚLTIMA (`txs.pop()`) enquanto o erro carrega
    /// o índice do corpo. Com a ofensora no início da seleção, isso descarta
    /// uma a uma todas as boas atrás dela, re-rodando a transição inteira a
    /// cada volta — e, desde que o cache de recusa entrou em 2026-08-30,
    /// BARRANDO cada inocente por `REJECTION_TTL_SLOTS`. Uma transação ruim
    /// podia barrar até 255 legítimas por ~64 minutos. O cache não criou o
    /// defeito; transformou um slot desperdiçado em uma hora de censura.
    #[test]
    fn the_drop_loop_accuses_the_transaction_the_transition_named() {
        use bloch_pos_committee::interfaces::{TransferReject, TransitionError};

        // As duas variantes que nomeiam índice.
        assert_eq!(
            culprit_index(&TransitionError::Transfer(0, TransferReject::UnknownInput), 8),
            Some(0),
            "a ofensora no INICIO e o caso que o pop() da cauda errava por 7 posicoes"
        );
        assert_eq!(culprit_index(&TransitionError::Transaction(5), 8), Some(5));

        // Índice obsoleto: o laço encurta `txs` a cada volta, então um índice
        // válido quando o erro subiu pode não ser mais. Fora de alcance cai no
        // descarte da cauda, que é o que mantém o nó produzindo.
        assert_eq!(culprit_index(&TransitionError::Transaction(8), 8), None);
        assert_eq!(culprit_index(&TransitionError::Transaction(0), 0), None);

        // Erros que não nomeiam transação nenhuma continuam na cauda.
        assert_eq!(culprit_index(&TransitionError::AttestationRootMismatch, 8), None);
        assert_eq!(culprit_index(&TransitionError::CoherenceRootMismatch, 8), None);
    }

    /// **The bar is what makes the drop stick.** Removing a refused
    /// transaction from the mempool does not remove it from the network: the
    /// peers still holding it re-offer it, and the structural admission check
    /// cannot see what the transition saw. Measured on the live chain
    /// 2026-08-30 — a node proposed at slot 47,878 with `mempool 0` in the
    /// same log line, and was holding 21 of the same transactions 383 slots
    /// later.
    ///
    /// Mutation: delete the `is_rejected` arm from `on_transaction` and this
    /// test goes red on the second assertion — the transaction walks straight
    /// back in, which is the pre-2026-08-30 behaviour.
    #[test]
    fn a_refused_transaction_does_not_come_back_through_gossip() {
        let (entries, tx) = sweep_fixture(16);
        let mut node = engine_at_wall_epoch(V2_FLAG_DAY + 1, &entries);
        let key = tx.canonical_bytes();

        assert_eq!(
            node.on_transaction(tx.clone()),
            Ok(Admitted::New),
            "control: the fixture must be admissible before anything bars it"
        );

        // Exactly what the proposer's drop loop does when the transition
        // refuses: out of the mempool, and barred.
        let slot = node.wall_slot();
        node.mempool.remove(&key);
        node.reject_transaction(key.clone(), slot);

        match node.on_transaction(tx.clone()) {
            Err(Refusal::PreviouslyRefused { until_slot }) => assert_eq!(
                until_slot,
                slot + REJECTION_TTL_SLOTS,
                "the bar must lift exactly REJECTION_TTL_SLOTS after the refusal"
            ),
            other => panic!("a barred transaction must not be re-admitted: {other:?}"),
        }
        assert!(
            node.mempool.is_empty(),
            "a barred transaction must not take a mempool slot"
        );
    }

    /// **A barra tem que ser mensuravel de fora.** A primeira versao deste
    /// cache nao era: o caminho de gossip descarta o resultado de
    /// `on_transaction` de proposito, entao barrar nao deixava rastro nenhum e
    /// "o cache esta funcionando?" so podia ser respondido por inferencia
    /// sobre o tamanho do mempool. Num repo cujo lema e que prova que ninguem
    /// pode rodar de novo e alegacao, isso era a coisa errada de embarcar.
    ///
    /// `barred` e `barred_hits` respondem perguntas diferentes: quantas
    /// transacoes o no esta se recusando a readmitir, e quantas reofertas ele
    /// de fato ja recusou. Cache com entradas e zero hits nao esta barrando
    /// nada real — distincao que o tamanho do mempool sozinho nao faz.
    #[test]
    fn the_bar_is_counted_so_it_can_be_measured_from_outside() {
        let (entries, tx) = sweep_fixture(16);
        let mut node = engine_at_wall_epoch(V2_FLAG_DAY + 1, &entries);
        let key = tx.canonical_bytes();
        let slot = node.wall_slot();

        node.reject_transaction(key.clone(), slot);
        assert_eq!(node.rejected.len(), 1, "uma entrada no cache");
        assert_eq!(node.rejected_hits, 0, "entrada nova ainda nao barrou nada");

        // Tres reofertas pelo gossip, como a malha faz.
        for _ in 0..3 {
            assert!(matches!(
                node.on_transaction(tx.clone()),
                Err(Refusal::PreviouslyRefused { .. })
            ));
        }
        assert_eq!(node.rejected_hits, 3, "as tres reofertas tem que ser contadas");
        assert_eq!(
            node.rejected.get(&key).map(|(_, hits)| *hits),
            Some(3),
            "e contadas TAMBEM por chave, que e o que decide se a linha de log sai uma vez so"
        );

        // E o RPC precisa dizer isso sem ninguem ter chave da caixa.
        let out = node.serve_rpc(RpcRequest::MempoolInfo).expect("mempoolinfo responde");
        let json = out.to_string();
        assert!(
            json.contains("\"barred\":1"),
            "getmempoolinfo tem que expor o tamanho do cache: {json}"
        );
        assert!(
            json.contains("\"barred_hits\":3"),
            "getmempoolinfo tem que expor as reofertas barradas: {json}"
        );
    }

    /// **The engine answers `getbuildinfo`, and answers it about ITSELF.**
    ///
    /// The routing test in `rpc/tests.rs` proves the dispatcher decodes the
    /// name; it cannot prove the engine has an arm for it, because a spy
    /// backend answers everything. This one goes through `serve_rpc` on a real
    /// engine, which is the path an exchange's request actually takes.
    ///
    /// The reason it matters here rather than only in the RPC module: on
    /// 2026-09-02 both public archivals answered `getmempoolinfo` with four
    /// fields where this build emits six. Nothing on the surface said which
    /// binary either of them was. This is the method that would have said it,
    /// and a method that routes but is never dispatched would have shipped
    /// looking identical from the outside.
    #[test]
    fn getbuildinfo_is_answered_by_the_engine_and_names_this_tree() {
        let entries = vec![];
        let mut node = engine_at_wall_epoch(V2_FLAG_DAY + 1, &entries);

        let json = node.serve_rpc(RpcRequest::BuildInfo).expect("getbuildinfo responde").to_string();

        // The identity fields a partner is told to compare.
        for k in ["commit", "commit_source", "tree_state", "source_digest", "rustc", "target"] {
            assert!(json.contains(&format!("\"{k}\"")), "engine reply has no `{k}`: {json}");
        }
        // And the digest is the one this binary was built with — not a stub
        // the engine substituted, and not a value read at request time.
        assert!(
            json.contains(env!("BLOCH_SOURCE_DIGEST")),
            "the engine must report the digest compiled into it: {json}"
        );
        assert_ne!(
            env!("BLOCH_SOURCE_DIGEST"),
            "unavailable",
            "built inside the workspace, so the build script must have found the tree"
        );
    }

    /// **And the bar lifts.** `UnknownInput` — the refusal that sends almost
    /// everything here — is a verdict against a STATE, not against the bytes:
    /// a transfer spending a parent still in the mempool is refused now and
    /// applies once the parent lands. A permanent bar would make a chained
    /// spend an unspendable coin, silently.
    ///
    /// The clock is real here (`wall_slot()` reads the manifest against the
    /// system clock), so the expiry is exercised by barring at a slot far
    /// behind the wall rather than by winding the wall forward.
    #[test]
    fn the_bar_lifts_after_the_ttl() {
        let (entries, tx) = sweep_fixture(16);
        let mut node = engine_at_wall_epoch(V2_FLAG_DAY + 1, &entries);
        let key = tx.canonical_bytes();
        let now = node.wall_slot();
        assert!(
            now > REJECTION_TTL_SLOTS,
            "harness: the wall slot must be past the TTL for this test to mean anything"
        );

        node.reject_transaction(key.clone(), 0); // lapses at slot REJECTION_TTL_SLOTS
        assert_eq!(
            node.is_rejected(&key, now),
            None,
            "a bar whose slot has passed must not be honoured"
        );
        assert_eq!(
            node.on_transaction(tx),
            Ok(Admitted::New),
            "once the bar lapses the transaction must be admissible again"
        );
    }

    /// **Remembering refusals must not become the exhaustion it prevents.**
    /// The cache is capped, and the entry evicted is the one expiring soonest
    /// — the one closest to worthless anyway.
    #[test]
    fn the_rejection_cache_is_bounded() {
        let (entries, tx) = sweep_fixture(16);
        let mut node = engine_at_wall_epoch(V2_FLAG_DAY + 1, &entries);
        let now = node.wall_slot();
        for i in 0..(REJECTION_MAX as u64 + 64) {
            // Distinct keys, increasing expiry, so eviction has a defined order.
            node.reject_transaction(i.to_le_bytes().to_vec(), now + i);
        }
        assert!(
            node.rejected.len() <= REJECTION_MAX,
            "the cache grew past its cap: {} entries",
            node.rejected.len()
        );
        assert_eq!(
            node.is_rejected(&0u64.to_le_bytes().to_vec(), now),
            None,
            "the earliest-expiring entry must be the one evicted"
        );
        assert!(
            node.is_rejected(&(REJECTION_MAX as u64 + 63).to_le_bytes().to_vec(), now)
                .is_some(),
            "the most recent bar must survive the eviction"
        );
        // The mempool fixture is untouched by any of this.
        assert_eq!(node.on_transaction(tx), Ok(Admitted::New));
    }

    /// **The bar answers before capacity, and the order is the message.** A
    /// mempool filled to `MEMPOOL_MAX` answering `AtCapacity` tells the sender
    /// to retry later; for a transaction this node has already watched the
    /// transition refuse, that is precisely the wrong advice, and it invites
    /// the retry loop that keeps the population alive.
    #[test]
    fn the_bar_is_answered_before_capacity() {
        let (entries, tx) = sweep_fixture(16);
        let mut node = engine_at_wall_epoch(V2_FLAG_DAY + 1, &entries);
        let key = tx.canonical_bytes();
        let slot = node.wall_slot();
        node.reject_transaction(key, slot);
        // Fill to the cap with anything: the point is which check speaks first.
        for i in 0..MEMPOOL_MAX as u64 {
            node.mempool.insert(i.to_le_bytes().to_vec(), tx.clone());
        }
        assert!(node.mempool.len() >= MEMPOOL_MAX, "harness: the mempool must be full");
        assert!(
            matches!(
                node.on_transaction(tx),
                Err(Refusal::PreviouslyRefused { .. })
            ),
            "a barred transaction must be told it is barred, never told to retry"
        );
    }

    /// A backend that hands the dispatcher ONE answer the real engine
    /// produced, so a test can see the literal bytes a client receives.
    ///
    /// `Engine` is not `Sync` and cannot be an `RpcBackend` itself, so the
    /// error is carried across rather than the engine: everything from
    /// `on_transaction` through `serve_rpc` to `handle_body` is the production
    /// code, and only the socket is missing.
    struct Canned(std::sync::Mutex<Option<RpcResult>>);

    impl crate::rpc::RpcBackend for Canned {
        fn call(&self, _req: RpcRequest) -> RpcResult {
            self.0.lock().unwrap().take().expect("one canned answer, one call")
        }
    }

    /// Put an engine-produced outcome on the wire and return the response body.
    fn on_the_wire(outcome: RpcResult) -> String {
        let backend = Canned(std::sync::Mutex::new(Some(outcome)));
        crate::rpc::handle_body(
            r#"{"jsonrpc":"2.0","id":1,"method":"getchaininfo","params":[]}"#,
            &backend,
        )
    }

    /// **The defect, end to end: the two refusals must reach the client as two
    /// codes, and the retryable one must carry its deadline as a number.**
    ///
    /// `Refusal::Invalid` is a verdict on the BYTES — no passage of time
    /// changes an unverifiable signature, so the client must stop.
    /// `Refusal::PreviouslyRefused` is a verdict on the bytes AGAINST A STATE —
    /// the bar lifts by itself after `REJECTION_TTL_SLOTS`, so the client must
    /// try again. Both used to leave this node as `TX_REFUSED` (-32008), whose
    /// published meaning is "never resubmit these bytes"; an exchange
    /// following that guidance permanently abandoned transactions this node
    /// would have admitted ~64 minutes later. The two facts were separable
    /// only by reading the English message, and `Refusal`'s own doc says a
    /// caller that must act on the difference has to match the variant.
    ///
    /// Both halves are asserted here, because either alone can be satisfied
    /// wrongly: without the terminal control, "always return -32009" passes;
    /// without the retryable half, "always return -32008" — today's defect —
    /// passes.
    #[test]
    fn the_two_refusals_reach_the_client_as_two_codes() {
        // ── Retryable: barred against a state, and the bar lifts on its own ──
        let (entries, tx) = sweep_fixture(16);
        let mut node = engine_at_wall_epoch(V2_FLAG_DAY + 1, &entries);
        let slot = node.wall_slot();
        node.reject_transaction(tx.canonical_bytes(), slot);

        let RpcResult::Err(retryable) = node.serve_rpc(RpcRequest::SendRawTransaction(tx.clone()))
        else {
            panic!("a barred transaction must produce an RPC error");
        };
        assert_eq!(
            retryable.code,
            rpc::TX_REFUSED_RETRYABLE,
            "a bar that lifts by itself must NOT be reported as terminal: {retryable:?}"
        );
        assert_ne!(
            retryable.code,
            rpc::TX_REFUSED,
            "collapsing the retryable refusal back onto -32008 is the defect"
        );

        // The deadline is a value the client computes with, so it must be
        // readable without parsing the sentence — and it must be the real one.
        let data = retryable
            .data
            .as_ref()
            .expect("the retryable refusal must carry `error.data`");
        assert_eq!(
            data.get("until_slot").and_then(rpc::Json::as_u64),
            Some(slot + REJECTION_TTL_SLOTS),
            "the deadline must be the slot the bar actually lifts at: {data:?}"
        );
        assert_eq!(data.get("retryable"), Some(&rpc::Json::Bool(true)));

        // And it survives to the wire, in the literal bytes a client reads.
        let wire = on_the_wire(Err(retryable));
        assert!(
            wire.contains(r#""code":-32009"#),
            "the wire must carry -32009: {wire}"
        );
        assert!(
            wire.contains(&format!(r#""until_slot":{}"#, slot + REJECTION_TTL_SLOTS)),
            "the wire must carry the deadline as a number: {wire}"
        );

        // ── Terminal: a verdict on the bytes, and it must stay terminal ──────
        let (entries, tx) = sweep_fixture(16);
        let mut pre = engine_at_wall_epoch(0, &entries);
        let RpcResult::Err(terminal) = pre.serve_rpc(RpcRequest::SendRawTransaction(tx)) else {
            panic!("a transaction refused on its merits must produce an RPC error");
        };
        assert_eq!(
            terminal.code,
            rpc::TX_REFUSED,
            "-32008 is published as terminal and must keep meaning that: {terminal:?}"
        );
        assert!(
            terminal.data.is_none(),
            "a terminal refusal must not offer a deadline: {terminal:?}"
        );
        let wire = on_the_wire(Err(terminal));
        assert!(wire.contains(r#""code":-32008"#), "{wire}");
        assert!(
            !wire.contains("until_slot") && !wire.contains(r#""data""#),
            "a terminal refusal must carry no retry hint at all: {wire}"
        );
    }

    /// (d): before the flag day NOTHING changes — this is the photograph of
    /// today's behaviour, taken with the same harness, the same transaction
    /// bytes, and a manifest whose genesis is now (wall epoch 0). Both entry
    /// paths refuse with today's message, the mempool stays empty, selection
    /// stays empty.
    ///
    /// Mutation log (2026-08-22): flag-day gate deleted from the arm — this
    /// test dies on every assertion; it is the half that keeps the
    /// activation an activation instead of an unconditional opening.
    #[test]
    fn v2_sweep_is_refused_everywhere_before_the_flag_day() {
        let (entries, tx) = sweep_fixture(16);
        let mut node = engine_at_wall_epoch(0, &entries);
        assert_eq!(
            epoch_of(node.wall_slot()),
            0,
            "harness: a fresh genesis must put the wall clock in epoch 0"
        );

        // Gossip path: refused with today's string.
        let err = node
            .on_transaction(tx.clone())
            .expect_err("pre-activation, the gossip path must refuse V2");
        assert!(
            err.reason().contains("deduplicated transfers (tag 0x06) are not active"),
            "the refusal must be today's, byte for byte its opening clause: {}",
            err.reason()
        );

        // RPC path: refused too, as an error the client sees.
        let out = node.serve_rpc(RpcRequest::SendRawTransaction(tx.clone()));
        assert!(
            out.is_err(),
            "pre-activation, sendrawtransaction must refuse V2: {out:?}"
        );

        // And nothing propagates: no mempool entry, nothing to select — the
        // sweep does not exist to this era's node, exactly as today.
        assert!(node.mempool.is_empty(), "the mempool must stay empty");
        assert!(
            node.select_transactions(0).is_empty(),
            "selection must stay empty"
        );

        // THE POINT OF THE ERROR CODE: a refused transaction must not be
        // reported as a full mempool. The founder's sweep submits hundreds of
        // thousands of transfers through this method; "retry later" against
        // bytes that can never be admitted sends the operator after capacity
        // while the real fault goes unread.
        let RpcResult::Err(e) = node.serve_rpc(RpcRequest::SendRawTransaction(tx.clone())) else {
            panic!("a refused transaction must produce an RPC error");
        };
        assert_eq!(e.code, rpc::TX_REFUSED, "refused is not full: {e:?}");
        assert!(
            !e.message.contains("retry later"),
            "a refused transaction must not be told to retry later: {}",
            e.message
        );

        // THE CONTROL: a genuinely full mempool still reports MEMPOOL_FULL,
        // and there "retry later" is the correct advice. Without this half,
        // the assertion above could be satisfied by never reporting a full
        // mempool at all.
        //
        // Each filler entry gets a DISTINCT source (R7 M6's per-source cap,
        // `MEMPOOL_MAX_PER_SOURCE` = 64, is far below `MEMPOOL_MAX` = 4,096):
        // without this, every filler shares `tx`'s one source and the fill
        // trips the per-source cap at 64 entries rather than ever reaching
        // real capacity, which is a different, more specific refusal
        // (`TX_REFUSED_SOURCE_CAP`) than the one this control is for.
        let mut full = node;
        for i in 0..MEMPOOL_MAX {
            let mut filler = tx.clone();
            if let PosTransaction::TransferV2 { keys, .. } = &mut filler {
                if let Some(k) = keys.first_mut() {
                    k.pubkey = (i as u32).to_le_bytes().to_vec();
                }
            }
            full.mempool.insert(vec![0xEE, (i >> 8) as u8, i as u8], filler);
        }
        let RpcResult::Err(e2) = full.serve_rpc(RpcRequest::SendRawTransaction(tx.clone()))
        else {
            panic!("a full mempool must produce an RPC error");
        };
        assert_eq!(e2.code, rpc::MEMPOOL_FULL, "full is not refused: {e2:?}");
        assert!(
            e2.message.contains("retry later"),
            "a full mempool SHOULD advise retrying: {}",
            e2.message
        );
    }
}

/// A real, proposing `Engine`, for tests that must drive the actual block
/// path rather than a stand-in.
///
/// One genesis validator whose hybrid key this node holds, so this node is
/// the proposer AND the whole committee at every slot: `propose(slot)` always
/// fires and the block it builds is validated by the real
/// `Transition::apply_block` under the real ML-DSA-65 ‖ Falcon-1024 verifier.
/// That is what makes a claim measured here a claim about production code.
#[cfg(test)]
mod perf_support {
    use super::*;
    use crate::genesis::ManifestValidator;
    use bloch_pos_committee::beacon::RandaoChain;

    const SAT_PER_BLOCH: u128 = 100_000_000;

    /// Throwaway data dir, deleted when the returned guard drops.
    pub(super) struct TestDir(pub PathBuf);

    impl Drop for TestDir {
        fn drop(&mut self) {
            let _ = std::fs::remove_dir_all(&self.0);
        }
    }

    /// Build the engine. `slot_ms` and `genesis_time_ms` are irrelevant to
    /// every path exercised here — `propose`, `ingest` and `do_reorg` all take
    /// the slot as an argument and read no clock — so the manifest's cadence
    /// is set to something plausible and then not depended upon.
    pub(super) fn proposing_engine() -> (Engine, TestDir) {
        proposing_engine_funded(&[])
    }

    /// The same engine, opening with a ledger — for the tests whose claim is
    /// about what happens (or must not happen) to the eUTXO map. On an empty
    /// map "no copies" is vacuous; on a funded one it is the catch-up fix.
    pub(super) fn proposing_engine_funded(
        opening: &[bloch_pos_committee::state_root::EutxoEntry],
    ) -> (Engine, TestDir) {
        static DIR_SEQ: AtomicU64 = AtomicU64::new(0);
        let dir = std::env::temp_dir().join(format!(
            "bloch-pos-perf-{}-{}",
            std::process::id(),
            DIR_SEQ.fetch_add(1, Ordering::Relaxed),
        ));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).expect("create the test data dir");

        // Explicit plaintext opt-in (audit I-H1): these are disposable in-process
        // devnet keys in a temp dir, and paying Argon2id 64 MiB per keystore
        // in an unoptimized test binary would dominate the suite.
        let ks = Keystore::generate_with(&dir, 0, &crate::keys::Unlock::PlaintextOptIn)
            .expect("generate a devnet keystore");
        let manifest = Manifest {
            genesis_time_ms: now_ms(),
            slot_ms: 1_000,
            validators: vec![ManifestValidator {
                index: 0,
                stake_sat: 200_000 * SAT_PER_BLOCH,
                randao_commitment: RandaoChain::generate(ks.randao_seed).commitment(),
                pubkey: ks.pubkey.clone(),
                withdrawal_credentials: Vec::new(),
                commission_bps: 0,
            }],
            cohort: Vec::new(),
            carryover: None,
            allocations: Vec::new(),
            carryover_entries: opening.to_vec(),
            format: crate::genesis::ManifestFormat::V1Unbound,
            pre_state_root: std::sync::OnceLock::new(),
        };
        let genesis_id = manifest.genesis_id();
        let state = manifest.genesis_state();
        let store = Store::open(&dir, &[0u8; 32]).expect("open the test store");
        let (events, _rx) = mpsc::channel::<EngineEvent>();
        let head_slot = Arc::new(AtomicU64::new(0));
        let inflight = net::QueueBudget::new();
        let net = net::Net::Devnet(
            net::start(
                "127.0.0.1",
                0, // ephemeral port: bind for real, listen to nobody
                Vec::new(),
                events,
                dir.clone(),
                head_slot.clone(),
                inflight,
            )
            .expect("bind the devnet transport on an ephemeral port"),
        );
        let verifier = HybridVerifier::new();
        let engine = Engine {
            genesis_validator_count: manifest.validators.len() as u32,
            manifest,
            state: StateCell::new(state),
            tr: Transition::new(verifier.clone()),
            tr_probe: Transition::new(ProbeVerifier),
            verifier,
            keys: Some(ks),
            blocks: BTreeMap::new(),
            observed_proposals: BTreeMap::new(),
            chain: vec![(0, genesis_id)],
            canonical: BTreeSet::from([*genesis_id.as_bytes()]),
            recent_states: VecDeque::new(),
            pool: BTreeMap::new(),
            att_pool: AttestationPool::new(),
            wall_slot: 0,
            mempool: BTreeMap::new(),
            mempool_admitted_at: BTreeMap::new(),
            mempool_expired: 0,
            mempool_evicted_low_fee: 0,
            rejected: BTreeMap::new(),
        rejected_hits: 0,
        mempool_suspect: BTreeSet::new(),
        mempool_swept_epoch: u64::MAX,
            store,
            slashprot: SlashingProtection::open(&dir).expect("open slashing protection"),
            net,
            head_slot,
            live: true,
            needs_sync: false,
            orphans: VecDeque::new(),
            orphans_evicted: 0,
            orphans_admitted: 0,
            blocks_pruned: 0,
            rejected_unsigned: 0,
            rejected_future: 0,
            last_applied_ms: now_ms(),
            booted_ms: now_ms(),
            ws_anchor: None,
            ws_anchor_hard: false,
            ws_conflict_reported: false,
            // A fresh engine has dropped nothing from an empty pool, so the
            // running total is zero — the same value `boot`'s literal uses.
            // Not a placeholder: `forkchoice_inputs` reads this as
            // `pool.len() + this`, and starting it anywhere but 0 would
            // offset the very first comparison against a pool that really is
            // empty.
            fc_covered_removals: 0,
            finalized_latch: None,
            finality_rewinds_refused: 0,
            parked_refused_finality: VecDeque::new(),
            finality_rewind_override: false,
            tx_slot_index: BTreeMap::new(),
            tx_slot_index_order: VecDeque::new(),
            doppelganger_observe_until: None,
            doppelganger_halted: false,
        };
        (engine, TestDir(dir))
    }
}

/// Doppelgänger protection (R6 HIGH-8, node half): `Engine::note_possible_doppelganger`
/// and `Engine::doppelganger_blocks_duties`.
#[cfg(test)]
mod doppelganger_tests {
    use super::*;

    #[test]
    fn replay_of_own_committed_proposal_does_not_report_a_duplicate() {
        let (mut engine, _dir) = perf_support::proposing_engine();
        engine.propose(1);
        assert_eq!(engine.chain.len(), 2, "fixture must commit an own proposal");
        let block = engine.blocks.get(engine.head_id().as_bytes()).unwrap().clone();
        let genesis = engine.manifest.genesis_id();
        engine.state = StateCell::new(engine.manifest.genesis_state());
        engine.blocks.clear();
        engine.chain.truncate(1);
        engine.canonical = BTreeSet::from([*genesis.as_bytes()]);
        engine.recent_states.clear();
        // Even an accidentally pre-armed window must not classify disk history
        // as gossip. Keep live=true to test the explicit replay source guard.
        engine.start_doppelganger_observation(0);
        engine.ingest_replay(block);
        assert_eq!(engine.state.slot(), 1, "replay must actually accept the block");
        assert!(!engine.doppelganger_halted);
    }

    #[test]
    fn observation_keeps_a_full_window_after_a_long_replay() {
        let (mut engine, _dir) = perf_support::proposing_engine();
        assert!(engine.doppelganger_observe_until.is_none());
        engine.start_doppelganger_observation(10_000);
        assert!(engine.doppelganger_blocks_duties(10_000));
        assert!(engine.doppelganger_blocks_duties(10_063));
        assert!(!engine.doppelganger_blocks_duties(10_064));
    }

    #[test]
    fn delayed_old_duty_is_ignored_but_current_duty_halts() {
        let (mut engine, _dir) = perf_support::proposing_engine();
        let index = engine.keys.as_ref().unwrap().index;
        engine.start_doppelganger_observation(100);
        let mut old = sample_attestation_for(index);
        old.data.slot = 99;
        engine.apply_decision(old, GossipDecision::Accept { slashing_candidate: None }, &Origin::none());
        assert!(!engine.doppelganger_halted);
        let mut current = sample_attestation_for(index);
        current.data.slot = 100;
        engine.apply_decision(current, GossipDecision::Accept { slashing_candidate: None }, &Origin::none());
        assert!(engine.doppelganger_halted);
        assert!(engine.doppelganger_blocks_duties(10_000));
    }

    fn sample_attestation_for(validator: u32) -> Attestation {
        Attestation {
            data: AttestationData {
                slot: 1,
                head: [0u8; 32],
                source_epoch: 0,
                source_root: [0u8; 32],
                target_epoch: 0,
                target_root: [0u8; 32],
            },
            validator,
            signature: Vec::new(),
        }
    }

    /// **The finding's own scenario.** A synthetic gossip attestation
    /// carrying this node's own validator index, accepted during the
    /// observation window, is unambiguous evidence of a live duplicate: this
    /// process refuses ALL duties throughout the window (`attest`/`propose`
    /// both check `doppelganger_blocks_duties` first), so it did not produce
    /// this itself.
    #[test]
    fn a_synthetic_gossip_attestation_from_own_index_is_detected() {
        let (mut engine, _dir) = perf_support::proposing_engine();
        let my_index = engine.keys.as_ref().expect("fixture: has a keystore").index;
        engine.doppelganger_observe_until = Some(DOPPELGANGER_OBSERVE_SLOTS);
        engine.wall_slot = 5; // well inside the window

        assert!(!engine.doppelganger_halted, "must not start halted");
        engine.apply_decision(
            sample_attestation_for(my_index),
            GossipDecision::Accept { slashing_candidate: None },
            &Origin::none(),
        );
        assert!(
            engine.doppelganger_halted,
            "an attestation from this node's own index, during the observation window, \
             must be detected as a live duplicate"
        );
    }

    /// A duty under SOMEONE ELSE'S index proves nothing about this key.
    #[test]
    fn an_attestation_from_another_index_is_not_a_doppelganger() {
        let (mut engine, _dir) = perf_support::proposing_engine();
        let my_index = engine.keys.as_ref().expect("fixture: has a keystore").index;
        engine.doppelganger_observe_until = Some(DOPPELGANGER_OBSERVE_SLOTS);
        engine.wall_slot = 5;

        engine.apply_decision(
            sample_attestation_for(my_index + 1),
            GossipDecision::Accept { slashing_candidate: None },
            &Origin::none(),
        );
        assert!(!engine.doppelganger_halted, "another validator's duty must not trip the halt");
    }

    /// Once the window has closed, THIS node may itself be producing duties
    /// under its own index — seeing that index attest is then the expected
    ///, ordinary case, not evidence of a duplicate.
    #[test]
    fn own_index_after_the_window_closes_is_not_flagged() {
        let (mut engine, _dir) = perf_support::proposing_engine();
        let my_index = engine.keys.as_ref().expect("fixture: has a keystore").index;
        engine.doppelganger_observe_until = Some(10);
        engine.wall_slot = 50; // past the window

        engine.apply_decision(
            sample_attestation_for(my_index),
            GossipDecision::Accept { slashing_candidate: None },
            &Origin::none(),
        );
        assert!(!engine.doppelganger_halted, "past the window, this node's own index is expected");
    }

    /// The whole point of a PERMANENT halt: once detected, duties stay
    /// blocked even past the window's own original deadline — the halt is a
    /// fact about the key having a live duplicate, not about the moment it
    /// was first seen, and must survive the window closing.
    #[test]
    fn once_detected_duties_stay_blocked_past_the_original_deadline() {
        let (mut engine, _dir) = perf_support::proposing_engine();
        let my_index = engine.keys.as_ref().expect("fixture: has a keystore").index;
        engine.doppelganger_observe_until = Some(10);
        engine.wall_slot = 5;
        engine.apply_decision(
            sample_attestation_for(my_index),
            GossipDecision::Accept { slashing_candidate: None },
            &Origin::none(),
        );
        assert!(engine.doppelganger_halted, "fixture: must have detected the duplicate");
        assert!(
            engine.doppelganger_blocks_duties(9_999),
            "a detected duplicate must block duties indefinitely, not just until the window"
        );
    }

    /// No window armed (bypassed via `--no-doppelganger-check` /
    /// `BLOCH_NO_DOPPELGANGER`, or an observer with no keys) means no
    /// suppression at all — the default every OTHER test's engine relies on,
    /// since none of them arm the window.
    #[test]
    fn no_window_means_duties_are_never_blocked() {
        let (engine, _dir) = perf_support::proposing_engine();
        assert!(engine.doppelganger_observe_until.is_none(), "fixture: window must start unarmed");
        assert!(!engine.doppelganger_blocks_duties(0));
        assert!(!engine.doppelganger_blocks_duties(u64::MAX));
    }

    /// Inside the window but nothing has been seen yet: duties are blocked
    /// (observe-only mode), silently — this is the expected, ordinary state
    /// for every slot of a normal boot, not an error condition.
    #[test]
    fn inside_the_window_with_nothing_seen_duties_are_blocked_without_halting() {
        let (engine, _dir) = perf_support::proposing_engine();
        let mut engine = engine;
        engine.doppelganger_observe_until = Some(DOPPELGANGER_OBSERVE_SLOTS);
        assert!(engine.doppelganger_blocks_duties(5), "still observing: duties must wait");
        assert!(!engine.doppelganger_halted, "observing alone is not a detected duplicate");
        assert!(
            !engine.doppelganger_blocks_duties(DOPPELGANGER_OBSERVE_SLOTS),
            "at the deadline slot itself, the window has closed"
        );
    }
}

/// **Win 3's proof.** A proposer used to compute the whole committed state
/// root THREE times for one slot; it now computes it twice, and the two that
/// remain are the two that carry a rule.
///
/// The three were: stamping the header (`propose`, from the probe's
/// post-state), the transition's own step-12 check inside `apply_block`, and
/// a third for the `applied …` log line. The first two are the
/// producer=validator seam — the producer must commit a root and then face
/// the same check every peer will run — so neither may go. The third was a
/// display of a number the second had already proved equal to
/// `header.state_root`, which the log now prints directly.
///
/// The assertion is a COUNT, not a duration: it fails on the old code and
/// passes on the new one on any box, at any load. A timing test would only
/// have said "faster on this machine today".
#[cfg(test)]
mod root_budget_tests {
    use super::*;
    use bloch_pos_committee::transition::root_computations;

    #[test]
    fn a_proposer_spends_two_state_roots_per_slot_not_three() {
        let (mut engine, _dir) = perf_support::proposing_engine();

        let before = root_computations();
        engine.propose(1);
        let spent = root_computations() - before;

        assert_eq!(
            engine.chain.len(),
            2,
            "the harness must actually have produced and adopted a block — \
             a proposer that produced nothing would spend no roots and pass \
             this test for the wrong reason"
        );
        assert_eq!(
            spent, 2,
            "one proposed slot must cost exactly two state-root computations: \
             the header stamp and the transition's step-12 check. Three means \
             the log line's root came back; one means a check went missing."
        );

        // And the value the log prints is still the head's real root — the
        // whole basis for deleting the computation.
        let head = engine
            .blocks
            .get(engine.head_id().as_bytes())
            .expect("the adopted block is stored");
        let recomputed_before = root_computations();
        assert_eq!(
            head.header.state_root,
            engine.state.state_root(),
            "the header root the log now prints must equal the recomputed \
             state root, or the log is lying about the head"
        );
        assert_eq!(
            root_computations() - recomputed_before,
            1,
            "the check above must itself cost exactly one root, or the \
             counter is not counting what this test claims it counts"
        );
    }

    /// The same budget over several consecutive slots, so a one-off cannot
    /// pass: `n` proposed slots cost exactly `2n` roots.
    #[test]
    fn the_budget_holds_across_consecutive_slots() {
        let (mut engine, _dir) = perf_support::proposing_engine();
        let before = root_computations();
        for slot in 1..=5 {
            engine.propose(slot);
        }
        assert_eq!(
            engine.chain.len(),
            6,
            "five proposed slots must land five blocks on genesis"
        );
        assert_eq!(
            root_computations() - before,
            10,
            "five slots must cost ten state-root computations, not fifteen"
        );
    }
}

/// What the deleted work actually cost, on a state the size the fleet runs.
///
/// `#[ignore]`d: it is a measurement, not an assertion, and it builds a
/// Genesis-3-sized balance set (hundreds of thousands of outputs), which is
/// seconds of setup no ordinary test run should pay. Run it with
/// `cargo test --release -p bloch-pos-node -- --ignored --nocapture bench_`.
///
/// A devnet state roots in microseconds; mainnet's does not, and the number
/// that matters is mainnet's. The size below is the Genesis-3 carryover's own
/// output count, so the figure is the fleet's, not a toy's.
#[cfg(test)]
mod bench {
    use super::*;
    use bloch_pos_committee::state_root::{EutxoEntry, EvmCommitment};
    use std::time::Instant;

    /// The opening-ledger size this bench sizes its state to.
    ///
    /// It does NOT agree with `CARRYOVER-SNAPSHOT.md`, which records 452,726
    /// rows, nor with `engine/replay_bench.rs`'s `CARRYOVER_N`, which is that
    /// same 452,726 — a gap of 593 outputs. The constant is left at 452,133
    /// rather than quietly moved: this is an `#[ignore]`d measurement that
    /// asserts nothing, so the gap costs nothing today, and editing a figure to
    /// match a document is exactly how a wrong figure becomes load-bearing.
    /// Which of the two is stale is for the founder to settle.
    const MAINNET_EUTXOS: u32 = 452_133;

    fn mainnet_sized_state(n: u32) -> CommittedState {
        let entries: Vec<EutxoEntry> = (0..n)
            .map(|i| EutxoEntry {
                txid: {
                    let mut t = [0u8; 32];
                    t[..4].copy_from_slice(&i.to_le_bytes());
                    t
                },
                vout: i % 8,
                value: 8_400 * 100_000_000,
                script_hash: {
                    let mut h = [0u8; 32];
                    h[..4].copy_from_slice(&(i % 4096).to_le_bytes());
                    h
                },
            })
            .collect();
        CommittedState::genesis(
            BlockId::of(&BlockHeaderV4 {
                version: VERSION_G4,
                parent: [0u8; 32],
                state_root: [0u8; 32],
                body_root: [0u8; 32],
                slot: 0,
                proposer_index: 0,
                randao_reveal: [0u8; 32],
                randao_mix: [0u8; 32],
                justified_root: [0u8; 32],
                finalized_root: [0u8; 32],
                attestation_root: [0u8; 32],
                coherence_root: [0u8; 32],
            }),
            GENESIS_MIX,
            &[],
            &[],
            [0u8; 32],
            [0u8; 32],
            [0u8; 32],
            EvmCommitment {
                account_root: [0u8; 32],
                receipts_root: [0u8; 32],
                gas_used: 0,
                base_fee_per_gas: 0,
            },
            &entries,
        )
    }

    /// A carryover-sized state that also carries a REGISTRY.
    ///
    /// [`mainnet_sized_state`] leaves `validators` empty, which is fine for
    /// the benches that only move eUTXOs but wrong for anything measuring a
    /// whole state root: the registry is most of the non-eUTXO tree, and each
    /// record hashes a hybrid ML-DSA-65 ‖ Falcon-1024 pubkey (~3,749 B) into
    /// its leaf. Sized and shaped after `tests/replay_hotpath_perf.rs`'s
    /// fixture so the two are comparable.
    fn carryover_state_with_validators(n: u32, validators: u32) -> CommittedState {
        let entries: Vec<EutxoEntry> = (0..n)
            .map(|i| EutxoEntry {
                txid: {
                    let mut t = [0u8; 32];
                    t[..4].copy_from_slice(&i.to_le_bytes());
                    t
                },
                vout: i % 8,
                value: 8_400 * 100_000_000,
                script_hash: {
                    let mut h = [0u8; 32];
                    h[..4].copy_from_slice(&(i % 4096).to_le_bytes());
                    h
                },
            })
            .collect();
        let vs: Vec<bloch_pos_committee::transition::GenesisValidator> = (0..validators)
            .map(|i| bloch_pos_committee::transition::GenesisValidator {
                index: i,
                // The real hybrid pubkey length. It is hashed whole into the
                // leaf, so the length is part of what is being measured.
                pubkey: vec![(i % 251) as u8; 3_749],
                staked_sat: 32 * 100_000_000,
                randao_commitment: {
                    let mut c = [0u8; 32];
                    c[..4].copy_from_slice(&i.to_le_bytes());
                    c
                },
                withdrawal_credentials: vec![0xAB; 32],
                commission_bps: 500,
            })
            .collect();
        CommittedState::genesis(
            BlockId::of(&BlockHeaderV4 {
                version: VERSION_G4,
                parent: [0u8; 32],
                state_root: [0u8; 32],
                body_root: [0u8; 32],
                slot: 0,
                proposer_index: 0,
                randao_reveal: [0u8; 32],
                randao_mix: [0u8; 32],
                justified_root: [0u8; 32],
                finalized_root: [0u8; 32],
                attestation_root: [0u8; 32],
                coherence_root: [0u8; 32],
            }),
            GENESIS_MIX,
            &vs,
            &[],
            [0u8; 32],
            [0u8; 32],
            [0u8; 32],
            EvmCommitment {
                account_root: [0u8; 32],
                receipts_root: [0u8; 32],
                gas_used: 0,
                base_fee_per_gas: 0,
            },
            &entries,
        )
    }

    fn median(mut v: Vec<u128>) -> u128 {
        v.sort_unstable();
        v[v.len() / 2]
    }

    /// **What `getchaininfo` costs to build, before and after.**
    ///
    /// `chain_info_json` computed the committed state root on the consensus
    /// thread for every caller. The 2026-08-21 n21 incident (`-32004 consensus
    /// thread did not answer within 10s`, answered after 10.7 s, box load
    /// average 1.01 — not CPU-bound, one thread eaten) is what prompted this,
    /// but see [`Engine::head_state_root`]: the 733 ms it was reported at does
    /// NOT reproduce on this tree, which already has the incremental eUTXO
    /// subtree. What this bench measures is what the call costs HERE.
    ///
    /// Sized at 452,726 eUTXO leaves — the Genesis-4 carryover's own count,
    /// the same constant `tests/replay_hotpath_perf.rs` calls `CARRYOVER_N`.
    /// The 452,133 above it is Genesis-3's and is left alone.
    ///
    /// BEFORE is not a paraphrase: it is `state.state_root()` followed by the
    /// same `chain_info_json` call, which is exactly what the old body did
    /// (the root computation was the first thing inside it). AFTER hands in
    /// the head header's root. Everything else about the two is identical, so
    /// the difference is the walk and nothing else.
    ///
    /// **Cold vs warm is the whole reason this is not a one-liner.**
    /// `state_root.rs` keeps a THREAD-LOCAL memo of singleton subtree roots,
    /// so the second call on a thread is artificially fast and reporting only
    /// that would understate what a freshly-spawned RPC worker pays. Each cold
    /// figure below is the FIRST call on a thread that has never rooted
    /// anything; the warm figures are medians over repeats on one thread.
    #[test]
    #[ignore]
    fn bench_chain_info_json() {
        /// The Genesis-4 carryover's output count.
        const CARRYOVER_N: u32 = 452_726;
        /// Roughly the live Genesis-4 set: 12 classic + 49 Fly, per
        /// `tests/replay_hotpath_perf.rs`, which uses the same 64.
        const N_VALIDATORS: u32 = 64;

        // NOT `mainnet_sized_state`, and the difference is the whole
        // measurement. That helper registers NO validators, and the validator
        // records are what the non-eUTXO half of the tree is made of — each
        // one serializes a ~3,749-byte hybrid pubkey into its leaf. With an
        // empty registry this bench reported a BEFORE of 0.1 ms, which is not
        // a fast node, it is an empty one. `perf_state_root_breakdown`'s
        // fixture has 202 non-eUTXO leaves and costs 5.8 ms for the same call.
        let st = carryover_state_with_validators(CARRYOVER_N, N_VALIDATORS);
        let head = st.head();

        // The header value the engine now reads. Computed once here, off the
        // measured path, exactly as `apply_block` computed it once on the way
        // in.
        let header_root = st.state_root();

        let before = |st: &CommittedState| -> u128 {
            let t = Instant::now();
            let root = st.state_root();
            let v = crate::rpc::chain_info_json(st, &head, root, 0, Some(0), 0, 1, 0, 1, "devnet", (Some(0), None));
            let us = t.elapsed().as_micros();
            std::hint::black_box(v);
            us
        };
        let after = |st: &CommittedState| -> u128 {
            let t = Instant::now();
            let v = crate::rpc::chain_info_json(st, &head, header_root, 0, Some(0), 0, 1, 0, 1, "devnet", (Some(0), None));
            let us = t.elapsed().as_micros();
            std::hint::black_box(v);
            us
        };

        // ── COLD: one call each, on a thread with an empty singleton memo ──
        let (cold_before, cold_after) = std::thread::scope(|sc| {
            let b = sc.spawn(|| before(&st));
            let b = b.join().expect("cold BEFORE thread");
            let a = sc.spawn(|| after(&st));
            let a = a.join().expect("cold AFTER thread");
            (b, a)
        });

        // ── WARM: medians on this thread, memo populated by the first call ──
        let _ = before(&st);
        let warm_before = median((0..7).map(|_| before(&st)).collect());
        let _ = after(&st);
        let warm_after = median((0..7).map(|_| after(&st)).collect());

        let ms = |us: u128| us as f64 / 1_000.0;
        println!(
            "getchaininfo response construction @ n = {CARRYOVER_N} eUTXOs \
             + {N_VALIDATORS} validators (Genesis-4 carryover)"
        );
        println!(
            "  BEFORE (root recomputed): cold {:>8.1} ms   warm {:>8.1} ms",
            ms(cold_before),
            ms(warm_before)
        );
        println!(
            "  AFTER  (root handed in) : cold {:>8.3} ms   warm {:>8.3} ms",
            ms(cold_after),
            ms(warm_after)
        );

        // Byte-identical, which is what makes this transport-only. Asserted
        // rather than printed: a bench that quietly changed the answer would
        // be measuring the wrong thing to begin with.
        let a = crate::rpc::chain_info_json(&st, &head, header_root, 0, Some(0), 0, 1, 0, 1, "devnet", (Some(0), None));
        let b = {
            let root = st.state_root();
            crate::rpc::chain_info_json(&st, &head, root, 0, Some(0), 0, 1, 0, 1, "devnet", (Some(0), None))
        };
        assert_eq!(
            a.to_string(),
            b.to_string(),
            "the handed-in root produced a different response body than the recomputed one"
        );
    }

    #[test]
    #[ignore]
    fn bench_state_root() {
        let st = mainnet_sized_state(MAINNET_EUTXOS);
        let mut samples = Vec::new();
        for _ in 0..7 {
            let t = Instant::now();
            let _ = st.state_root();
            samples.push(t.elapsed().as_micros());
        }
        println!(
            "state_root over {MAINNET_EUTXOS} eUTXOs: median {} us (min {}, max {})",
            median(samples.clone()),
            samples.iter().min().unwrap(),
            samples.iter().max().unwrap()
        );
    }

    /// The whole of Win 1, end to end: what one arriving attestation used to
    /// cost `judge` before it could even look at a committee, and what it
    /// costs now. `epoch` = head epoch is the identity roll (a bare clone
    /// before, an `Arc` bump now); `epoch` = head epoch + 1 is the one that
    /// also ran `process_epoch`.
    #[test]
    #[ignore]
    fn bench_rolled_to() {
        let st = mainnet_sized_state(MAINNET_EUTXOS);
        let tr = Transition::new(ProbeVerifier);
        let roll = |s: &CommittedState| tr.process_epoch(s).expect("infallible");

        // BEFORE: the pre-change body, verbatim.
        let uncached = |epoch: u64| {
            let mut cur_state = st.clone();
            let mut cur = epoch_of(cur_state.slot());
            while cur < epoch {
                cur_state = roll(&cur_state);
                cur += 1;
            }
            cur_state
        };
        for target in [0u64, 1] {
            let mut samples = Vec::new();
            for _ in 0..7 {
                let t = Instant::now();
                let out = uncached(target);
                samples.push(t.elapsed().as_micros());
                std::hint::black_box(&out);
            }
            println!(
                "BEFORE rolled_to(head_epoch + {target}): median {} us",
                median(samples)
            );
        }

        // AFTER: the memo. First call is the miss that pays; the rest are
        // what the other attestations in the same flight actually see.
        let cell = StateCell::new(st.clone());
        for target in [0u64, 1] {
            let t = Instant::now();
            let out = cell.rolled_to(target, roll);
            let miss = t.elapsed().as_micros();
            std::hint::black_box(&out);
            let mut samples = Vec::new();
            for _ in 0..64 {
                let t = Instant::now();
                let out = cell.rolled_to(target, roll);
                samples.push(t.elapsed().as_nanos());
                std::hint::black_box(&out);
            }
            println!(
                "AFTER  rolled_to(head_epoch + {target}): miss {miss} us, \
                 hit median {} ns",
                median(samples.iter().map(|n| *n as u128).collect::<Vec<_>>())
            );
        }
    }

    /// Resident bytes one Genesis-3-sized `CommittedState` costs — the price
    /// of one slot in [`REORG_STATE_WINDOW`]. Read from the OS, not from
    /// `size_of`, because the cost is the allocator's and not the struct's.
    #[test]
    #[ignore]
    fn bench_state_footprint() {
        fn rss_kb() -> u64 {
            let out = std::process::Command::new("ps")
                .args(["-o", "rss=", "-p", &std::process::id().to_string()])
                .output()
                .expect("ps");
            String::from_utf8_lossy(&out.stdout).trim().parse().unwrap_or(0)
        }
        let base = mainnet_sized_state(MAINNET_EUTXOS);
        let before = rss_kb();
        let held: Vec<CommittedState> = (0..4).map(|_| base.clone()).collect();
        let after = rss_kb();
        println!(
            "4 extra Genesis-3-sized states: RSS {before} kB -> {after} kB \
             ({} MB each)",
            (after.saturating_sub(before)) / 4 / 1024
        );
        std::hint::black_box(&held);
    }

    /// Win 2's shape: the base state a reorg starts from, computed the old
    /// way (replay every canonical block from genesis) and the new way (a
    /// retained snapshot), as the chain gets longer.
    ///
    /// Devnet-sized state, so the absolute numbers are small — the finding is
    /// the SHAPE. The old cost grows with chain height and the new one does
    /// not, which is the whole change; on a chain with a Genesis-3 carryover
    /// every one of those `apply_block` calls also carries the state root
    /// measured above.
    #[test]
    #[ignore]
    fn bench_reorg_base_state() {
        for height in [10u64, 30, 60] {
            let (mut engine, _dir) = perf_support::proposing_engine();
            for slot in 1..=height {
                engine.propose(slot);
            }
            let parent = *engine.chain[engine.chain.len() - 2].1.as_bytes();
            assert!(
                engine.recent_states.iter().any(|(id, _)| *id == parent),
                "the parent must be in the window for the AFTER measurement"
            );

            let mut old = Vec::new();
            for _ in 0..5 {
                let t = Instant::now();
                let st = engine.replay_to(parent);
                old.push(t.elapsed().as_micros());
                std::hint::black_box(&st);
            }
            let mut new = Vec::new();
            for _ in 0..5 {
                let t = Instant::now();
                let st = engine.state_at_canonical(parent);
                new.push(t.elapsed().as_micros());
                std::hint::black_box(&st);
            }
            println!(
                "reorg base state at height {height}, depth 1: BEFORE (replay from genesis) \
                 median {} us, AFTER (snapshot) median {} us",
                median(old),
                median(new)
            );
        }
    }

    #[test]
    #[ignore]
    fn bench_clone_and_process_epoch() {
        let st = mainnet_sized_state(MAINNET_EUTXOS);
        let tr = Transition::new(ProbeVerifier);
        let mut clones = Vec::new();
        let mut rolls = Vec::new();
        for _ in 0..7 {
            let t = Instant::now();
            let c = st.clone();
            clones.push(t.elapsed().as_micros());
            let t = Instant::now();
            let _ = tr.process_epoch(&c).expect("infallible");
            rolls.push(t.elapsed().as_micros());
        }
        println!(
            "clone over {MAINNET_EUTXOS} eUTXOs: median {} us; process_epoch: median {} us",
            median(clones),
            median(rolls)
        );
    }

    /// **The catch-up regime, measured.** A node `gap` epochs behind the wall
    /// clock re-derives `rolled_to(wall_epoch)` after every applied block,
    /// because applying a block bumps the state generation and empties the
    /// memo. The number that decides whether such a node can catch up is the
    /// cost of that one re-roll — `gap` × `process_epoch` — paid per block,
    /// against a 30 s slot.
    ///
    /// Sized at the Genesis-4 carryover's own output count so the figure is
    /// the fleet's. `cargo test --release -p bloch-pos-node -- --ignored
    /// --nocapture bench_catch_up_roll`.
    ///
    /// MEASURED 2026-08-31 (macOS/x86_64, `--release`, box under load — the
    /// counts are exact, the times are indicative):
    ///
    /// BEFORE the eUTXO map was shared, the primitives on this same state
    /// were clone ≈ 204 ms and `process_epoch` ≈ 369 ms (the clone is inside
    /// it), 65 MB RSS per unshared state — so one re-roll cost the gap times
    /// that, per applied block: gap 4 ≈ 1.7 s, gap 15 ≈ 5.8 s, gap 100
    /// ≈ 37 s (past the 30 s slot), gap 1550 ≈ 9.5 min and ~93 GB transient
    /// — unrunnable on this 16 GB machine, which is the fleet's cold-start
    /// death reproduced as an OOM instead of a stall. Map copies per block
    /// = the gap, by construction.
    ///
    /// AFTER: clone ≈ 0 µs, `process_epoch` ≈ 3 µs, rolled states share the
    /// ledger (~0 MB each). The re-roll per applied block measured gap 1 =
    /// 6 µs, gap 4 = 14 µs, gap 15 = 82 µs, gap 100 = 842 µs, gap 1550 =
    /// 81 ms — and ZERO map copies at every gap. The catch-up bound moves
    /// from `gap × ~0.37 s + t_apply < 30 s` (breaks near gap ≈ 6–10 on
    /// fleet hardware) to `gap × ~50 µs + t_apply < 30 s`, with memory flat
    /// at `MEMO_CAP` ledger-sharing entries instead of `gap × 60 MB`.
    #[test]
    #[ignore]
    fn bench_catch_up_roll() {
        let st = mainnet_sized_state(MAINNET_EUTXOS);
        let tr = Transition::new(ProbeVerifier);
        let head = epoch_of(st.slot());
        for gap in [1u64, 4, 15, 100, 1550] {
            let mut cell = StateCell::new(st.clone());
            let mut samples = Vec::new();
            let copies_before = bloch_pos_committee::transition::eutxo_map_deep_copies();
            // Three "applied blocks": each replaces the state (same content —
            // the cost under measurement is the roll, not the apply) so the
            // generation moves and the memo empties, exactly as `set` does on
            // the live path. The timed call is what the first attestation
            // after each block pays.
            for _ in 0..3 {
                cell.set((*cell.arc()).clone());
                let t = Instant::now();
                let out = cell.rolled_to(head + gap, |s| {
                    tr.process_epoch(s).expect("infallible")
                });
                samples.push(t.elapsed().as_micros());
                std::hint::black_box(&out);
            }
            let copies = bloch_pos_committee::transition::eutxo_map_deep_copies() - copies_before;
            println!(
                "gap {gap:>5} epochs: rolled_to after each of 3 applied blocks = \
                 {samples:?} us (median {} us), eUTXO-map deep copies {copies}",
                median(samples.clone())
            );
        }
    }
}

/// **Win 1's proof.** The memoized rolled state must be the SAME STATE the
/// uncached derivation produces — not merely a state, and not a state that
/// was right a block ago.
///
/// This is the change in this branch that could silently become a consensus
/// change. A rolled state supplies the duty roster and the sortition seed, so
/// serving a stale one makes this node judge attestations against a committee
/// no other node is using: it accepts what peers reject and rejects what peers
/// accept, from an honest binary, with no error anywhere. That is the shape of
/// the `expected_bits` split of 2026-08-08, which is why the key is
/// `(generation, epoch)` and why these tests exist in this form.
///
/// `rolled_to_uncached` is the pre-change body, kept verbatim, so "identical"
/// here means identical to the code that shipped and not to a paraphrase of
/// it. Comparison is by `PartialEq` over the whole `CommittedState` — every
/// field, committed or not — rather than by state root, so a divergence in
/// something the root does not cover still fails.
#[cfg(test)]
mod rolled_memo_tests {
    use super::*;

    /// Across forty proposed slots — which crosses an epoch boundary — and
    /// for four target epochs at each of them, the memoized answer equals the
    /// freshly-derived one.
    ///
    /// The state advances on every iteration, so this is the invalidation
    /// path exercised forty times over: a memo that failed to notice a block
    /// would be serving the previous slot's roster by the second assertion.
    #[test]
    fn the_memo_is_bit_identical_to_the_uncached_derivation() {
        let (mut engine, _dir) = perf_support::proposing_engine();
        let mut crossed = false;
        for slot in 1..=40u64 {
            engine.propose(slot);
            let base = epoch_of(engine.state.slot());
            crossed |= base >= 1;
            for target in base..=base + 3 {
                let memoized = engine.rolled_to(target);
                let fresh = engine.rolled_to_uncached(target);
                assert_eq!(
                    *memoized, fresh,
                    "slot {slot}: the memoized roll to epoch {target} is not the state the \
                     uncached derivation produces"
                );
                // Asked twice, the memo now HAS to answer from itself — and
                // it must answer the same thing.
                assert_eq!(
                    *engine.rolled_to(target),
                    fresh,
                    "slot {slot}: the second, memo-served roll to epoch {target} diverged"
                );
            }
        }
        assert!(
            crossed,
            "the run must actually cross an epoch boundary, or this proves nothing about \
             rolling across one"
        );
        assert_eq!(
            engine.chain.len(),
            41,
            "forty proposed slots must land forty blocks on genesis"
        );
    }

    /// **The signing paths are actually wired to slashing protection.**
    ///
    /// The guard itself is proved in `slashprot.rs` (ordering, restart,
    /// double vote, surround). What that cannot prove is that `propose` and
    /// `attest` *go through it* — a guard nothing calls is the gap this
    /// finding was re-opened for. So this drives the real engine and then
    /// reads the watermark file the way the NEXT BOOT would: a fresh
    /// `SlashingProtection::open` over the same data dir, no shared state
    /// with the engine that wrote it.
    ///
    /// Mutation: take `guard_proposal` (or `guard_attestation`) back out of
    /// the signing path and this fails — the duty still happens, the block is
    /// still signed, and the file the next boot reads knows nothing about it,
    /// which is precisely how a restart double-signs.
    #[test]
    fn every_signature_leaves_a_durable_watermark_the_next_boot_can_read() {
        use bloch_pos_committee::SLOTS_PER_EPOCH;
        let (mut engine, dir) = perf_support::proposing_engine();

        engine.propose(1);
        assert_eq!(engine.chain.len(), 2, "slot 1 must have landed, or nothing was signed");

        // Attest the epoch-1 duty. With one validator the epoch committees
        // partition it into exactly ONE slot (see `epoch_committees`: chunks
        // of `len / SLOTS_PER_EPOCH`), and which slot depends on the seed, so
        // the duty is found rather than assumed.
        let mut attested_at = None;
        for slot in SLOTS_PER_EPOCH..2 * SLOTS_PER_EPOCH {
            let before = engine.pool.len();
            engine.attest(slot);
            if engine.pool.len() > before {
                attested_at = Some(slot);
                break;
            }
        }
        let attested_at = attested_at.expect(
            "this engine is the whole committee, so exactly one slot of epoch 1 is its duty; \
             finding none means the test never exercised the attest path at all",
        );

        // What a restart would load.
        let next_boot = SlashingProtection::open(&dir.0).expect("the next boot reads the file");
        let wm = next_boot.watermarks();
        assert_eq!(
            wm.proposal_slot,
            Some(1),
            "a block was signed for slot 1 but the next boot does not know it — the proposer \
             path is not going through slashing protection"
        );
        assert_eq!(
            wm.attestation_slot,
            Some(attested_at),
            "an attestation was signed for slot {attested_at} but the next boot does not know \
             it — the attester path is not going through slashing protection"
        );
        assert_eq!(wm.target_epoch, Some(1), "the target epoch voted is watermarked too");

        // And that loaded state is a real refusal, not a record: the duties
        // just signed cannot be signed again by the process that comes next.
        let mut next_boot = next_boot;
        let mut signed = false;
        assert!(
            next_boot.guard_proposal(1, || signed = true).is_err(),
            "the next boot would re-propose slot 1"
        );
        assert!(
            next_boot.guard_attestation(attested_at, 0, 1, || signed = true).is_err(),
            "the next boot would re-attest slot {attested_at}"
        );
        assert!(!signed, "a refused duty must never reach a signing closure");
    }

    /// A block moves the state, and the rolled view of the *same* epoch must
    /// move with it.
    ///
    /// The `assert_ne!` is the half that makes this a test: if rolling to a
    /// fixed epoch gave the same answer before and after a block, a memo
    /// keyed on the epoch alone would be correct and there would be nothing
    /// to prove.
    #[test]
    fn a_block_invalidates_the_rolled_view_of_the_same_epoch() {
        let (mut engine, _dir) = perf_support::proposing_engine();
        for slot in 1..=3 {
            engine.propose(slot);
        }
        let target = epoch_of(engine.state.slot()) + 1;

        let before = engine.rolled_to(target).state_root();
        let gen_before = engine.state.generation();

        engine.propose(4);
        assert_eq!(engine.chain.len(), 5, "slot 4 must have landed");
        assert_ne!(
            engine.state.generation(),
            gen_before,
            "an applied block must move the generation, or the key's identity half is inert"
        );

        let after = engine.rolled_to(target);
        assert_ne!(
            before,
            after.state_root(),
            "rolling to epoch {target} must give a different state once a block has landed — \
             if it does not, this test cannot detect a stale memo"
        );
        assert_eq!(
            *after,
            engine.rolled_to_uncached(target),
            "after the state moved, the memo must serve the NEW roll"
        );
    }

    /// The generation half of the key is load-bearing, proved by planting a
    /// wrong answer under it.
    ///
    /// First half: an entry for the right epoch carrying the wrong state, but
    /// tagged with a generation that is not the live one, must be ignored —
    /// this is exactly the entry a naive epoch-only key would have returned.
    ///
    /// Second half is the control, and without it the first proves nothing: a
    /// memo that is never consulted at all would also pass. The identical
    /// entry under the LIVE generation IS returned, so the lookup is real and
    /// what rejected the first entry was the generation.
    #[test]
    fn a_stale_generation_is_never_served_and_a_live_one_is() {
        let (mut engine, _dir) = perf_support::proposing_engine();
        for slot in 1..=3 {
            engine.propose(slot);
        }
        let base = epoch_of(engine.state.slot());
        let target = base + 1;
        let control_target = base + 2;

        let honest = engine.rolled_to_uncached(target);
        // A state that is emphatically not the answer for `target`.
        let poison = engine.rolled_to_uncached(base + 9);
        assert_ne!(
            poison.state_root(),
            honest.state_root(),
            "fixture: the planted state must differ from the honest one"
        );

        let live = engine.state.generation();
        assert!(live > 0, "fixture: blocks must have moved the generation");

        // ── the stale entry ────────────────────────────────────────────────
        engine
            .state
            .plant(live.wrapping_sub(1), target, poison.clone());
        assert_eq!(
            *engine.rolled_to(target),
            honest,
            "a rolled state memoized against a DIFFERENT state was served — this is the \
             wrong-committee bug the key exists to prevent"
        );

        // ── the control ───────────────────────────────────────────────────
        engine.state.plant(live, control_target, poison.clone());
        assert_eq!(
            engine.rolled_to(control_target).state_root(),
            poison.state_root(),
            "an entry under the LIVE generation was not served, so the test above passed \
             because nothing reads the memo rather than because the key rejected the entry"
        );
    }

    /// **The catch-up stall of 2026-08-31, reproduced and pinned shut.** A
    /// node whose head lags the wall clock runs exactly this loop: apply a
    /// block (which moves the generation and empties the memo), then judge
    /// the next gossiped attestation, which calls `rolled_to(wall_epoch)` —
    /// a fresh roll across the entire gap, every block, all the way up.
    ///
    /// Before the eUTXO map was shared, each of those rolls deep-copied the
    /// full ledger once per epoch crossed (`close_epoch` starts with
    /// `self.clone()`), so a block cost `gap` map copies — ~60 MB and tens
    /// of milliseconds each at carryover scale — and eviction ran only after
    /// the roll, so the roll transiently held `gap` whole states. The fleet's
    /// measured break was a 6–10-epoch gap; a cold start (~1,550 epochs)
    /// was unconditionally fatal.
    ///
    /// The claim that ends that regime, as assertions rather than timings:
    /// over the same number of applied blocks, the number of full-map copies
    /// is **the same at a trivial gap and at a deep one — and it is zero** —
    /// and the memo's population never exceeds `MEMO_CAP` even immediately
    /// after a roll much longer than the cap. The bit-identity check against
    /// the uncached derivation is what makes "the roll still happened" a
    /// fact and not an assumption: the rolled state at the far epoch equals
    /// the one derived from scratch, on a funded ledger, so nothing was
    /// skipped to make the counter read zero.
    ///
    /// With the copies gone, catch-up needs `gap × t_process_epoch + t_apply
    /// < slot time` and `MEMO_CAP` small memo entries of memory — not
    /// `gap × t_map_clone` and `gap × 60 MB`.
    #[test]
    fn a_node_far_behind_judges_the_wall_epoch_without_copying_the_ledger() {
        use bloch_pos_committee::transition::eutxo_map_deep_copies;

        // A funded ledger, so "zero copies" is a claim about real entries and
        // not about an empty map.
        let opening: Vec<bloch_pos_committee::state_root::EutxoEntry> = (0..256u32)
            .map(|i| {
                let mut txid = [0u8; 32];
                txid[..4].copy_from_slice(&i.to_le_bytes());
                bloch_pos_committee::state_root::EutxoEntry {
                    txid,
                    vout: 0,
                    value: 1_000 + u64::from(i),
                    script_hash: [7u8; 32],
                }
            })
            .collect();

        // 48 epochs is past the fleet's measured 6–10-epoch break AND well
        // past MEMO_CAP, so the mid-roll eviction actually runs; 3 epochs is
        // the gap the fleet survives. The regime being killed is "copies
        // scale with the gap", so the assertion is equality across the two.
        const BLOCKS: u64 = 10;
        let mut copies_per_gap = Vec::new();
        for gap in [3u64, 48] {
            let (mut engine, _dir) = perf_support::proposing_engine_funded(&opening);
            assert_eq!(
                engine.state.utxos().count(),
                opening.len(),
                "fixture: the opening ledger must actually be in the state"
            );
            let before = eutxo_map_deep_copies();
            let mut wall = 0;
            for slot in 1..=BLOCKS {
                engine.propose(slot);
                wall = epoch_of(engine.state.slot()) + gap;
                let rolled = engine.rolled_to(wall);
                std::hint::black_box(&rolled);
                assert!(
                    engine.state.memo_len() <= StateCell::memo_cap(),
                    "slot {slot}, gap {gap}: the memo held {} entries after the roll — \
                     the in-loop eviction is not bounding it",
                    engine.state.memo_len()
                );
            }
            // The roll is real: its far end is bit-identical to the uncached
            // derivation on this funded ledger.
            assert_eq!(
                *engine.rolled_to(wall),
                engine.rolled_to_uncached(wall),
                "gap {gap}: the rolled state diverged from the from-scratch derivation"
            );
            copies_per_gap.push(eutxo_map_deep_copies() - before);
        }
        assert_eq!(
            copies_per_gap[0], copies_per_gap[1],
            "full-map copies scale with the gap again ({copies_per_gap:?} for gaps [3, 48]) — \
             a node far behind is back to paying the ledger per epoch per block"
        );
        assert_eq!(
            copies_per_gap[1], 0,
            "an epoch roll deep-copied the ledger — close_epoch writes to it, or a clone \
             stopped sharing it"
        );
    }
}

/// **Win 2's proof.** A reorg that starts from a retained snapshot must land
/// on exactly the state and the head that replaying from genesis lands on.
///
/// The retention window is an optimisation with a correct slow path
/// underneath it, and both halves are tested here: that the fast path agrees
/// with the slow one wherever it applies, and that a reorg deeper than the
/// window really does fall through to the slow one rather than quietly
/// serving something else. The `assert_eq!` on the hit/miss is what stops the
/// second claim from being a comment.
#[cfg(test)]
mod reorg_state_tests {
    use super::*;

    /// A chain and a real competing branch, built with the node's own APIs
    /// and nothing else: propose a rival on the fork point, hand it back with
    /// a reorg to an empty branch (a legitimate LMD-GHOST outcome — weight
    /// moved to a sibling and the chain gives blocks back), then outrun it by
    /// `depth` canonical blocks. What is left is a stored, valid block whose
    /// parent sits `depth` below the head.
    pub(super) fn forked(depth: u64) -> (Engine, perf_support::TestDir, [u8; 32], BlockEnvelope) {
        let (mut engine, dir) = perf_support::proposing_engine();
        engine.propose(1);
        let fork_point = *engine.head_id().as_bytes();

        engine.propose(2);
        let rival = engine
            .blocks
            .get(engine.head_id().as_bytes())
            .expect("the rival was just proposed and adopted")
            .clone();
        assert!(
            engine.do_reorg(fork_point, Vec::new()),
            "handing the rival back must succeed"
        );
        assert_eq!(
            *engine.head_id().as_bytes(),
            fork_point,
            "after giving the block back the head is the fork point"
        );

        // Take the rival OUT of the block store while the canonical branch is
        // built.
        //
        // Not tidiness — determinism. `propose` ends in `ingest`, which runs
        // fork choice over every stored block; the rival and the new block are
        // siblings with no attestations, so LMD-GHOST breaks a zero-weight tie
        // by block id, and the id depends on this run's throwaway keystore.
        // Left in, the fixture re-adopts the rival on some runs and the test
        // then compares a state against itself. It was caught by the
        // `assert_ne!` fixture guard below, which is the entire reason that
        // guard is there.
        let rival_id = *rival.block_id().as_bytes();
        engine
            .blocks
            .remove(&rival_id)
            .expect("the rival is stored until this line removes it");

        for slot in 3..3 + depth {
            engine.propose(slot);
        }

        // Back in: the test needs it stored to reorg onto it.
        engine.blocks.insert(rival_id, rival.clone());
        assert!(
            !engine.canonical.contains(&rival_id),
            "the rival must be off the canonical chain when the fixture is handed over"
        );
        assert_eq!(
            engine.chain.len() as u64,
            2 + depth,
            "genesis, the fork point, and {depth} blocks above it"
        );
        (engine, dir, fork_point, rival)
    }

    /// At every canonical depth, in a shuffled order, the snapshot answer and
    /// the replay answer are the same state — and the ring is holding exactly
    /// the depths it claims to.
    #[test]
    fn the_snapshot_and_the_replay_agree_at_every_canonical_depth() {
        let (mut engine, _dir) = perf_support::proposing_engine();
        for slot in 1..=6 {
            engine.propose(slot);
        }
        assert_eq!(engine.chain.len(), 7);

        // A deterministic shuffle, so no depth is only ever visited in the
        // order the ring happens to like.
        let mut order: Vec<usize> = (1..engine.chain.len()).collect();
        let mut seed = 0x9E37_79B9_7F4A_7C15u64;
        for i in (1..order.len()).rev() {
            seed = seed
                .wrapping_mul(6_364_136_223_846_793_005)
                .wrapping_add(1_442_695_040_888_963_407);
            let j = (seed >> 33) as usize % (i + 1);
            order.swap(i, j);
        }

        for idx in order {
            let id = *engine.chain[idx].1.as_bytes();
            let depth = engine.chain.len() - 1 - idx;
            let retained = engine.recent_states.iter().any(|(bid, _)| *bid == id);
            assert_eq!(
                retained,
                depth < REORG_STATE_WINDOW,
                "depth {depth}: the ring must retain exactly the last \
                 {REORG_STATE_WINDOW} blocks — if it retained more, the deep \
                 cases below would never exercise the replay fallback"
            );
            assert_eq!(
                *engine.state_at_canonical(id),
                engine.replay_to(id),
                "depth {depth}: the snapshot and the replay-from-genesis \
                 disagree about the same block's post-state"
            );
        }
    }

    /// A real reorg at depths on both sides of the retention window lands on
    /// the state and head the pre-change path lands on.
    ///
    /// `expected` is computed with `replay_to` plus `apply_block` over the
    /// branch, which IS the body `do_reorg` had before this change — so this
    /// compares against the old code, not against a paraphrase of it.
    #[test]
    fn a_reorg_lands_where_replay_from_genesis_lands() {
        let mut saw_hit = false;
        let mut saw_fallback = false;
        for depth in 1..=5u64 {
            let (mut engine, _dir, fork_point, rival) = forked(depth);

            let expected = {
                let base = engine.replay_to(fork_point);
                let envelope = ProposalEnvelope {
                    header: rival.header.clone(),
                    proposer_sig: rival.proposer_sig.clone(),
                };
                let txs = body_transactions(&rival).expect("the rival's body decodes");
                engine
                    .tr
                    .apply_block(&base, &envelope, &rival.body.attestations, &txs)
                    .expect("the rival is valid on its own parent")
            };
            assert_ne!(
                *engine.state, expected,
                "depth {depth}: fixture — the reorg must actually move the state, or this \
                 test would pass without the reorg happening at all"
            );

            let hit = engine
                .recent_states
                .iter()
                .any(|(id, _)| *id == fork_point);
            if hit {
                saw_hit = true;
            } else {
                saw_fallback = true;
            }
            assert_eq!(
                hit,
                depth < REORG_STATE_WINDOW as u64,
                "depth {depth}: the fork point should be retained iff it is inside the window"
            );

            assert!(
                engine.do_reorg(fork_point, vec![rival.clone()]),
                "depth {depth}: the reorg must be adopted"
            );
            assert_eq!(
                *engine.state, expected,
                "depth {depth}: the reorg landed on a DIFFERENT state than replaying from \
                 genesis would have — this is a consensus divergence, not a slow path"
            );
            assert_eq!(
                engine.head_id(),
                rival.block_id(),
                "depth {depth}: the head must be the adopted branch tip"
            );
            assert_eq!(
                engine.chain.len(),
                3,
                "depth {depth}: genesis, the fork point, the rival"
            );
            // The ring must now describe the branch that WON. A ring still
            // holding the abandoned branch would make the next reorg start
            // from a state on a chain this node no longer has.
            for (id, st) in engine.recent_states.iter() {
                assert_eq!(
                    **st,
                    engine.replay_to(*id),
                    "depth {depth}: the ring kept a post-state that is not this block's"
                );
                assert!(
                    engine.canonical.contains(id),
                    "depth {depth}: the ring kept a block that is not canonical"
                );
            }
        }
        assert!(
            saw_hit && saw_fallback,
            "the sweep must exercise BOTH the retained snapshot and the replay fallback \
             (hit: {saw_hit}, fallback: {saw_fallback})"
        );
    }
}

/// **The invariant `getchaininfo` is about to rest on.**
///
/// `chain_info_json` used to recompute the committed state root on the
/// consensus thread for every caller — MEASURED at 32.6 ms cold / 3.0 ms warm
/// at Genesis-4's size, see [`Engine::head_state_root`], which also records
/// why that is not the 733 ms the 2026-08-21 n21 incident was reported at.
///
/// The head block's HEADER already carries that root. `apply_block` returns
/// `Ok(post)` on exactly one condition — `post.compute_root() ==
/// header.state_root` (transition.rs step 12) — so for any head this node
/// adopted, the header field and `state.state_root()` are the same 32 bytes.
/// `apply_canonical`'s log line and `do_reorg`'s already lean on that.
///
/// What that argument does NOT cover by inspection is whether `self.state` is
/// always the *head's* post-state: a reorg replaces both, and a boot has a
/// head with no header at all. Those are the paths that would make the RPC
/// lie silently rather than loudly, and `getchaininfo` is what integrators and
/// exchanges read. So they are pinned here, against the real block path —
/// `propose`/`ingest`/`do_reorg`, the production transition, the production
/// ML-DSA-65 ‖ Falcon-1024 verifier — rather than argued.
#[cfg(test)]
mod head_root_tests {
    use super::*;

    /// The equality, at whatever the engine's head is right now.
    ///
    /// Returns the header root so a caller can also pin that it MOVED, which
    /// is what stops "the roots agree" from passing on a chain that never
    /// advanced.
    fn assert_invariant(engine: &Engine, ctx: &str) -> [u8; 32] {
        let head = engine.head_id();
        let env = engine
            .blocks
            .get(head.as_bytes())
            .unwrap_or_else(|| panic!("{ctx}: the head must be a stored block here"));
        let computed = engine.state.state_root();
        assert_eq!(
            env.header.state_root, computed,
            "{ctx}: the head header's committed root and the engine's live state root \
             disagree at slot {} — `getchaininfo` reading the header would publish a \
             root that is not this node's state",
            env.header.slot
        );
        // And the accessor `getchaininfo` actually calls, so this pins the
        // shipped code path and not just the property it rests on.
        assert_eq!(
            engine.head_state_root(),
            computed,
            "{ctx}: `head_state_root` disagrees with the recomputed root"
        );
        computed
    }

    /// Ordinary blocks AND an epoch boundary, on the real proposal path.
    ///
    /// The slots are sparse on purpose. `propose` takes the slot as an
    /// argument and this fixture's single validator is the proposer at every
    /// one of them, so 31 → 32 crosses from epoch 0 into epoch 1 (and 63 → 64
    /// into epoch 2) for the price of two blocks instead of thirty. The
    /// boundary is where `apply_block` rolls epoch accounting into the
    /// post-state, so it is the step most likely to move the state out from
    /// under a header — which is why it is here and not left to a comment.
    #[test]
    fn the_head_header_root_is_the_committed_state_root_across_an_epoch_boundary() {
        let (mut engine, _dir) = perf_support::proposing_engine();

        let slots = [1u64, 2, 3, 30, 31, 32, 33, 63, 64, 65];
        let mut seen_epochs = BTreeSet::new();
        let mut roots = BTreeSet::new();
        let mut applied = 0usize;

        for slot in slots {
            let before = engine.chain.len();
            engine.propose(slot);
            assert_eq!(
                engine.chain.len(),
                before + 1,
                "fixture: slot {slot} did not extend the chain, so nothing was checked there"
            );
            applied += 1;
            let root = assert_invariant(&engine, &format!("after proposing slot {slot}"));
            // Read off the ENGINE's committed state, not off the slot this
            // loop asked for — otherwise the epoch-coverage assertion below
            // would only be restating the literal array above.
            seen_epochs.insert(epoch_of(engine.state.slot()));
            roots.insert(root);
        }

        assert_eq!(applied, slots.len(), "fixture: every slot must have applied");
        assert!(
            seen_epochs.len() >= 3,
            "fixture: the sweep must cross at least two epoch boundaries, saw epochs {seen_epochs:?}"
        );
        assert!(
            roots.len() > 1,
            "fixture: the state root never moved across {applied} blocks — the equality \
             above would then be one constant compared with itself"
        );
    }

    /// A REORG, at depths on both sides of the snapshot retention window.
    ///
    /// `reorg_state_tests::forked` builds a real competing branch with the
    /// node's own APIs; `do_reorg` adopts it through the production
    /// `apply_block`. The reorg is proved to have actually happened rather
    /// than no-opped four ways: the head id must change to the rival's, the
    /// pre-reorg head must leave the canonical set, `chain.len()` must
    /// collapse from `2 + depth` to 3, and the whole `CommittedState` must
    /// compare unequal across the call.
    ///
    /// **The state, not the state ROOT — and that distinction is a real
    /// property of Genesis-4, found here.** `ConsensusState` (state_root.rs
    /// §5.5, the closed list `compute_root` builds the tree from) carries no
    /// head block id and no slot; the finest time it commits is the epoch,
    /// through the RANDAO window. So two SIBLING blocks in one epoch with
    /// empty bodies commit the SAME 32 bytes, and this sweep hits that at
    /// depth 1: head slot 3 -> 2 with the root unmoved at both ends. The
    /// invariant still held there — it is the root that is coarse, not the
    /// engine that is wrong. Anyone reading `getchaininfo` should note that
    /// `state_root` does NOT identify the head; `block_id`, in the same
    /// object, does.
    #[test]
    fn a_reorg_leaves_the_head_header_root_equal_to_the_committed_state_root() {
        let mut saw_snapshot_hit = false;
        let mut saw_replay_fallback = false;

        for depth in 1..=5u64 {
            let (mut engine, _dir, fork_point, rival) = reorg_state_tests::forked(depth);
            let ctx = format!("depth {depth}");

            let before_head = engine.head_id();
            let before_state = (*engine.state).clone();
            assert_invariant(&engine, &format!("{ctx}: before the reorg"));

            if engine
                .recent_states
                .iter()
                .any(|(id, _)| *id == fork_point)
            {
                saw_snapshot_hit = true;
            } else {
                saw_replay_fallback = true;
            }

            assert!(
                engine.do_reorg(fork_point, vec![rival.clone()]),
                "{ctx}: the reorg must be adopted"
            );

            // It really reorged, not no-opped.
            assert_eq!(
                engine.head_id(),
                rival.block_id(),
                "{ctx}: the head must be the adopted branch tip"
            );
            assert_ne!(
                engine.head_id(),
                before_head,
                "{ctx}: the head did not move, so no reorg was exercised"
            );
            assert_eq!(
                engine.chain.len(),
                3,
                "{ctx}: genesis, the fork point, the rival — the canonical chain must have \
                 been truncated, not extended"
            );

            assert!(
                !engine.canonical.contains(before_head.as_bytes()),
                "{ctx}: the pre-reorg head is still canonical, so nothing was given back"
            );
            assert_ne!(
                *engine.state, before_state,
                "{ctx}: the committed state did not change across the reorg — the check \
                 after it would then be the same comparison as the one before"
            );

            assert_invariant(&engine, &format!("{ctx}: after the reorg"));
        }

        assert!(
            saw_snapshot_hit && saw_replay_fallback,
            "the sweep must exercise BOTH the retained-snapshot reorg and the \
             replay-from-genesis fallback (hit: {saw_snapshot_hit}, fallback: \
             {saw_replay_fallback})"
        );
    }

    /// The empty branch: LMD-GHOST moved weight to a sibling and the chain
    /// gives a block BACK. The new head is then a block this node already had
    /// — a different write path into `state` (`set_arc` from the snapshot
    /// ring, not `set` from a fresh `apply_block`) and the one place a stale
    /// header could survive an unchanged block store.
    #[test]
    fn giving_a_block_back_leaves_the_head_header_root_equal_to_the_committed_state_root() {
        let (mut engine, _dir) = perf_support::proposing_engine();
        engine.propose(1);
        let fork_point = *engine.head_id().as_bytes();
        let at_fork = assert_invariant(&engine, "at the fork point");

        engine.propose(2);
        let ahead = assert_invariant(&engine, "one block above the fork point");
        assert_ne!(at_fork, ahead, "fixture: the second block must move the root");

        assert!(
            engine.do_reorg(fork_point, Vec::new()),
            "handing the block back must succeed"
        );
        assert_eq!(
            *engine.head_id().as_bytes(),
            fork_point,
            "the head is the fork point again"
        );

        let back = assert_invariant(&engine, "after giving the block back");
        assert_eq!(
            back, at_fork,
            "giving a block back must restore the state that block's parent committed"
        );
    }

    /// **Genesis, the one head with no header to read.**
    ///
    /// `ingest` returns early on slot 0 — "genesis is synthesized, never
    /// received" — so at boot the head is canonical, is the state's own head,
    /// and is NOT in `blocks`. A lookup there returns `None`, and letting that
    /// fall into `unwrap_or_default()` would publish 32 zero bytes as if it
    /// were an answer. This pins that the situation is real, so the fallback
    /// in `head_state_root` is not dead code guarding an impossible case.
    #[test]
    fn at_boot_the_head_is_genesis_and_genesis_has_no_stored_header() {
        let (engine, _dir) = perf_support::proposing_engine();
        assert!(
            engine.blocks.is_empty(),
            "a fresh engine has no stored blocks"
        );
        assert_eq!(engine.chain.len(), 1, "the chain is genesis alone");
        assert!(
            engine.blocks.get(engine.head_id().as_bytes()).is_none(),
            "genesis is synthesized and is never in `blocks` — the header lookup MUST \
             miss here, and the fallback below is what answers"
        );

        // The fallback answers with the value the RPC returned before the
        // change, which is what makes this transport-only rather than a new
        // behaviour at boot. Both halves matter: it must equal the computed
        // root, and it must NOT be the all-zero root `unwrap_or_default()`
        // would have produced.
        assert_eq!(
            engine.head_state_root(),
            engine.state.state_root(),
            "at genesis the fallback must return the computed root — the same bytes \
             `getchaininfo` returned here before"
        );
        assert_ne!(
            engine.head_state_root(),
            [0u8; 32],
            "the genesis answer must not be the default-initialised root"
        );
    }
}

/// **The anchor defect, on one fixture.**
///
/// The consensus AUTHORITY for the seed is
/// [`CommittedState::seed_for_epoch`], evaluated by `apply_block` on the state
/// the block is applied against — its parent's, because step 2 refuses any
/// other (`WrongParent`). That is ancestry, and two nodes applying the same
/// block to the same parent cannot disagree about it.
///
/// The node's DUTY view evaluates the same function on `rolled_to(epoch)`,
/// which is this node's OWN head rolled forward. When the head is not the
/// judged block's parent — a node three blocks behind, a node whose head sits
/// on a sibling branch — the duty view and the authority part company, and the
/// node rejects honest votes as `NotInCommittee` while every rule it is
/// applying is the right rule.
///
/// The fixture below moves ONLY the head, on ONE branch, with no fork and no
/// disagreement about any block, and shows the seed and the partition move
/// with it. That is the whole defect: the anchor, not the expression.
///
/// It needs no flag day to fix — the target value is the one consensus already
/// defines — which is why it is deliberately NOT bundled with the look-ahead
/// gate this branch also carries.
#[cfg(test)]
mod duty_view_anchor {
    use super::*;
    use crate::genesis::ManifestValidator;
    use bloch_pos_committee::SLOTS_PER_EPOCH;
    use bloch_pos_committee::beacon::RandaoChain;

    const SAT_PER_BLOCH: u128 = 100_000_000;

    struct Dir(PathBuf);
    impl Drop for Dir {
        fn drop(&mut self) {
            let _ = std::fs::remove_dir_all(&self.0);
        }
    }

    /// A devnet engine whose REGISTRY holds `n` validators while this node
    /// holds the key for index 0 only.
    ///
    /// `perf_support::proposing_engine` registers one validator, and one
    /// validator is not enough for this test: `epoch_committees` partitions
    /// the roster, and the only permutation of a one-element roster is the
    /// identity, so its partition is the same for every seed. The first
    /// version of this test asserted the partition moved, and its own fixture
    /// guard failed — which is the guard doing its job rather than a
    /// comparator that quietly proves nothing.
    ///
    /// The other `n - 1` validators never sign: they exist to give the
    /// partition something to permute. Production is therefore sparse — node 0
    /// proposes only in the slots it is drawn for — which is what a real
    /// validator's view looks like anyway.
    fn engine_with_registry(n: u32) -> (Engine, Dir) {
        static DIR_SEQ: AtomicU64 = AtomicU64::new(0);
        let dir = Dir(std::env::temp_dir().join(format!(
            "bloch-anchor-{}-{}",
            std::process::id(),
            DIR_SEQ.fetch_add(1, Ordering::Relaxed)
        )));
        let _ = std::fs::remove_dir_all(&dir.0);
        std::fs::create_dir_all(&dir.0).expect("create the test data dir");

        let keys: Vec<Keystore> = (0..n)
            .map(|i| {
                // Disposable devnet keys, plaintext by explicit opt-in — see
                // the note in the single-validator harness above.
                Keystore::generate_with(
                    &dir.0.join(format!("v{i}")),
                    i,
                    &crate::keys::Unlock::PlaintextOptIn,
                )
                .expect("generate a devnet keystore")
            })
            .collect();
        let manifest = Manifest {
            genesis_time_ms: now_ms(),
            slot_ms: 1_000,
            validators: keys
                .iter()
                .map(|ks| ManifestValidator {
                    index: ks.index,
                    stake_sat: 200_000 * SAT_PER_BLOCH,
                    randao_commitment: RandaoChain::generate(ks.randao_seed).commitment(),
                    pubkey: ks.pubkey.clone(),
                    withdrawal_credentials: Vec::new(),
                    commission_bps: 0,
                })
                .collect(),
            cohort: Vec::new(),
            carryover: None,
            allocations: Vec::new(),
            carryover_entries: Vec::new(),
            format: crate::genesis::ManifestFormat::V1Unbound,
            pre_state_root: std::sync::OnceLock::new(),
        };
        let genesis_id = manifest.genesis_id();
        let state = manifest.genesis_state();
        let store = Store::open(&dir.0, &[0u8; 32]).expect("open the test store");
        let (events, _rx) = mpsc::channel::<EngineEvent>();
        let head_slot = Arc::new(AtomicU64::new(0));
        let inflight = net::QueueBudget::new();
        let net = net::Net::Devnet(
            net::start(
                "127.0.0.1",
                0,
                Vec::new(),
                events,
                dir.0.clone(),
                head_slot.clone(),
                inflight,
            )
            .expect("bind the devnet transport on an ephemeral port"),
        );
        let verifier = HybridVerifier::new();
        let ks0 = Keystore::load_with(&dir.0.join("v0"), &crate::keys::Unlock::PlaintextOptIn)
            .expect("re-load validator 0");
        let engine = Engine {
            genesis_validator_count: manifest.validators.len() as u32,
            manifest,
            state: StateCell::new(state),
            tr: Transition::new(verifier.clone()),
            tr_probe: Transition::new(ProbeVerifier),
            verifier,
            keys: Some(ks0),
            blocks: BTreeMap::new(),
            observed_proposals: BTreeMap::new(),
            chain: vec![(0, genesis_id)],
            canonical: BTreeSet::from([*genesis_id.as_bytes()]),
            recent_states: VecDeque::new(),
            pool: BTreeMap::new(),
            att_pool: AttestationPool::new(),
            wall_slot: 0,
            mempool: BTreeMap::new(),
            mempool_admitted_at: BTreeMap::new(),
            mempool_expired: 0,
            mempool_evicted_low_fee: 0,
            rejected: BTreeMap::new(),
        rejected_hits: 0,
        mempool_suspect: BTreeSet::new(),
        mempool_swept_epoch: u64::MAX,
            store,
            slashprot: SlashingProtection::open(&dir.0).expect("open slashing protection"),
            net,
            head_slot,
            live: true,
            needs_sync: false,
            orphans: VecDeque::new(),
            orphans_evicted: 0,
            orphans_admitted: 0,
            blocks_pruned: 0,
            rejected_unsigned: 0,
            rejected_future: 0,
            last_applied_ms: now_ms(),
            booted_ms: now_ms(),
            ws_anchor: None,
            ws_anchor_hard: false,
            ws_conflict_reported: false,
            fc_covered_removals: 0,
            finalized_latch: None,
            finality_rewinds_refused: 0,
            parked_refused_finality: VecDeque::new(),
            finality_rewind_override: false,
            tx_slot_index: BTreeMap::new(),
            tx_slot_index_order: VecDeque::new(),
            doppelganger_observe_until: None,
            doppelganger_halted: false,
        };
        (engine, dir)
    }

    #[test]
    fn giving_three_blocks_back_moves_the_duty_view_seed_and_the_partition() {
        let (mut engine, _dir) = engine_with_registry(8);
        // Sparse production: this node proposes only in the slots it is drawn
        // for, so the loop runs until the HEAD is in epoch 2 rather than for a
        // fixed block count.
        for slot in 1..=(SLOTS_PER_EPOCH * 3) {
            engine.propose(slot);
        }
        let head_epoch = epoch_of(engine.state.slot());
        assert!(
            head_epoch >= 2,
            "the head only reached epoch {head_epoch}; the fixture needs epoch 2"
        );
        assert!(
            engine.chain.len() >= 5,
            "only {} blocks were produced — too few to give three back",
            engine.chain.len() - 1
        );

        let e = head_epoch + 1;
        let rolled = engine.rolled_to(e);
        let seed_caught_up = Engine::seed_for(&rolled, e);
        let partition_caught_up =
            committees::epoch_committees(&seed_caught_up, e, &rolled.active_validators());

        // Give three blocks back. Same branch, same rules, same everything —
        // three blocks less of it. This is what "a node that is behind" is.
        let ancestor = *engine.chain[engine.chain.len() - 4].1.as_bytes();
        let before = engine.chain.len();
        assert!(
            engine.do_reorg(ancestor, Vec::new()),
            "handing three blocks back on the node's own branch must succeed"
        );
        assert_eq!(engine.chain.len(), before - 3);

        let rolled_behind = engine.rolled_to(e);
        let seed_behind = Engine::seed_for(&rolled_behind, e);
        let partition_behind =
            committees::epoch_committees(&seed_behind, e, &rolled_behind.active_validators());

        assert_ne!(
            seed_caught_up, seed_behind,
            "THE DEFECT: the duty-view seed for epoch {e} changed because this node's HEAD \
             moved, on a branch nobody disputes"
        );
        assert_ne!(
            partition_caught_up, partition_behind,
            "the seed moved but the partition did not — widen the fixture, because as \
             written this test would not notice the bug it exists to show"
        );

        // The number that matters for the flood: how many of the epoch's 32
        // committees changed membership because this node's head moved.
        let moved = partition_caught_up
            .iter()
            .zip(partition_behind.iter())
            .filter(|(a, b)| a != b)
            .count();
        println!(
            "duty-view anchor: giving 3 blocks back changed {moved} of {} slot committees \
             in epoch {e}, on one undisputed branch",
            partition_caught_up.len()
        );
        assert!(moved > 0);
    }

    /// **The `NotInCommittee` flood, in one assertion.**
    ///
    /// Two functions in this file decide committee membership for the same
    /// attestation, and they must agree or every honest vote on the network is
    /// answered with a Reject:
    ///
    ///   * [`Engine::attest`] draws with [`Engine::seed_for`], which is
    ///     `CommittedState::seed_for_epoch` — GATED, so below
    ///     `ANCESTRY_SEED_ACTIVATION_EPOCH` it is the mix at the close of
    ///     `E − 1`.
    ///   * [`Engine::judge`] draws with [`Engine::seed_for_attestation`],
    ///     anchored to the attestation's own branch.
    ///
    /// Until 2026-08-25 the second applied
    /// `committees::MIN_SEED_LOOKAHEAD_EPOCHS` UNCONDITIONALLY while the first
    /// was gated, so the two read boundaries one apart for every epoch below
    /// the flag day — which is every epoch this chain has ever had. With 64
    /// validators over 32 slots the committees are pairs, and two independent
    /// permutations agree on a given validator's slot about 3% of the time. So
    /// ~97% of honest attestations were Rejected as `NotInCommittee` by every
    /// receiver, blocks carried almost no votes, and finality froze while the
    /// chain looked healthy — one branch, a block every 30 s, 63 peers.
    /// Measured on mainnet 2026-08-25: 156 of the last 156 rejections were
    /// `NotInCommittee`, and 19 consecutive blocks carried 4 attestations
    /// against the ~38 the roster predicts.
    ///
    /// This is a REGRESSION test, not an aspiration: run it against the fleet
    /// binary (`98d8fb06`) and the `assert_eq!` on the seeds fails.
    #[test]
    fn the_attester_and_the_judge_draw_the_same_committee_below_the_flag_day() {
        assert_eq!(
            bloch_pos_committee::params::ANCESTRY_SEED_ACTIVATION_EPOCH,
            u64::MAX,
            "this test describes the PRE-flag-day regime; if the gate has been armed, the              agreement it pins has to be re-derived rather than assumed"
        );

        let (mut engine, _dir) = engine_with_registry(8);
        for slot in 1..=(SLOTS_PER_EPOCH * 3) {
            engine.propose(slot);
        }
        let head_epoch = epoch_of(engine.state.slot());
        assert!(
            head_epoch >= 2,
            "the head only reached epoch {head_epoch}; the fixture needs epoch 2"
        );

        let e = head_epoch;
        let rolled = engine.rolled_to(e);
        let roster = rolled.active_validators();

        // What `attest` signs under.
        let attester_seed = Engine::seed_for(&rolled, e);
        // What `judge` checks it against: anchored on the very `target_root`
        // `attest` stamps into the attestation.
        let target = engine.checkpoint_root(e);
        let judge_seed = engine
            .seed_for_attestation(&target, e)
            .expect("the checkpoint of this node's own epoch is on its own branch");

        assert_eq!(
            attester_seed, judge_seed,
            "THE FLOOD: the seed a validator attests under and the seed its peers judge it              against are different boundaries, so honest votes read as NotInCommittee"
        );

        // And the consequence spelled out, so a future refactor that keeps the
        // seeds equal but changes the draw is still caught.
        for slot in e * SLOTS_PER_EPOCH..(e + 1) * SLOTS_PER_EPOCH {
            assert_eq!(
                committees::committee_for_slot(&attester_seed, slot, &roster),
                committees::committee_for_slot(&judge_seed, slot, &roster),
                "slot {slot}: attester and judge disagree on who is in the committee"
            );
        }
    }
}

/// The node half of the untrusted-`header.slot` bound (finding C1-slot-bound),
/// and the deferred block verdict that goes with it.
///
/// Two rules live here and they are deliberately different in kind. The
/// horizon is LOCAL — a node may hold it or not without forking, because a
/// block it refuses is simply one it did not store. The ceiling in
/// `params::MAX_EPOCH_ADVANCE` is CONSENSUS, and is the backstop for every
/// path that does not come through this door. This module pins the local one.
#[cfg(test)]
mod slot_horizon {
    use super::*;
    use bloch_pos_committee::state_root::EvmCommitment;

    /// A real `Engine` whose slot-0 origin is `back_slots` slots in the past,
    /// so `wall_slot()` is a number the test chose rather than whatever the
    /// clock happens to say. Observer mode, empty state, devnet transport on
    /// an ephemeral port with no peers — everything except `ingest_judged` is
    /// scenery.
    pub(super) fn engine_at_wall_slot(back_slots: u64) -> Engine {
        let slot_ms = 1_000u64;
        let manifest = Manifest {
            genesis_time_ms: now_ms().saturating_sub(back_slots.saturating_mul(slot_ms)),
            slot_ms,
            validators: Vec::new(),
            cohort: Vec::new(),
            carryover: None,
            allocations: Vec::new(),
            carryover_entries: Vec::new(),
            // v1: this harness is about the slot horizon, and the frozen
            // genesis identity keeps `GENESIS_MIX` below the right constant.
            format: crate::genesis::ManifestFormat::V1Unbound,
            pre_state_root: std::sync::OnceLock::new(),
        };
        let genesis_id = manifest.genesis_id();
        let state = CommittedState::genesis(
            genesis_id,
            GENESIS_MIX,
            &[],
            &[],
            [0u8; 32],
            [0u8; 32],
            [0u8; 32],
            EvmCommitment {
                account_root: [0u8; 32],
                receipts_root: [0u8; 32],
                gas_used: 0,
                base_fee_per_gas: 0,
            },
            &[],
        );
        static DIR_SEQ: AtomicU64 = AtomicU64::new(0);
        let dir = std::env::temp_dir().join(format!(
            "bloch-pos-slot-horizon-{}-{}",
            std::process::id(),
            DIR_SEQ.fetch_add(1, Ordering::Relaxed),
        ));
        std::fs::create_dir_all(&dir).expect("create the test data dir");
        let store = Store::open(&dir, &[0u8; 32]).expect("open the test store");
        let (events, _rx) = mpsc::channel::<EngineEvent>();
        let head_slot = Arc::new(AtomicU64::new(0));
        let inflight = net::QueueBudget::new();
        let net = net::Net::Devnet(
            net::start("127.0.0.1", 0, Vec::new(), events, dir.clone(), head_slot.clone(), inflight)
                .expect("bind the devnet transport on an ephemeral port"),
        );
        let verifier = HybridVerifier::new();
        Engine {
            genesis_validator_count: manifest.validators.len() as u32,
            manifest,
            state: StateCell::new(state),
            tr: Transition::new(verifier.clone()),
            tr_probe: Transition::new(ProbeVerifier),
            verifier,
            keys: None,
            blocks: BTreeMap::new(),
            observed_proposals: BTreeMap::new(),
            chain: vec![(0, genesis_id)],
            canonical: BTreeSet::from([*genesis_id.as_bytes()]),
            recent_states: VecDeque::new(),
            pool: BTreeMap::new(),
            att_pool: AttestationPool::new(),
            wall_slot: 0,
            mempool: BTreeMap::new(),
            mempool_admitted_at: BTreeMap::new(),
            mempool_expired: 0,
            mempool_evicted_low_fee: 0,
            rejected: BTreeMap::new(),
            rejected_hits: 0,
            mempool_suspect: BTreeSet::new(),
            mempool_swept_epoch: u64::MAX,
            store,
            net,
            head_slot,
            live: true,
            needs_sync: false,
            last_applied_ms: now_ms(),
            booted_ms: now_ms(),
            ws_anchor: None,
            ws_anchor_hard: false,
            ws_conflict_reported: false,
            fc_covered_removals: 0,
            finalized_latch: None,
            finality_rewinds_refused: 0,
            parked_refused_finality: VecDeque::new(),
            finality_rewind_override: false,
            tx_slot_index: BTreeMap::new(),
            tx_slot_index_order: VecDeque::new(),
            doppelganger_observe_until: None,
            doppelganger_halted: false,
            orphans: VecDeque::new(),
            orphans_evicted: 0,
            orphans_admitted: 0,
            blocks_pruned: 0,
            rejected_unsigned: 0,
            rejected_future: 0,
            slashprot: SlashingProtection::open(&dir).expect("open slashing protection"),
        }
    }

    /// An envelope that clears every check `ingest_judged` runs BEFORE the
    /// horizon — the body/attestation commitments and the tx decode — so the
    /// horizon is the only thing left that can refuse it. It names a parent
    /// this node does not have, which is on purpose: a block that fails the
    /// horizon must never be stored, and one that passes it must be stored
    /// even though it cannot be applied. That separates "did the door let it
    /// in" from "did the chain adopt it", which are different questions.
    fn envelope_at_slot(slot: u64) -> BlockEnvelope {
        BlockEnvelope {
            header: BlockHeaderV4 {
                version: VERSION_G4,
                parent: [1; 32],
                state_root: [2; 32],
                body_root: derive::body_root(&[]),
                slot,
                proposer_index: 0,
                randao_reveal: [4; 32],
                randao_mix: [5; 32],
                justified_root: [6; 32],
                finalized_root: [7; 32],
                attestation_root: derive::attestation_root(&[]),
                coherence_root: [9; 32],
            },
            proposer_sig: vec![0u8; 96],
            body: Body { transactions: Vec::new(), attestations: Vec::new() },
        }
    }

    /// **The finding.** One gossiped header carrying `u64::MAX` used to be
    /// stored and handed to the transition, whose boundary walk is linear in
    /// `epoch_of(header.slot)`. Nothing about that header was signed by anyone
    /// this node had checked. It must be refused at the door, before the
    /// insert, and the peer that forwarded it must be charged for it.
    ///
    /// Remove the horizon check from `ingest_judged` and this fails on the
    /// verdict AND on the store — two independent assertions of the same
    /// defect, so a partial fix cannot make it green.
    #[test]
    fn a_block_from_the_far_future_is_refused_before_it_is_stored() {
        let mut e = engine_at_wall_slot(10);
        let env = envelope_at_slot(u64::MAX);
        let id = *env.block_id().as_bytes();

        assert_eq!(
            e.ingest_judged(env),
            Verdict::Reject,
            "a slot no clock can justify is provable, and Reject is what charges the peer",
        );
        assert!(
            !e.blocks.contains_key(&id),
            "a block past the horizon must never reach `blocks` — storing it is what puts \
             `epoch_of(u64::MAX)` in front of the transition",
        );
    }

    /// The control, and the half that makes the test above mean something: a
    /// block INSIDE both clock rules is not refused BY them — it reaches the
    /// gates that come after. Without this, `ingest_judged` returning `Reject`
    /// unconditionally would pass.
    ///
    /// The witness is the ORPHAN POOL, and it is the right one precisely
    /// because parking happens strictly behind both clock rules AND behind
    /// H8's proposer-authentication gate. This fixture's envelope names a
    /// proposer index the fixture state never registered, so an envelope that
    /// reaches `orphans` is one that BOTH the horizon and the tolerance let
    /// through. `rejected_future == 0` says the same thing from the other
    /// side, and `blocks` staying empty says H8's rule is still in force.
    #[test]
    fn a_block_inside_the_horizon_reaches_the_gates_behind_it() {
        let mut e = engine_at_wall_slot(10);
        let wall = e.wall_slot();
        // Inside the horizon (64) AND inside the tolerance (8): the clock has
        // no answer for this block, so a later rule must be the one that does.
        let env = envelope_at_slot(wall + FUTURE_SLOT_TOLERANCE);
        let id = *env.block_id().as_bytes();

        let verdict = e.ingest_judged(env);
        assert_eq!(
            e.rejected_future, 0,
            "a block inside the tolerance must not be charged to the clock",
        );
        assert_eq!(
            e.orphans.len(),
            1,
            "it must have reached the gates behind the clock — that is what proves neither slot rule turned it away",
        );
        assert_eq!(
            verdict,
            Verdict::Ignore,
            "held under an identity this node cannot check is no charge against the peer that relayed it",
        );
        assert!(
            !e.blocks.contains_key(&id),
            "and an unauthenticated block still never reaches `blocks` (H8)",
        );
    }

    /// The horizon is measured against the wall clock, not against the head.
    /// A node whose chain is thousands of slots behind — every node on this
    /// fleet, routinely — must keep judging current blocks on their merits,
    /// or the rule would quietly stop such a node from ever catching up.
    #[test]
    fn a_node_far_behind_its_own_chain_still_judges_current_blocks_on_merit() {
        let mut e = engine_at_wall_slot(50_000);
        let wall = e.wall_slot();
        assert!(wall > 40_000, "fixture must actually be far along; wall = {wall}");
        let env = envelope_at_slot(wall);
        let id = *env.block_id().as_bytes();
        let verdict = e.ingest_judged(env);
        assert_eq!(e.rejected_future, 0, "a current block is never past any clock rule");
        assert_eq!(
            e.orphans.len(),
            1,
            "however far behind the chain is, a current block still gets past both slot rules to the gates behind them",
        );
        assert_eq!(verdict, Verdict::Ignore);
        assert!(!e.blocks.contains_key(&id));
    }

    /// **The horizon is not shadowed by the tighter tolerance.**
    ///
    /// `FUTURE_SLOT_TOLERANCE` (8 slots) is stricter than `MAX_FUTURE_SLOTS`
    /// (64) and would answer first — but only while the node is `live`. During
    /// boot and sync it is skipped entirely, and this horizon is then the only
    /// thing standing between a gossiped `u64::MAX` and `epoch_of` walking it.
    ///
    /// Delete the horizon check and this fails: the envelope lands in the
    /// orphan pool instead of being turned away.
    #[test]
    fn the_horizon_still_bounds_a_gossiped_slot_while_the_node_is_not_live() {
        let mut e = engine_at_wall_slot(10);
        e.live = false;
        let env = envelope_at_slot(u64::MAX);
        let id = *env.block_id().as_bytes();

        assert_eq!(
            e.ingest_judged(env),
            Verdict::Reject,
            "the tolerance is off during sync; the horizon must still answer",
        );
        assert_eq!(e.rejected_future, 0, "and it is the horizon answering, not the tolerance");
        assert!(!e.blocks.contains_key(&id));
        assert!(
            e.orphans.is_empty(),
            "a slot past the horizon must not even reach the orphan pool",
        );
    }

    /// Slot 0 keeps its own answer. Genesis is synthesized, never received, so
    /// a peer gossiping one is not racing — it is sending something no honest
    /// node produces. The pre-existing `return` said nothing about the peer;
    /// now it charges them, and that must not regress into a silent drop.
    #[test]
    fn slot_zero_is_still_refused_and_now_says_so() {
        let mut e = engine_at_wall_slot(10);
        let env = envelope_at_slot(0);
        let id = *env.block_id().as_bytes();
        assert_eq!(e.ingest_judged(env), Verdict::Reject);
        assert!(!e.blocks.contains_key(&id));
    }

    /// The horizon is a skew budget, and naming the number it buys keeps the
    /// next person from tightening it into a rule that refuses honest blocks
    /// off a slightly-wrong clock.
    #[test]
    fn the_horizon_is_at_least_half_an_hour_of_clock_skew() {
        // The §5.1 consensus cadence, not the 1s the fixtures run at.
        let secs = MAX_FUTURE_SLOTS * bloch_pos_committee::params::SLOT_DURATION_SECS;
        assert!(
            secs >= 30 * 60,
            "{MAX_FUTURE_SLOTS} slots is only {secs}s of skew tolerance — too tight for a \
             fleet whose clocks are not a consensus input",
        );
    }
}

/// **H8 — `blocks` is no longer a write-anything map.**
///
/// The finding: `Engine::blocks` grew from UNVALIDATED envelopes. Nothing
/// checked the proposer signature, nothing bounded the slot, nothing required
/// the parent to be known, and fork choice was rebuilt over the result on
/// every ingest — so one unauthenticated peer could grow this node's memory
/// without limit AND make each subsequent ingest more expensive, since both
/// `advance`'s loop bound and `path_to_canonical`'s cycle guard are
/// `blocks.len()`.
///
/// The reason the leak survived is worth stating, because it is what these
/// tests are shaped around: `advance` DOES delete an invalid block — but only
/// the one block it actually tried to apply. A block whose parent is unknown
/// is never tried (`path_to_canonical` returns `None`), and a block that
/// loses the fork-choice tie is never tried either. Both stay forever. So
/// every test here uses an envelope `advance` will not reach, which is
/// precisely the envelope an attacker would send.
#[cfg(test)]
mod ingest_admission_tests {
    use super::*;

    /// A block built from a real proposal, re-pointed at `parent` and re-signed
    /// so that the ONLY thing the node can hold against it is what the test is
    /// about. Re-signing matters: `proposal_signing_root` covers the header, so
    /// moving the parent invalidates the original signature and the block would
    /// otherwise be refused for the wrong reason.
    fn repointed(
        engine: &Engine,
        template: &BlockEnvelope,
        parent: [u8; 32],
        slot: u64,
    ) -> BlockEnvelope {
        let mut env = template.clone();
        env.header.parent = parent;
        env.header.slot = slot;
        env.proposer_sig = engine
            .keys
            .as_ref()
            .expect("the proposing fixture holds a keystore")
            .sign(&env.header.proposal_signing_root());
        env
    }

    /// One real proposal to use as a template, and the store size to compare
    /// against.
    fn fixture() -> (Engine, perf_support::TestDir, BlockEnvelope, usize) {
        let (mut engine, dir) = perf_support::proposing_engine();
        engine.propose(1);
        let template = engine
            .blocks
            .get(engine.head_id().as_bytes())
            .expect("the proposal was adopted")
            .clone();
        let stored = engine.blocks.len();
        (engine, dir, template, stored)
    }

    /// **A block that connects to nothing does not become a fork-choice
    /// input.** It is held in the bounded orphan pool and the gap it is
    /// evidence of is asked for.
    ///
    /// Fails without the fix: `ingest` stored it, `advance` could not reach it
    /// (`path_to_canonical` → `None`), and nothing ever removed it.
    #[test]
    fn an_unconnected_block_is_parked_not_stored() {
        let (mut engine, _dir, template, stored) = fixture();
        engine.needs_sync = false;

        let orphan = repointed(&engine, &template, [0x9A; 32], 2);
        engine.ingest(orphan);

        assert_eq!(
            engine.blocks.len(),
            stored,
            "a block hanging off a root this node has never seen must not enter \
             `blocks` — nothing in `advance` can ever remove it again"
        );
        assert_eq!(engine.orphans.len(), 1, "it must be held, not dropped");
        assert!(
            engine.needs_sync,
            "parking an orphan is evidence of a gap and must ask for it"
        );
    }

    /// **And the pool is bounded, oldest out first.**
    ///
    /// The envelopes here name an unregistered proposer index, which is the
    /// second half of the gate: an identity this node cannot check is parked
    /// rather than stored, so it costs one bounded slot instead of a permanent
    /// entry in a fork-choice input. That also makes the test cheap — it needs
    /// no hybrid signatures at all, which is the shape the attack has too.
    ///
    /// Fails without the fix: all `ORPHAN_MAX + 8` land in `blocks` and stay.
    #[test]
    fn the_orphan_pool_is_bounded_and_evicts_the_oldest_first() {
        let (mut engine, _dir, template, stored) = fixture();
        const EXTRA: usize = 8;

        let mut first_parent = [0u8; 32];
        for i in 0..ORPHAN_MAX + EXTRA {
            let mut env = template.clone();
            // An index the genesis manifest never registered.
            env.header.proposer_index = 7;
            env.header.slot = 2;
            env.header.parent = [0u8; 32];
            env.header.parent[0] = (i & 0xFF) as u8;
            env.header.parent[1] = ((i >> 8) & 0xFF) as u8;
            if i == 0 {
                first_parent = env.header.parent;
            }
            engine.ingest(env);
        }

        assert_eq!(
            engine.blocks.len(),
            stored,
            "unauthenticated envelopes must never reach `blocks`"
        );
        assert_eq!(
            engine.orphans.len(),
            ORPHAN_MAX,
            "the pool is capped at ORPHAN_MAX"
        );
        assert_eq!(
            engine.orphans_evicted, EXTRA as u64,
            "everything above the cap must be counted out, not silently kept"
        );
        assert!(
            !engine
                .orphans
                .iter()
                .any(|(_, env)| env.header.parent == first_parent),
            "FIFO: the oldest entry is the one evicted"
        );
    }

    /// **A repeated orphan takes one slot, not one per delivery.** Without the
    /// dedup a full mesh re-offering the same block would evict the whole pool
    /// with copies of itself.
    #[test]
    fn the_same_orphan_offered_repeatedly_occupies_one_slot() {
        let (mut engine, _dir, template, _stored) = fixture();
        let orphan = repointed(&engine, &template, [0x9A; 32], 2);
        for _ in 0..16 {
            engine.ingest(orphan.clone());
        }
        assert_eq!(engine.orphans.len(), 1, "dedup by block id");
        assert_eq!(engine.orphans_evicted, 0, "and nothing was pushed out");
    }

    /// **A forged signature under a key this node HAS registered is refused at
    /// the door** — it does not even take an orphan slot, because this node
    /// can prove it is a forgery and the transition would reject it too.
    ///
    /// Fails without the fix: the envelope is stored and unreachable.
    #[test]
    fn a_forged_proposer_signature_is_refused_outright() {
        let (mut engine, _dir, template, stored) = fixture();

        let mut forged = repointed(&engine, &template, [0x9A; 32], 2);
        let n = forged.proposer_sig.len();
        forged.proposer_sig = vec![0u8; n];
        engine.ingest(forged);

        assert_eq!(engine.blocks.len(), stored, "a forgery must not be stored");
        assert!(
            engine.orphans.is_empty(),
            "a provable forgery must not consume a slot the honest gap needs"
        );
        assert_eq!(engine.rejected_unsigned, 1, "and it must be counted");
    }

    /// **O04 (external audit 2026-09-07): a signature failure under a
    /// DEPOSIT-ADDED index is not a provable forgery, so it is parked, not
    /// refused, and the relaying peer is not charged.**
    ///
    /// Two branches that each admit a different `Deposit` as their next
    /// registration assign the same index to two different keys; this node's
    /// head holds one of them, and a block signed by the other is honest on
    /// its own branch. The genesis registry has no such ambiguity — it is in
    /// the manifest every node booted from — which is why the previous test
    /// still holds for genesis indices.
    ///
    /// The fixture's registry is entirely genesis-registered, so the branch
    /// is simulated by lowering `genesis_validator_count` to zero: every index
    /// is then "deposit-added" from the engine's point of view. Before the fix
    /// this block was `Reject`ed and counted as unsigned; now it is `Ignore`d
    /// and parked.
    #[test]
    fn a_failed_signature_under_a_deposit_added_index_is_parked_not_refused() {
        let (mut engine, _dir, template, stored) = fixture();
        engine.genesis_validator_count = 0;

        let mut other_key = repointed(&engine, &template, [0x9A; 32], 2);
        let n = other_key.proposer_sig.len();
        other_key.proposer_sig = vec![0u8; n];
        let verdict = engine.ingest_judged(other_key);

        assert!(matches!(verdict, Verdict::Ignore), "no verdict on a key this branch may not hold");
        assert_eq!(engine.blocks.len(), stored, "not stored: it may not weigh on fork choice");
        assert_eq!(engine.orphans.len(), 1, "parked, awaiting the branch that can judge it");
        assert_eq!(engine.rejected_unsigned, 0, "not a forgery, not counted as one");

        // The genesis line restored, the identical envelope IS a provable
        // forgery again — the two rules meet exactly at `genesis_validator_count`.
        let (mut engine, _dir, template, stored) = fixture();
        assert!(engine.genesis_validator_count > template.header.proposer_index);
        let mut forged = repointed(&engine, &template, [0x9A; 32], 2);
        forged.proposer_sig = vec![0u8; n];
        let verdict = engine.ingest_judged(forged);
        assert!(matches!(verdict, Verdict::Reject));
        assert_eq!(engine.blocks.len(), stored);
        assert_eq!(engine.rejected_unsigned, 1);
    }

    /// **A slot the clock will not reach for hours is refused.** Otherwise a
    /// peer signing at `u64::MAX - k` writes entries no `advance` will ever
    /// consume.
    ///
    /// The parent is unknown as well, so that the ONLY thing standing between
    /// this envelope and the orphan pool is the slot bound: fails without the
    /// fix by landing in `orphans` instead of being turned away.
    #[test]
    fn a_block_far_ahead_of_the_wall_clock_is_refused() {
        let (mut engine, _dir, template, stored) = fixture();
        // Well beyond the tolerance rather than one slot past it: the
        // fixture's genesis is `now`, hybrid signing in a debug build takes
        // real seconds, and the wall slot moves while the envelope is being
        // built. One slot of margin makes this test pass or fail on how
        // loaded the box is; forty makes it a test of the rule.
        //
        // Forty and not ten thousand, because C1's `MAX_FUTURE_SLOTS` horizon
        // now sits in front of this check and would answer first for a slot
        // that far out. Staying inside the horizon is what keeps THIS test
        // about the tolerance — `rejected_future` is incremented on no other
        // path, so it also proves the horizon did not shadow the tolerance.
        let far = repointed(
            &engine,
            &template,
            [0x9A; 32],
            engine.wall_slot() + FUTURE_SLOT_TOLERANCE + 40,
        );
        engine.ingest(far);

        assert_eq!(engine.blocks.len(), stored);
        assert!(
            engine.orphans.is_empty(),
            "the slot bound must turn it away before the orphan pool sees it"
        );
        assert_eq!(engine.rejected_future, 1);

        // The control: one slot inside the tolerance is NOT refused, so the
        // bound is a bound and not a blanket.
        let near = repointed(
            &engine,
            &template,
            [0x9B; 32],
            engine.wall_slot() + FUTURE_SLOT_TOLERANCE,
        );
        engine.ingest(near);
        assert_eq!(engine.orphans.len(), 1, "inside the tolerance it is held");
        assert_eq!(engine.rejected_future, 1, "and nothing more was refused");
    }

    /// **The pool is not a black hole.** Out-of-order delivery — the child
    /// before its parent, which is the normal case on a mesh — still converges
    /// on the same head, through the promotion path rather than through a
    /// re-request.
    ///
    /// This is the liveness half of the fix, and it is why the parent rule can
    /// be as strict as it is.
    #[test]
    fn an_orphan_is_admitted_when_its_parent_lands() {
        let (mut engine, _dir) = perf_support::proposing_engine();
        let genesis = *engine.head_id().as_bytes();

        engine.propose(1);
        let b1 = engine
            .blocks
            .get(engine.head_id().as_bytes())
            .expect("proposed")
            .clone();
        engine.propose(2);
        let b2 = engine
            .blocks
            .get(engine.head_id().as_bytes())
            .expect("proposed")
            .clone();

        // Hand both blocks back and forget them, so the same envelopes can be
        // delivered again — this time in the wrong order.
        assert!(
            engine.do_reorg(genesis, Vec::new()),
            "giving the chain back must succeed"
        );
        engine
            .blocks
            .remove(b1.block_id().as_bytes())
            .expect("stored until now");
        engine
            .blocks
            .remove(b2.block_id().as_bytes())
            .expect("stored until now");
        assert_eq!(*engine.head_id().as_bytes(), genesis);

        // The child first.
        engine.ingest(b2.clone());
        assert_eq!(engine.orphans.len(), 1, "the child has nowhere to attach yet");
        assert_eq!(
            *engine.head_id().as_bytes(),
            genesis,
            "and it must not have moved the head"
        );

        // Then the parent, which must pull the child in behind it.
        engine.ingest(b1.clone());
        assert!(engine.orphans.is_empty(), "the child was promoted");
        assert!(engine.orphans_admitted >= 1, "and the promotion was counted");
        assert_eq!(
            *engine.head_id().as_bytes(),
            *b2.block_id().as_bytes(),
            "out-of-order delivery must still land on the same head as in-order \
             delivery — a bounded pool that never releases is just a slower leak"
        );
    }

    /// **The slot bound is a rule about PEERS, not about this node's own
    /// producer.**
    ///
    /// A proposer chose the slot it is building for, and the slot loop only
    /// ever calls `propose` for the slot it is currently in. Re-judging that
    /// block against the wall clock adds nothing and subtracts a lot: on a
    /// box loaded enough that the two readings drift, the node would refuse
    /// its own proposal and lose the slot — the h28080 shape, arrived at from
    /// a different direction.
    ///
    /// The fixture makes the difference visible: its genesis is `now`, so a
    /// slot past the tolerance is trivially reachable, and every other gate
    /// (authentication, known parent) still applies to the block.
    ///
    /// Fails if the `Source::Local` exemption is removed.
    #[test]
    fn the_producer_is_not_refused_by_the_bound_it_imposes_on_peers() {
        let (mut engine, _dir) = perf_support::proposing_engine();
        // Far enough past the tolerance that the clock moving during the
        // proposal cannot quietly bring it back inside and make the assertion
        // vacuous — 60 slots is 60 s of drift at the fixture's cadence.
        let far = engine.wall_slot() + FUTURE_SLOT_TOLERANCE + 60;

        engine.propose(far);

        assert_eq!(
            engine.head_slot_now(),
            far,
            "the node must adopt the block it just built for the slot it was \
             asked to build for"
        );
        assert_eq!(
            engine.rejected_future, 0,
            "and it must not have been counted as a future-slot refusal"
        );
    }

    /// **A node must be able to replay its own log whatever its clock says —
    /// and that must be true BY SOURCE, not by an accident of ordering.**
    ///
    /// The two halves are the same envelope, byte for byte, and they must get
    /// opposite answers:
    ///
    /// - down [`Engine::ingest_replay`] — the boot path, reading this node's
    ///   own committed log — it is applied, however far its slot sits past
    ///   this box's wall clock;
    /// - arriving over gossip on a live node it is `Reject`ed by
    ///   `MAX_FUTURE_SLOTS` and never reaches `blocks`, which is C1's whole
    ///   point and is not weakened by the exemption above it.
    ///
    /// The slot is past the HORIZON, not merely past the tolerance, because
    /// the horizon is the check `self.live` never guarded. Boot replay used to
    /// route through `ingest` -> `Source::Gossip`, so a replayed block was
    /// judged against this node's clock exactly as a stranger's is; what kept
    /// that from refusing a node its own finalized history was only that a
    /// node's log and its clock usually agree. `live` is set AFTER the replay
    /// loop, and it guards the OTHER check.
    ///
    /// Mutation check: give replay `Source::Gossip` again (or drop `Replay`
    /// from `Source::bounded_by_wall_clock`'s exempt arm) and the first half
    /// fails — the head stays at genesis, the node having refused to replay
    /// its own log. Drop the `Gossip` arm and the second half fails.
    #[test]
    fn boot_replay_applies_a_block_the_same_node_would_reject_from_gossip() {
        let (mut engine, _dir) = perf_support::proposing_engine();
        let genesis = *engine.head_id().as_bytes();

        // Past `MAX_FUTURE_SLOTS`, with margin: the fixture's genesis is
        // `now` at a 1 s cadence and hybrid signing in a debug build takes
        // real seconds, so the wall slot moves underneath this test. 100
        // slots of headroom keeps the block past the horizon at every point
        // below rather than making the assertion depend on load.
        let far = engine.wall_slot() + MAX_FUTURE_SLOTS + 100;
        engine.propose(far);
        assert_eq!(
            engine.head_slot_now(),
            far,
            "the fixture must have produced the block this test is about"
        );
        let env = engine
            .blocks
            .get(engine.head_id().as_bytes())
            .expect("proposed")
            .clone();
        let id = *env.block_id().as_bytes();

        // Give the chain back and forget the envelope, so the SAME bytes can
        // be delivered again down a different path. Both `blocks` and
        // `canonical` have to let go, or `ingest_one`'s duplicate check
        // answers first and neither half proves anything.
        let forget = |engine: &mut Engine| {
            assert!(
                engine.do_reorg(genesis, Vec::new()),
                "giving the chain back must succeed"
            );
            engine.blocks.remove(&id);
            assert_eq!(*engine.head_id().as_bytes(), genesis);
            assert!(!engine.canonical.contains(&id), "and it is no longer canonical");
        };
        forget(&mut engine);

        // ── Half one: the boot path. `live` is false here exactly as it is
        // during `run`'s replay loop, but the exemption under test is the one
        // carried by `Source::Replay` — the horizon this block is past is not
        // guarded by `live` at all.
        engine.live = false;
        engine.ingest_replay(env.clone());
        assert_eq!(
            engine.head_slot_now(),
            far,
            "a node must apply a block out of its OWN log however far that \
             block's slot sits past this box's wall clock — refusing here is a \
             node that cannot restart"
        );
        assert!(engine.blocks.contains_key(&id), "and it must have been stored");
        assert_eq!(
            engine.rejected_future, 0,
            "replay is not charged to either clock rule"
        );

        // ── Half two: the same bytes, over the wire, on a live node.
        forget(&mut engine);
        engine.live = true;
        let verdict = engine.ingest_judged(env);
        assert_eq!(
            verdict,
            Verdict::Reject,
            "the exemption is for this node's own log and nothing else — a \
             gossiped slot past the horizon is still provably refusable"
        );
        assert!(
            !engine.blocks.contains_key(&id),
            "and it must never reach `blocks` (C1)"
        );
        assert_eq!(
            engine.head_slot_now(),
            0,
            "nor move the head"
        );
    }

    /// **Pruning is finality-shaped, not slot-shaped.** With nothing finalized
    /// there is no floor, so nothing may be dropped; this pins that the sweep
    /// cannot start eating a live branch on a chain that has not finalized.
    #[test]
    fn nothing_is_pruned_before_the_chain_finalizes_anything() {
        let (mut engine, _dir, template, stored) = fixture();
        assert_eq!(
            engine.state.finality().finalized.epoch,
            0,
            "the fixture has not finalized anything"
        );
        let orphan = repointed(&engine, &template, [0x9A; 32], 2);
        engine.ingest(orphan);

        engine.prune_below_finalized();

        assert_eq!(engine.blocks.len(), stored, "no stored block may be dropped");
        assert_eq!(engine.orphans.len(), 1, "and no parked block either");
        assert_eq!(engine.blocks_pruned, 0);
    }
}

/// Retention, which is not admission: [`MEMPOOL_TTL_SLOTS`].
///
/// The defect these pin is that a transaction the producer can never include
/// had no way out of the mempool. Admission and retention were one decision —
/// an entry left only by being included, refused by a proposal, or caught by
/// `sweep_mempool`'s spent-input scan — so a transfer that is none of those
/// (stale fee, sub-dust output, an input spent on a branch this node does not
/// hold) was skipped block after block and stayed forever. Measured on the
/// live chain 2026-09-05: one held for over 200 blocks, chain healthy.
///
/// Every test here drives `evict_stale_mempool` against a HEAD this test
/// moves, because the head is the clock the rule is written in: the claim is
/// "this many blocks of chain went by and never took it", not "this much time
/// passed". Revert the body of `evict_stale_mempool` to a no-op and
/// `an_unincludable_transaction_does_not_outlive_the_ttl` fails on the first
/// assertion.
#[cfg(test)]
mod mempool_ttl {
    use super::slot_horizon::engine_at_wall_slot;
    use super::*;
    use bloch_pos_committee::transition::{TransferInput, TransferOutput};

    /// A transfer that is never included and never needs to be valid: nothing
    /// on the retention path parses it. `n` only separates the keys.
    ///
    /// `pub(super)`: also reused by `tx_status_tests` (R4 F-11), a sibling
    /// module under `engine` that needs a cheap, distinct transaction and no
    /// reason to duplicate this one.
    pub(super) fn parked_transfer(n: u8) -> PosTransaction {
        PosTransaction::Transfer {
            inputs: vec![TransferInput {
                txid: [n; 32],
                vout: 0,
                pubkey: Vec::new(),
                signature: Vec::new(),
            }],
            outputs: vec![TransferOutput { value: 1_000, script_hash: [n; 32] }],
            tx_bytes: 256,
            tip_millisat_per_gas: 0,
        }
    }

    /// Put `tx` in the pool the way `on_transaction` does, admitted at the
    /// head the engine is on right now. `pub(super)` — see `parked_transfer`.
    pub(super) fn admit(e: &mut Engine, tx: PosTransaction) -> Vec<u8> {
        let key = tx.canonical_bytes();
        e.mempool_admitted_at.insert(key.clone(), e.head_slot_now());
        e.mempool.insert(key.clone(), tx);
        key
    }

    /// Move the head `to` without applying anything — the producer skipping
    /// this transaction for that many blocks, which is the whole scenario.
    fn head_to(e: &mut Engine, to: u64) {
        // A real id through the one §5.4 path — `BlockId` has no constructor
        // from raw bytes, deliberately. Only the slot moves, which is all
        // `head_slot_now` reads.
        let mut h = e.manifest.genesis_header();
        h.slot = to;
        e.chain.push((to, BlockId::of(&h)));
    }

    /// **The finding.** An entry the producer never includes must not be
    /// immortal — and must survive right up to the boundary, so the rule is a
    /// TTL and not a random sweep.
    #[test]
    fn an_unincludable_transaction_does_not_outlive_the_ttl() {
        let mut e = engine_at_wall_slot(0);
        let key = admit(&mut e, parked_transfer(1));

        // Exactly at the TTL: still held. `<=` in the comparison, and this is
        // the assertion that pins it — an off-by-one here is a node that
        // drops a transaction one block early, every time.
        head_to(&mut e, MEMPOOL_TTL_SLOTS);
        e.evict_stale_mempool();
        assert!(e.mempool.contains_key(&key), "the TTL is a bound, not a deadline before it");
        assert_eq!(e.mempool_expired, 0);

        // One block past it: gone, and counted.
        head_to(&mut e, MEMPOOL_TTL_SLOTS + 1);
        e.evict_stale_mempool();
        assert!(!e.mempool.contains_key(&key), "unincluded past the TTL must not stay");
        assert_eq!(e.mempool_expired, 1, "an expiry an operator cannot see is not a fix");
        // The bookkeeping leaves with it, or this map is a slower leak than
        // the one the TTL closes.
        assert!(!e.mempool_admitted_at.contains_key(&key));
    }

    /// The clock is per-entry, not per-pool: a transaction admitted late must
    /// not inherit the age of one admitted early. Without the parallel map —
    /// with a single "last swept" slot, say — this is the test that fails.
    #[test]
    fn the_ttl_clock_is_per_transaction() {
        let mut e = engine_at_wall_slot(0);
        let old = admit(&mut e, parked_transfer(1));

        head_to(&mut e, MEMPOOL_TTL_SLOTS);
        let young = admit(&mut e, parked_transfer(2));

        head_to(&mut e, MEMPOOL_TTL_SLOTS + 1);
        e.evict_stale_mempool();
        assert!(!e.mempool.contains_key(&old));
        assert!(e.mempool.contains_key(&young), "a fresh entry must not inherit an old one's age");
        assert_eq!(e.mempool_expired, 1);
    }

    /// A reorg can move the head backwards. The honest answer to a negative
    /// age is zero, not eviction — `saturating_sub` — because the alternative
    /// is a node that empties its mempool every time it reorgs.
    #[test]
    fn a_head_that_moves_backwards_expires_nothing() {
        let mut e = engine_at_wall_slot(0);
        head_to(&mut e, 500);
        let key = admit(&mut e, parked_transfer(1));
        head_to(&mut e, 400);
        e.evict_stale_mempool();
        assert!(e.mempool.contains_key(&key));
        assert_eq!(e.mempool_expired, 0);
    }

    /// An entry that left by any of the four OTHER paths (included, refused,
    /// swept, replaced) takes its clock with it. This is what keeps
    /// `mempool_admitted_at` from growing without bound while `mempool` stays
    /// small — the leak a naive TTL introduces while closing another.
    #[test]
    fn bookkeeping_does_not_outlive_the_entry_it_times() {
        let mut e = engine_at_wall_slot(0);
        let key = admit(&mut e, parked_transfer(1));
        // The inclusion path: `advance` removes from `mempool` and nothing
        // else, exactly as the applied-block arm does.
        e.mempool.remove(&key);
        e.evict_stale_mempool();
        assert!(e.mempool_admitted_at.is_empty(), "the clock must leave with the entry");
        assert_eq!(e.mempool_expired, 0, "an inclusion is not an expiry");
    }

    /// Dropping for age is NOT a refusal: nothing is barred, so the mesh
    /// re-offering the transaction gets it admitted again with a fresh clock.
    /// That is the property that makes this node-local policy rather than
    /// consensus — the set of blocks this node accepts does not move.
    #[test]
    fn an_expiry_bars_nothing() {
        let mut e = engine_at_wall_slot(0);
        let key = admit(&mut e, parked_transfer(1));
        head_to(&mut e, MEMPOOL_TTL_SLOTS + 1);
        e.evict_stale_mempool();
        assert!(!e.mempool.contains_key(&key));
        assert!(!e.rejected.contains_key(&key), "age is not a refusal, and must not bar a re-offer");
        assert!(!e.mempool_suspect.contains(&key));
    }
}

/// `gettxstatus`'s bookkeeping (finding R4 F-11): `Engine::tx_slot_index`,
/// `note_tx_slots`, `forget_tx_slots_if_stale` and `tx_status`.
#[cfg(test)]
mod tx_status_tests {
    use super::mempool_ttl::{admit, parked_transfer};
    use super::slot_horizon::engine_at_wall_slot;
    use super::*;

    /// A slot safely past epoch 0 — `tx_status` compares an epoch against
    /// the finality checkpoints, and a fresh engine's `finalized`/`justified`
    /// both sit at epoch 0, so testing AT epoch 0 could not tell "included"
    /// apart from "finalized" (`0 <= 0`). Epoch 1 can.
    fn epoch1_slot() -> u64 {
        SLOTS_PER_EPOCH
    }

    #[test]
    fn unknown_when_never_seen() {
        let e = engine_at_wall_slot(0);
        let tx = parked_transfer(1);
        assert_eq!(e.tx_status(&tx.txid()), "unknown");
    }

    #[test]
    fn pending_when_only_in_the_mempool() {
        let mut e = engine_at_wall_slot(0);
        let tx = parked_transfer(1);
        let txid = tx.txid();
        admit(&mut e, tx);
        assert_eq!(e.tx_status(&txid), "pending");
    }

    /// The whole point of the index: a status query does not need to scan
    /// the mempool at all once a transaction is noted as included, and it
    /// reports a real chain fact (`included`, since epoch 1 is past neither
    /// checkpoint on a fresh engine) rather than falling through to
    /// `pending`/`unknown`.
    #[test]
    fn included_once_noted_even_if_never_admitted_to_the_mempool() {
        let mut e = engine_at_wall_slot(0);
        let tx = parked_transfer(1);
        let txid = tx.txid();
        e.note_tx_slots(epoch1_slot(), std::slice::from_ref(&tx));
        assert_eq!(e.tx_status(&txid), "included");
    }

    /// The index lookup is CHEAPER than the mempool scan and must win: a
    /// transaction that is somehow (a stale entry) in both must report the
    /// chain fact, not `pending`.
    #[test]
    fn the_index_takes_precedence_over_a_stale_mempool_entry() {
        let mut e = engine_at_wall_slot(0);
        let tx = parked_transfer(1);
        let txid = tx.txid();
        admit(&mut e, tx.clone());
        e.note_tx_slots(epoch1_slot(), std::slice::from_ref(&tx));
        assert_eq!(e.tx_status(&txid), "included");
    }

    /// Re-noting the SAME txid at a later slot overwrites, not duplicates —
    /// the newer slot is the one a reorg's winning branch actually landed it
    /// at.
    #[test]
    fn renoting_the_same_txid_overwrites_the_slot() {
        let mut e = engine_at_wall_slot(0);
        let tx = parked_transfer(1);
        let txid = tx.txid();
        e.note_tx_slots(epoch1_slot(), std::slice::from_ref(&tx));
        assert_eq!(e.tx_slot_index.get(&txid), Some(&epoch1_slot()));
        e.note_tx_slots(epoch1_slot() + 5, std::slice::from_ref(&tx));
        assert_eq!(
            e.tx_slot_index.get(&txid),
            Some(&(epoch1_slot() + 5)),
            "a later inclusion must overwrite the earlier slot"
        );
    }

    /// `forget_tx_slots_if_stale` removes an entry only if it STILL points at
    /// the slot being forgotten — the reorg-cleanup contract that keeps a
    /// winning branch's re-inclusion (a newer `note_tx_slots` call) from
    /// being clobbered by cleanup for the losing branch it came from.
    #[test]
    fn forget_only_removes_a_still_matching_slot() {
        let mut e = engine_at_wall_slot(0);
        let tx = parked_transfer(1);
        let txid = tx.txid();

        // Case 1: the entry still points at the slot being forgotten — it
        // must be removed, and the status must fall back (here: unknown,
        // since it was never admitted to the mempool either).
        e.note_tx_slots(epoch1_slot(), std::slice::from_ref(&tx));
        e.forget_tx_slots_if_stale(epoch1_slot(), std::slice::from_ref(&tx));
        assert_eq!(e.tx_status(&txid), "unknown");

        // Case 2: the entry has ALREADY been overwritten with a newer slot
        // (the winning branch re-included it) — forgetting the OLD slot must
        // not touch it.
        e.note_tx_slots(epoch1_slot(), std::slice::from_ref(&tx));
        e.note_tx_slots(epoch1_slot() + 1, std::slice::from_ref(&tx));
        e.forget_tx_slots_if_stale(epoch1_slot(), std::slice::from_ref(&tx));
        assert_eq!(
            e.tx_slot_index.get(&txid),
            Some(&(epoch1_slot() + 1)),
            "forgetting a stale slot must not clobber a newer one for the same txid"
        );
    }

    /// R4 F-11's own bound: [`MAX_TX_SLOT_INDEX`] caps the index, FIFO —
    /// remembering where a transaction landed must not become an unbounded
    /// archive over the chain's lifetime.
    #[test]
    fn the_index_is_bounded_fifo() {
        let mut e = engine_at_wall_slot(0);
        // Distinct txids: vary `tx_bytes`, which the signing root and
        // therefore the txid covers.
        let make = |n: u64| PosTransaction::Transfer {
            inputs: Vec::new(),
            outputs: Vec::new(),
            tx_bytes: n,
            tip_millisat_per_gas: 0,
        };
        let first = make(0);
        let first_id = first.txid();
        e.note_tx_slots(1, std::slice::from_ref(&first));
        for n in 1..=(MAX_TX_SLOT_INDEX as u64) {
            let tx = make(n);
            e.note_tx_slots(1, std::slice::from_ref(&tx));
        }
        assert_eq!(
            e.tx_slot_index_order.len(),
            MAX_TX_SLOT_INDEX,
            "the order queue must never exceed the cap"
        );
        assert!(
            !e.tx_slot_index.contains_key(&first_id),
            "the oldest entry must be evicted once the cap is exceeded"
        );
    }
}

/// The finality latch (finding F-03): `finalized` is a downward ratchet, and
/// fork choice may never move this node's head below it.
///
/// The defect these pin: the finalized checkpoint lived ONLY in replayed
/// state, so a reorg — including the in-rules empty-branch "give the chain
/// back" cut that LMD-GHOST legitimately proposes from the justified root —
/// simply REPLACED it with an older one. Measured on the live network:
/// finalized epoch 6 -> 4 -> 2 -> 0 in three cuts, on nodes running identical
/// binaries. An exchange crediting on `finality == "finalized"` loses funds
/// on exactly that move.
///
/// Mutation targets, each of which fails a test here:
/// - delete the `cut_below_finalized_latch` check in `do_reorg` →
///   `a_reorg_below_the_finalized_latch_is_refused` adopts the rewind;
/// - delete the `ratchet_finalized` calls → the latch stays `None` and
///   `own_finality_arms_the_latch` fails;
/// - weaken the strict `<` to `<=` in `cut_below_finalized_latch` →
///   `a_cut_at_the_latch_itself_stays_legal` fails.
#[cfg(test)]
mod finality_latch_tests {
    use super::*;

    /// Drive the one-validator devnet engine to real finality the same way
    /// `run`'s slot loop does: attest, then propose, every slot. Local
    /// proposals are not wall-clock bounded (`Source::Local`), so the test
    /// walks epochs as fast as it can sign. This is the expensive fixture —
    /// a couple of epochs of real hybrid signatures — so only the ratchet
    /// test pays for it; the refusal tests arm the latch by hand instead.
    fn engine_with_own_finality() -> (Engine, perf_support::TestDir) {
        let (mut engine, dir) = perf_support::proposing_engine();
        for slot in 1..=(4 * SLOTS_PER_EPOCH) {
            engine.attest(slot);
            engine.propose(slot);
            if engine.state.finality().finalized.epoch >= 1 {
                break;
            }
        }
        assert!(
            engine.state.finality().finalized.epoch >= 1,
            "harness must reach finality on its own votes; got e{} at head slot {}",
            engine.state.finality().finalized.epoch,
            engine.head_slot_now(),
        );
        (engine, dir)
    }

    /// Three real proposed blocks and the latch armed by hand at height 2 —
    /// the state the ratchet test proves is reachable, without paying for
    /// two epochs of signatures in every test. Only `finalized_latch` is
    /// forged; every block, state and reorg below runs the production code.
    fn latched_engine() -> (Engine, perf_support::TestDir, u64, [u8; 32]) {
        let (mut engine, dir) = perf_support::proposing_engine();
        for slot in 1..=3 {
            engine.propose(slot);
        }
        assert_eq!(engine.chain.len(), 4, "three blocks over genesis");
        let (floor, root) = (2u64, *engine.chain[2].1.as_bytes());
        engine.finalized_latch = Some((floor, root));
        (engine, dir, floor, root)
    }

    /// **The ratchet arms itself from this node's OWN finality** — no
    /// operator input, no checkpoint file — and records exactly the state's
    /// finalized checkpoint at its canonical height.
    #[test]
    fn own_finality_arms_the_latch() {
        let (engine, _dir) = engine_with_own_finality();
        let fin = engine.state.finality().finalized;
        let (floor, root) = engine
            .finalized_latch
            .expect("finalizing must arm the latch");
        assert_eq!(
            root, fin.root,
            "the latch must name the finalized checkpoint itself"
        );
        assert_eq!(
            Some(floor),
            engine.height_of(&fin.root),
            "and pin it at its canonical height"
        );
        assert!(floor > 0, "genesis is no floor");
    }

    /// **An attempt to move the head below finalized is rejected.** The
    /// empty-branch give-back to genesis is the exact shape of the measured
    /// live rewind, and `an_orphan_is_admitted_when_its_parent_lands` (which
    /// gives a PRE-finality chain back to genesis and asserts it succeeds) is
    /// the standing control — so what refuses it here is the latch and only
    /// the latch.
    #[test]
    fn a_reorg_below_the_finalized_latch_is_refused() {
        let (mut engine, _dir, _floor, _root) = latched_engine();
        let genesis = *engine.chain[0].1.as_bytes();
        let head_before = engine.head_id();
        let chain_before = engine.chain.len();
        let latch_before = engine.finalized_latch;

        assert!(
            !engine.do_reorg(genesis, Vec::new()),
            "a reorg below this node's own finalized checkpoint must be refused"
        );

        assert_eq!(engine.head_id(), head_before, "the head must not move");
        assert_eq!(engine.chain.len(), chain_before, "no canonical block may be cut");
        assert_eq!(engine.finalized_latch, latch_before, "the latch must not move either");
        assert_eq!(
            engine.finality_rewinds_refused, 1,
            "a refusal an operator cannot count is a rewind diagnosed as sync trouble"
        );
    }

    /// **The floor is strict** — a cut AT the latch height keeps the
    /// finalized block canonical and must stay legal, or the latch would be
    /// quietly widening into a freeze of ordinary fork choice above finality.
    #[test]
    fn a_cut_at_the_latch_itself_stays_legal() {
        let (mut engine, _dir, floor, root) = latched_engine();
        let fin_block = *engine.chain[floor as usize].1.as_bytes();
        assert_eq!(fin_block, root, "the latch names the block at its height");

        assert!(
            engine.do_reorg(fin_block, Vec::new()),
            "giving back everything ABOVE the finalized checkpoint is still \
             ordinary fork choice and must not be refused"
        );
        assert_eq!(
            engine.finalized_latch,
            Some((floor, root)),
            "the latch survives the reorg even though the fork-point state \
             reports older finality — that asymmetry IS the fix"
        );
        assert!(
            engine.canonical.contains(&root),
            "the finalized block itself stays canonical"
        );
        assert_eq!(engine.finality_rewinds_refused, 0);
    }

    /// **A conflicting branch that demands the rewind is dropped, not kept.**
    /// Keeping its blocks would let the heaviest-branch walk re-propose the
    /// same refused head forever; dropping them is the "refuse blocks that
    /// would" half of the rule and what lets `advance` converge afterwards.
    #[test]
    fn the_branch_demanding_a_rewind_is_dropped() {
        let (mut engine, _dir, _floor, _root) = latched_engine();
        // A fake sibling of block 1: forks below the latch. It only needs to
        // exist in `blocks` — `refuse_finality_rewind` judges the cut, not
        // the signatures.
        let genesis = *engine.chain[0].1.as_bytes();
        let mut env = engine
            .blocks
            .get(engine.chain[1].1.as_bytes())
            .expect("block 1 stored")
            .clone();
        env.header.parent = genesis;
        env.header.randao_mix = [0xEE; 32]; // any header change: new identity
        let evil_id = *env.block_id().as_bytes();
        engine.blocks.insert(evil_id, env.clone());

        let latch = engine.finalized_latch.expect("fixture is latched");
        engine.refuse_finality_rewind(latch, &[env]);

        assert!(
            !engine.blocks.contains_key(&evil_id),
            "the refused branch must leave the fork-choice inputs"
        );
        assert_eq!(engine.finality_rewinds_refused, 1);
    }

    // ── R3 M-1: park, don't delete; refuse re-offers at the door; override ──

    /// A refused branch is PARKED, not merely removed. Before this fix the
    /// only trace of a refusal was the counter — the blocks themselves were
    /// gone, so nothing distinguished "refused once" from "refused, deleted,
    /// and about to be refused again from scratch the next time this exact
    /// branch arrives".
    #[test]
    fn refused_branch_is_parked_not_only_deleted() {
        let (mut engine, _dir, _floor, _root) = latched_engine();
        let genesis = *engine.chain[0].1.as_bytes();
        let mut env = engine
            .blocks
            .get(engine.chain[1].1.as_bytes())
            .expect("block 1 stored")
            .clone();
        env.header.parent = genesis;
        env.header.randao_mix = [0xEE; 32];
        let evil_id = *env.block_id().as_bytes();
        engine.blocks.insert(evil_id, env.clone());

        assert!(engine.parked_refused_finality.is_empty(), "nothing parked yet");
        let latch = engine.finalized_latch.expect("fixture is latched");
        engine.refuse_finality_rewind(latch, &[env]);

        assert!(
            engine.parked_refused_finality.iter().any(|(id, _)| *id == evil_id),
            "a refused block must be parked, not merely dropped"
        );
    }

    /// A re-offer of an already-parked, already-refused block is dropped at
    /// the door — `Verdict::Ignore`, and none of the LATER admission checks
    /// (unsigned rejection, future-slot rejection, orphan parking) ever run.
    /// This is the fix for "sync re-fetches and re-refuses forever": without
    /// it, the deleted block would fall through to full re-authentication
    /// every single time it arrived again.
    #[test]
    fn a_reoffered_parked_block_is_ignored_before_any_further_check() {
        let (mut engine, _dir, _floor, _root) = latched_engine();
        let genesis = *engine.chain[0].1.as_bytes();
        let mut env = engine
            .blocks
            .get(engine.chain[1].1.as_bytes())
            .expect("block 1 stored")
            .clone();
        env.header.parent = genesis;
        env.header.randao_mix = [0xEE; 32];
        // An unregistered proposer index: if the door's parked-check did NOT
        // fire first, this would fall through to `park_orphan` (unknown
        // parent) or the identity gate, NOT the parked-refusal short-circuit
        // — so this also proves ORDER, not just outcome.
        env.header.proposer_index = u32::MAX;
        let evil_id = *env.block_id().as_bytes();
        engine.blocks.insert(evil_id, env.clone());
        let latch = engine.finalized_latch.expect("fixture is latched");
        engine.refuse_finality_rewind(latch, &[env.clone()]);
        assert!(!engine.blocks.contains_key(&evil_id), "parking removes it from `blocks`");

        let rejected_unsigned_before = engine.rejected_unsigned;
        let orphans_before = engine.orphans.len();
        let (verdict, released) = engine.ingest_one(env, Source::Gossip);

        assert_eq!(verdict, Verdict::Ignore, "a re-offered parked block must be ignored");
        assert!(released.is_none());
        assert!(
            !engine.blocks.contains_key(&evil_id),
            "a parked block must not be re-admitted to `blocks` by a re-offer"
        );
        assert_eq!(
            engine.rejected_unsigned, rejected_unsigned_before,
            "the door must refuse BEFORE any signature work, not after failing it"
        );
        assert_eq!(
            engine.orphans.len(), orphans_before,
            "the door must refuse BEFORE the orphan pool, not park it there instead"
        );
    }

    /// `finality_rewind_override` lifts the latch: a cut that would
    /// otherwise be refused is allowed, and the refusal counter — which an
    /// operator would otherwise read as "the latch is doing its job" — stays
    /// at zero, because it never fired.
    #[test]
    fn override_lifts_the_latch() {
        let (mut engine, _dir, _floor, _root) = latched_engine();
        let genesis = *engine.chain[0].1.as_bytes();

        engine.finality_rewind_override = true;
        assert!(
            engine.do_reorg(genesis, Vec::new()),
            "the override must allow a rewind the latch would otherwise refuse"
        );
        assert_eq!(
            engine.finality_rewinds_refused, 0,
            "an allowed rewind must not be counted as a refusal"
        );
    }

    /// Without the override, the exact same rewind is refused — the standing
    /// control for the test above, proving the override is what changed the
    /// outcome and not some other difference between the two tests.
    #[test]
    fn without_override_the_same_rewind_is_still_refused() {
        let (mut engine, _dir, _floor, _root) = latched_engine();
        let genesis = *engine.chain[0].1.as_bytes();
        assert!(!engine.finality_rewind_override, "override must default to off");
        assert!(!engine.do_reorg(genesis, Vec::new()), "unchanged default behaviour: refuse");
        assert_eq!(engine.finality_rewinds_refused, 1);
    }
}

#[cfg(test)]
#[path = "engine/validator_admission_tests.rs"]
mod validator_admission_tests;

#[cfg(test)]
mod branch_gap_repair_tests {
    use super::*;

    #[test]
    fn missing_branch_sync_walks_behind_the_head_without_rewinding_state() {
        let (mut node, _dir) = perf_support::proposing_engine();
        let _clock = validator_lifecycle::clock_at(201);
        node.wall_slot = 201;
        node.propose(200);
        assert_eq!(node.state.slot(), 200);
        assert_eq!(node.sync_after_slot(), 200);
        let head = node.head_id();
        let root = node.state.state_root();
        let original = node.blocks[head.as_bytes()].clone();
        for (slot, expected) in [(201, 136), (137, 72), (73, 8), (9, 0)] {
            let mut orphan = original.clone();
            orphan.header.slot = slot;
            orphan.header.parent = [slot as u8; 32];
            orphan.proposer_sig = node.keys.as_ref().unwrap().sign(&orphan.header.proposal_signing_root());
            node.ingest(orphan);
            assert!(node.needs_sync);
            assert_eq!(node.sync_after_slot(), expected);
            assert_eq!(node.head_id(), head);
            assert_eq!(node.state.state_root(), root);
        }
    }
}
