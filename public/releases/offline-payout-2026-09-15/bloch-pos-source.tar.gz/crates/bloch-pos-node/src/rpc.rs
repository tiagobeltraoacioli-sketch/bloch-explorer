// SPDX-License-Identifier: AGPL-3.0-or-later

//! JSON-RPC 2.0 over HTTP/1.1 — the Genesis-4 node's query and submission
//! surface.
//!
//! ## What this is a read layer over
//!
//! Everything answered here comes from the engine's committed state
//! (`CommittedState`) and its canonical chain. Nothing in this module decides
//! anything: it has no opinion about validity, it never writes state, and the
//! one method that *changes* anything (`sendrawtransaction`) does so by handing
//! bytes to the same `on_transaction` admission path a peer's gossip goes
//! through. That is deliberate, and it is the shape §5.5 asks for — a second
//! path into the mempool with its own checks would be the `expected_bits`
//! defect with a URL in front of it.
//!
//! ## Why there is no framework here
//!
//! The Genesis-3 node's RPC (`src/rpc/mod.rs` at the repo root) is axum + tower
//! + serde_json + tokio. **This module** imports `std`, `bloch-pos-committee`
//! and `sha3` and nothing else: no framework, no `async`, no `await`, and the
//! server is blocking `std::net` with one thread per connection, the same shape
//! `net.rs` has.
//!
//! The **crate** is not runtime-free, and saying it was is what this note used
//! to get wrong: `Cargo.toml` declares `libp2p`, `tokio`, `futures` and
//! `async-trait` for the production transport, and `p2p::start` builds a
//! current-thread tokio runtime on its own thread. What is avoided is dragging
//! that stack across the RPC surface as well — an axum + tower server in front
//! of a consensus loop that is a single synchronous thread, to serve nine read
//! methods. So HTTP/1.1 and JSON are implemented here, in about 400 lines,
//! against `std` only: `serve` mirrors `net::start`'s accept-thread shape
//! exactly.
//!
//! The cost is stated rather than hidden: this server speaks the subset of
//! HTTP/1.1 a JSON-RPC client needs (POST, `Content-Length`, no chunked
//! transfer-encoding, no keep-alive, no TLS, no compression). It is not a
//! general-purpose web server and must not become one.
//!
//! ## Conventions this obeys (`docs/specs/BLOCH-RPC-V4.md` §0)
//!
//! - **R3 — every satoshi-denominated field is a decimal string.** Not for
//!   Rust's benefit: the V4 cap is 10^19 sat, ~1110x JavaScript's 2^53 exact
//!   integer limit, so a JSON *number* is silently corrupted by every browser
//!   that reads it. [`Json::sat`] is the only way an amount leaves this module,
//!   and `amounts_are_decimal_strings_not_json_numbers` pins it.
//! - **R4 — failures are the top-level JSON-RPC `error` object**, never a
//!   `result.error` string under HTTP 200. The V3 convention forced a
//!   `ResultError` shim into both generated SDKs and the explorer; V4 is the
//!   one chance to not carry it forward.
//! - **R5 — `commission_bps` rides on every validator response.** Tokenomics
//!   V4 leaves commission uncapped on the explicit bet that clients surface the
//!   rate, which only works if the rate is always there to surface.
//!
//! ## Authentication: there is none
//!
//! No API key, no rate limit, no per-method authorisation — unlike the
//! Genesis-3 surface, which has all three (`src/rpc/auth.rs`). That is why
//! `--rpc-bind` defaults to `127.0.0.1` and why binding anything routable is an
//! explicit act that the help text pairs with a firewall instruction. The
//! bounds that *are* here are anti-exhaustion, not authorisation:
//! [`MAX_BODY_BYTES`], [`MAX_HEADER_BYTES`], [`MAX_CONNECTIONS`] and the socket
//! timeouts. They stop one client from consuming the node; they stop no one
//! from reading it.

use std::io::{self, Read, Write};
use std::net::{SocketAddr, TcpListener, TcpStream};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::mpsc::{self, Sender};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::{Duration, Instant};

use bloch_pos_committee::header::{BlockEnvelope, BlockId};
use bloch_pos_committee::interfaces::{StateReader, ValidatorRecord};
use bloch_pos_committee::state_root::EutxoEntry;
use bloch_pos_committee::transition::{CommittedState, PosTransaction};
use bloch_pos_committee::{epoch_of, params::SLOTS_PER_EPOCH};

// ─── Limits (anti-exhaustion, not authorisation) ────────────────────────────

/// Largest request body accepted. A JSON-RPC call is a few hundred bytes; the
/// only method that can legitimately approach this is `sendrawtransaction`.
pub const MAX_BODY_BYTES: usize = 1024 * 1024;

/// Largest request head (request line + headers) accepted before the body.
const MAX_HEADER_BYTES: usize = 16 * 1024;

/// Connections served concurrently. Past this the listener answers 503 and
/// closes, rather than spawning threads until the process dies — the node's
/// consensus thread must survive its RPC port being hammered.
const MAX_CONNECTIONS: usize = 64;

/// Total time allowed to receive a request, and per-write response timeout.
/// Occasional bytes must not renew a connection's request budget.
const IO_TIMEOUT: Duration = Duration::from_secs(30);

/// How long a request waits for the consensus thread to answer before giving
/// up. The engine services RPC between slot duties, so a request arriving while
/// a proposal is being signed waits for that signature; it should never wait
/// for a whole slot.
const ENGINE_TIMEOUT: Duration = Duration::from_secs(10);

/// Default and maximum page size for [`RpcRequest::Utxos`].
const UTXO_PAGE_DEFAULT: usize = 100;
const UTXO_PAGE_MAX: usize = 1_000;

// ─── Errors ─────────────────────────────────────────────────────────────────
//
// # The error contract
//
// An integrator writes a client against these codes, so each one names **one
// cause**. A single generic "-32000: something went wrong" forces every caller
// to parse English to decide whether to retry, skip, or alert — which is the
// V3 defect R4 exists to end. The codes below are stable; the messages explain
// and may be reworded.
//
// | Code     | Name                     | Cause, and what a client should do |
// |----------|--------------------------|------------------------------------|
// | `-32700` | parse error              | Body was not JSON. Fix the client. |
// | `-32600` | invalid request          | JSON, but not a JSON-RPC 2.0 request object. |
// | `-32601` | method not found         | No such method in this build. |
// | `-32602` | invalid params           | Method exists, arguments do not fit (bad hex, missing field, out of range). |
// | `-32603` | internal error           | A bug in this node. Report it. |
// | `-32000` | `BLOCK_NOT_FOUND`        | No block with that id is known. Retry after syncing, or it never existed. |
// | `-32001` | `VALIDATOR_NOT_FOUND`    | Index is not in the committed registry. |
// | `-32002` | `TX_DECODE_FAILED`       | Bytes were valid hex but are not a canonical transaction. Do not retry unchanged. |
// | `-32003` | `MEMPOOL_FULL`           | Admission refused for capacity. Retry later — the transaction is not invalid. |
// | `-32004` | `NODE_UNAVAILABLE`       | Consensus thread did not answer, or is shutting down. Retry. |
// | `-32005` | `NO_TRANSACTION_INDEX`   | This build cannot look a transaction up by id — see [`RpcError::no_transaction_index`]. Not a transient failure. |
// | `-32006` | `NO_WALLET`              | This node holds no wallet and mints no addresses — see [`RpcError::no_wallet`]. Not a transient failure. |
// | `-32007` | `SLOT_EMPTY`             | The slot exists and carries no canonical block. **Normal under PoS** (a missed proposal); advance to the next slot. |
// | `-32008` | `TX_REFUSED`             | The node judged these BYTES invalid on their merits. **Terminal**: never resubmit them. Carries no `error.data`. |
// | `-32009` | `TX_REFUSED_RETRYABLE`   | The transaction was barred against a **state**, not condemned on its bytes. **Retryable**: `error.data.until_slot` says from which slot. |
//
// ## `error.data`
//
// JSON-RPC 2.0 §5.1 allows an `error.data` member, and this surface uses it for
// exactly one thing: a value a client must ACT on that would otherwise exist
// only inside the English message. A retry deadline is the whole example — a
// client that has to regex `until slot 4242` out of a sentence is a client that
// breaks the next time the sentence is reworded, and the wording is explicitly
// the part of this contract that may change. `data` is OPTIONAL and absent on
// every code above except `-32009`: a client that ignores it still reads a
// correct `code` and `message`.

/// No block with that id is known to this node.
pub const BLOCK_NOT_FOUND: i64 = -32000;
/// The validator index is not in the committed registry.
pub const VALIDATOR_NOT_FOUND: i64 = -32001;
/// Valid hex, but not a canonical transaction encoding.
pub const TX_DECODE_FAILED: i64 = -32002;
/// The mempool is at capacity; the transaction itself was not judged invalid.
pub const MEMPOOL_FULL: i64 = -32003;
/// The consensus thread could not be reached.
pub const NODE_UNAVAILABLE: i64 = -32004;
/// There is no txid→block index. The transaction id itself exists
/// (`PosTransaction::txid`); what this node lacks is anywhere to look one up.
pub const NO_TRANSACTION_INDEX: i64 = -32005;
/// This node has no wallet and no frozen address format.
pub const NO_WALLET: i64 = -32006;
/// The slot carries no canonical block — a missed proposal, not an error state.
pub const SLOT_EMPTY: i64 = -32007;

/// The node refused a submitted transaction on its merits — it was judged
/// invalid, not deferred. Distinct from [`MEMPOOL_FULL`] because the client's
/// correct response is opposite: never resubmit these bytes.
///
/// **Terminal, and only terminal.** This code is published to integrators with
/// that meaning, so it must never come to mean "try again later" for some
/// subset of its causes: a client branching on the number alone would then be
/// wrong for half of them, which is worse than having no code at all. Any
/// refusal that time can lift belongs to [`TX_REFUSED_RETRYABLE`] — which is
/// exactly the split this constant used to be missing: `Refusal::Invalid` and
/// `Refusal::PreviouslyRefused` both landed here, distinguishable only by
/// reading the English message.
pub const TX_REFUSED: i64 = -32008;

/// A submitted transaction was barred **against a state**, not condemned on
/// its bytes — so the bar lifts on its own, and the answer says when.
///
/// # Why this is a second code rather than a second message
///
/// [`TX_REFUSED`] (-32008) is a verdict on the bytes: no passage of time
/// changes an unverifiable signature, so the only correct client behaviour is
/// to stop. A transaction can also be turned away for a reason that is true
/// *now* and false later — this node's own proposer watched the transition
/// refuse it against the current branch, most often because it spends an
/// output this branch does not have yet. The engine bars those bytes for
/// `REJECTION_TTL_SLOTS` (128 slots, ~64 minutes) and then admits them again
/// with no further action from anyone.
///
/// That is the opposite advice, and a client that reads only the code cannot
/// tell the two apart if they share one number. It is not a hypothetical: our
/// own published integration guidance says never to resubmit after -32008, so
/// an exchange following it permanently abandons transactions the node would
/// have taken an hour later.
///
/// The deadline rides in `error.data.until_slot` rather than only in the
/// message, because "retry after slot N" is a value a client must compute
/// with, and the messages on this surface are explicitly allowed to be
/// reworded while the codes are not.
pub const TX_REFUSED_RETRYABLE: i64 = -32009;

/// One source (by the first spent input's spend-authority hash) already has
/// `MEMPOOL_MAX_PER_SOURCE` transactions pending (R7 M6).
///
/// A third distinct shape, not a reuse of [`MEMPOOL_FULL`] or
/// [`TX_REFUSED_RETRYABLE`]: the mempool overall is NOT full (that is
/// `MEMPOOL_FULL`'s claim) and nothing about these bytes is wrong (so
/// `TX_REFUSED` would be false) — this source's own share of the mempool is
/// what is full, and it clears as soon as one of ITS pending transactions
/// leaves (included, expires, or is itself evicted), not on any fixed
/// schedule this response could name.
pub const TX_REFUSED_SOURCE_CAP: i64 = -32010;

/// A JSON-RPC error object: a code a client can branch on and a message a human
/// can act on. Both halves are required — a bare code makes an operator read
/// this source file, and a bare message makes a client parse English.
///
/// The optional third member is `data` (JSON-RPC 2.0 §5.1): a machine-readable
/// companion to the message, for the cases where the message contains a value
/// the client has to act on. It is `None` for every error here except
/// [`TX_REFUSED_RETRYABLE`], and a client that never looks at it is still a
/// correct client.
///
/// `Eq` is gone from the derive list because [`Json`] holds numbers as their
/// raw source text and derives only `PartialEq`. Nothing compares `RpcError`
/// for `Eq`; the codes and messages compare exactly as before.
#[derive(Clone, Debug, PartialEq)]
pub struct RpcError {
    pub code: i64,
    pub message: String,
    /// Structured detail, serialised as `error.data`. Omitted from the wire
    /// object entirely when `None` — never emitted as `null`, which a client
    /// would have to distinguish from "absent".
    pub data: Option<Json>,
}

impl RpcError {
    pub fn new(code: i64, message: impl Into<String>) -> Self {
        RpcError { code, message: message.into(), data: None }
    }

    /// Attach structured detail to an error, to be emitted as `error.data`.
    pub fn with_data(mut self, data: Json) -> Self {
        self.data = Some(data);
        self
    }

    /// [`TX_REFUSED_RETRYABLE`]: barred until `until_slot`, then admissible
    /// again — with the deadline in `data` where a client can read it.
    ///
    /// The wire shape is fixed:
    ///
    /// ```text
    /// "data": { "retryable": true, "until_slot": 4242 }
    /// ```
    ///
    /// `retryable` is redundant with the code and is there on purpose: it is
    /// the one field a generic client can branch on without a table of Bloch
    /// error numbers, and it is what keeps "did I get the retryable one?" from
    /// being answered by string-matching the message.
    ///
    /// `until_slot` is a JSON number, not a string: it is a slot index, and
    /// slot indexes are nowhere near the 2^53 boundary that makes this module
    /// render satoshis as strings (see [`Json::sat`]).
    pub fn tx_refused_retryable(until_slot: u64, detail: impl Into<String>) -> Self {
        Self::new(TX_REFUSED_RETRYABLE, detail.into()).with_data(Json::obj(vec![
            ("retryable", Json::Bool(true)),
            ("until_slot", Json::u(until_slot)),
        ]))
    }

    /// -32700: the body was not JSON.
    pub fn parse_error(detail: &str) -> Self {
        Self::new(-32700, format!("parse error: {detail}"))
    }
    /// -32600: it was JSON, but not a JSON-RPC 2.0 request.
    pub fn invalid_request(detail: &str) -> Self {
        Self::new(-32600, format!("invalid request: {detail}"))
    }
    /// -32601: no such method on this node.
    pub fn method_not_found(method: &str) -> Self {
        Self::new(-32601, format!("method not found: {method}"))
    }
    /// -32602: the method exists, the arguments do not fit it.
    pub fn invalid_params(detail: impl Into<String>) -> Self {
        Self::new(-32602, format!("invalid params: {}", detail.into()))
    }
    /// [`NODE_UNAVAILABLE`]: the consensus thread could not be reached.
    pub fn unavailable(detail: impl Into<String>) -> Self {
        Self::new(NODE_UNAVAILABLE, detail.into())
    }

    /// [`NO_TRANSACTION_INDEX`] — `gettransaction`'s permanent answer in this
    /// build. The missing thing is an INDEX, not an identity.
    ///
    /// A `PosTransaction` does have a transaction id, and every node agrees on
    /// it: `PosTransaction::txid` (`bloch-pos-committee/src/transition.rs`) is
    /// `SHA3-256(DS_TXID ‖ spend_signing_root)`, and it is consensus-committed
    /// — the transfer arms of `apply_transaction` key every created
    /// `EutxoEntry` by `(txid, vout)`, so the state root the whole network
    /// checks commits to it. A `Transfer` is not fee-market terms only either:
    /// it carries `inputs`, `outputs` (each a value and a `script_hash`),
    /// `tx_bytes` and `tip_millisat_per_gas`. This module both serves and
    /// consumes that id — `eutxo_json` emits `txid`, and `gettxout` takes one
    /// as a parameter.
    ///
    /// What is absent is the txid→block index. Blocks commit to a `body_root`
    /// over the canonical *bytes*, and the store is an append-only block log
    /// with no secondary index, so answering `gettransaction` would mean
    /// scanning every block in the log on every call. The transaction may well
    /// be on this chain; this node simply cannot find it by id — which is why
    /// this is a distinct code and not [`BLOCK_NOT_FOUND`].
    pub fn no_transaction_index() -> Self {
        Self::new(
            NO_TRANSACTION_INDEX,
            "this node keeps no transaction index: a transaction does have an id \
             (`PosTransaction::txid`, the same id the eUTXO set is keyed by and \
             that `listunspent` and `gettxout` use), but the block store is an \
             append-only log with no txid-to-block mapping, so it cannot be \
             looked up by id here. Track deposits by scanning blocks via \
             `getblockbyslot` and reading the eUTXO set via `getbalance` / \
             `listunspent`, both of which are exact and both of which return the \
             txid. This is a permanent answer for this build, not a transient \
             failure — do not retry.",
        )
    }

    /// [`NO_WALLET`] — `getnewaddress` cannot be served, on two independent
    /// grounds, and neither is a scheduling accident.
    ///
    /// First: **a node RPC must never mint keys.** Key generation belongs in a
    /// wallet the operator controls; a node that mints a keypair on an
    /// unauthenticated port and hands back an address has generated key
    /// material in an observable session, with no record of who asked. Rule
    /// zero of `BLOCH-GENESIS-KEYS.md` puts production key generation on an
    /// air-gapped machine operated by a human, and this port is the opposite of
    /// that in every respect.
    ///
    /// Second, and it would block the method even if the first did not:
    /// Genesis-4 has **no frozen address format**. `withdrawal_credentials` is
    /// declared as opaque bytes precisely because the address format belongs to
    /// a transaction layer that does not exist yet (recorded as an open point in
    /// `BLOCH-POS-INTERFACES.md`). There is no string this method could return
    /// that a later build would still honour.
    pub fn no_wallet() -> Self {
        Self::new(
            NO_WALLET,
            "this node holds no wallet and does not generate addresses. Two reasons, \
             both permanent for this build: a node RPC must never mint key material \
             (production keys are generated by a human on an air-gapped machine, per \
             BLOCH-GENESIS-KEYS.md), and Genesis-4 has not frozen an address format \
             yet — `withdrawal_credentials` is opaque bytes by declaration, so any \
             address returned here could not be honoured later. Generate deposit \
             addresses in your own wallet and watch them with `getbalance` / \
             `listunspent`, which take a 32-byte script hash.",
        )
    }
}

pub type RpcResult = Result<Json, RpcError>;

// ─── Minimal JSON ───────────────────────────────────────────────────────────

/// A JSON value.
///
/// Numbers are held as their **raw source text** rather than as `f64`. That is
/// the whole R3 concern in the type system: an id of `9007199254740993` or a
/// satoshi amount must survive a round trip, and it cannot if it passes through
/// a double. This layer never does arithmetic on a parsed number, so the raw
/// token is not merely sufficient — it is strictly more faithful.
#[derive(Clone, Debug, PartialEq)]
pub enum Json {
    Null,
    Bool(bool),
    /// Invariant: always a valid JSON number literal.
    Num(String),
    Str(String),
    Arr(Vec<Json>),
    Obj(Vec<(String, Json)>),
}

impl Json {
    /// An unsigned integer, as a JSON number. For counts, slots, epochs and
    /// indexes — never for satoshis (see [`Json::sat`]).
    pub fn u(n: u64) -> Json {
        Json::Num(n.to_string())
    }

    /// A satoshi amount, as a decimal **string** (R3).
    ///
    /// `u128` in, string out, with no lossy step anywhere between: the
    /// consensus types carry `u128` because sums of balances wrap `u64`, and
    /// the wire carries a string because 10^19 does not fit a double. Every
    /// satoshi-denominated field in this module goes through here.
    pub fn sat(v: u128) -> Json {
        Json::Str(v.to_string())
    }

    pub fn s(v: impl Into<String>) -> Json {
        Json::Str(v.into())
    }

    pub fn hex(b: &[u8; 32]) -> Json {
        Json::Str(crate::codec::hex32(b))
    }

    pub fn obj(fields: Vec<(&str, Json)>) -> Json {
        Json::Obj(fields.into_iter().map(|(k, v)| (k.to_string(), v)).collect())
    }

    pub fn as_str(&self) -> Option<&str> {
        match self {
            Json::Str(s) => Some(s),
            _ => None,
        }
    }

    /// The value as a `u64`, from either a JSON number or a decimal string.
    ///
    /// Strings are accepted because R3 makes every client string-minded about
    /// large integers; refusing `"41290"` for a slot would be gratuitous.
    /// Non-integers (`1.5`, `1e3`) are refused rather than truncated.
    pub fn as_u64(&self) -> Option<u64> {
        match self {
            Json::Num(raw) => raw.parse().ok(),
            Json::Str(s) => s.parse().ok(),
            _ => None,
        }
    }

    pub fn get(&self, key: &str) -> Option<&Json> {
        match self {
            Json::Obj(fields) => fields.iter().find(|(k, _)| k == key).map(|(_, v)| v),
            _ => None,
        }
    }

    pub fn at(&self, i: usize) -> Option<&Json> {
        match self {
            Json::Arr(items) => items.get(i),
            _ => None,
        }
    }

    /// Serialise. Total: every `Json` has a rendering, so this cannot fail.
    pub fn write(&self, out: &mut String) {
        match self {
            Json::Null => out.push_str("null"),
            Json::Bool(true) => out.push_str("true"),
            Json::Bool(false) => out.push_str("false"),
            Json::Num(raw) => out.push_str(raw),
            Json::Str(s) => write_string(s, out),
            Json::Arr(items) => {
                out.push('[');
                for (i, v) in items.iter().enumerate() {
                    if i > 0 {
                        out.push(',');
                    }
                    v.write(out);
                }
                out.push(']');
            }
            Json::Obj(fields) => {
                out.push('{');
                for (i, (k, v)) in fields.iter().enumerate() {
                    if i > 0 {
                        out.push(',');
                    }
                    write_string(k, out);
                    out.push(':');
                    v.write(out);
                }
                out.push('}');
            }
        }
    }

    pub fn to_string(&self) -> String {
        let mut s = String::new();
        self.write(&mut s);
        s
    }
}

fn write_string(s: &str, out: &mut String) {
    out.push('"');
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            // Every other control character must be escaped or the output is
            // not JSON. Non-ASCII passes through as UTF-8, which is legal and
            // avoids a surrogate-encoding step nothing here needs.
            c if (c as u32) < 0x20 => out.push_str(&format!("\\u{:04x}", c as u32)),
            c => out.push(c),
        }
    }
    out.push('"');
}

/// Nesting depth accepted while parsing.
///
/// This is a stack-overflow bound, not a taste judgement: the parser is
/// recursive, and `[[[[[…` repeated far enough aborts the *process* — which on
/// a validator means an unauthenticated request killing a node. A depth limit
/// is the fix; `deeply_nested_json_is_refused_not_fatal` pins it.
const MAX_DEPTH: u32 = 64;

struct Parser<'a> {
    b: &'a [u8],
    i: usize,
    depth: u32,
}

/// Parse one JSON value from `text`, which must contain nothing else.
pub fn parse_json(text: &str) -> Result<Json, &'static str> {
    let mut p = Parser { b: text.as_bytes(), i: 0, depth: 0 };
    p.ws();
    let v = p.value()?;
    p.ws();
    if p.i != p.b.len() {
        return Err("trailing bytes after the top-level value");
    }
    Ok(v)
}

impl<'a> Parser<'a> {
    /// Move the cursor `n` bytes forward. The one place the cursor is added
    /// to: every caller has just observed `n` bytes at `i` (a `peek`/`get`
    /// that returned `Some`, a `starts_with` that matched, a `get(i..i + 4)`
    /// that was in range), so `i + n <= b.len() <= isize::MAX` and the add
    /// cannot overflow.
    #[allow(clippy::arithmetic_side_effects)]
    fn advance(&mut self, n: usize) {
        self.i += n;
    }

    fn ws(&mut self) {
        while matches!(self.b.get(self.i), Some(b' ' | b'\t' | b'\n' | b'\r')) {
            self.advance(1);
        }
    }

    fn peek(&self) -> Option<u8> {
        self.b.get(self.i).copied()
    }

    fn eat(&mut self, lit: &[u8]) -> bool {
        if self.b[self.i..].starts_with(lit) {
            self.advance(lit.len());
            true
        } else {
            false
        }
    }

    fn value(&mut self) -> Result<Json, &'static str> {
        // Same refusal for the (unreachable) u32 overflow as for the depth cap.
        self.depth = self.depth.checked_add(1).ok_or("nesting too deep")?;
        if self.depth > MAX_DEPTH {
            return Err("nesting too deep");
        }
        let v = match self.peek().ok_or("unexpected end of input")? {
            b'{' => self.object(),
            b'[' => self.array(),
            b'"' => self.string().map(Json::Str),
            b't' => {
                if self.eat(b"true") {
                    Ok(Json::Bool(true))
                } else {
                    Err("invalid literal")
                }
            }
            b'f' => {
                if self.eat(b"false") {
                    Ok(Json::Bool(false))
                } else {
                    Err("invalid literal")
                }
            }
            b'n' => {
                if self.eat(b"null") {
                    Ok(Json::Null)
                } else {
                    Err("invalid literal")
                }
            }
            b'-' | b'0'..=b'9' => self.number(),
            _ => Err("unexpected character"),
        };
        // cannot underflow: incremented at the top of this call, and every
        // nested `value` leaves `depth` at least where it found it.
        #[allow(clippy::arithmetic_side_effects)]
        {
            self.depth -= 1;
        }
        v
    }

    fn object(&mut self) -> Result<Json, &'static str> {
        self.advance(1); // '{'
        let mut fields = Vec::new();
        self.ws();
        if self.peek() == Some(b'}') {
            self.advance(1);
            return Ok(Json::Obj(fields));
        }
        loop {
            self.ws();
            if self.peek() != Some(b'"') {
                return Err("object key must be a string");
            }
            let k = self.string()?;
            self.ws();
            if self.peek() != Some(b':') {
                return Err("expected ':' after object key");
            }
            self.advance(1);
            self.ws();
            let v = self.value()?;
            fields.push((k, v));
            self.ws();
            match self.peek() {
                Some(b',') => self.advance(1),
                Some(b'}') => {
                    self.advance(1);
                    return Ok(Json::Obj(fields));
                }
                _ => return Err("expected ',' or '}' in object"),
            }
        }
    }

    fn array(&mut self) -> Result<Json, &'static str> {
        self.advance(1); // '['
        let mut items = Vec::new();
        self.ws();
        if self.peek() == Some(b']') {
            self.advance(1);
            return Ok(Json::Arr(items));
        }
        loop {
            self.ws();
            items.push(self.value()?);
            self.ws();
            match self.peek() {
                Some(b',') => self.advance(1),
                Some(b']') => {
                    self.advance(1);
                    return Ok(Json::Arr(items));
                }
                _ => return Err("expected ',' or ']' in array"),
            }
        }
    }

    fn string(&mut self) -> Result<String, &'static str> {
        self.advance(1); // opening quote
        let mut s = String::new();
        loop {
            // Where this byte starts, for the raw-UTF-8 arm below.
            let start = self.i;
            let c = *self.b.get(self.i).ok_or("unterminated string")?;
            self.advance(1);
            match c {
                b'"' => return Ok(s),
                b'\\' => {
                    let e = *self.b.get(self.i).ok_or("unterminated escape")?;
                    self.advance(1);
                    match e {
                        b'"' => s.push('"'),
                        b'\\' => s.push('\\'),
                        b'/' => s.push('/'),
                        b'b' => s.push('\u{08}'),
                        b'f' => s.push('\u{0c}'),
                        b'n' => s.push('\n'),
                        b'r' => s.push('\r'),
                        b't' => s.push('\t'),
                        b'u' => {
                            let hi = self.hex4()?;
                            // A lone surrogate is not a character. Pair it when
                            // the low half follows, and otherwise substitute
                            // U+FFFD — never fail, and never panic on a
                            // `char::from_u32` of a surrogate.
                            let cp = if (0xD800..0xDC00).contains(&hi) {
                                if self.b[self.i..].starts_with(b"\\u") {
                                    let save = self.i;
                                    self.advance(2);
                                    let lo = self.hex4()?;
                                    if (0xDC00..0xE000).contains(&lo) {
                                        // cannot overflow: hi in D800..DC00 and lo in
                                        // DC00..E000 (both checked), so this is < 0x110000.
                                        #[allow(clippy::arithmetic_side_effects)]
                                        {
                                            0x10000 + ((hi - 0xD800) << 10) + (lo - 0xDC00)
                                        }
                                    } else {
                                        self.i = save;
                                        0xFFFD
                                    }
                                } else {
                                    0xFFFD
                                }
                            } else if (0xDC00..0xE000).contains(&hi) {
                                0xFFFD
                            } else {
                                hi
                            };
                            s.push(char::from_u32(cp).unwrap_or('\u{FFFD}'));
                        }
                        _ => return Err("invalid escape"),
                    }
                }
                // Raw control characters are illegal inside a JSON string.
                0x00..=0x1F => return Err("control character in string"),
                // UTF-8 continuation: copy the whole sequence verbatim. The
                // input is a `&str`, so it is already valid UTF-8 and the
                // boundary walk cannot land mid-character.
                _ => {
                    while self.b.get(self.i).is_some_and(|b| b & 0xC0 == 0x80) {
                        self.advance(1);
                    }
                    match std::str::from_utf8(&self.b[start..self.i]) {
                        Ok(chunk) => s.push_str(chunk),
                        Err(_) => return Err("invalid utf-8 in string"),
                    }
                }
            }
        }
    }

    fn hex4(&mut self) -> Result<u32, &'static str> {
        // An end offset that does not fit is as truncated as one past the buffer.
        let bytes = self
            .i
            .checked_add(4)
            .and_then(|end| self.b.get(self.i..end))
            .ok_or("truncated \\u escape")?;
        let text = std::str::from_utf8(bytes).map_err(|_| "invalid \\u escape")?;
        let v = u32::from_str_radix(text, 16).map_err(|_| "invalid \\u escape")?;
        self.advance(4);
        Ok(v)
    }

    fn number(&mut self) -> Result<Json, &'static str> {
        let start = self.i;
        if self.peek() == Some(b'-') {
            self.advance(1);
        }
        // The integer part is `0` or `[1-9][0-9]*` — JSON forbids leading
        // zeros, and accepting `01` would make this parser more permissive than
        // the grammar every client encodes against. That matters more here than
        // it looks: a number with two spellings is a value with two encodings,
        // and this module's whole reason for keeping numeric *text* is that a
        // request id and an amount must round-trip as written.
        match self.peek() {
            Some(b'0') => {
                self.advance(1);
                if matches!(self.peek(), Some(b'0'..=b'9')) {
                    return Err("number has a leading zero");
                }
            }
            Some(b'1'..=b'9') => {
                self.digits();
            }
            _ => return Err("number has no integer part"),
        }
        if self.peek() == Some(b'.') {
            self.advance(1);
            if self.digits() == 0 {
                return Err("number has no fractional digits");
            }
        }
        if matches!(self.peek(), Some(b'e' | b'E')) {
            self.advance(1);
            if matches!(self.peek(), Some(b'+' | b'-')) {
                self.advance(1);
            }
            if self.digits() == 0 {
                return Err("number has no exponent digits");
            }
        }
        // Valid UTF-8 by construction: the slice is ASCII digits and signs.
        Ok(Json::Num(String::from_utf8_lossy(&self.b[start..self.i]).into_owned()))
    }

    fn digits(&mut self) -> usize {
        let start = self.i;
        while matches!(self.peek(), Some(b'0'..=b'9')) {
            self.advance(1);
        }
        // cannot underflow: the cursor only moved forward from `start`.
        #[allow(clippy::arithmetic_side_effects)]
        {
            self.i - start
        }
    }
}

// ─── Hex ────────────────────────────────────────────────────────────────────

/// Decode a hex string (optionally `0x`-prefixed). `None` on any malformed
/// input — odd length, non-hex digit — rather than a partial decode.
pub fn from_hex(s: &str) -> Option<Vec<u8>> {
    let s = s.strip_prefix("0x").unwrap_or(s);
    if s.len() % 2 != 0 {
        return None;
    }
    let b = s.as_bytes();
    let mut out = Vec::with_capacity(s.len() / 2);
    for pair in b.chunks_exact(2) {
        let hi = (pair[0] as char).to_digit(16)?;
        let lo = (pair[1] as char).to_digit(16)?;
        // `to_digit(16)` yields 0..=15, so `hi << 4 | lo` is exactly `hi * 16 + lo` and fits a u8.
        out.push(((hi << 4) | lo) as u8);
    }
    Some(out)
}

fn hex32_from(s: &str) -> Option<[u8; 32]> {
    let bytes = from_hex(s)?;
    bytes.try_into().ok()
}

// ─── The request surface ────────────────────────────────────────────────────

/// A decoded call, with its arguments already validated into node types.
///
/// The dispatcher turns JSON into one of these and the engine turns one of
/// these into JSON. Neither half handles the other's failure modes: by the time
/// a request reaches the engine, "the slot was not a number" has already been
/// answered, and by the time a reply reaches the dispatcher, "no such block"
/// has already been decided.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum RpcRequest {
    ChainInfo,
    /// `getbuildinfo` — which binary is answering. Reads no chain state.
    BuildInfo,
    /// `getblockcount` — the polling method, carrying finality with it.
    BlockCount,
    BlockBySlot(u64),
    BlockById([u8; 32]),
    Validator(u32),
    ValidatorCount,
    ValidatorByKey([u8; 32]),
    ValidatorAdmission,
    Balance([u8; 32]),
    Utxos { script_hash: [u8; 32], limit: usize },
    /// `gettxout` — is this ONE output still unspent?
    ///
    /// Exists because `listunspent` cannot answer it. That method takes a
    /// script hash and a limit, has no cursor, and caps at `UTXO_PAGE_MAX`
    /// (1,000). The founder's script hash holds 425,568 outputs on the live
    /// chain, so 424,568 of them are unreachable through it: the same first
    /// page comes back every time.
    ///
    /// That gap has a consequence beyond convenience. The vesting-lock flag day
    /// has a go/no-go precondition — the founder and team allocation outpoints
    /// must still be unspent when the rule arms, or the lock seeds nothing and
    /// silently never exists for that bucket. The runbook asks an operator to
    /// confirm that by RPC, and until this method existed no such query was
    /// possible. A holder also could not audit their own position beyond an
    /// aggregate balance and an arbitrary first thousand outputs.
    ///
    /// Read-only: no consensus surface, no flag day.
    TxOut { txid: [u8; 32], vout: u32 },
    /// A transaction that **already decoded**.
    ///
    /// Decoding happens at this edge, not in the engine, for the same reason
    /// `net::decode_event` decodes at the network edge: bytes this build cannot
    /// read must never reach the mempool, because a proposer would then commit
    /// to a body it cannot reproduce. It also means "these bytes are not a
    /// transaction" is answered as `invalid params` by a pure function, which
    /// is what makes it testable without standing up a node.
    SendRawTransaction(PosTransaction),
    MempoolInfo,
    /// `getvalidators` (R4 F-11) — the whole registry, one call. Unlike
    /// `getvalidator` (one index) this has no cursor and no cap: the live
    /// validator set is 64 and R4 F-13 already names "the validator set
    /// cannot grow" as its own open finding, so an unbounded dump here is
    /// bounded in practice by that ceiling, not by anything this method adds.
    /// The day the set can grow past a few hundred, this needs pagination —
    /// not before.
    Validators,
    /// `gettxstatus` (R4 F-11) — `pending | included | justified | finalized
    /// | unknown` for one transaction id. Backed by the mempool (`pending`)
    /// and `Engine::tx_slot_index` (`included`/`justified`/`finalized`); see
    /// `Engine::serve_rpc`'s arm for the exact precedence.
    TxStatus([u8; 32]),
}

/// Whatever can answer an [`RpcRequest`]. In production this is the channel to
/// the consensus thread; in tests it is a stub, which is the point — the HTTP
/// and JSON layers are exercised without standing up a node.
pub trait RpcBackend: Send + Sync + 'static {
    fn call(&self, req: RpcRequest) -> RpcResult;
}

/// One in-flight request handed to the consensus thread, with the channel it
/// must answer on.
pub struct RpcCall {
    pub req: RpcRequest,
    pub reply: Sender<RpcResult>,
}

/// The production backend: hand the request to the engine's event loop and wait
/// — except for the two ledger reads, which are answered from the published
/// head (see [`Self::from_head`]).
///
/// Nearly everything goes through the consensus thread rather than through a
/// shared snapshot of state, and that is a deliberate cost. The engine's whole
/// design is "one thread owns all consensus state; nothing else mutates it"; a
/// cached state-shaped copy updated alongside is a second source of truth that
/// can drift, which is the `expected_bits` failure in miniature. Serialising
/// queries behind the loop means a query can never observe a half-applied
/// block, and it means no reader can be looking at last epoch's answer.
///
/// **The exception, and why it does not reopen that.** `getbalance` and
/// `getutxos` are served from an `Arc<CommittedState>` the consensus thread
/// publishes — the identical value it holds, not a copy shaped like it, so
/// there is nothing to drift and no half-applied state to observe. They earn
/// the exception because they were the only reads whose cost scaled with the
/// LEDGER rather than with the answer, and on 2026-08-21 that cost was paid by
/// the slot loop while the node missed its duties. The `expected_bits` lesson
/// is about a second *derivation* of a consensus value; this is the same
/// value, handed over by reference.
pub struct EngineBackend {
    /// `Mutex` because `mpsc::Sender` only became `Sync` in Rust 1.72 and this
    /// crate pins no MSRV. The lock is held exactly long enough to clone.
    engine: Mutex<Sender<crate::engine::EngineEvent>>,
    /// The committed head, for the reads listed in [`Self::from_head`].
    ///
    /// `Option` because the engine is not the only thing that constructs this
    /// backend, and a backend with no handle behaves exactly as it did before
    /// this field existed: everything goes through the loop.
    head: Option<crate::engine::SharedHead>,
}

impl EngineBackend {
    pub fn new(engine: Sender<crate::engine::EngineEvent>) -> Self {
        EngineBackend { engine: Mutex::new(engine), head: None }
    }

    /// The production constructor: the channel to the loop, plus the handle on
    /// the committed head the ledger reads are answered from.
    pub fn with_head(
        engine: Sender<crate::engine::EngineEvent>,
        head: crate::engine::SharedHead,
    ) -> Self {
        EngineBackend { engine: Mutex::new(engine), head: Some(head) }
    }

    /// Answer `req` from the published head, or `None` if it is not one of the
    /// requests that may be answered there.
    ///
    /// # Which requests, and why only these
    ///
    /// `getbalance` and `getutxos` read the eUTXO set and nothing else. They
    /// touch no mempool, no block store and no fork-choice store — the three
    /// things that live only on the consensus thread — so a committed state is
    /// a complete answer to them.
    ///
    /// They are also the only two reads whose cost is set by the size of the
    /// **ledger** rather than by the size of the answer, which is what makes
    /// this necessary rather than merely nice: on 2026-08-21 a balance query
    /// over the founder's 452,726 outputs sat in the slot loop for its whole
    /// duration, and the node missed duties while an honest holder waited for
    /// a number. The script index makes that query small; serving it here
    /// makes a query that is somehow still large stop being the node's
    /// problem. Both halves are needed — an index alone leaves the loop
    /// exposed to the next unbounded read, and a snapshot alone leaves the
    /// query paying for the whole set on a thread that has to answer many of
    /// them at once.
    ///
    /// **Staleness, stated.** The answer is the state at this node's committed
    /// head at the instant of the read — the same state the loop would have
    /// used, since the loop applies a block by *replacing* this value. It can
    /// be one block older than an answer the loop would give if a block lands
    /// between the clone and the reply, which was already true of the channel
    /// path (the reply crosses a channel too). No caller can observe a
    /// half-applied block either way.
    fn from_head(&self, req: &RpcRequest) -> Option<RpcResult> {
        let head = self.head.as_ref()?;
        // Matched BEFORE the state is cloned, so a request that must go to the
        // loop does not even touch the lock.
        match req {
            RpcRequest::Balance(_) | RpcRequest::Utxos { .. } => {}
            _ => return None,
        }
        // The lock is held for one `Arc::clone` and dropped. The query below
        // runs on a state this thread owns a reference to, so the consensus
        // thread can replace the published head — and go on proposing —
        // while the query is still running.
        let state = {
            let guard = match head.lock() {
                Ok(g) => g,
                Err(poisoned) => poisoned.into_inner(),
            };
            Arc::clone(&guard)
        };
        match req {
            RpcRequest::Balance(script_hash) => Some(Ok(balance_json(&state, script_hash))),
            RpcRequest::Utxos { script_hash, limit } => {
                Some(Ok(utxos_json(&state, script_hash, *limit)))
            }
            _ => None,
        }
    }
}

impl RpcBackend for EngineBackend {
    fn call(&self, req: RpcRequest) -> RpcResult {
        if let Some(answered) = self.from_head(&req) {
            return answered;
        }
        let (tx, rx) = mpsc::channel::<RpcResult>();
        let sender = match self.engine.lock() {
            Ok(guard) => guard.clone(),
            // Poisoned only if a thread panicked while holding it. The channel
            // itself is still fine, but saying so honestly beats unwrapping.
            Err(poisoned) => poisoned.into_inner().clone(),
        };
        if sender.send(crate::engine::EngineEvent::Rpc(RpcCall { req, reply: tx })).is_err() {
            return Err(RpcError::unavailable("node is shutting down"));
        }
        match rx.recv_timeout(ENGINE_TIMEOUT) {
            Ok(result) => result,
            Err(mpsc::RecvTimeoutError::Timeout) => Err(RpcError::unavailable(format!(
                "consensus thread did not answer within {}s",
                ENGINE_TIMEOUT.as_secs()
            ))),
            Err(mpsc::RecvTimeoutError::Disconnected) => {
                Err(RpcError::unavailable("node is shutting down"))
            }
        }
    }
}

// ─── Dispatch ───────────────────────────────────────────────────────────────

/// Read argument `pos` (positional) or `name` (named). Supporting both costs
/// four lines and spares every client the guess.
fn pick<'a>(params: Option<&'a Json>, pos: usize, name: &str) -> Option<&'a Json> {
    match params? {
        arr @ Json::Arr(_) => arr.at(pos),
        obj @ Json::Obj(_) => obj.get(name),
        _ => None,
    }
}

fn want_u64(params: Option<&Json>, pos: usize, name: &str) -> Result<u64, RpcError> {
    pick(params, pos, name)
        .ok_or_else(|| RpcError::invalid_params(format!("missing `{name}`")))?
        .as_u64()
        .ok_or_else(|| {
            RpcError::invalid_params(format!("`{name}` must be a non-negative integer"))
        })
}

fn want_u32(params: Option<&Json>, pos: usize, name: &str) -> Result<u32, RpcError> {
    let v = want_u64(params, pos, name)?;
    u32::try_from(v).map_err(|_| {
        RpcError::invalid_params(format!("`{name}` must fit in 32 bits (got {v})"))
    })
}

fn want_hex32(params: Option<&Json>, pos: usize, name: &str) -> Result<[u8; 32], RpcError> {
    let raw = pick(params, pos, name)
        .ok_or_else(|| RpcError::invalid_params(format!("missing `{name}`")))?
        .as_str()
        .ok_or_else(|| RpcError::invalid_params(format!("`{name}` must be a hex string")))?;
    hex32_from(raw).ok_or_else(|| {
        RpcError::invalid_params(format!("`{name}` must be 32 bytes of hex (64 characters)"))
    })
}

/// Turn a method name and its params into a request, or say precisely why not.
///
/// # The exchange-integration surface
///
/// Six of these names are the ones a Genesis-3 integration already calls, kept
/// verbatim so a client ports by re-pointing its endpoint rather than by being
/// rewritten. Each is mapped to the PoS model without inventing semantics:
///
/// - `getbalance`, `listunspent` — read the eUTXO set out of `CommittedState`.
///   `listunspent` is the same request as `getutxos`; two names, one meaning,
///   because inventing a second semantics for the second name is how a client
///   ends up with two disagreeing balances.
/// - `getblockcount` — canonical height, plus the slot/epoch it sits at and the
///   finality that height is entitled to (see [`block_count_json`]).
/// - `sendrawtransaction` — canonical bytes in, mempool admission out.
/// - `gettransaction` — **refused**, with [`RpcError::no_transaction_index`].
///   The transaction has an id (`PosTransaction::txid`, the key of every eUTXO
///   entry this node serves); what is missing is a txid→block index to look it
///   up in, and scanning the whole block log per call is not a lookup.
/// - `getnewaddress` — **refused**, with [`RpcError::no_wallet`]. A node RPC
///   does not mint key material, and no address format is frozen.
///
/// Beside them, `getbuildinfo` answers a question this surface could not
/// answer at all before: **which binary is this?** See [`build_info_json`].
/// It is the ONLY method that answers it — see the registry note on
/// [`build_info_json`] and `tests/rpc_method_registry.rs`.
///
/// The refusals are routed here, as methods that exist and answer, rather than
/// left to fall through to `method not found`. The distinction is the whole
/// point: "this node cannot do that, here is why, do not retry" is actionable,
/// and "no such method" would send an integrator looking for a newer build.
pub fn route(method: &str, params: Option<&Json>) -> Result<RpcRequest, RpcError> {
    Ok(match method {
        "getchaininfo" => RpcRequest::ChainInfo,
        "getbuildinfo" => RpcRequest::BuildInfo,
        "getblockcount" => RpcRequest::BlockCount,
        "getblockbyslot" => RpcRequest::BlockBySlot(want_u64(params, 0, "slot")?),
        "getblockbyid" => RpcRequest::BlockById(want_hex32(params, 0, "block_id")?),
        "getvalidator" => RpcRequest::Validator(want_u32(params, 0, "index")?),
        "getvalidatorcount" => RpcRequest::ValidatorCount,
        "getvalidatorbykey" => RpcRequest::ValidatorByKey(want_hex32(params, 0, "pubkey_hash")?),
        "getvalidatoradmission" => RpcRequest::ValidatorAdmission,
        "getbalance" => RpcRequest::Balance(want_hex32(params, 0, "script_hash")?),
        // Refused on purpose, and permanently for this build. See the doc
        // comments on the two constructors for the full reasoning.
        "gettransaction" => return Err(RpcError::no_transaction_index()),
        "getnewaddress" => return Err(RpcError::no_wallet()),
        "gettxout" => {
            let txid = want_hex32(params, 0, "txid")?;
            let vout = match pick(params, 1, "vout") {
                None | Some(Json::Null) => 0,
                Some(v) => {
                    let n = v.as_u64().ok_or_else(|| {
                        RpcError::invalid_params("`vout` must be a non-negative integer")
                    })?;
                    u32::try_from(n).map_err(|_| {
                        RpcError::invalid_params("`vout` does not fit in 32 bits")
                    })?
                }
            };
            RpcRequest::TxOut { txid, vout }
        }
        "getutxos" | "listunspent" => {
            let script_hash = want_hex32(params, 0, "script_hash")?;
            let limit = match pick(params, 1, "limit") {
                None | Some(Json::Null) => UTXO_PAGE_DEFAULT,
                Some(v) => {
                    let n = v.as_u64().ok_or_else(|| {
                        RpcError::invalid_params("`limit` must be a non-negative integer")
                    })?;
                    (n as usize).clamp(1, UTXO_PAGE_MAX)
                }
            };
            RpcRequest::Utxos { script_hash, limit }
        }
        "sendrawtransaction" => {
            let raw = pick(params, 0, "hex")
                .ok_or_else(|| RpcError::invalid_params("missing `hex`"))?
                .as_str()
                .ok_or_else(|| {
                    RpcError::invalid_params("`hex` must be a hex string of the canonical bytes")
                })?;
            let bytes = from_hex(raw)
                .ok_or_else(|| RpcError::invalid_params("`hex` is not valid hexadecimal"))?;
            if bytes.is_empty() {
                return Err(RpcError::invalid_params("`hex` decoded to zero bytes"));
            }
            // Two distinct causes, two distinct codes: bad hex above is a
            // client-side encoding mistake (-32602), while hex that decodes to
            // bytes which are not a canonical transaction is a different
            // failure the client must not retry unchanged (TX_DECODE_FAILED).
            let tx = PosTransaction::from_canonical_bytes(&bytes).map_err(|e| {
                RpcError::new(
                    TX_DECODE_FAILED,
                    format!("not a canonical Genesis-4 transaction: {e}"),
                )
            })?;
            RpcRequest::SendRawTransaction(tx)
        }
        "getmempoolinfo" => RpcRequest::MempoolInfo,
        // R4 F-11.
        "getvalidators" => RpcRequest::Validators,
        "gettxstatus" => RpcRequest::TxStatus(want_hex32(params, 0, "txid")?),
        other => return Err(RpcError::method_not_found(other)),
    })
}

fn envelope(id: Json, outcome: RpcResult) -> String {
    let body = match outcome {
        Ok(result) => Json::Obj(vec![
            ("jsonrpc".into(), Json::s("2.0")),
            ("id".into(), id),
            ("result".into(), result),
        ]),
        // R4: failures are the top-level `error` object, never a string inside
        // `result` under HTTP 200.
        Err(e) => {
            // `data` is written only when there is data. An `error.data: null`
            // would be a third state a client has to tell apart from absence,
            // for no gain — JSON-RPC 2.0 §5.1 makes the member optional, so
            // absence is the honest encoding of "nothing structured to add",
            // and every code that predates `data` keeps the exact shape it
            // has always had on the wire.
            let mut err = vec![
                ("code".to_string(), Json::Num(e.code.to_string())),
                ("message".to_string(), Json::s(e.message)),
            ];
            if let Some(data) = e.data {
                err.push(("data".to_string(), data));
            }
            Json::Obj(vec![
                ("jsonrpc".into(), Json::s("2.0")),
                ("id".into(), id),
                ("error".into(), Json::Obj(err)),
            ])
        }
    };
    body.to_string()
}

/// Handle one request body and return one response body.
///
/// Total on every input: any byte string produces a JSON-RPC response, and no
/// input path can panic. That is the property `malformed_input_never_panics`
/// exercises, and it is not a nicety — this is an unauthenticated port, so
/// "malformed input crashes the node" and "anyone can stop the validator" are
/// the same sentence.
pub fn handle_body(body: &str, backend: &dyn RpcBackend) -> String {
    let request = match parse_json(body) {
        Ok(v) => v,
        Err(why) => return envelope(Json::Null, Err(RpcError::parse_error(why))),
    };

    if matches!(request, Json::Arr(_)) {
        return envelope(
            Json::Null,
            Err(RpcError::invalid_request(
                "batch requests are not supported; send one call per request",
            )),
        );
    }
    if !matches!(request, Json::Obj(_)) {
        return envelope(
            Json::Null,
            Err(RpcError::invalid_request("a request must be a JSON object")),
        );
    }

    // Echo the id whatever it is, including absent (null). A client correlating
    // responses must get its id back even when the rest of the request was
    // nonsense — that is the only thing tying an error to the call that caused
    // it. Ids that are objects or arrays are out of spec but are echoed rather
    // than rewritten, because rewriting one breaks correlation silently.
    let id = request.get("id").cloned().unwrap_or(Json::Null);

    if let Some(v) = request.get("jsonrpc") {
        if v.as_str() != Some("2.0") {
            return envelope(id, Err(RpcError::invalid_request("`jsonrpc` must be \"2.0\"")));
        }
    }

    let Some(method) = request.get("method").and_then(Json::as_str) else {
        return envelope(id, Err(RpcError::invalid_request("`method` must be a string")));
    };

    let params = request.get("params").filter(|p| !matches!(p, Json::Null));
    let outcome = route(method, params).and_then(|req| backend.call(req));
    envelope(id, outcome)
}

// ─── HTTP/1.1, the subset a JSON-RPC client uses ────────────────────────────

/// Start the RPC server on `bind_addr:port` and return the address it actually
/// bound (which is how a test asks for port 0 and learns what it got).
///
/// # Exposure
///
/// This server authenticates nothing. `bind_addr` is `127.0.0.1` unless the
/// operator passed `--rpc-bind`, and a routable bind must be firewalled to the
/// clients that are meant to reach it. `sendrawtransaction` is a write, so an
/// open port is not merely a read leak.
pub fn serve(
    bind_addr: &str,
    port: u16,
    backend: Arc<dyn RpcBackend>,
) -> io::Result<SocketAddr> {
    let listener = TcpListener::bind((bind_addr, port))?;
    let local = listener.local_addr()?;
    let live = Arc::new(AtomicUsize::new(0));
    // Computed once per bind, not per request (R1 A3-M4): env and the bound
    // address are both fixed for the life of this listener.
    let hosts = Arc::new(HostPolicy::new(bind_addr));
    thread::spawn(move || {
        for conn in listener.incoming() {
            let Ok(sock) = conn else { continue };
            // Reserve a slot before spawning: incrementing inside the thread
            // would let an unbounded burst spawn first and count later.
            if live.fetch_add(1, Ordering::SeqCst) >= MAX_CONNECTIONS {
                live.fetch_sub(1, Ordering::SeqCst);
                let mut sock = sock;
                let _ = respond(&mut sock, 503, "{\"error\":\"too many connections\"}");
                continue;
            }
            let backend = backend.clone();
            let live = live.clone();
            let hosts = hosts.clone();
            thread::spawn(move || {
                let mut sock = sock;
                serve_connection(&mut sock, backend.as_ref(), &hosts);
                live.fetch_sub(1, Ordering::SeqCst);
            });
        }
    });
    Ok(local)
}

fn serve_connection(sock: &mut TcpStream, backend: &dyn RpcBackend, hosts: &HostPolicy) {
    let _ = sock.set_read_timeout(Some(IO_TIMEOUT));
    let _ = sock.set_write_timeout(Some(IO_TIMEOUT));
    match read_request(sock, hosts) {
        Ok(body) => {
            // The body must be text before it can be JSON. Invalid UTF-8 is a
            // parse error with a JSON-RPC shape, not a dropped connection.
            let response = match std::str::from_utf8(&body) {
                Ok(text) => handle_body(text, backend),
                Err(_) => envelope(Json::Null, Err(RpcError::parse_error("body is not UTF-8"))),
            };
            let _ = respond(sock, 200, &response);
        }
        Err(HttpError { status, message }) => {
            let _ = respond(sock, status, &envelope(Json::Null, Err(RpcError::invalid_request(message))));
        }
    }
}

struct HttpError {
    status: u16,
    message: &'static str,
}

fn http_err(status: u16, message: &'static str) -> HttpError {
    HttpError { status, message }
}

// ─── Browser-request gate (R1 A3-M4): Content-Type + Origin + Host ─────────
//
// The PoS RPC has never had this. The legacy G3 RPC's H-R3-5 fix
// (`legacy/genesis3-node/src/rpc/auth.rs`) hardened ONLY that binary's RPC —
// this one is the gap R1 A3-M4 names. Deliberately simpler than G3's policy
// (no wildcard Origin for read methods, no read/write split): nothing that
// calls THIS endpoint over HTTP has a legitimate reason to look like a
// browser request at all. curl, a wallet, a monitoring script choose their
// own `Content-Type` and never send `Origin`; anything that looks like a
// browser's fetch/XHR is refused outright, not merely rate-scored.
//
// - **Content-Type** must be `application/json` (parameters after `;`
//   ignored, matched case-insensitively per RFC 9110 §8.3). This defeats a
//   "simple request" CSRF: a bare `<form>`/`<img>`-shaped cross-site POST
//   cannot set an arbitrary Content-Type, so it is stuck with
//   `text/plain`, `application/x-www-form-urlencoded` or
//   `multipart/form-data` — none of which pass this gate.
// - **Origin** must be ABSENT. Every browser this matters for attaches
//   `Origin` to a cross-origin fetch/XHR — and, in every current browser,
//   to same-origin POSTs too — so this RPC's only legitimate callers
//   (non-browser clients) never send one. A present Origin is refused
//   regardless of its value: this is stricter than G3's wildcard-for-reads
//   policy on purpose, because a JSON-RPC endpoint has no "read request
//   from a web page" use case to preserve.
// - **Host** must name the address this server is actually bound to — a
//   loopback literal or `localhost` — or a name on the operator's
//   allowlist. Defeats DNS rebinding: a page at an attacker-registered
//   public hostname that resolves to 127.0.0.1 makes the browser send
//   `Host: <attacker's name>` on a connection that really did land on
//   loopback; comparing Host (not the socket's peer address) is what
//   catches that.

/// Extra hostnames an operator has explicitly decided to trust in `Host`,
/// beyond the built-in loopback literals — comma-separated, e.g.
/// `rpc.internal,10.0.0.5`. Read once per [`HostPolicy::new`] call (once per
/// `serve`, i.e. once per process), not per request: env is fixed for the
/// life of a process.
const RPC_HOST_ALLOWLIST_ENV: &str = "BLOCH_RPC_HOST_ALLOWLIST";

/// The Host values this server will accept, computed once at `serve` time
/// from the address it actually bound plus any operator-configured extras.
/// Compared against the request's `Host` header with the port stripped —
/// see [`host_name_only`] — because the identity that matters for DNS
/// rebinding is the NAME, not the port a browser filled in from the URL.
struct HostPolicy {
    allowed: Vec<String>,
}

impl HostPolicy {
    fn new(bind_addr: &str) -> Self {
        let mut allowed = vec!["127.0.0.1".to_string(), "localhost".to_string(), "::1".to_string()];
        // An operator who bound a specific, literal address made an explicit
        // decision to trust that name — `0.0.0.0`/`::` are wildcard BIND
        // addresses, never values a client would put in `Host`, so they add
        // nothing here.
        if bind_addr != "0.0.0.0" && bind_addr != "::" && !allowed.iter().any(|a| a == bind_addr) {
            allowed.push(bind_addr.to_string());
        }
        if let Ok(extra) = std::env::var(RPC_HOST_ALLOWLIST_ENV) {
            allowed.extend(
                extra
                    .split(',')
                    .map(|s| s.trim().to_ascii_lowercase())
                    .filter(|s| !s.is_empty()),
            );
        }
        HostPolicy { allowed }
    }

    fn allows(&self, host: Option<&str>) -> bool {
        let Some(h) = host else { return false };
        let name = host_name_only(h).to_ascii_lowercase();
        self.allowed.iter().any(|a| *a == name)
    }
}

/// The hostname portion of an HTTP `Host` header value, with a trailing
/// `:<port>` stripped. Handles the IPv6 literal form (`[::1]:8080` or bare
/// `[::1]`), which a naive split on `:` would mangle into `[` and a garbled
/// remainder.
fn host_name_only(host: &str) -> &str {
    let host = host.trim();
    if let Some(rest) = host.strip_prefix('[') {
        return rest.split(']').next().unwrap_or(rest);
    }
    host.split_once(':').map_or(host, |(name, _)| name)
}

/// `Content-Type`, ignoring `;`-separated parameters (e.g. `; charset=utf-8`)
/// and matched case-insensitively.
fn content_type_allowed(ct: Option<&str>) -> bool {
    match ct {
        Some(ct) => ct.split(';').next().unwrap_or("").trim().eq_ignore_ascii_case("application/json"),
        None => false,
    }
}

/// Read one HTTP request and return its body — after the browser-request
/// gate above has passed.
fn read_request(sock: &mut TcpStream, hosts: &HostPolicy) -> Result<Vec<u8>, HttpError> {
    let deadline = Instant::now().checked_add(IO_TIMEOUT)
        .ok_or_else(|| http_err(408, "request deadline out of range"))?;
    read_request_until(sock, hosts, deadline)
}

/// One deadline spans both the head and body. A socket timeout alone starts
/// over on every `read`, allowing a slow sender to reserve a worker forever.
fn read_request_until(
    sock: &mut TcpStream,
    hosts: &HostPolicy,
    deadline: Instant,
) -> Result<Vec<u8>, HttpError> {
    let mut buf: Vec<u8> = Vec::with_capacity(1024);
    let mut chunk = [0u8; 4096];

    // Head: read until CRLFCRLF, bounded.
    let head_end = loop {
        if let Some(p) = find_head_end(&buf) {
            if p.checked_add(4).is_none_or(|end| end > MAX_HEADER_BYTES) {
                return Err(http_err(431, "request header too large"));
            }
            break p;
        }
        if buf.len() >= MAX_HEADER_BYTES {
            return Err(http_err(431, "request header too large"));
        }
        let want = chunk.len().min(MAX_HEADER_BYTES.saturating_sub(buf.len()));
        match read_before_deadline(sock, &mut chunk[..want], deadline) {
            Ok(0) => return Err(http_err(400, "connection closed before the request head ended")),
            Ok(n) => buf.extend_from_slice(&chunk[..n]),
            Err(_) => return Err(http_err(408, "timed out reading the request head")),
        }
    };

    let head = std::str::from_utf8(&buf[..head_end])
        .map_err(|_| http_err(400, "request head is not UTF-8"))?;
    let mut lines = head.split("\r\n");
    let request_line = lines.next().unwrap_or("");
    let mut parts = request_line.split(' ');
    let verb = parts.next().unwrap_or("");
    let target = parts.next().unwrap_or("");
    let version = parts.next().unwrap_or("");
    if target.is_empty()
        || target.bytes().any(|b| b <= b' ' || b == 0x7f)
        || !matches!(version, "HTTP/1.1" | "HTTP/1.0")
        || parts.next().is_some()
    {
        return Err(http_err(400, "malformed request line"));
    }
    if verb != "POST" {
        return Err(http_err(405, "this endpoint accepts POST only"));
    }

    let mut content_length: Option<usize> = None;
    let mut content_type: Option<String> = None;
    let mut origin: Option<String> = None;
    let mut host: Option<String> = None;
    for line in lines {
        let Some((name, value)) = line.split_once(':') else {
            return Err(http_err(400, "malformed header field"));
        };
        // RFC 9112: whitespace before ':' and obsolete line folding must
        // not be normalized into a different proxy/backend interpretation.
        if name.is_empty() || !name.bytes().all(http_token_byte)
            || value.bytes().any(|b| (b < 0x20 && b != b'\t') || b == 0x7f)
        {
            return Err(http_err(400, "malformed header field"));
        }
        let value = value.trim_matches([' ', '\t']);
        if name.eq_ignore_ascii_case("content-length") {
            if content_length.is_some() {
                return Err(http_err(400, "duplicate Content-Length"));
            }
            if value.is_empty() || !value.bytes().all(|b| b.is_ascii_digit()) {
                return Err(http_err(400, "invalid Content-Length"));
            }
            content_length = Some(value.parse::<usize>()
                .map_err(|_| http_err(400, "invalid Content-Length"))?);
        } else if name.eq_ignore_ascii_case("transfer-encoding") {
            // Chunked bodies are not implemented. Saying so beats reading the
            // chunk headers as if they were JSON.
            return Err(http_err(411, "chunked transfer-encoding is not supported; send Content-Length"));
        } else if name.eq_ignore_ascii_case("content-type") {
            if content_type.replace(value.to_string()).is_some() {
                return Err(http_err(400, "duplicate Content-Type"));
            }
        } else if name.eq_ignore_ascii_case("origin") {
            origin = Some(value.to_string());
        } else if name.eq_ignore_ascii_case("host") {
            if host.replace(value.to_string()).is_some() {
                return Err(http_err(400, "duplicate Host"));
            }
        }
    }

    // R1 A3-M4: the browser-request gate, before Content-Length is even
    // consulted — three header comparisons are cheaper than anything past
    // this point, including the size check below.
    if !hosts.allows(host.as_deref()) {
        return Err(http_err(
            403,
            "Host does not match this server's bound address (or its configured allowlist); \
             set BLOCH_RPC_HOST_ALLOWLIST if this Host is expected",
        ));
    }
    if origin.is_some() {
        return Err(http_err(
            403,
            "requests carrying an Origin header are refused; this endpoint has no \
             browser-request use case to preserve",
        ));
    }
    if !content_type_allowed(content_type.as_deref()) {
        return Err(http_err(415, "Content-Type must be application/json"));
    }

    let Some(len) = content_length else {
        return Err(http_err(411, "Content-Length is required"));
    };
    if len > MAX_BODY_BYTES {
        return Err(http_err(413, "request body too large"));
    }

    // Body: whatever already arrived with the head, plus the rest.
    // Everything after the CRLFCRLF: `buf[head_end..]` starts with the 4-byte
    // terminator `find_head_end` located, so `[4..]` of it is `buf[head_end + 4..]`.
    let mut body = buf[head_end..][4..].to_vec();
    body.truncate(len);
    while body.len() < len {
        let want = chunk.len().min(len.saturating_sub(body.len()));
        match read_before_deadline(sock, &mut chunk[..want], deadline) {
            Ok(0) => return Err(http_err(400, "connection closed before the body was complete")),
            Ok(n) => {
                // cannot underflow: the loop runs while body.len() < len.
                #[allow(clippy::arithmetic_side_effects)]
                let want = len - body.len();
                body.extend_from_slice(&chunk[..n.min(want)]);
            }
            Err(_) => return Err(http_err(408, "timed out reading the request body")),
        }
    }
    Ok(body)
}

fn http_token_byte(b: u8) -> bool {
    b.is_ascii_alphanumeric() || b"!#$%&'*+-.^_`|~".contains(&b)
}

/// Recompute the remaining budget even after an interrupted read. Failure to
/// install the timeout is an error, never an unbounded socket operation.
fn read_before_deadline(sock: &mut TcpStream, buf: &mut [u8], deadline: Instant) -> io::Result<usize> {
    loop {
        let remaining = deadline.checked_duration_since(Instant::now())
            .filter(|d| !d.is_zero())
            .ok_or_else(|| io::Error::new(io::ErrorKind::TimedOut, "request deadline exceeded"))?;
        sock.set_read_timeout(Some(remaining))?;
        match sock.read(buf) {
            Err(e) if e.kind() == io::ErrorKind::Interrupted => continue,
            result => return result,
        }
    }
}

fn find_head_end(buf: &[u8]) -> Option<usize> {
    buf.windows(4).position(|w| w == b"\r\n\r\n")
}

fn respond(sock: &mut TcpStream, status: u16, body: &str) -> io::Result<()> {
    let reason = match status {
        200 => "OK",
        400 => "Bad Request",
        403 => "Forbidden",
        405 => "Method Not Allowed",
        408 => "Request Timeout",
        411 => "Length Required",
        413 => "Payload Too Large",
        415 => "Unsupported Media Type",
        431 => "Request Header Fields Too Large",
        503 => "Service Unavailable",
        _ => "Error",
    };
    // `Connection: close` because this server does not implement keep-alive:
    // one request per connection, and the client is told so instead of being
    // left waiting on a socket that will never answer again.
    let head = format!(
        "HTTP/1.1 {status} {reason}\r\n\
         Content-Type: application/json\r\n\
         Content-Length: {}\r\n\
         Connection: close\r\n\r\n",
        body.len()
    );
    sock.write_all(head.as_bytes())?;
    sock.write_all(body.as_bytes())?;
    sock.flush()
}

// ─── Formatting: pure projections of committed state ────────────────────────
//
// Free functions of their arguments, not methods on the engine, for the reason
// §5.5 gives and `engine::lmd_ghost_head` follows: a value a client will read
// must be derivable from its inputs so it can be tested without standing up a
// node. Every one of them is exercised below against a real `CommittedState`.

// `getnodeversion` / `node_version_json` were removed here on 2026-09-02.
//
// They answered the same question as [`build_info_json`] below, arrived on a
// sibling branch off the same tag, and the two merged with no conflict in this
// file — leaving both names routed and both dispatched. What decided which
// survives was not which branch was older but what each answer PROVES:
//
// * every identity field `getnodeversion` reported was either a compile-time
//   constant (`name`, `version`, `block_version`) or `commit`, which
//   `BLOCH_BUILD_COMMIT` lets any builder assert to any value. Its `dirty`
//   field, the one fact about the TREE, could not report `clean` at all on
//   this tag (see `build.rs`). So on its own motivating case — "is this
//   archival running the release?" — it was defeated by one environment
//   variable, and it said nothing about the tree that was compiled;
// * `build_info_json` reports those same fields plus `source_digest`, computed
//   from bytes on disk with no environment variable in the path, and
//   `commit_source`, which makes the forgeability of `commit` visible IN the
//   response rather than only in a doc comment.
//
// No alias was kept: swept across every local and remote ref on 2026-09-02,
// `getnodeversion` had no caller anywhere outside the five files of its own
// branch, so there was no compatibility claim — and an alias with no caller is
// just the second name again.


/// `getchaininfo` — the method the finality-aware consumers read (V4 §2).
#[allow(clippy::too_many_arguments)]
pub fn chain_info_json(
    state: &CommittedState,
    head: &BlockId,
    // The committed root at `head`, HANDED IN rather than derived from
    // `state`. It used to be `state.state_root()` on this line, which is a
    // full walk of the committed state tree — 733 ms at Genesis-4's carryover
    // size — run on the consensus thread once per caller. See
    // `Engine::head_state_root` for why the head block's header already holds
    // exactly this value and what happens at genesis, where there is no header
    // to hold it. The value is unchanged for every input; only who computes it
    // is.
    state_root: [u8; 32],
    height: u64,
    finalized_height: Option<u64>,
    wall_slot: u64,
    validators_total: usize,
    mempool: usize,
    blocks_known: usize,
    // `devnet`, `libp2p` or `dual` — read from the live `net::Net`, never
    // from the command line, so this field is what the process is on and not
    // what it was asked for.
    transport: &str,
    // Peers per stack: `(devnet, libp2p)`. `None` for a stack this node does
    // not run, `Some(0)` for one it runs and that nobody has reached. See
    // `net::Net::peer_counts` for why those two are not the same answer.
    peers: (Option<usize>, Option<usize>),
) -> Json {
    let fin = state.finality();
    let slot = state.slot();
    Json::obj(vec![
        ("block_id", Json::hex(head.as_bytes())),
        ("slot", Json::u(slot)),
        ("height", Json::u(height)),
        // The finalised line, next to the head. See `Finality`: this is what
        // replaces a confirmation count, and an integrator reading only
        // `height` is reading a number that is weaker still. "Replaces" is not
        // "guarantees" — the retraction on `Finality` bounds what this line
        // buys, and it is less than an earlier revision of this file promised.
        ("finalized_height", finalized_height.map_or(Json::Null, Json::u)),
        ("epoch", Json::u(epoch_of(slot))),
        ("slot_in_epoch", Json::u(slot % SLOTS_PER_EPOCH)),
        ("slots_per_epoch", Json::u(SLOTS_PER_EPOCH)),
        ("state_root", Json::hex(&state_root)),
        (
            "justified",
            Json::obj(vec![
                ("epoch", Json::u(fin.justified.epoch)),
                ("root", Json::hex(&fin.justified.root)),
            ]),
        ),
        (
            "finalized",
            Json::obj(vec![
                ("epoch", Json::u(fin.finalized.epoch)),
                ("root", Json::hex(&fin.finalized.root)),
            ]),
        ),
        (
            "previous_justified",
            Json::obj(vec![
                ("epoch", Json::u(fin.previous_justified.epoch)),
                ("root", Json::hex(&fin.previous_justified.root)),
            ]),
        ),
        (
            "validators",
            Json::obj(vec![
                ("total", Json::u(validators_total as u64)),
                ("active", Json::u(state.active_validators().len() as u64)),
            ]),
        ),
        ("total_active_stake_sat", Json::sat(state.total_active_stake_sat())),
        ("base_fee_millisat_per_gas", Json::sat(state.base_fee_millisat_per_gas())),
        ("next_base_fee_millisat_per_gas", Json::sat(state.next_base_fee())),
        ("mempool", Json::u(mempool as u64)),
        ("blocks_known", Json::u(blocks_known as u64)),
        // Wall-clock slot and the gap to it: under PoS this is what "am I
        // synced" means. There is no depth and no difficulty to infer it from
        // (R1), so the node states it.
        ("wall_slot", Json::u(wall_slot)),
        ("behind_by_slots", Json::u(wall_slot.saturating_sub(slot))),
        // WHICH NETWORK LAYER THIS NODE IS ON, AND WHETHER ANYONE IS ON IT
        // WITH IT.
        //
        // The transport used to be invisible from outside the process. A node
        // on the wrong one does not fail: it finds no peers, builds its own
        // chain, and answers `getchaininfo` with a plausible height, a moving
        // slot and a `finalized` epoch — the exact failure
        // `docs/THIRD-PARTY-QUICKSTART.md` warns about under "Why not
        // libp2p". `behind_by_slots` does not catch it either, because a node
        // alone on its own fork is not behind; it is current, on nothing.
        //
        // `peers.devnet` / `peers.libp2p` are `null` for a stack this node
        // does not run and a number for one it does, so a `dual` node is the
        // only shape that answers with two numbers. That is what makes a
        // rolling transport migration auditable from outside: an operator
        // polls the fleet and sees who has crossed.
        (
            "transport",
            Json::obj(vec![
                ("name", Json::s(transport)),
                (
                    "peers",
                    Json::obj(vec![
                        ("devnet", peers.0.map_or(Json::Null, |n| Json::u(n as u64))),
                        ("libp2p", peers.1.map_or(Json::Null, |n| Json::u(n as u64))),
                    ]),
                ),
            ]),
        ),
    ])
}

/// How a block stands relative to this node's own checkpoints.
///
/// The coordinated release schedules lifecycle epoch 2884 for 2026-09-14
/// 22:35:19 UTC. Before that epoch, slashing evidence is consensus-invalid.
/// At and after it, valid evidence can apply the configured penalties. A
/// scheduled source constant does not prove that deployed nodes have upgraded,
/// that a particular proof was included, or that a payment has settled.
///
/// Historical retraction: an earlier revision said "Credit here" and called
/// finality "economic by intent and cryptographic by nothing". Neither slogan
/// describes the scheduled release. The node's finalized latch refuses a
/// protocol reorg below its own finalized checkpoint. It does not establish
/// agreement between independent nodes or a universal one-third-stake cost.
/// The one-half quorum-denominator floor retains the limitations documented
/// in `finality.rs`; an epoch schedule does not remove them.
///
/// `finalized: true` is this node's classification, not a settlement guarantee.
/// Compare the release and independent finalized checkpoints, and follow the
/// controlled withdrawal-and-spend qualification in ADR-041 before broad
/// external-validator opening. Historical retractions in the integration
/// documents apply to the earlier unarmed release.

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Finality {
    /// At or below the finalised checkpoint. The strongest classification
    /// this node offers. Since 2026-09-05 (finding F-03) it IS a latch on
    /// the answering node: the engine refuses any reorg below its own
    /// highest finalized checkpoint, so a block this node once reported
    /// `finalized` never later leaves ITS canonical chain. It is still
    /// not an economic guarantee across nodes. Evidence is refused before
    /// lifecycle epoch 2884 and protocol-gated afterwards. Read the status on
    /// [`Finality`] before crediting anything on it.
    Finalized,
    /// At or below the justified checkpoint but above the finalised one. One
    /// epoch away from finality in the normal case; still reversible.
    Justified,
    /// On this node's canonical chain, not yet justified. Reorganisable by
    /// ordinary fork choice.
    Canonical,
    /// Known to this node but not on its canonical chain.
    NotCanonical,
}

impl Finality {
    pub fn as_str(self) -> &'static str {
        match self {
            Finality::Finalized => "finalized",
            Finality::Justified => "justified",
            Finality::Canonical => "canonical",
            Finality::NotCanonical => "not_canonical",
        }
    }

    /// The single boolean a deposit decision should branch on.
    pub fn is_final(self) -> bool {
        matches!(self, Finality::Finalized)
    }
}

/// One block, in the V4 §3.2 shape.
///
/// `finality` is this node's own classification of the block against its own
/// justified/finalized checkpoints — R1's replacement for confirmations — and
/// `finalized` is the same judgement as the one boolean a client should branch
/// on. Both are emitted: the string carries the gradation for display, the
/// boolean removes any need to hardcode the string set.
///
/// `timestamp` is derived from the slot for display and is not a consensus
/// field: `BlockHeaderV4` carries no time.
pub fn block_json(
    env: &BlockEnvelope,
    height: Option<u64>,
    finality: Finality,
    timestamp_secs: u64,
) -> Json {
    let h = &env.header;
    Json::obj(vec![
        ("block_id", Json::hex(env.block_id().as_bytes())),
        // The header's `version` field VERBATIM — `VERSION_G4`, a 32-bit magic
        // (0xB10C0005), which renders as 2970353669 and looks wrong at a
        // glance. It is not. `BLOCH-RPC-V4.md` §3.2 sketches `"version": 4`,
        // but a client that recomputes `block_id` hashes the 304 header bytes
        // including this field, so emitting a friendlier `4` would hand it a
        // number it cannot verify anything with. Do not "fix" this to 4.
        ("version", Json::u(u64::from(h.version))),
        ("parent", Json::hex(&h.parent)),
        ("slot", Json::u(h.slot)),
        ("epoch", Json::u(epoch_of(h.slot))),
        ("height", height.map_or(Json::Null, Json::u)),
        ("proposer_index", Json::u(u64::from(h.proposer_index))),
        ("timestamp", Json::u(timestamp_secs)),
        ("state_root", Json::hex(&h.state_root)),
        ("body_root", Json::hex(&h.body_root)),
        ("randao_reveal", Json::hex(&h.randao_reveal)),
        ("randao_mix", Json::hex(&h.randao_mix)),
        ("justified_root", Json::hex(&h.justified_root)),
        ("finalized_root", Json::hex(&h.finalized_root)),
        ("attestation_root", Json::hex(&h.attestation_root)),
        ("coherence_root", Json::hex(&h.coherence_root)),
        ("finality", Json::s(finality.as_str())),
        ("finalized", Json::Bool(finality.is_final())),
        ("tx_count", Json::u(env.body.transactions.len() as u64)),
        ("attestation_count", Json::u(env.body.attestations.len() as u64)),
    ])
}

/// `getblockcount` — height first, finality alongside it.
///
/// A bare integer would match Genesis-3's shape, and it is the wrong shape for
/// a chain whose security is not depth. An integrator polling this method needs
/// the head *and* the line below which history is settled; returning only the
/// former is what makes someone reinvent "N confirmations" on top of it. So the
/// response carries the finalised height as a sibling field: `height` is what
/// exists, `finalized_height` is what is safe, and the gap between them is the
/// only lag that matters.
pub fn block_count_json(
    height: u64,
    slot: u64,
    finalized_height: Option<u64>,
    justified_epoch: u64,
    finalized_epoch: u64,
) -> Json {
    Json::obj(vec![
        ("height", Json::u(height)),
        ("slot", Json::u(slot)),
        ("epoch", Json::u(epoch_of(slot))),
        ("finalized_height", finalized_height.map_or(Json::Null, Json::u)),
        ("justified_epoch", Json::u(justified_epoch)),
        ("finalized_epoch", Json::u(finalized_epoch)),
    ])
}

/// What became of a submitted transaction.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Admitted {
    /// Newly admitted to the mempool and gossiped to peers.
    New,
    /// Byte-identical to one already pending. The client's intent is satisfied,
    /// so this is a success and not an error — but it is reported distinctly,
    /// because a resubmission loop that cannot tell the two apart will keep
    /// resubmitting forever.
    Duplicate,
}

/// `sendrawtransaction` — what the node did with the bytes.
///
/// The consensus txid is not in this response — a gap in this method, not in
/// the format. The transaction has an id (`PosTransaction::txid`, the key of
/// every eUTXO entry it creates), and this response does not carry it.
///
/// `tx_hash` below is a DIFFERENT digest: SHA3-256 over the canonical bytes,
/// not over the spend signing root. It is labelled for what it is — a **local**
/// handle for correlating this submission with this response. No block commits
/// to `tx_hash`, and building deposit crediting on it would be building on a
/// number this node invented. Take the txid from the eUTXO set instead
/// (`listunspent`, `gettxout`), where it is the consensus one.
pub fn submitted_json(tx: &PosTransaction, outcome: Admitted) -> Json {
    use sha3::{Digest, Sha3_256};
    let bytes = tx.canonical_bytes();
    let hash: [u8; 32] = Sha3_256::digest(&bytes).into();
    let kind = match tx {
        PosTransaction::Transfer { .. } => "transfer",
        PosTransaction::TransferV2 { .. } => "transfer_v2",
        PosTransaction::Deposit { .. } => "deposit",
        PosTransaction::FundedDeposit(_) => "funded_deposit",
        PosTransaction::Exit { .. } => "exit",
        // Distinct from "exit" on purpose: the two are different messages with
        // different rules (one authenticated, one not) and an operator reading
        // this field needs to see which one the chain took.
        PosTransaction::ExitV2 { .. } => "exit_v2",
        PosTransaction::Withdraw { .. } => "withdraw",
        PosTransaction::Delegate { .. } => "delegate",
        PosTransaction::SlashingEvidence(_) => "slashing_evidence",
        // Unreachable today twice over — the wire byte (0x0A) is undecodable
        // and `admissible` refuses the shape below its flag day — but this
        // match is exhaustive on purpose, and an operator reading the field
        // post-activation needs the honest name.
        PosTransaction::RandaoRecommit { .. } => "randao_recommit",
    };
    Json::obj(vec![
        ("accepted", Json::Bool(true)),
        (
            "status",
            Json::s(match outcome {
                Admitted::New => "accepted",
                Admitted::Duplicate => "duplicate",
            }),
        ),
        ("kind", Json::s(kind)),
        ("bytes", Json::u(bytes.len() as u64)),
        ("tx_hash", Json::hex(&hash)),
        (
            "tx_hash_note",
            Json::s(
                "local correlation handle only (SHA3-256 of the canonical bytes); \
                 not a consensus transaction id — no block commits to it",
            ),
        ),
        (
            "confirmation",
            Json::s(
                "this transport does not confirm: watch for the transaction in a \
                 block via `getblockbyslot`. `finalized: true` on that block is \
                 the strongest signal this chain offers, but it is NOT a \
                 settlement guarantee across nodes; evidence penalties depend on \
                 the activated protocol rules. See `docs/integration/\
                 BLOCH-GENESIS4-EXCHANGE-INTEGRATION.md` \u{a7}5",
            ),
        ),
    ])
}

/// Lifecycle of one validator as of `current_epoch`.
///
/// The order of the arms is the rule: `slashed` outranks everything, because a
/// slashed validator whose exit epoch has not arrived is not "exiting" in any
/// sense a client should display.
pub fn validator_state(rec: &ValidatorRecord, current_epoch: u64) -> &'static str {
    if rec.staked_sat == 0 && rec.exit_epoch != u64::MAX
        && rec.withdrawable_epoch != u64::MAX && current_epoch >= rec.withdrawable_epoch {
        "withdrawn"
    } else if rec.slashed {
        "slashed"
    } else if rec.exit_epoch != u64::MAX && current_epoch >= rec.exit_epoch {
        "exited"
    } else if rec.exit_epoch != u64::MAX {
        "exiting"
    } else if rec.activation_epoch == u64::MAX || current_epoch < rec.activation_epoch {
        "queued"
    } else {
        "active"
    }
}

/// One validator registry record (V4 §4.2).
///
/// `effective_stake_sat` is `None` for a validator the active set does not
/// carry — which is a different statement from zero, and is why it is not
/// defaulted: "not sampled this epoch" and "sampled with no weight" are
/// distinguishable states and a delegator cares which one it is looking at.
pub fn validator_json(
    rec: &ValidatorRecord,
    effective_stake_sat: Option<u64>,
    current_epoch: u64,
) -> Json {
    use sha3::{Digest, Sha3_256};
    let pubkey_hash: [u8; 32] = Sha3_256::digest(&rec.pubkey).into();
    let never = |e: u64| if e == u64::MAX { Json::Null } else { Json::u(e) };
    Json::obj(vec![
        ("index", Json::u(u64::from(rec.index))),
        ("pubkey_hash", Json::hex(&pubkey_hash)),
        ("pubkey_bytes", Json::u(rec.pubkey.len() as u64)),
        ("state", Json::s(validator_state(rec, current_epoch))),
        ("own_stake_sat", Json::sat(rec.staked_sat)),
        (
            "effective_stake_sat",
            effective_stake_sat.map_or(Json::Null, |v| Json::sat(u128::from(v))),
        ),
        // R5: the rate is on every validator response, not behind a detail
        // call. Consensus applies it capped at `rewards::MAX_COMMISSION_BPS`;
        // the committed value is reported verbatim so a rate someone set above
        // the cap is visible rather than laundered into the cap.
        ("commission_bps", Json::sat(rec.commission_bps)),
        ("randao_commitment", Json::hex(&rec.randao_commitment)),
        ("slashed", Json::Bool(rec.slashed)),
        ("activation_epoch", never(rec.activation_epoch)),
        ("exit_epoch", never(rec.exit_epoch)),
        ("withdrawable_epoch", never(rec.withdrawable_epoch)),
    ])
}

/// Enrich the existing registry response with committed lifecycle accounting.
pub fn validator_lifecycle_json(state: &CommittedState, rec: &ValidatorRecord, effective: Option<u64>) -> Json {
    let mut result = validator_json(rec, effective, bloch_pos_committee::epoch_of(state.slot()));
    if let Json::Obj(fields) = &mut result {
        fields.extend([
            ("withdrawal_credentials".into(), Json::s(crate::codec::hex(&rec.withdrawal_credentials))),
            ("funded".into(), Json::Bool(state.is_funded_validator(rec.index))),
            ("withdrawal_payout_sat".into(), if state.is_write_off_indeterminate(rec.index) { Json::Null }
                else { Json::sat(state.withdrawable_sat(rec.index)) }),
            ("unbacked_principal_sat".into(), if state.is_write_off_indeterminate(rec.index) { Json::Null }
                else { Json::sat(state.unbacked_principal_sat(rec.index)) }),
            ("randao_generation".into(), Json::u(u64::from(state.validator_randao_generation(rec.index)))),
            ("randao_reveals_used".into(), Json::u(u64::from(state.validator_reveals_used(rec.index).unwrap_or(0)))),
        ]);
    }
    result
}

/// `getvalidators` (R4 F-11) — one entry per registered validator.
///
/// Deliberately a NARROWER shape than [`validator_json`], not a wrapper
/// around it: the finding names exactly five fields (index, pubkey hash,
/// status, effective stake, commission in basis points) and specifies
/// `commission_bps` as a **plain JSON number**, not [`Json::sat`]'s decimal
/// string. `validator_json`'s own `commission_bps` uses `Json::sat` — R3's
/// convention is for SATOSHI amounts that can exceed a JS double's exact
/// range, and commission is a basis-points integer capped at 10,000, so that
/// choice was always a category mismatch there. This method does not repeat
/// it, and does not "fix" the existing single-validator response either:
/// that field is part of an already-shipped, already-documented shape
/// (`docs/specs/BLOCH-RPC-V4.md` §4.2) and changing its JSON type out from
/// under an existing integrator is its own decision, for someone who owns
/// that spec section — not a side effect of adding a new method.
pub fn validators_json(entries: &[(ValidatorRecord, Option<u64>)], current_epoch: u64) -> Json {
    use sha3::{Digest, Sha3_256};
    Json::Arr(
        entries
            .iter()
            .map(|(rec, effective_stake_sat)| {
                let pubkey_hash: [u8; 32] = Sha3_256::digest(&rec.pubkey).into();
                Json::obj(vec![
                    ("index", Json::u(u64::from(rec.index))),
                    ("pubkey_hash", Json::hex(&pubkey_hash)),
                    ("status", Json::s(validator_state(rec, current_epoch))),
                    (
                        "effective_stake_sat",
                        effective_stake_sat.map_or(Json::Null, |v| Json::sat(u128::from(v))),
                    ),
                    // Plain integer (R4 F-11's own words) — see this
                    // function's doc for why that differs from
                    // `validator_json`'s `commission_bps`.
                    (
                        "commission_bps",
                        Json::u(u64::try_from(rec.commission_bps).unwrap_or(u64::MAX)),
                    ),
                ])
            })
            .collect(),
    )
}

/// `gettxstatus` (R4 F-11): one of `pending | included | justified |
/// finalized | unknown`. A bare string result rather than an object — there
/// is exactly one fact being reported, and wrapping it would invite a caller
/// to look for fields that do not exist.
pub fn tx_status_json(status: &'static str) -> Json {
    Json::obj(vec![("status", Json::s(status))])
}

fn eutxo_json(e: &EutxoEntry) -> Json {
    Json::obj(vec![
        ("txid", Json::hex(&e.txid)),
        ("vout", Json::u(u64::from(e.vout))),
        ("value_sat", Json::sat(u128::from(e.value))),
        ("script_hash", Json::hex(&e.script_hash)),
    ])
}

/// `getbalance` — the summed value of every output locked to `script_hash`.
///
/// Two lookups against the script index, and neither walks the set. Until
/// 2026-09-05 this made **two full passes** over every output that exists —
/// one to count, one to sum — for an answer about one holder's, on the thread
/// that proposes blocks. At the carryover's 452,726 outputs that is the
/// 2026-08-21 stall, reachable by anyone who could ask a node for a balance.
pub fn balance_json(state: &CommittedState, script_hash: &[u8; 32]) -> Json {
    Json::obj(vec![
        ("script_hash", Json::hex(script_hash)),
        ("balance_sat", Json::sat(state.balance_sat(script_hash))),
        ("utxo_count", Json::u(state.utxo_count_for_script(script_hash) as u64)),
    ])
}

/// `getutxos` — the outputs themselves, paginated.
///
/// `truncated` rather than a cursor: the honest thing for a devnet-stage
/// surface is to say the page was cut, not to invent a pagination protocol the
/// OpenAPI V4 freeze has not decided on.
///
/// # Cost
///
/// `total` comes from the script index without visiting an output, and the
/// page is built by taking `limit` items from a LAZY iterator over that
/// holder's outputs — so the work is bounded by the page, not by the holder's
/// position and not by the size of the ledger. The previous form collected
/// every matching output into a `Vec` and applied the limit afterwards, which
/// meant `limit: 1` against the founder's script hash still materialised
/// hundreds of thousands of references before returning one of them.
pub fn utxos_json(state: &CommittedState, script_hash: &[u8; 32], limit: usize) -> Json {
    let total = state.utxo_count_for_script(script_hash);
    // `take(limit)` BEFORE `collect`: the iterator stops at the page.
    let page: Vec<Json> =
        state.utxos_for_script(script_hash).take(limit).map(eutxo_json).collect();
    Json::obj(vec![
        ("script_hash", Json::hex(script_hash)),
        ("total", Json::u(total as u64)),
        ("returned", Json::u(page.len() as u64)),
        ("truncated", Json::Bool(total > page.len())),
        ("utxos", Json::Arr(page)),
    ])
}

/// `gettxout` — one outpoint, answered as present-or-absent.
///
/// `unspent` is stated as its own boolean rather than left implicit in whether
/// `utxo` is null. An integrator reading a null field has to decide whether it
/// means "spent", "never existed", or "this node does not know", and those are
/// three different facts to act on. Here the first two are both `unspent:
/// false` — this node's committed set does not contain it — and the third
/// cannot arise, because the set is committed state, not a cache: if the node
/// answered at all, it answered from the same eUTXO set its state root commits.
///
/// So a `false` is a real statement about the chain, and `at_slot` — the head
/// this node answered from — is returned either way, so the answer can be
/// pinned to a point on the chain rather than to the moment the call happened.
pub fn txout_json(state: &CommittedState, txid: &[u8; 32], vout: u32) -> Json {
    match state.utxo(txid, vout) {
        Some(e) => Json::obj(vec![
            ("txid", Json::hex(txid)),
            ("vout", Json::u(vout as u64)),
            ("unspent", Json::Bool(true)),
            ("utxo", eutxo_json(e)),
            ("at_slot", Json::u(state.slot())),
        ]),
        None => Json::obj(vec![
            ("txid", Json::hex(txid)),
            ("vout", Json::u(vout as u64)),
            ("unspent", Json::Bool(false)),
            ("utxo", Json::Null),
            ("at_slot", Json::u(state.slot())),
        ]),
    }
}

/// `getmempoolinfo`.
pub fn mempool_info_json(
    size: usize,
    max: usize,
    bytes: usize,
    next_base_fee_millisat_per_gas: u128,
    barred: usize,
    barred_hits: u64,
    expired: u64,
    evicted_low_fee: u64,
) -> Json {
    Json::obj(vec![
        ("size", Json::u(size as u64)),
        ("max", Json::u(max as u64)),
        ("bytes", Json::u(bytes as u64)),
        ("next_base_fee_millisat_per_gas", Json::sat(next_base_fee_millisat_per_gas)),
        // The rejection cache, from outside. Two numbers and they answer
        // different questions: `barred` is how many transactions this node is
        // currently refusing to re-admit, `barred_hits` is how many re-offers
        // it has actually turned away since boot. A cache with entries and
        // zero hits is barring nothing real — the distinction the mempool size
        // alone cannot make, and the reason measuring this needed an RPC
        // rather than a log line on a box someone has to hold a key for.
        ("barred", Json::u(barred as u64)),
        ("barred_hits", Json::u(barred_hits)),
        // Transactions dropped for AGE, which is a different event from every
        // other way an entry leaves. Without it, a mempool that shrank because
        // blocks included things and one that shrank because the TTL swept a
        // wedged transaction out look identical from the outside — and the
        // second is the one an operator needs to see.
        ("expired", Json::u(expired)),
        // R7 M6: transactions evicted for a higher-fee arrival at capacity —
        // a mempool under genuine fee pressure and one simply idle both
        // "get smaller" without this counter to tell them apart.
        ("evicted_low_fee", Json::u(evicted_low_fee)),
    ])
}


/// `getbuildinfo` — the identity of the binary that is answering.
///
/// # Why this method exists
///
/// We told a partner exchange to trust a read only when two nodes agree. That
/// rule is unfalsifiable if you cannot tell the two nodes apart, and until this
/// method there was no way to: nothing on this surface said which binary was on
/// the other end of the socket. The failure is not hypothetical here. The
/// 2026-08-11 fleet survey found three boxes running three different binaries,
/// all reporting `bloch 0.3.0-genesis2`. The published Genesis-3 release was an
/// abandoned branch while the fleet ran unpublished fixes, and nobody noticed
/// until nodes froze at block 10802. And on 2026-09-02 both public archivals
/// answered `getmempoolinfo` with four fields where this build emits six — a
/// difference no version string on either side would have shown.
///
/// # The honesty bar, and the part that is only evidence
///
/// A version string a developer typed proves nothing; that is the whole lesson
/// above. So the load-bearing field here is `source_digest`, which the build
/// script computes over the FILES it is about to compile
/// (`crates/**/*.{rs,toml,c,h,S,s}` plus the workspace `Cargo.toml` and
/// `Cargo.lock`), not over anything anyone asserted. No environment variable
/// moves it.
///
/// What it can prove:
///
/// - Two nodes reporting **different** `source_digest` were built from
///   different trees. Full stop, no interpretation needed.
/// - A node whose `source_digest` differs from the digest published for a
///   release tag is **not** running that tag's source, even if it reports the
///   tag's commit id — which is exactly the accident this method is for, since
///   `BLOCH_BUILD_COMMIT` lets a caller assert any commit it likes.
///
/// What it cannot prove:
///
/// - It cannot prove a node IS running the tag. Equal digests mean the hashed
///   set matched; a hostile operator who can edit the source can also edit
///   `build.rs` to print a digest it never computed, or patch the linked
///   binary after the fact. This is tamper-EVIDENT against drift and accident,
///   not tamper-PROOF against a liar. Only a reproducible build compared
///   against an independently built artifact closes that, and
///   `deploy/RELEASE-INTEGRITY.md` is where that lives.
/// - It says nothing about behaviour. Equal source and equal `rustc`,
///   `profile` and `target` is a strong claim about the artifact and still not
///   a claim that two nodes will derive the same committee — see the fork
///   history in this repo, where identical binaries diverged on local state.
/// - It does not cover `legacy/`, `tools/`, `apps/` or `scripts/`, and it does
///   not cover the compiled artifact itself.
///
/// `commit_source` is the field that keeps `commit` from being read as more
/// than it is: `git` means the build script read it from the repository,
/// `asserted` means the caller passed `BLOCH_BUILD_COMMIT` and nothing checked
/// it, `none` means there was no repository. An `asserted` commit beside a
/// `source_digest` that does not match the tag is the signature of exactly the
/// mistake this method was written to catch.
///
/// # What is deliberately absent
///
/// No paths, no hostname, no peer id, no key material, no data directory, no
/// operator identity. Everything reported is either a hash, a compiler
/// version, or a target triple. `getbuildinfo_leaks_nothing_operational` in
/// `rpc/tests.rs` holds that line.
///
/// # Cost
///
/// Constant. Every field is a `&'static str` baked in at compile time; the
/// method reads no chain state, takes no lock and allocates one small object.
/// It does not move with the height.
// NAMESPACE NOTE, 2026-09-02 — read before adding `RPC_SURFACE_VERSION` here.
//
// This method deliberately does NOT report a semantic surface version, and the
// omission is a decision rather than an oversight.
//
// `RPC_SURFACE_VERSION` is defined against `RPC_SURFACE` and `getcapabilities`.
// Neither exists on this lineage: `main`, the release tag `g4-node-20260901`
// (7a83ca89) and the fleet commit 46133196 contain no `RPC_SURFACE`, no
// `RPC_SURFACE_VERSION` and no `getcapabilities`, and the three documents that
// carry the counter (BLOCH-GENESIS4-EXCHANGE-INTEGRATION.md,
// BLOCH-RPC-STABILITY-V4.md, WIRE-NAMESPACE-REGISTRY.md) are absent from the
// tag entirely. Landing a bare "4.2.0" string here would assert that 4.0.0 and
// 4.1.0 shipped on the lineage the fleet runs. They did not. A version number
// is a claim, and that one would be false in the same way `bloch 0.3.0-genesis2`
// on three different binaries was false.
//
// The collision itself, for whoever lands the counter: 4.1.0 comes from
// `dev/rpc-surface-20260901` (d28b2edc), and TWO unlanded branches each bump it
// to 4.2.0 off that base — `rpc/build-identity` (8cece026, for getbuildinfo)
// and 163befdb (for the settlement-guarantee retraction on `Finality`). Both
// merge without a conflict and a client would then see one string standing for
// two surfaces. **4.3.0 is reserved here for whichever of the two lands
// second**, so 4.2.0 stays free for exactly one claimant instead of being burnt
// by a third. When `RPC_SURFACE`/`getcapabilities` reach this lineage, the
// counter arrives with them and `getbuildinfo` gains a `surface_version` field
// in the same commit — a minor bump, since it only adds a field.
//
// Until then the honest answer to "which surface is this?" is the one below:
// a digest of the tree that was compiled. It cannot drift from the binary,
// which is the property a hand-maintained counter has never had here.
pub fn build_info_json() -> Json {
    Json::obj(vec![
        // The display string `--version` prints, so an operator can match what
        // the RPC says against what the binary says on the console.
        ("build_version", Json::s(env!("BLOCH_BUILD_VERSION"))),
        ("package_version", Json::s(env!("CARGO_PKG_VERSION"))),
        ("commit", Json::s(env!("BLOCH_BUILD_COMMIT_ID"))),
        ("commit_source", Json::s(env!("BLOCH_BUILD_COMMIT_SOURCE"))),
        ("tree_state", Json::s(env!("BLOCH_BUILD_TREE_STATE"))),
        ("source_digest", Json::s(env!("BLOCH_SOURCE_DIGEST"))),
        ("source_digest_alg", Json::s("sha3-256")),
        (
            "source_digest_scope",
            Json::s(
                "workspace crates dir: rs, toml, c, h, S, s; \
                 plus workspace Cargo.toml and Cargo.lock; \
                 relative paths, sorted, length-prefixed",
            ),
        ),
        ("source_files", Json::s(env!("BLOCH_SOURCE_FILES"))),
        ("source_bytes", Json::s(env!("BLOCH_SOURCE_BYTES"))),
        ("rustc", Json::s(env!("BLOCH_BUILD_RUSTC"))),
        ("profile", Json::s(env!("BLOCH_BUILD_PROFILE"))),
        ("target", Json::s(env!("BLOCH_BUILD_TARGET"))),
        // The bound rides with the answer. A client that reads `source_digest`
        // and stops reading has been told, in the response itself, what it is
        // allowed to conclude.
        (
            "digest_note",
            Json::s(
                "different digests prove different source trees; \
                 equal digests are evidence of the same source, not proof — \
                 whoever can edit the source can edit the build script that hashes it",
            ),
        ),
    ])
}

#[cfg(test)]
mod tests;

// The frozen method registry — layer 1 of the guard against two methods
// answering one question. It lives in its OWN file, at a path no other branch
// in this repository carries, so a merge that brings a rival `rpc.rs` cannot
// bring a rival copy of the freeze with it.
//
// THIS LINE IS LOAD-BEARING: it is how the freeze is attached, and a merge
// could drop it. `crates/bloch-pos-node/tests/rpc_method_registry.rs` asserts
// this declaration is still here, so deleting it goes red rather than quiet.
#[cfg(test)]
mod method_registry;

/// Network-bound admission terms. Null activation means the binary is unarmed.
pub fn validator_admission_json(state: &bloch_pos_committee::transition::CommittedState) -> Json {
    use bloch_pos_committee::{params, staking};
    use bloch_pos_committee::interfaces::StateReader;
    let activation = params::FUNDED_VALIDATOR_ADMISSION_ACTIVATION_EPOCH;
    let epoch = bloch_pos_committee::epoch_of(state.slot());
    let cap = state.total_active_stake_sat().saturating_mul(bloch_pos_committee::delegation::MAX_VALIDATOR_STAKE_BPS)
        .checked_div(10_000).unwrap_or(0).max(staking::MIN_DEPOSIT_SAT);
    Json::obj(vec![
        ("active", Json::Bool(params::funded_validator_admission_active(epoch))),
        ("activation_epoch", if activation == u64::MAX { Json::Null } else { Json::u(activation) }),
        ("network_domain", state.admission_network_domain().map_or(Json::Null, |v| Json::hex(&v))),
        ("epoch", Json::u(epoch)),
        ("wire_tag", Json::s("0x0b")),
        ("signature_suite", Json::s("ML-DSA-65 AND Falcon-1024 (0x0001)")),
        ("minimum_stake_sat", Json::sat(staking::MIN_DEPOSIT_SAT)),
        ("maximum_stake_sat", Json::sat(cap)),
        ("activation_delay_epochs", Json::u(staking::ACTIVATION_DELAY_EPOCHS)),
        ("activation_requires_finalized_deposit", Json::Bool(true)),
        ("exit_wire_tag", Json::s("0x0c")),
        ("withdrawal_wire_tag", Json::s("0x0d")),
        ("randao_recommit_wire_tag", Json::s("0x0a")),
        ("exit_delay_epochs", Json::u(staking::EXIT_DELAY_EPOCHS)),
        ("withdrawal_delay_epochs", Json::u(staking::WITHDRAWAL_DELAY_EPOCHS)),
        ("maximum_exits_per_epoch", Json::u(staking::MAX_EXITS_PER_EPOCH as u64)),
        ("written_off_sat", Json::sat(state.written_off_sat())),
        ("maximum_activations_per_epoch", Json::u(staking::MAX_ACTIVATIONS_PER_EPOCH as u64)),
        ("next_base_fee_millisat_per_gas", Json::sat(state.next_base_fee())),
        ("legacy_unfunded_deposit_enabled", Json::Bool(false)),
    ])
}
