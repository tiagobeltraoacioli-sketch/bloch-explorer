// SPDX-License-Identifier: AGPL-3.0-or-later

//! Genesis manifest: the one file every node of a network loads (integration
//! plan §3.4), and the deterministic synthesis of block 0 and its committed
//! state from it.
//!
//! Two independently built nodes must agree on genesis byte-for-byte before
//! the first slot ticks. Everything here is therefore a pure function of the
//! manifest bytes: the genesis header is fixed-field, the genesis
//! `CommittedState` comes from `CommittedState::genesis`, and the manifest's
//! SHA3-256 digest is pinned into the data dir's `meta` so a node can never
//! silently switch networks (§3.1 refusal rule).
//!
//! What the devnet manifest does NOT yet carry, honestly: the stake-eligibility
//! policy (integration plan §3.4 / decision 9). This is a *devnet* genesis: a
//! validator set and a clock. The mainnet shape is the same format with the
//! carryover commitment and the vested allocations filled in — the balance set
//! itself arrives out of band, through [`Manifest::ingest_carryover`].

use std::fs;
use std::io;
use std::io::{BufRead, BufReader};
use std::path::Path;

use bloch_pos_committee::header::{BlockHeaderV4, BlockId, VERSION_G4};
use bloch_pos_committee::state_root::{EutxoEntry, EvmCommitment};
use bloch_pos_committee::tokenomics_v4;
use bloch_pos_committee::transition::{CommittedState, GenesisValidator};
use sha3::{Digest, Sha3_256};

/// Format 1: the genesis header is fixed-field and carries no commitment to
/// the ledger the manifest describes. Every Genesis-4 manifest published so
/// far — the live mainnet's included — is this format, and its `genesis_id`
/// is what the running fleet has agreed on since slot 0.
const MANIFEST_MAGIC_V1: &[u8; 8] = b"BPOSMAN1";

/// Format 2: the genesis header binds the ledger (audit C5-genesis-header).
/// Byte-identical layout to v1 — only the magic differs, and only the derived
/// header changes. See [`ManifestFormat`].
const MANIFEST_MAGIC_V2: &[u8; 8] = b"BPOSMAN2";

/// Which genesis-binding rule a manifest's header derivation follows.
///
/// # Why this is a format flag and not just a fix
///
/// The v1 genesis header is all compile-time constants: zero state root, zero
/// mix, zero everything but `version`. So `genesis_id()` is the SAME 32 bytes
/// for every manifest ever written — a devnet with three validators and no
/// money, and mainnet with 452k carried outputs, have the identical genesis
/// block id. Two consequences, and the second is the finding:
///
/// 1. The manifest digest pinned into `meta` is what actually stops a node
///    from switching networks, and it does (§3.1). That check is why this was
///    a latent hole rather than a live break.
/// 2. Nothing in the *block graph* carries the ledger. A substituted manifest
///    — same validator set, different balances, different carryover
///    commitment — produces a genesis block that pairs at height 0 with the
///    real chain: same id, same parent, same everything a peer compares. The
///    divergence only surfaces later, as a state-root mismatch attributed to
///    whatever block happened to expose it.
///
/// [`ManifestFormat::V2Bound`] closes that: `state_root` carries the genesis
/// state's own root and `randao_mix` is seeded from the carryover digest, the
/// way `genesis4-ceremony::genesis_header` has always assembled the published
/// header. Two manifests that describe different ledgers then have different
/// genesis ids, which is the property the block graph was missing.
///
/// # Why v1 is still here
///
/// Changing the derivation for the manifest the fleet already runs would
/// change `genesis_id` under a live chain: every stored block's ancestry
/// walks back to an id the new binary no longer computes, so every node
/// breaks on its next restart. Genesis identity cannot be flag-dayed by
/// height — the flag day IS publishing a new manifest. So the rule ships
/// inert: a `BPOSMAN1` file derives exactly the bytes it derives today, and
/// the binding takes effect the moment a `BPOSMAN2` manifest is published.
/// That publication is a founder decision, not this module's.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ManifestFormat {
    /// `BPOSMAN1` — legacy, unbound genesis header. Consensus-frozen: the
    /// live Genesis-4 chain's genesis id is derived under this rule.
    V1Unbound,
    /// `BPOSMAN2` — genesis header bound to the manifest's ledger.
    V2Bound,
}

/// The beacon mix that seeds epoch 0 — fixed before any validator could have
/// influenced it (same convention as the pure crate's tests).
pub const GENESIS_MIX: [u8; 32] = [0u8; 32];

/// One genesis validator, public parts only.
#[derive(Clone)]
pub struct ManifestValidator {
    pub index: u32,
    pub stake_sat: u128,
    pub randao_commitment: [u8; 32],
    pub pubkey: Vec<u8>,
    pub withdrawal_credentials: Vec<u8>,
    /// Commission on delegators' rewards, in basis points. Published in the
    /// manifest because it is a committed registry column (2026-08-12): the
    /// epoch boundary splits both issuance and producer fees with it, so a
    /// launch validator's rate has to be part of the genesis every node
    /// agrees on, not a local setting.
    pub commission_bps: u128,
}

pub struct Manifest {
    /// Slot-0 wall-clock origin, unix milliseconds.
    pub genesis_time_ms: u64,
    /// Slot duration in milliseconds. 30_000 is the §5.1 consensus cadence;
    /// a devnet may run faster — the value is wall-clock pacing only, it
    /// never enters any consensus object (slots are numbers, not times).
    pub slot_ms: u64,
    pub validators: Vec<ManifestValidator>,
    /// Genesis-cohort indices (founder-operated launch set, cap tapered by
    /// `genesis_cohort.rs`). Empty on a devnet.
    pub cohort: Vec<u32>,
    /// The Genesis-3 balances this chain opens with. `None` on a devnet, where
    /// nobody holds anything and a fresh validator set is the whole state.
    ///
    /// The entries are **not** here. At the terminal height Genesis-3 has on
    /// the order of hundreds of thousands of outputs, and a manifest is a file
    /// every node reads, hashes and pins; carrying the set inline would make
    /// the thing nodes compare tens of megabytes long for no gain. What is
    /// here is the commitment — digest, count, total — and the node ingests
    /// the snapshot file separately and refuses it unless all three agree.
    /// Genesis-3 opened the same way (`carryover.tsv` + a `carryover_root` in
    /// meta) and that mechanism is the one piece of this that has been proven
    /// on a live chain.
    pub carryover: Option<CarryoverCommitment>,
    /// The consensus-vested allocations (`BLOCH-TOKENOMICS-V4.md` §3). Empty
    /// on a devnet.
    pub allocations: Vec<GenesisAllocation>,
    /// The ingested carryover set — **not encoded, not hashed, not part of the
    /// network digest**. It is the balance set the commitment above describes,
    /// materialised from the snapshot file by
    /// [`Manifest::ingest_carryover`], which is the only thing that should
    /// ever write it: the entries are meaningful precisely because they were
    /// checked against all four fields of [`CarryoverCommitment`] — digest,
    /// set root, entry count and total — and a value assigned here by any
    /// other route carries no such evidence.
    ///
    /// A manifest that commits to a carryover and has this empty is the
    /// zero-balance launch this whole path exists to prevent, so
    /// [`Manifest::opening_balances`] refuses it rather than quietly
    /// committing an empty ledger.
    pub carryover_entries: Vec<EutxoEntry>,
    /// Which genesis-binding rule this manifest's header follows — decided by
    /// the file's magic, never by a local setting. See [`ManifestFormat`].
    pub format: ManifestFormat,
    /// Memo for [`Manifest::genesis_pre_state_root`], which is otherwise a
    /// full genesis-state synthesis (452k outputs into an SMT on mainnet) on
    /// every `genesis_header()` call — and `genesis_header` is on the RPC path
    /// for height 0. Derived, never encoded, never hashed: it is a cache of a
    /// pure function of the fields above, so it carries no identity of its
    /// own and a stale one cannot exist (nothing mutates a manifest after
    /// `ingest_carryover`, which is why that method clears it).
    pub(crate) pre_state_root: std::sync::OnceLock<[u8; 32]>,
}

/// What the genesis state must reproduce from the carryover snapshot: four
/// independent facts about it, checked in order by
/// [`CarryoverSnapshot::check_against`].
///
/// Four, not one, because they fail for different reasons and each one is
/// blind to the others' failure. A file can be corrupt in transit (digest), be
/// a different artifact that is internally perfect (set root), be the right
/// artifact truncated or padded (count), or be the right shape carrying the
/// wrong money (total). Only the fourth catches a snapshot taken at another
/// height with the same number of outputs, and only the first catches a byte
/// flipped by a bad disk in a file whose set was never re-derived.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct CarryoverCommitment {
    /// SHA3-256 over the snapshot file's bytes, exactly as they sit on disk.
    /// **Integrity in transit**: this is the "did the file arrive intact"
    /// question, and it is asked of the bytes, not of anything parsed out of
    /// them.
    ///
    /// SHA-3 rather than SHA-2 deliberately: the Genesis-4 stack is SHA-3
    /// throughout (the manifest's own digest included) and a consensus
    /// artifact is the wrong place to introduce a second hash family. The
    /// `sha256sum` line in the carryover runbook stays what it is — an
    /// operator convenience for moving a file between machines, checked by
    /// nothing in here.
    pub digest: [u8; 32],
    /// SHAKE-256 (32 bytes of XOF output) over the canonical rows — the root
    /// `bloch-snapshot-utxo` prints, `tokenomics_v4::CARRYOVER_MEASURED_ROOT`
    /// records, and `build_carryover.py` / `genesis4-ceremony` recompute for
    /// their derived artifacts.
    ///
    /// **Identity of the content**: this is the "is this the same set of
    /// outputs" question, and it is asked of the parsed, re-serialised rows.
    /// It is what independent operators compare — several people snapshot the
    /// same halted data-dir and agree on this number, which is the evidence a
    /// single tool's say-so is not.
    pub set_root: [u8; 32],
    /// How many outputs the snapshot carries. Lines in the file, one per
    /// unspent Genesis-3 output — not addresses, and not entries after any
    /// aggregation.
    pub entry_count: u64,
    /// Their total value **in Genesis-4 satoshis**: the snapshot's Genesis-3
    /// total after the ×100/21 split (`tokenomics_v4::split_g3_sat`), which is
    /// the money this chain actually opens with. It is stated post-split
    /// because [`Manifest::check_supply`] adds it to the allocations and holds
    /// the sum against `GENESIS_ISSUED_SAT`, and that constant is denominated
    /// in the new unit — a pre-split figure would be short by a factor of
    /// 100/21 and the check would compare two different currencies.
    ///
    /// Held separately from the digest on purpose: a digest says "these exact
    /// bytes", a total says "this much money". Checking both catches a
    /// snapshot that is internally consistent but is not the one the
    /// tokenomics was written against — the failure a digest alone cannot see,
    /// because a wrong file has a perfectly good digest of its own.
    pub total_sat: u128,
}

/// One consensus-vested allocation output.
///
/// These are the buckets §3 names — founder, VC, team, marketing, liquidity,
/// validator emission — expressed as genesis outputs rather than as a promise
/// kept off-chain.
///
/// # `unlock_epoch` is NOT enforced
///
/// This comment used to say that `unlock_epoch` "is what makes the vesting
/// consensus: an output is unspendable until the chain reaches that epoch, so
/// the schedule is enforced by every node instead of by whoever holds the
/// key." **That is false, and it was false when it was written.**
///
/// The field is encoded into the manifest, decoded from it, and hashed into
/// the allocation's txid — so every node agrees on the number. No node ever
/// reads it to decide whether an output may be spent: `unlock_epoch` does not
/// appear anywhere in `bloch-pos-committee`, which is the crate that
/// authorises spends. See `vesting_is_not_enforced` in this module.
///
/// It is doubly inert on the live chain, for two independent reasons: the
/// shipped `genesis-mainnet` path writes `0` for all five buckets, and even a
/// non-zero value would be ignored. Every allocation is liquid from slot 0,
/// and the schedule is kept by whoever holds the key — the exact thing the
/// old comment claimed it was not.
///
/// Enforcing it later is a consensus change: coins already liquid cannot be
/// re-locked by a rule adopted after the fact.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct GenesisAllocation {
    /// Which bucket this is, as a stable tag (see `alloc_purpose`).
    pub purpose: u8,
    /// SHA3-256 of the locking script that owns it.
    pub script_hash: [u8; 32],
    pub amount_sat: u128,
    /// First epoch at which this output may be spent. 0 means liquid at
    /// genesis.
    pub unlock_epoch: u64,
}

/// Stable purpose tags. Never renumber: they are committed in the manifest,
/// therefore in its digest, therefore in what every node agrees it joined.
pub mod alloc_purpose {
    pub const FOUNDER: u8 = 0x01;
    pub const VC: u8 = 0x02;
    pub const TEAM: u8 = 0x03;
    pub const MARKETING: u8 = 0x04;
    pub const LIQUIDITY: u8 = 0x05;
    /// Held for validator emission — issued over time, not spendable at once.
    pub const VALIDATOR_EMISSION: u8 = 0x06;
}

// ── Genesis-3 carryover ingestion ───────────────────────────────────────────
//
// The snapshot is the file `bloch-snapshot-utxo` writes at the Genesis-3
// terminal height: one line per unspent output, tab-separated, no header,
//
//     txid_hex <TAB> vout <TAB> value_sat <TAB> address_hex
//
// sorted by (txid, vout) — the tool sorts explicitly so the artifact does not
// depend on a RocksDB iteration detail — with a trailing newline on every
// line. Measured on the real file (2026-08-13, h39,328): 452,133 lines, ~54 MB,
// 16 distinct addresses, 380,574,600,000,000,000 G3 satoshis; column 1 is 64
// hex characters and column 4 is 40 in every single row. It only grows until
// Genesis-3 halts.
//
// Three properties this reader is built around:
//
//   1. **Streaming.** 54 MB in one `String`, or one allocation per line across
//      452k lines, is a cost paid for nothing. One reused line buffer, one
//      reused hex buffer, hash-as-you-read.
//   2. **All four checks.** File digest, set root, count, total — see
//      `check_against`. A wrong file has a perfectly good digest *of itself*;
//      the count and the total are what say it is the *right* file, and the
//      set root is the number independent operators compare across machines.
//   3. **Strict parsing.** Anything a builder would not have written —
//      uppercase hex, a leading zero, five columns, a `\r`, rows out of order,
//      an address that is not 20 bytes — is refused with the line number,
//      never skipped. A silently skipped line is a balance that vanishes, and
//      a genesis is the one artifact nobody can re-derive later.

/// Cap on entries read from a snapshot: ~35× the measured Genesis-3 set. A
/// bound so a corrupt or hostile file cannot ask for unbounded memory; not a
/// policy about how large a real snapshot may be.
pub const MAX_CARRYOVER_ENTRIES: u64 = 16_000_000;

/// Cap on a single snapshot line. A real line is ~120 bytes (64 hex txid, a
/// small vout, a value, 40 hex address); this leaves room and still refuses a
/// file with no newlines in it.
const MAX_SNAPSHOT_LINE: usize = 4_096;

/// A Genesis-3 address as the snapshot carries it: hash160, 20 bytes. Measured
/// across all 452,133 rows of the 2026-08-13 snapshot — every one is 40 hex
/// characters, not one is a longer script.
const G3_ADDRESS_BYTES: usize = 20;
const G3_ADDRESS_HEX: usize = G3_ADDRESS_BYTES * 2;

/// What went wrong ingesting the snapshot.
///
/// Every variant names *which* check failed and by how much. "Carryover
/// invalid" tells an operator holding a 54 MB file nothing they can act on,
/// and at a genesis ceremony the difference between "these are not the bytes"
/// and "these are the bytes but 4 outputs short" is the difference between
/// re-fetching a file and stopping the launch.
#[derive(Debug)]
pub enum CarryoverError {
    Io(io::Error),
    /// A line that could not be parsed, with its 1-based number.
    Line { line: u64, what: String },
    /// The bytes are not the committed bytes.
    Digest { found: [u8; 32], expected: [u8; 32] },
    /// The bytes parse, and describe a different set of outputs.
    SetRoot { found: [u8; 32], expected: [u8; 32] },
    /// The right kind of file, the wrong number of outputs.
    Count { found: u64, expected: u64 },
    /// The right shape, the wrong money.
    Total { found: u128, expected: u128 },
    /// A snapshot was offered to a manifest that commits to none.
    NotCommitted,
}

impl std::fmt::Display for CarryoverError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            CarryoverError::Io(e) => write!(f, "carryover snapshot: {e}"),
            CarryoverError::Line { line, what } => {
                write!(f, "carryover snapshot line {line}: {what}")
            }
            CarryoverError::Digest { found, expected } => write!(
                f,
                "carryover FILE-DIGEST mismatch: the file's bytes hash (SHA3-256) to {}, \
                 the manifest commits to {} — these are not the committed bytes; if the \
                 set root below still matches, suspect the transfer, not the snapshot",
                crate::codec::hex32(found),
                crate::codec::hex32(expected),
            ),
            CarryoverError::SetRoot { found, expected } => write!(
                f,
                "carryover SET-ROOT mismatch: the outputs in this file root (SHAKE-256) to {}, \
                 the manifest commits to {} — this is a different balance set, not a \
                 damaged copy of the committed one",
                crate::codec::hex32(found),
                crate::codec::hex32(expected),
            ),
            CarryoverError::Count { found, expected } => write!(
                f,
                "carryover ENTRY-COUNT mismatch: the file carries {found} outputs, \
                 the manifest commits to {expected} ({} {})",
                found.abs_diff(*expected),
                if found > expected { "too many" } else { "missing" },
            ),
            CarryoverError::Total { found, expected } => write!(
                f,
                "carryover TOTAL mismatch: the file carries {found} sat after the \
                 x100/21 split, the manifest commits to {expected} (difference {} sat, \
                 the file is {})",
                found.abs_diff(*expected),
                if found > expected { "richer" } else { "poorer" },
            ),
            CarryoverError::NotCommitted => write!(
                f,
                "this manifest commits to no carryover — refusing to open a chain \
                 with balances the network digest says nothing about"
            ),
        }
    }
}

impl std::error::Error for CarryoverError {}

impl From<CarryoverError> for io::Error {
    fn from(e: CarryoverError) -> io::Error {
        match e {
            CarryoverError::Io(e) => e,
            other => io::Error::new(io::ErrorKind::InvalidData, other.to_string()),
        }
    }
}

/// A parsed snapshot: the Genesis-4 outputs it becomes, plus everything the
/// commitment is checked against and the arithmetic that got there.
#[derive(Debug)]
pub struct CarryoverSnapshot {
    /// The opening outputs, in file order — which is (txid, vout) order.
    pub entries: Vec<EutxoEntry>,
    /// SHA3-256 over the exact bytes read.
    pub digest: [u8; 32],
    /// SHAKE-256 over the canonical rows — the published set root.
    pub set_root: [u8; 32],
    /// The snapshot's own total, in Genesis-3 satoshis, before the split.
    pub g3_total_sat: u128,
    /// What `entries` sum to: Genesis-4 satoshis, dust included.
    pub total_sat: u128,
    /// Sub-satoshi remainders of the per-output split, gathered and given to
    /// one output — see [`read_carryover_snapshot`] for the rule and why one
    /// is needed.
    pub dust_sat: u128,
}

impl CarryoverSnapshot {
    /// The four checks, in the order that explains the most: file digest
    /// (wrong bytes explains everything after it), set root (right bytes,
    /// wrong set), count, total.
    pub fn check_against(&self, c: &CarryoverCommitment) -> Result<(), CarryoverError> {
        if self.digest != c.digest {
            return Err(CarryoverError::Digest { found: self.digest, expected: c.digest });
        }
        if self.set_root != c.set_root {
            return Err(CarryoverError::SetRoot { found: self.set_root, expected: c.set_root });
        }
        let n = self.entries.len() as u64;
        if n != c.entry_count {
            return Err(CarryoverError::Count { found: n, expected: c.entry_count });
        }
        if self.total_sat != c.total_sat {
            return Err(CarryoverError::Total { found: self.total_sat, expected: c.total_sat });
        }
        Ok(())
    }
}

// Each arm's pattern guarantees the subtraction (and, for `'a'..='f'`, the
// following `+ 10`) stays within its match-arm bound: `b'0'..=b'9' => 0..=9`,
// `b'a'..=b'f' => (0..=5) + 10 == 10..=15` — always in-range for `u8`, never
// underflowing or overflowing.
#[allow(clippy::arithmetic_side_effects)]
fn hex_nibble(b: u8) -> Option<u8> {
    match b {
        b'0'..=b'9' => Some(b - b'0'),
        // Lowercase only. `hex::encode` — what the snapshot tool writes —
        // emits lowercase, so uppercase means the bytes are not the bytes
        // that were hashed, and it would fail the digest check anyway; saying
        // so at the line is more use than a digest mismatch over 54 MB.
        b'a'..=b'f' => Some(b - b'a' + 10),
        _ => None,
    }
}

/// Decode lowercase hex into `out` (cleared first). False on any non-hex byte
/// or an odd length.
fn hex_into(s: &str, out: &mut Vec<u8>) -> bool {
    out.clear();
    let b = s.as_bytes();
    if b.len() % 2 != 0 {
        return false;
    }
    for pair in b.chunks_exact(2) {
        match (hex_nibble(pair[0]), hex_nibble(pair[1])) {
            (Some(hi), Some(lo)) => out.push((hi << 4) | lo),
            _ => return false,
        }
    }
    true
}

/// Canonical unsigned decimal: digits only, no sign, no leading zero unless
/// the number *is* zero. `str::parse` accepts `+7` and `007`; both would be
/// bytes no builder wrote, and both hash differently from what they mean.
fn canonical_u64(s: &str) -> Option<u64> {
    if s.is_empty() || !s.bytes().all(|b| b.is_ascii_digit()) {
        return None;
    }
    if s.len() > 1 && s.starts_with('0') {
        return None;
    }
    s.parse().ok()
}

/// Read, parse and split a Genesis-3 balance snapshot. No commitment is
/// consulted here — [`load_carryover`] is the checked entry point.
///
/// ## Who owns a carried output — founder decision, 2026-08-13
///
/// The snapshot's fourth column is 20 bytes in every one of the 452,133 rows:
/// a Genesis-3 hash160 address, not a script. The committed column
/// (`EutxoEntry::script_hash`) is 32. The conversion is therefore a consensus
/// rule — it decides who owns each output — and it was decided, not inferred:
///
/// ```text
/// script_hash[0..20]  = the snapshot's 20 bytes (the Genesis-3 hash160)
/// script_hash[20..32] = 0x00
/// ```
///
/// **Zero-extension to the right, no re-hashing.** The criterion was
/// auditability: a holder proves their balance crossed by comparing their own
/// Genesis-3 address against the first 20 bytes of the field, with no
/// conversion table and no preimage argument — and an exchange or an auditor
/// reconciling the migration will want exactly that comparison. Re-hashing
/// (`SHA3-256(tag ‖ address)`) would have made the column uniformly a SHA-3
/// digest, which is tidier, but it makes every such proof indirect.
///
/// The cost is known and accepted: **this column now carries a 20-byte format
/// inside a 32-byte field, permanently.** Whoever finds twelve zero bytes here
/// in two years is reading the reason for them right now. Two consequences
/// worth stating rather than discovering: the padding direction is itself
/// consensus (padding on the wrong side gives every output a different owner,
/// which is a different ledger), and a carried output is not spendable by any
/// rule of the form `SHA3-256(script) == script_hash`, so the migration spend
/// path must recognise carried outputs explicitly — that path does not exist
/// yet and this is the fact it has to be built around.
///
/// A row whose fourth column is not exactly 20 bytes is refused rather than
/// converted: there is no decided rule for it, and inventing one silently is
/// how an output acquires an owner nobody chose.
///
/// ## The split, and the dust rule this states
///
/// Every value crosses through `tokenomics_v4::split_g3_sat` — ×100/21,
/// truncating — because that is the policy the constants crate already
/// writes down, and the whole point of the 2026-08-12 decision is that every
/// balance moves by the same ratio.
///
/// Measured on the real snapshot (2026-08-13, 452,133 outputs): the aggregate
/// is exact — 380,574,600,000,000,000 G3 sat × 100/21 =
/// 1,812,260,000,000,000,000 with no remainder — and 452,021 rows split
/// exactly, because a Genesis-3 coinbase of 8,400 BLCH is divisible by 21.
/// **112 rows leave a remainder, and truncating them row by row loses 59
/// satoshis** across the whole ledger: 0.00000059 BLOCH. Tiny, and fatal
/// anyway — [`Manifest::check_supply`] demands equality, so a launch would
/// stop on a rounding error 59 satoshis wide.
///
/// **The rule, stated: the largest output absorbs the whole remainder.** The
/// remainder is `split_g3_sat(total) - Σ split_g3_sat(value_i)` — the exact
/// gap between splitting the aggregate and splitting the rows — and it goes
/// to the highest-value output, ties broken by the lowest (txid, vout), which
/// is the first such line in the file since the file is sorted. Determinism
/// is the point: two nodes that place the dust differently commit different
/// state roots, so "the largest" is not enough on its own and the tie-break
/// is part of the rule.
///
/// On the real snapshot that lands the 59 satoshis on the founder's address
/// (`e986db51…`, which holds 425,599 of the 452,133 outputs) — the same
/// posture as the 100 B split, where the founder absorbs the rounding. The
/// alternative considered and rejected was to declare the truncated sum as
/// the carryover total, which closes by construction but leaves
/// `CARRYOVER_TOTAL_BLOCH` a non-round 18,122,599,999.99999941. What is *not*
/// acceptable is dropping the remainder, the one option that cannot close the
/// accounting at all.
pub fn read_carryover_snapshot<R: BufRead>(
    mut src: R,
) -> Result<CarryoverSnapshot, CarryoverError> {
    use sha3::digest::{ExtendableOutput, Update, XofReader};

    // Two hashers over one pass. `file` answers "did these bytes arrive
    // intact"; `set` answers "is this the same set of outputs", over the
    // canonical re-serialisation of what was parsed. On a well-formed
    // snapshot they cover identical bytes — the strict parser admits exactly
    // one encoding — and they are still two questions, asked of two things.
    let mut file = Sha3_256::new();
    let mut set = sha3::Shake256::default();
    // Reused across every line: `clear` keeps the allocation, so 452k lines
    // cost two allocations, not 904k.
    let mut line = Vec::with_capacity(256);
    // One scratch buffer for both hex columns: the txid is decoded and copied
    // out before the script column overwrites it.
    let mut hexbuf = Vec::with_capacity(64);

    let mut entries: Vec<EutxoEntry> = Vec::new();
    let mut g3_total_sat: u128 = 0;
    let mut split_total: u128 = 0;
    let mut prev: Option<([u8; 32], u32)> = None;
    let mut n: u64 = 0;

    loop {
        line.clear();
        // Bounded per line, not merely checked afterwards: `read_until` on a
        // file with no newline in it would otherwise pull the whole thing into
        // memory before the cap below could object — which is the allocation
        // the cap exists to prevent.
        // `MAX_SNAPSHOT_LINE` is a fixed 4_096-byte constant; `+ 1` (one byte
        // over the cap, so a too-long line is detected rather than silently
        // truncated at the boundary) cannot approach u64::MAX.
        let read = std::io::Read::take(&mut src, (MAX_SNAPSHOT_LINE as u64).saturating_add(1))
            .read_until(b'\n', &mut line)
            .map_err(CarryoverError::Io)?;
        if read == 0 {
            break;
        }
        // Line counter, used only for the cap check just below and in error
        // messages: saturating is the intended semantics.
        n = n.saturating_add(1);
        // Hash the raw bytes, before any interpretation of them: the file
        // digest must be over the file as it sits on disk, or "these exact
        // bytes" silently becomes "these bytes as this parser understood
        // them".
        Digest::update(&mut file, &line);

        if n > MAX_CARRYOVER_ENTRIES {
            return Err(CarryoverError::Line {
                line: n,
                what: format!(
                    "snapshot exceeds the {MAX_CARRYOVER_ENTRIES}-entry cap — refusing to \
                     read further"
                ),
            });
        }
        if line.len() > MAX_SNAPSHOT_LINE {
            return Err(CarryoverError::Line {
                line: n,
                what: format!("line is {} bytes, over the {MAX_SNAPSHOT_LINE} cap", line.len()),
            });
        }

        let body = line.strip_suffix(b"\n").unwrap_or(&line);
        let text = match std::str::from_utf8(body) {
            Ok(t) => t,
            Err(_) => {
                return Err(CarryoverError::Line { line: n, what: "not UTF-8".into() });
            }
        };
        if text.ends_with('\r') {
            return Err(CarryoverError::Line {
                line: n,
                what: "CRLF line ending — the snapshot is written with bare LF, and \
                       a CRLF copy is not the bytes that were hashed"
                    .into(),
            });
        }
        if text.is_empty() {
            return Err(CarryoverError::Line {
                line: n,
                what: "empty line — the snapshot has no blank lines and no trailing \
                       separator"
                    .into(),
            });
        }

        let mut cols = text.split('\t');
        let (Some(txid_s), Some(vout_s), Some(value_s), Some(script_s), None) =
            (cols.next(), cols.next(), cols.next(), cols.next(), cols.next())
        else {
            return Err(CarryoverError::Line {
                line: n,
                what: format!(
                    "expected 4 tab-separated columns \
                     (txid<TAB>vout<TAB>value_sat<TAB>script_hex), got {}",
                    text.split('\t').count()
                ),
            });
        };

        let mut txid = [0u8; 32];
        if txid_s.len() != 64 || !hex_into(txid_s, &mut hexbuf) {
            return Err(CarryoverError::Line {
                line: n,
                what: format!("txid must be 64 lowercase-hex characters, got {txid_s:?}"),
            });
        }
        txid.copy_from_slice(&hexbuf);

        let Some(vout) = canonical_u64(vout_s).and_then(|v| u32::try_from(v).ok()) else {
            return Err(CarryoverError::Line {
                line: n,
                what: format!("vout must be a canonical u32 decimal, got {vout_s:?}"),
            });
        };
        let Some(value) = canonical_u64(value_s) else {
            return Err(CarryoverError::Line {
                line: n,
                what: format!("value must be a canonical u64 decimal of satoshis, got {value_s:?}"),
            });
        };
        // The address column: exactly 20 bytes in all 452,133 rows of the
        // measured snapshot, a Genesis-3 hash160. Any other length has no
        // decided conversion into the 32-byte committed field, and guessing
        // one would hand the output to an owner nobody chose.
        if script_s.len() != G3_ADDRESS_HEX || !hex_into(script_s, &mut hexbuf) {
            return Err(CarryoverError::Line {
                line: n,
                what: format!(
                    "address must be exactly {G3_ADDRESS_HEX} lowercase-hex characters \
                     (a Genesis-3 hash160), got {script_s:?} — there is no decided rule \
                     for carrying anything else across",
                ),
            });
        }
        let mut script_hash = [0u8; 32];
        // Zero-extension to the RIGHT — founder decision, 2026-08-13, see the
        // function docs. The direction is consensus: padded on the left, every
        // output has a different owner and this is a different chain.
        script_hash[..G3_ADDRESS_BYTES].copy_from_slice(&hexbuf);

        // The canonical row, into the set root: the same bytes the snapshot
        // tool wrote, rebuilt from what was parsed rather than replayed from
        // the line, so this root is a statement about the outputs and not
        // about the file's whitespace.
        Update::update(&mut set, txid_s.as_bytes());
        Update::update(&mut set, b"\t");
        Update::update(&mut set, vout_s.as_bytes());
        Update::update(&mut set, b"\t");
        Update::update(&mut set, value_s.as_bytes());
        Update::update(&mut set, b"\t");
        Update::update(&mut set, script_s.as_bytes());
        Update::update(&mut set, b"\n");

        // Strictly ascending (txid, vout). The tool sorts, so this costs
        // nothing on a real file — and it is the only check that catches a
        // duplicated outpoint, which `CommittedState::genesis` would otherwise
        // absorb into its map, dropping one copy and leaving the ledger short
        // of the total it just verified.
        if let Some(p) = prev {
            if (txid, vout) <= p {
                return Err(CarryoverError::Line {
                    line: n,
                    what: "outpoints must be strictly ascending by (txid, vout) — this row \
                           repeats or precedes the one before it"
                        .into(),
                });
            }
        }
        prev = Some((txid, vout));

        let split = tokenomics_v4::split_g3_sat(u128::from(value));
        let Ok(split_u64) = u64::try_from(split) else {
            return Err(CarryoverError::Line {
                line: n,
                what: format!("{value} sat becomes {split} sat under the split, past u64"),
            });
        };
        // u128 accumulator over at most MAX_CARRYOVER_ENTRIES (16,000,000)
        // rows, each at most u64::MAX: the sum is bounded by
        // 16_000_000 * u64::MAX ≈ 2.95e26, far below u128::MAX ≈ 3.4e38.
        #[allow(clippy::arithmetic_side_effects)]
        {
            g3_total_sat += u128::from(value);
        }
        // `split` is `split_g3_sat(value)` — the split of one row never
        // exceeds the row (§ the dust-rule comment below) — so this sum is
        // bounded by the same 16,000,000 × u64::MAX argument as above.
        #[allow(clippy::arithmetic_side_effects)]
        {
            split_total += split;
        }

        entries.push(EutxoEntry {
            // The Genesis-3 outpoint crosses unchanged. It is what wallets,
            // explorers and the published snapshot already call this output,
            // and a re-derived id would make every holder's coin unfindable
            // by the only name it has ever had.
            txid,
            vout,
            value: split_u64,
            // 20 bytes of Genesis-3 address, then 12 zeros. Not a hash of
            // anything — see the founder decision in this function's docs, and
            // note that `GenesisAllocation::script_hash` in the same state IS
            // a real SHA3-256, so this field is a union of two formats by
            // decision rather than by accident.
            script_hash,
        });
    }

    let digest: [u8; 32] = file.finalize().into();
    let mut set_root = [0u8; 32];
    set.finalize_xof().read(&mut set_root);

    // The dust rule, applied. `split_g3_sat` of the aggregate is what the
    // ledger is worth; the rows sum to that or just under it, never over
    // (a sum of floors never exceeds the floor of the sum).
    let exact = tokenomics_v4::split_g3_sat(g3_total_sat);
    // Per the comment above: a sum of floors never exceeds the floor of the
    // sum, so `split_total <= exact` always.
    #[allow(clippy::arithmetic_side_effects)]
    let dust_sat = exact - split_total;
    if dust_sat > 0 {
        // Highest value; ties to the lowest (txid, vout). The strict `>` is
        // what implements the tie-break: entries are in strictly ascending
        // outpoint order (the parser enforces it), so keeping the first
        // maximum keeps the lowest outpoint. `>=` here would silently take the
        // last one instead, and two nodes disagreeing about where one satoshi
        // landed is two state roots.
        let mut best = 0usize;
        for (i, e) in entries.iter().enumerate() {
            if e.value > entries[best].value {
                best = i;
            }
        }
        let Ok(d) = u64::try_from(dust_sat) else {
            return Err(CarryoverError::Line {
                line: n,
                what: format!("split remainder {dust_sat} sat does not fit u64"),
            });
        };
        let Some(v) = entries[best].value.checked_add(d) else {
            return Err(CarryoverError::Line {
                line: n,
                what: format!(
                    "largest output {} sat overflows u64 absorbing {d} sat of split remainder",
                    entries[best].value
                ),
            });
        };
        entries[best].value = v;
    }

    Ok(CarryoverSnapshot {
        entries,
        digest,
        set_root,
        g3_total_sat,
        total_sat: exact,
        dust_sat,
    })
}

/// Read a snapshot file and hold it against all four fields of the commitment
/// — digest, set root, entry count, total — via
/// [`CarryoverSnapshot::check_against`]. The only function that should produce
/// carryover entries for a live chain.
pub fn load_carryover(
    path: &Path,
    commitment: &CarryoverCommitment,
) -> Result<CarryoverSnapshot, CarryoverError> {
    let f = fs::File::open(path).map_err(CarryoverError::Io)?;
    // 1 MiB of buffer against a 54 MB file: ~54 syscalls instead of ~13,000.
    let snap = read_carryover_snapshot(BufReader::with_capacity(1 << 20, f))?;
    snap.check_against(commitment)?;
    Ok(snap)
}

impl Manifest {
    pub fn encode(&self) -> Vec<u8> {
        let mut out = Vec::new();
        // The magic IS the format: everything after it is byte-identical
        // between v1 and v2, so a manifest cannot be re-tagged by editing a
        // field, and the digest pinned into `meta` covers these 8 bytes.
        out.extend_from_slice(match self.format {
            ManifestFormat::V1Unbound => MANIFEST_MAGIC_V1,
            ManifestFormat::V2Bound => MANIFEST_MAGIC_V2,
        });
        out.extend_from_slice(&self.genesis_time_ms.to_le_bytes());
        out.extend_from_slice(&self.slot_ms.to_le_bytes());
        out.extend_from_slice(&(self.validators.len() as u32).to_le_bytes());
        for v in &self.validators {
            out.extend_from_slice(&v.index.to_le_bytes());
            out.extend_from_slice(&v.stake_sat.to_le_bytes());
            out.extend_from_slice(&v.randao_commitment);
            crate::codec::put_bytes(&mut out, &v.pubkey);
            crate::codec::put_bytes(&mut out, &v.withdrawal_credentials);
            out.extend_from_slice(&v.commission_bps.to_le_bytes());
        }
        out.extend_from_slice(&(self.cohort.len() as u32).to_le_bytes());
        for c in &self.cohort {
            out.extend_from_slice(&c.to_le_bytes());
        }
        match &self.carryover {
            None => out.push(0),
            Some(c) => {
                out.push(1);
                out.extend_from_slice(&c.digest);
                out.extend_from_slice(&c.set_root);
                out.extend_from_slice(&c.entry_count.to_le_bytes());
                out.extend_from_slice(&c.total_sat.to_le_bytes());
            }
        }
        out.extend_from_slice(&(self.allocations.len() as u32).to_le_bytes());
        for a in &self.allocations {
            out.push(a.purpose);
            out.extend_from_slice(&a.script_hash);
            out.extend_from_slice(&a.amount_sat.to_le_bytes());
            out.extend_from_slice(&a.unlock_epoch.to_le_bytes());
        }
        out
    }

    pub fn decode(bytes: &[u8]) -> Result<Manifest, crate::codec::DecodeErr> {
        use crate::codec::{DecodeErr, Reader};
        let mut r = Reader::new(bytes);
        let format = match r.take(8)? {
            m if m == MANIFEST_MAGIC_V1 => ManifestFormat::V1Unbound,
            m if m == MANIFEST_MAGIC_V2 => ManifestFormat::V2Bound,
            _ => return Err(DecodeErr("not a genesis manifest")),
        };
        let genesis_time_ms = r.u64()?;
        let slot_ms = r.u64()?;
        if slot_ms == 0 {
            return Err(DecodeErr("slot_ms zero"));
        }
        let n = r.u32()? as usize;
        if n > 1_000_000 {
            return Err(DecodeErr("validator count over cap"));
        }
        // BLP-02 (CertiK, 2026-08-17). THE SUITE IS CHECKED HERE, AT INGESTION.
        //
        // `bloch_crypto::crypto::verify` dispatches on the suite carried INSIDE the
        // public key. A registry key stamped SUITE_MLDSA65_ONLY (0x0002) is therefore
        // verified with the ML-DSA half alone — and `HybridVerifier`, despite its
        // name, hands the registered bytes straight to that dispatcher. Staking
        // deposits already reject 0x0002; the manifest path did not, so the hybrid
        // invariant rested on whoever assembled the file.
        //
        // Genesis-4's live manifest carries 64 keys, every one of them 0x0001 and
        // 3,749 bytes (4 header + 1,952 ML-DSA-65 + 1,793 Falcon-1024), so nothing on
        // the chain today is affected. This closes the door rather than reporting that
        // nobody walked through it.
        //
        // Refusing here — at decode, before a key can reach a verifier — is what makes
        // the rule hold for every consumer of a manifest, including ones not written
        // yet.
        fn check_hybrid_pubkey(pk: &[u8], index: u32) -> Result<(), DecodeErr> {
            use bloch_crypto::crypto::{MLDSA_PUBKEY_LEN, SUITE_HEADER_LEN, SUITE_MLDSA65_FALCON1024};
            if pk.len() < SUITE_HEADER_LEN {
                let _ = index;
                return Err(DecodeErr("validator pubkey shorter than its suite header"));
            }
            if pk[0] != 0xB1 || pk[1] != 0x0C {
                return Err(DecodeErr("validator pubkey is not suite-enveloped"));
            }
            let suite = u16::from_le_bytes([pk[2], pk[3]]);
            if suite != SUITE_MLDSA65_FALCON1024 {
                // Named rather than numbered: "suite 0x0002" tells an operator nothing.
                return Err(DecodeErr(
                    "validator pubkey is not the hybrid ML-DSA-65 + Falcon-1024 suite — \
                     Genesis-4 consensus signatures must verify on BOTH halves",
                ));
            }
            // Both halves must be present. A body of exactly the ML-DSA length would
            // carry no Falcon key at all while still claiming the hybrid suite.
            if pk.len() <= SUITE_HEADER_LEN + MLDSA_PUBKEY_LEN {
                return Err(DecodeErr(
                    "validator pubkey claims the hybrid suite but carries no Falcon-1024 half",
                ));
            }
            Ok(())
        }

        let mut validators = Vec::with_capacity(n);
        for _ in 0..n {
            let index = r.u32()?;
            let stake_sat = r.u128()?;
            let randao_commitment = r.h32()?;
            let pubkey = r.bytes()?;
            check_hybrid_pubkey(&pubkey, index)?;
            validators.push(ManifestValidator {
                index,
                stake_sat,
                randao_commitment,
                pubkey,
                withdrawal_credentials: r.bytes()?,
                commission_bps: r.u128()?,
            });
        }
        let nc = r.u32()? as usize;
        if nc > n {
            return Err(DecodeErr("cohort larger than set"));
        }
        let mut cohort = Vec::with_capacity(nc);
        for _ in 0..nc {
            cohort.push(r.u32()?);
        }
        let carryover = match r.u8()? {
            0 => None,
            1 => Some(CarryoverCommitment {
                digest: r.h32()?,
                set_root: r.h32()?,
                entry_count: r.u64()?,
                total_sat: r.u128()?,
            }),
            // A third value would mean two encodings of one manifest and so
            // two digests for one network.
            _ => return Err(DecodeErr("carryover flag not canonical")),
        };
        let na = r.u32()? as usize;
        if na > 64 {
            return Err(DecodeErr("allocation count over cap"));
        }
        let mut allocations = Vec::with_capacity(na);
        for _ in 0..na {
            let purpose = r.u8()?;
            let script_hash = r.h32()?;
            let amount_sat = r.u128()?;
            // Refused here, at decode, rather than left to panic later: every
            // real node reaches `amount_sat` only through this function
            // (`Manifest::load`), and `allocation_outputs` converts it to
            // `u64` to build the genesis eUTXO set on every boot. A manifest
            // whose allocation cannot be committed truthfully as u64
            // satoshis is a malformed manifest, not a node crash.
            if u64::try_from(amount_sat).is_err() {
                return Err(DecodeErr("allocation amount exceeds u64 satoshis"));
            }
            allocations.push(GenesisAllocation {
                purpose,
                script_hash,
                amount_sat,
                unlock_epoch: r.u64()?,
            });
        }
        r.finish()?;
        Ok(Manifest {
            genesis_time_ms,
            slot_ms,
            validators,
            cohort,
            carryover,
            allocations,
            // Decoding a manifest can never produce the balance set: the set
            // is not in these bytes by design. A mainnet manifest therefore
            // arrives here incomplete and stays that way until
            // `ingest_carryover` checks a snapshot against the commitment.
            carryover_entries: Vec::new(),
            format,
            pre_state_root: std::sync::OnceLock::new(),
        })
    }

    /// Satoshis this manifest bonds into the genesis validator registry.
    ///
    /// These are coins. `CommittedState::genesis` writes each
    /// [`ManifestValidator::stake_sat`] into a `ValidatorRecord::staked_sat`,
    /// where it earns rewards, carries consensus weight and is slashable —
    /// every property a satoshi in the eUTXO set has, minus spendability until
    /// a withdrawal path exists. A supply check that counted only the outputs
    /// would be counting the smaller half of the money.
    ///
    /// **This is the term that had no name, and 1,600,000 BLOCH went through
    /// the hole.** Genesis-4 mainnet bonds 64 validators at 25,000 BLOCH each
    /// while [`Self::genesis_issued_sat`] sums the carryover and the
    /// allocations only, so the ceremony's arithmetic balanced with the
    /// cohort's entire stake outside it — minted from nothing, at slot 0, by a
    /// check that reported the manifest added up.
    ///
    /// Naming it does not un-mint it; that chain is running. What it changes
    /// is that the quantity is now summed, printed by `genesis-mainnet`, and
    /// checkable through [`Self::check_bonds_are_funded`], so the next
    /// ceremony cannot repeat the omission without seeing it.
    pub fn genesis_bonded_sat(&self) -> u128 {
        self.validators.iter().map(|v| v.stake_sat).sum()
    }

    /// What genesis **funds**: carried balances plus allocations.
    ///
    /// Deliberately *not* including [`Self::genesis_bonded_sat`], and the
    /// name is the reason. This is the number that must equal
    /// `tokenomics_v4::GENESIS_ISSUED_SAT`, because that constant is what
    /// `CommittedState::genesis` seeds the committed `issued_sat` counter
    /// with — so this function has to mean exactly what the counter means, or
    /// the check below verifies a different quantity from the one the chain
    /// commits.
    ///
    /// The bonds are real coins all the same. They are counted by
    /// [`Self::genesis_accounted_sat`], and the difference between the two —
    /// [`Self::genesis_unfunded_bonded_sat`] — is the supply gap Genesis-4
    /// opened with.
    pub fn genesis_issued_sat(&self) -> u128 {
        // For every real supply this chain has ever had or could plausibly
        // have, this is far below u128::MAX; `saturating_add` matters only
        // for a manifest so malformed its total already exceeds u128 range,
        // in which case saturating to u128::MAX makes `check_supply`'s
        // `issued > TOTAL_SUPPLY_SAT` comparison refuse it for certain,
        // rather than wrapping into a value that could look small.
        self.carryover
            .as_ref()
            .map_or(0, |c| c.total_sat)
            .saturating_add(self.allocations.iter().map(|a| a.amount_sat).sum::<u128>())
    }

    /// Every satoshi that exists the instant this manifest's genesis block is
    /// committed: what it funds, plus what it bonds.
    ///
    /// The manifest-side mirror of
    /// `CommittedState::accounted_supply_sat`, and it must stay that: at slot
    /// 0 the committed state holds exactly the carryover and allocation
    /// outputs (in the eUTXO set) and the cohort's bonds (in the registry).
    /// Pinned against the committed state by
    /// `genesis_accounting_matches_the_committed_state`.
    pub fn genesis_accounted_sat(&self) -> u128 {
        // Same reasoning as `genesis_issued_sat`: saturating only matters for
        // an already-malformed manifest, and saturating makes it read as
        // over-supply (refused downstream) rather than wrapping small.
        self.genesis_issued_sat().saturating_add(self.genesis_bonded_sat())
    }

    /// Coins this manifest bonds that its issuance never accounted for —
    /// `genesis_accounted_sat() - genesis_issued_sat()`, i.e. exactly
    /// [`Self::genesis_bonded_sat`], stated under the name that says what is
    /// wrong with it.
    ///
    /// **1,600,000 BLOCH on Genesis-4 mainnet** (64 validators × 25,000).
    /// Non-zero is not a manifest defect that [`Self::check_supply`] can
    /// refuse, because the mainnet manifest is already signed and its chain
    /// is already running: the fix would be a relaunch, not a check.
    ///
    /// What [`Self::check_bonds_are_funded`] does refuse — as a hard error
    /// since 2026-09-04, not a printed warning — is a manifest whose figure
    /// here exceeds `tokenomics_v4::GENESIS_UNFUNDED_BONDED_CEILING_SAT`, the
    /// frozen record of what this chain already did. A 65th validator, a
    /// raised stake, or a second unfunded cohort is therefore impossible to
    /// sign by accident, while regenerating the artifact the live chain runs
    /// from still succeeds.
    pub fn genesis_unfunded_bonded_sat(&self) -> u128 {
        self.genesis_bonded_sat()
    }

    /// The clean rule, with no tolerance at all: every bonded satoshi was
    /// funded, `genesis_accounted_sat() == GENESIS_ISSUED_SAT`.
    ///
    /// **False for Genesis-4 mainnet**, which is exactly why it is a separate
    /// predicate from [`Self::check_bonds_are_funded`] rather than the rule
    /// that one enforces. It is the state the next launch should be in, and
    /// it is stated here so both sides of the eventual tightening are tested
    /// today: when the cohort is funded out of an allocation bucket this
    /// returns `true`, the ceiling constant drops to zero, and the two checks
    /// become the same check with no edit to either.
    ///
    /// **No production caller**, and the dead-code warning is the honest
    /// signal rather than something to silence: this is the rule the chain
    /// does not yet satisfy. It is called only from
    /// `unfunded_genesis_bonds_are_refused_above_the_committed_ceiling`, which
    /// asserts it is FALSE for the live cohort and TRUE once the cohort is
    /// funded — so the tightening is tested from both sides before anyone
    /// performs it. Same posture as [`Self::pubkeys`] below.
    pub fn bonds_are_fully_funded(&self) -> bool {
        use bloch_pos_committee::tokenomics_v4 as t;
        self.genesis_accounted_sat() == t::GENESIS_ISSUED_SAT
    }

    /// Refuse a manifest that does not add up.
    ///
    /// This is the check that makes the manifest a claim rather than an
    /// assertion. A genesis file is the one artifact nobody can re-derive
    /// later — once a chain runs from it, whatever it said is what happened —
    /// so the arithmetic is verified before it is signed, not after someone
    /// notices the supply is wrong.
    pub fn check_supply(&self) -> Result<(), String> {
        use bloch_pos_committee::tokenomics_v4 as t;
        let issued = self.genesis_issued_sat();
        if issued > t::TOTAL_SUPPLY_SAT {
            return Err(format!(
                "genesis issues {issued} sat, above the hard cap {}",
                t::TOTAL_SUPPLY_SAT
            ));
        }
        // Validator emission is issued by blocks over decades; genesis must
        // leave exactly that much unissued, or the emission schedule and the
        // cap disagree and one of them silently wins.
        let expected = t::GENESIS_ISSUED_SAT;
        if self.carryover.is_some() && issued != expected {
            // The message names the bonded stake even though this check does
            // not judge it, because a ceremony operator reading a supply error
            // needs both figures in front of them: the one that failed and the
            // one that is unfunded on purpose (see `check_bonds_are_funded`).
            return Err(format!(
                "genesis funds {issued} sat (carryover + allocations); \
                 tokenomics §3 says {expected} (difference {}); \
                 {} sat additionally bonded to {} genesis validators",
                issued.abs_diff(expected),
                self.genesis_bonded_sat(),
                self.validators.len(),
            ));
        }
        Ok(())
    }

    /// The exhaustive genesis rule, **enforced**: a manifest may not bond
    /// more outside its issuance than this chain has already committed to.
    ///
    ///   `genesis_unfunded_bonded_sat() <= GENESIS_UNFUNDED_BONDED_CEILING_SAT`
    ///
    /// # Why a ceiling, and why that is still a hard error
    ///
    /// The clean rule is [`Self::bonds_are_fully_funded`] — zero tolerance,
    /// `accounted == GENESIS_ISSUED_SAT`. It is **false for the live chain**:
    /// Genesis-4 mainnet bonds 1,600,000 BLOCH outside its issuance, so a
    /// check that demanded zero would make the node's own `genesis-mainnet`
    /// subcommand refuse to regenerate the artifact the network is running
    /// from. A check that fails on committed history is not a check, it is a
    /// broken tool, and that is why this shipped as a printed warning until
    /// 2026-09-04.
    ///
    /// A warning was the wrong resolution. It made the omission a decision
    /// nobody makes — the ceremony operator sees `WARNING (not fatal)`,
    /// the tool exits zero, the artifact is written, and the next unfunded
    /// cohort goes out under exactly the reasoning that produced the first
    /// one. Comparing against a NAMED CEILING gets both: committed history
    /// passes, and anything worse than committed history is `Err` and a
    /// non-zero exit. A 65th validator, a raised `stake_sat`, a second
    /// cohort — each of those raises the figure past the ceiling and is now
    /// refused, which is the entire class of repeat the warning could only
    /// describe.
    ///
    /// The ceiling is frozen and documented as such on the constant. Raising
    /// it is the one edit that legalises a new mint from nothing, and it is
    /// now an edit someone has to make deliberately, to a constant whose doc
    /// says what it is, rather than a warning line scrolling past.
    ///
    /// Devnet manifests (no carryover) are exempt for the same reason
    /// `check_supply` exempts them: they issue nothing — `GENESIS_ISSUED_SAT`
    /// describes a network that carries Genesis-3 balances — and they bond
    /// play money against it.
    pub fn check_bonds_are_funded(&self) -> Result<(), String> {
        use bloch_pos_committee::tokenomics_v4 as t;
        if self.carryover.is_none() {
            return Ok(());
        }
        let unfunded = self.genesis_unfunded_bonded_sat();
        if unfunded > t::GENESIS_UNFUNDED_BONDED_CEILING_SAT {
            return Err(format!(
                "genesis holds {} sat at slot 0 (funded {} + bonded {}) but issues {}; \
                 {unfunded} sat of validator stake is minted from nothing, which is \
                 {} sat past the {} sat recorded Genesis-4 cohort offset. That offset \
                 is committed history, not a budget: see \
                 tokenomics_v4::GENESIS_UNFUNDED_BONDED_CEILING_SAT before raising it.",
                self.genesis_accounted_sat(),
                self.genesis_issued_sat(),
                self.genesis_bonded_sat(),
                t::GENESIS_ISSUED_SAT,
                // Guarded by `unfunded > ...CEILING_SAT` just above:
                // `saturating_sub` is exact here, not merely assumed.
                unfunded.saturating_sub(t::GENESIS_UNFUNDED_BONDED_CEILING_SAT),
                t::GENESIS_UNFUNDED_BONDED_CEILING_SAT,
            ));
        }
        Ok(())
    }

    pub fn load(path: &Path) -> io::Result<(Manifest, [u8; 32])> {
        let bytes = fs::read(path)?;
        let digest: [u8; 32] = Sha3_256::digest(&bytes).into();
        let m = Manifest::decode(&bytes)
            .map_err(|e| io::Error::new(io::ErrorKind::InvalidData, e.to_string()))?;
        Ok((m, digest))
    }

    /// The genesis block header, synthesized deterministically from the
    /// manifest. Genesis is a block, so its id derives from a header through
    /// the single §5.4 path — never from a label.
    ///
    /// Under [`ManifestFormat::V2Bound`] it commits to the ledger: the genesis
    /// state root in `state_root` and a carryover-seeded `randao_mix`, so no
    /// two manifests describing different chains can share a genesis id.
    /// Under [`ManifestFormat::V1Unbound`] every field is a constant and the
    /// id is the same for every network — see [`ManifestFormat`] for why that
    /// rule is still reachable and what it costs.
    pub fn genesis_header(&self) -> BlockHeaderV4 {
        let mut h = self.anchor_header();
        if self.format == ManifestFormat::V2Bound {
            h.state_root = self.genesis_pre_state_root();
        }
        h
    }

    /// The beacon mix genesis opens with.
    ///
    /// Under [`ManifestFormat::V2Bound`] this is one §6.3 mixing step over the
    /// carryover digest AND the chain's clock:
    /// `SHA3-256(DS_RANDAO ‖ 0 ‖ carryover_digest ‖ genesis_time_ms ‖ slot_ms)`.
    /// The beacon's origin entropy is then pinned to the artifact the chain
    /// opens with and to the cadence it opens at, instead of being a constant
    /// an operator can reuse across networks. A manifest with no carryover (a
    /// devnet) mixes over a zero digest: the ledger binding then rests
    /// entirely on `state_root`, which is where it belongs anyway, and the
    /// clock terms still separate two devnets launched at different times.
    ///
    /// The two clock terms are the gap the first cut of this fix left open
    /// (see the body). Correcting the expression is free today because no
    /// `BPOSMAN2` manifest has ever been published — the format is inert
    /// until a founder publishes one.
    ///
    /// # Before any `BPOSMAN2` manifest is published
    ///
    /// `tools/genesis4-ceremony::genesis_header` assembles the header the
    /// ceremony PUBLISHES, and it does not agree with this function. It mixes
    /// `SHA3-256(DS_RANDAO ‖ 0 ‖ carryover_digest)` with no clock terms, and
    /// it also differs in three fields this one leaves zero
    /// (`proposer_index`, `coherence_root`, and the state root it computes
    /// from its own `Genesis`). That disagreement PREDATES this correction —
    /// the tool has never matched the v1 rule the live chain runs either —
    /// so nothing here breaks an equality that was holding. But a v2 launch
    /// needs the two brought into line first, and the tool cannot even
    /// express these terms today: its `Genesis` struct carries no
    /// `genesis_time_ms` and no `slot_ms`. That is ceremony work, and it is a
    /// precondition of publishing a bound manifest, not of shipping this.
    ///
    /// Under [`ManifestFormat::V1Unbound`] it is [`GENESIS_MIX`], unchanged.
    pub fn genesis_mix(&self) -> [u8; 32] {
        match self.format {
            ManifestFormat::V1Unbound => GENESIS_MIX,
            ManifestFormat::V2Bound => {
                let digest = self.carryover.as_ref().map(|c| c.digest).unwrap_or([0u8; 32]);
                let mut h = Sha3_256::new();
                h.update(bloch_pos_committee::params::DS_RANDAO);
                h.update(GENESIS_MIX);
                h.update(digest);
                // The CLOSED GAP. The first cut of this fix mixed over the
                // carryover digest alone, which binds the ledger and stops
                // there. `state_root` binds the ledger too, so between them
                // the ONLY manifest fields left out of the genesis id were
                // these two -- and they are the two that define the chain's
                // clock. Measured on the b2 branch: two manifests differing
                // only in `slot_ms` produced the SAME genesis block id under
                // the bound format, and so did two differing only in
                // `genesis_time_ms`.
                //
                // That is the finding's own sentence unfulfilled. A node on
                // `slot_ms = 1_000` and a node on `slot_ms = 30_000` compute
                // different slots for the same instant, therefore different
                // epochs, committees and duties: they are not one network
                // that disagrees, they are two networks. Leaving them sharing
                // a genesis id reproduces exactly what C5 exists to close --
                // a substituted manifest that pairs at height 0 and diverges
                // later, as somebody else's block being blamed.
                //
                // Fixed widths, little-endian, declaration order: the same
                // encoding `Manifest::encode` writes them in, so there is one
                // reading of these bytes in the codebase and not two.
                h.update(self.genesis_time_ms.to_le_bytes());
                h.update(self.slot_ms.to_le_bytes());
                h.finalize().into()
            }
        }
    }

    /// The genesis header *before* it commits to the state it anchors: every
    /// field final except `state_root`.
    ///
    /// Its id is the anchor `genesis_pre_state_root` builds the genesis state
    /// against, which is what keeps the derivation from chasing its own tail
    /// (see that method). Under v1 this IS the genesis header — which is why
    /// a v1 manifest's `genesis_id` is bit-for-bit what it has always been.
    fn anchor_header(&self) -> BlockHeaderV4 {
        BlockHeaderV4 {
            version: VERSION_G4,
            parent: [0u8; 32],
            state_root: [0u8; 32],
            body_root: [0u8; 32],
            slot: 0,
            proposer_index: 0,
            randao_reveal: [0u8; 32],
            randao_mix: self.genesis_mix(),
            justified_root: [0u8; 32],
            finalized_root: [0u8; 32],
            attestation_root: [0u8; 32],
            coherence_root: [0u8; 32],
        }
    }

    /// The state root a [`ManifestFormat::V2Bound`] genesis header commits to.
    ///
    /// # The self-reference, and where it is cut
    ///
    /// Genesis is the one block whose state depends on its own identity:
    /// `CommittedState::genesis` seeds the justified and finalized checkpoints
    /// with the genesis block id, that id is `SHA3-256(DS_BLOCK ‖ header)`,
    /// and the header is what the root would go into. Committing the root of
    /// the *final* state is therefore not an object that can exist — no
    /// ordering of those three steps terminates.
    ///
    /// The cut: the state is built against [`Self::anchor_header`]'s id — the
    /// header with `state_root` still zero — and its root is what the final
    /// header carries. Every ledger fact is inside it: the validator registry
    /// with its stakes, commissions and RANDAO commitments; the genesis
    /// cohort; every opening balance (the whole carryover plus the vested
    /// allocations, through the eUTXO subtree); `issued_sat`; the taint,
    /// coherence and EVM commitments; epoch-0 participation. The only input
    /// NOT under it is the 32 bytes that are the answer — and those are
    /// determined by everything that is.
    ///
    /// So `genesis_id` becomes a function of the ledger, which is the whole
    /// point: substituting a manifest now moves the genesis block id, and a
    /// substituted chain no longer pairs at height 0.
    ///
    /// **Explicit expectation (R3 low):** this is DERIVED, on every call from
    /// every node, from `self`'s own committed fields (`validators`,
    /// `carryover`, the two clock fields) — it is never read off the wire as
    /// an opaque value one node produced and another must simply believe.
    /// `pre_state_root` is a memo of exactly this computation, not a second
    /// source for it: nothing anywhere decodes a `state_root` field off the
    /// manifest's own bytes into this cache. See
    /// `v2_bound_state_root_is_independently_recomputed_not_trusted`.
    pub fn genesis_pre_state_root(&self) -> [u8; 32] {
        *self.pre_state_root.get_or_init(|| {
            use bloch_pos_committee::interfaces::StateReader;
            self.state_anchored_at(BlockId::of(&self.anchor_header())).state_root()
        })
    }

    pub fn genesis_id(&self) -> BlockId {
        BlockId::of(&self.genesis_header())
    }

    /// The committed state of block 0. Coherence starts empty (integration
    /// plan decision 6) and taint is dissolved (decision 8): all three
    /// carried roots are zero.
    pub fn genesis_state(&self) -> CommittedState {
        self.state_anchored_at(self.genesis_id())
    }

    /// [`Self::genesis_state`] with the anchoring block id passed in.
    ///
    /// Two callers, one body: the real genesis state anchors at
    /// `genesis_id()`, and `genesis_pre_state_root` anchors at the
    /// pre-commitment header's id. Sharing the body is the point — if the two
    /// were written out separately, a component added to one (the way the
    /// eUTXO set once was not added to either) would go missing from the
    /// other's commitment without anything failing.
    fn state_anchored_at(&self, anchor: BlockId) -> CommittedState {
        let vals: Vec<GenesisValidator> = self
            .validators
            .iter()
            .map(|v| GenesisValidator {
                index: v.index,
                pubkey: v.pubkey.clone(),
                staked_sat: v.stake_sat,
                randao_commitment: v.randao_commitment,
                withdrawal_credentials: v.withdrawal_credentials.clone(),
                commission_bps: v.commission_bps,
            })
            .collect();
        CommittedState::genesis_with_network_domain(
            Sha3_256::digest(self.encode()).into(),
            anchor,
            self.genesis_mix(),
            &vals,
            &self.cohort,
            [0u8; 32],
            [0u8; 32],
            [0u8; 32],
            // Empty EVM segment at genesis. Spelled out rather than defaulted
            // so that adding a carried component breaks this call site and
            // someone decides what genesis commits, instead of it silently
            // becoming zero.
            EvmCommitment {
                account_root: [0u8; 32],
                receipts_root: [0u8; 32],
                gas_used: 0,
                base_fee_per_gas: 0,
            },
            &self.opening_balances(),
        )
    }

    /// Ingest the Genesis-3 balance snapshot this manifest commits to.
    ///
    /// The only supported way to fill [`Manifest::carryover_entries`]: it
    /// refuses a manifest with no commitment, and it refuses a file that fails
    /// any of the four checks. On success the manifest is complete — the
    /// genesis state it synthesises from here on carries every balance.
    ///
    /// Returns the snapshot, so a caller can print what it just accepted
    /// (count, totals, dust) instead of asserting it worked.
    pub fn ingest_carryover(&mut self, path: &Path) -> Result<CarryoverSnapshot, CarryoverError> {
        let Some(c) = self.carryover.clone() else {
            return Err(CarryoverError::NotCommitted);
        };
        let snap = load_carryover(path, &c)?;
        self.carryover_entries = snap.entries.clone();
        // The balance set just changed, so the memoised genesis root — which
        // commits to it — must not survive. `OnceLock::take` needs `&mut`,
        // which is exactly what this method holds and no other caller does.
        self.pre_state_root.take();
        Ok(snap)
    }

    /// Everything genesis puts into the ledger: the carried Genesis-3 outputs
    /// first, then the vested allocations.
    ///
    /// # Panics
    ///
    /// If the manifest commits to a carryover and none was ingested. That
    /// combination is the bug this path exists to make impossible — a mainnet
    /// launched from it opens with a state root nobody else computes and
    /// 452,133 outputs missing, and it would do so silently, which is the one
    /// outcome worse than not starting. It also panics on a duplicated
    /// outpoint between the two sets: `CommittedState::genesis` keys its map
    /// by `(txid, vout)`, so a collision would drop an output and leave the
    /// ledger short of the total that was just verified.
    pub fn opening_balances(&self) -> Vec<EutxoEntry> {
        if let Some(c) = &self.carryover {
            assert!(
                !self.carryover_entries.is_empty(),
                "manifest commits to a carryover of {} outputs ({} sat) but none were \
                 ingested — call Manifest::ingest_carryover before building genesis, or \
                 this chain opens with a zero balance for every holder",
                c.entry_count,
                c.total_sat,
            );
        }
        let allocs = self.allocation_outputs();
        // Capacity hint only: saturating is the intended semantics.
        let mut out = Vec::with_capacity(self.carryover_entries.len().saturating_add(allocs.len()));
        out.extend_from_slice(&self.carryover_entries);
        out.extend(allocs);
        // O(n log n) on 452k entries, once per genesis synthesis. Worth it:
        // the alternative is an output that silently does not exist.
        let mut keys: Vec<(&[u8; 32], u32)> = out.iter().map(|e| (&e.txid, e.vout)).collect();
        keys.sort_unstable();
        for w in keys.windows(2) {
            assert_ne!(
                w[0], w[1],
                "duplicate genesis outpoint {}:{} — one of these two outputs would vanish \
                 into the state map",
                crate::codec::hex32(w[0].0),
                w[0].1,
            );
        }
        out
    }

    /// The vested allocation outputs, as genesis eUTXOs.
    ///
    /// Deterministic from the manifest alone — every node synthesises the same
    /// outputs from the same bytes, which is the property genesis lives or
    /// dies by. The txid is a domain-separated digest over the allocation's
    /// own fields rather than a counter, so reordering the manifest's
    /// allocation list cannot silently change which output is which.
    ///
    /// The carryover is NOT here. Those entries come from the signed snapshot
    /// file, which the node ingests and checks against
    /// [`CarryoverCommitment`]; a 54 MB balance set does not belong inside the
    /// file every node hashes to decide which network it joined. The two sets
    /// meet in [`Manifest::opening_balances`], which is what genesis commits.
    pub fn allocation_outputs(&self) -> Vec<bloch_pos_committee::state_root::EutxoEntry> {
        self.allocations
            .iter()
            .map(|a| {
                let mut h = Sha3_256::new();
                Digest::update(&mut h, b"BLCH4:genesis-alloc\0");
                Digest::update(&mut h, [a.purpose]);
                Digest::update(&mut h, a.script_hash);
                Digest::update(&mut h, a.amount_sat.to_le_bytes());
                Digest::update(&mut h, a.unlock_epoch.to_le_bytes());
                let txid: [u8; 32] = h.finalize().into();
                bloch_pos_committee::state_root::EutxoEntry {
                    txid,
                    vout: 0,
                    // Values are u64 in the entry; an allocation above u64 is
                    // a manifest that could not be committed truthfully, so it
                    // is refused rather than truncated into a smaller number.
                    // Every manifest a real node loads passes through
                    // `Manifest::decode`, which now refuses (`DecodeErr`) any
                    // allocation whose `amount_sat` does not fit u64 before a
                    // `Manifest` value can exist at all — so this cannot fail
                    // on that path. (A `Manifest` built directly via a struct
                    // literal, as some tests do, bypasses that check; this
                    // matches the rest of this crate's existing posture of
                    // trusting values it assembled for itself in-process.)
                    // Left COUNTED by the hardened ratchet on purpose: a
                    // panic site with a hand proof is what it exists to track.
                    value: u64::try_from(a.amount_sat)
                        .expect("allocation exceeds u64 satoshis — see Manifest::decode"),
                    script_hash: a.script_hash,
                }
            })
            .collect()
    }

    /// The genesis public keys, keyed by validator **index**.
    ///
    /// Keyed, not positional, and that is the fix to a real defect. This used
    /// to return `Vec<Vec<u8>>` built as `vec![Vec::new(); validators.len()]`
    /// with each validator written at `pks[v.index]`, silently dropping any
    /// validator whose index was past the length. On a manifest that is not
    /// dense-from-0 that left an EMPTY key sitting at some position — and an
    /// empty key is the worst possible answer, because it looks like a
    /// present entry and verifies nothing, rather than being absent and
    /// saying so. It was the last of three position-vs-index defects in this
    /// codebase; the other two were in the committed registry's slice lookup
    /// and in the node's keystore gate.
    ///
    /// A `BTreeMap<u32, _>` removes the failure mode by construction: there
    /// is no position to confuse with an index, absence is `None`, and
    /// ordering is a function of the data. It also matches the shape the
    /// committed registry already uses (`BTreeMap<u32, ValidatorRecord>`),
    /// so the two can be compared directly — see
    /// `tests::registry_lookup_equals_the_manifest_table_at_genesis`.
    ///
    /// This has **no production caller**. Consensus signature checks used to
    /// read it through `HybridVerifier::new(manifest.pubkeys())`; they now
    /// resolve keys from the committed registry per call site. It survives as
    /// the genesis reference table the inertness proof is stated against.
    /// On the live fleet's dense, sorted, complete manifest the old and new
    /// forms agree entry for entry, which that proof asserts directly.
    pub fn pubkeys(&self) -> std::collections::BTreeMap<u32, Vec<u8>> {
        self.validators.iter().map(|v| (v.index, v.pubkey.clone())).collect()
    }
}

#[cfg(test)]
mod tests {
    /// `unlock_epoch` is committed but never consulted. This test exists so
    /// the claim is checked rather than remembered.
    ///
    /// The doc comment on [`GenesisAllocation`] once asserted the opposite —
    /// that an allocation is "unspendable until the chain reaches that epoch,
    /// so the schedule is enforced by every node". It was read as a guarantee
    /// for weeks. Nothing was verifying it, because a comment cannot fail.
    ///
    /// Spends are authorised in `bloch-pos-committee`. If the identifier ever
    /// appears there, this test fails — and the right response is not to
    /// delete the test but to go and correct that doc comment, which will by
    /// then be describing something real for the first time. Enforcement
    /// arriving is good news that must not arrive silently.
    #[test]
    fn vesting_is_not_enforced() {
        let mut src = Vec::new();
        let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../bloch-pos-committee/src");
        let mut stack = vec![root.clone()];
        while let Some(d) = stack.pop() {
            for e in std::fs::read_dir(&d).expect("bloch-pos-committee/src is readable") {
                let p = e.expect("dir entry").path();
                if p.is_dir() {
                    stack.push(p);
                } else if p.extension().is_some_and(|x| x == "rs") {
                    src.push((p.clone(), std::fs::read_to_string(&p).expect("utf-8 source")));
                }
            }
        }
        // If the crate ever moves, this test would pass by finding nothing —
        // the failure mode it is here to prevent.
        assert!(
            src.len() > 5,
            "found only {} source files under {} — this test cannot pass by \
             looking at nothing",
            src.len(),
            root.display(),
        );

        let hits: Vec<String> = src
            .iter()
            .flat_map(|(p, s)| {
                s.lines().enumerate().filter(|(_, l)| l.contains("unlock_epoch")).map(
                    move |(i, l)| format!("  {}:{}: {}", p.display(), i + 1, l.trim()),
                )
            })
            .collect();

        assert!(
            hits.is_empty(),
            "`unlock_epoch` now appears in bloch-pos-committee, the crate that \
             authorises spends:\n{}\n\nIf vesting is genuinely enforced now, say so: \
             the doc comment on GenesisAllocation states that it is NOT, and the \
             public supply page repeats that. Fix those first, then this test.",
            hits.join("\n"),
        );
    }

    /// The five shipped buckets are liquid at genesis independently of the
    /// above: `genesis-mainnet` writes `unlock_epoch: 0` for every one of
    /// them, so even an enforcing node would let them all spend from slot 0.
    /// Two independent reasons, so removing either one changes nothing.
    #[test]
    fn the_shipped_buckets_are_all_liquid_at_slot_zero() {
        let src = include_str!("main.rs");
        let start = src.find("let allocations = vec![").expect("the mainnet allocation list");
        let end = src[start..].find("];").expect("end of the allocation list") + start;
        let list = &src[start..end];
        let n = list.matches("alloc(ap::").count();
        assert_eq!(n, 5, "expected the five §3 buckets, found {n} in:\n{list}");
        let liquid = list.matches(", 0),").count();
        assert_eq!(
            liquid, 5,
            "a bucket in genesis-mainnet no longer has unlock_epoch 0. That is a \
             consensus-visible change to the genesis manifest — it changes the \
             allocation txids, therefore the state root, therefore which network \
             a node thinks it joined:\n{list}",
        );
    }

    use super::*;

    /// A validator pubkey shaped the way Genesis-4 requires: the 0x0001
    /// envelope, then the ML-DSA-65 half, then the Falcon-1024 half. These
    /// fixtures used sixteen filler bytes, which `Manifest::decode` now refuses
    /// (CertiK BLP-02). The bytes are still filler — only the SHAPE is real,
    /// which is all the decoder checks and all a round-trip test needs.
    fn shaped_pubkey(seed: u8) -> Vec<u8> {
        let mut v = vec![0xB1, 0x0C, 0x01, 0x00];
        v.extend(std::iter::repeat(seed).take(1952 + 1793));
        v
    }

    fn sample() -> Manifest {
        Manifest {
            genesis_time_ms: 1_800_000_000_000,
            slot_ms: 500,
            validators: (0..3)
                .map(|i| ManifestValidator {
                    index: i,
                    stake_sat: (i as u128 + 1) * 1_000,
                    randao_commitment: [i as u8; 32],
                    pubkey: shaped_pubkey(i as u8),
                    withdrawal_credentials: Vec::new(),
                    // Distinct non-zero rates, so a decoder that dropped or
                    // aliased the column would fail the round-trip below
                    // instead of round-tripping three identical zeros.
                    commission_bps: 250 * (i as u128 + 1),
                })
                .collect(),
            cohort: vec![0],
            carryover: None,
            allocations: Vec::new(),
            carryover_entries: Vec::new(),
            format: ManifestFormat::V1Unbound,
            pre_state_root: std::sync::OnceLock::new(),
        }
    }

    // ── Carryover fixtures ──────────────────────────────────────────────
    //
    // A hand-built snapshot in the shape `bloch-snapshot-utxo` writes:
    // `txid<TAB>vout<TAB>value_sat<TAB>script_hex`, sorted by (txid, vout),
    // every line closed with LF. Four outputs, three holders' worth of
    // structure in miniature:
    //
    //   - two outputs under one txid (vout 0 and 7), so (txid, vout) ordering
    //     is exercised rather than assumed;
    //   - one large value divisible by 21 — a Genesis-3 coinbase of 8,400
    //     BLCH is, so most real rows cross the split with no remainder at all;
    //   - three small values that are NOT, so the per-row truncation and the
    //     dust rule are live in every test that uses this file rather than
    //     being dead code until the real 452,133-line snapshot arrives.
    //
    // The arithmetic, in full, because a fixture whose numbers are asserted
    // but not derived is a fixture that can agree with a broken split:
    //   G3 total     840,000,000,021 sat (divisible by 21, so x100/21 is exact)
    //   exact split  4,000,000,000,100 sat
    //   rows split   4,000,000,000,098 sat  (840e9 -> 4e12; 1 -> 4; 2 -> 9; 18 -> 85)
    //   remainder    2 sat, to the largest output
    const SNAPSHOT: &str = concat!(
        "1111111111111111111111111111111111111111111111111111111111111111\t0\t840000000000\taaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n",
        "1111111111111111111111111111111111111111111111111111111111111111\t7\t1\taaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n",
        "2222222222222222222222222222222222222222222222222222222222222222\t0\t2\tbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\n",
        "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\t1\t18\tbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\n",
    );
    /// Both roots of [`SNAPSHOT`], generated with CPython's `hashlib` —
    /// `sha3_256` over the bytes and `shake_256` read to 32 bytes, the latter
    /// being what `bloch-snapshot-utxo` prints and `build_carryover.py`
    /// recomputes. Known answers from outside this crate, so these tests pin
    /// the *conventions* and not merely this implementation's agreement with
    /// itself.
    const SNAPSHOT_DIGEST: &str =
        "f622f4eb2f5ad61921c43b6b190ce9cdf9f9eb20e9726d884298b2db5f58cbc9";
    const SNAPSHOT_SET_ROOT: &str =
        "00a2dd27d33501f96ecb6105e96dcb55b72fb1b10be122a1af7228a71e37b54e";
    const SNAPSHOT_G3_SAT: u128 = 840_000_000_021;
    const SNAPSHOT_SPLIT_SAT: u128 = 4_000_000_000_100;

    fn read(text: &str) -> Result<CarryoverSnapshot, CarryoverError> {
        read_carryover_snapshot(text.as_bytes())
    }

    /// The commitment a ceremony would publish for [`SNAPSHOT`] — derived from
    /// the file, never retyped, so the three tests below can each break
    /// exactly one field.
    fn snapshot_commitment() -> CarryoverCommitment {
        let s = read(SNAPSHOT).expect("the fixture parses");
        CarryoverCommitment {
            digest: s.digest,
            set_root: s.set_root,
            entry_count: s.entries.len() as u64,
            total_sat: s.total_sat,
        }
    }

    /// Write the fixture to a scratch file so the file-reading path — not just
    /// the in-memory reader — is what the ingestion tests exercise.
    fn snapshot_file(name: &str, text: &str) -> std::path::PathBuf {
        let p = std::env::temp_dir().join(format!("bloch-pos-carryover-{name}.tsv"));
        fs::write(&p, text).expect("scratch write");
        p
    }

    /// A manifest exercising the mainnet fields, with values chosen so a
    /// field-order or width slip cannot round-trip: every integer differs and
    /// the two allocations differ in all four columns. The carryover
    /// commitment is the fixture snapshot's, and the entries are ingested, so
    /// this manifest is *complete* — the state it synthesises carries money.
    fn mainnet_sample() -> Manifest {
        let mut m = sample();
        m.carryover = Some(snapshot_commitment());
        m.carryover_entries = read(SNAPSHOT).expect("the fixture parses").entries;
        m.allocations = vec![
            GenesisAllocation {
                purpose: alloc_purpose::FOUNDER,
                script_hash: [0xF1; 32],
                amount_sat: 10_000_000_000 * 100_000_000,
                unlock_epoch: 0,
            },
            GenesisAllocation {
                purpose: alloc_purpose::TEAM,
                script_hash: [0x7E; 32],
                amount_sat: 10_000_000_000 * 100_000_000,
                unlock_epoch: 2_190,
            },
        ];
        m
    }

    /// The check that would have caught the empty balance component: a
    /// genesis carrying money must not commit the same root as one carrying
    /// none.
    ///
    /// Before the eUTXO set reached `CommittedState`, `compute_root` passed
    /// `&[]` and these two roots were identical — a chain with 20 billion
    /// BLOCH in it was indistinguishable, at the state root, from a chain with
    /// nothing. That is the whole bug in one assertion.
    /// Cheap structural clone for the reorder test — `Manifest` is not
    /// `Clone` in the crate, and making it so for a test would widen the
    /// public surface for no other reason.
    fn clone_of(m: &Manifest) -> Manifest {
        Manifest::decode(&m.encode()).expect("a manifest we just encoded decodes")
    }

    // ── Gate 3: the newcomer's own node will not boot (2026-09-02) ─────────

    /// The boot gate refuses a validator that a DEPOSIT added, because the
    /// gate reads the genesis manifest and a deposit-added validator is by
    /// definition not in it.
    ///
    /// This is independent of the verifier fix and survives it: with the
    /// verifier reading the registry, the rest of the network can verify this
    /// validator's signatures perfectly — and its own node still exits at
    /// startup with "keystore does not match the genesis manifest's validator
    /// set". Both must be fixed before a deposit-added validator can actually
    /// participate; fixing only the verifier produces a validator everyone can
    /// verify and that cannot start.
    #[test]
    fn gate3_refuses_a_deposit_added_validator() {
        use crate::engine::{check_keystore_identity, KeystoreIdentity};
        let m = sample(); // three genesis validators: indices 0, 1, 2
        assert_eq!(m.validators.len(), 3);
        // Index 3 is the validator a deposit registered after genesis. Its key
        // and RANDAO commitment live in the committed registry, not here.
        assert_eq!(
            check_keystore_identity(&m, 3, &shaped_pubkey(3), [3u8; 32]),
            KeystoreIdentity::NotInGenesisSet,
            "a deposit-added validator's node refuses to boot"
        );
    }

    #[test]
    fn gate3_admits_a_genesis_validator() {
        use crate::engine::{check_keystore_identity, KeystoreIdentity};
        let m = sample();
        // The fixture's RANDAO commitments are literal bytes, not chain heads,
        // so the identity half is what this asserts: index+pubkey match.
        assert_ne!(
            check_keystore_identity(&m, 1, &shaped_pubkey(1), [1u8; 32]),
            KeystoreIdentity::NotInGenesisSet,
            "a genesis validator must pass the identity half of the gate"
        );
    }

    #[test]
    fn gate3_rejects_a_wrong_key_at_a_real_index() {
        use crate::engine::{check_keystore_identity, KeystoreIdentity};
        let m = sample();
        assert_eq!(
            check_keystore_identity(&m, 1, &shaped_pubkey(2), [1u8; 32]),
            KeystoreIdentity::NotInGenesisSet,
        );
    }

    /// The latent position-vs-index defect the extraction closed.
    ///
    /// The original gate found the record by its `index` FIELD and then read
    /// the RANDAO commitment by POSITION (`manifest.validators[index]`). With
    /// a non-dense manifest that reads another validator's commitment — or
    /// panics out of bounds. Here validator index 9 sits at position 2: the
    /// old expression would have indexed position 9 of a 3-element vector and
    /// panicked. The extracted version uses the record it already found.
    #[test]
    fn gate3_does_not_index_the_manifest_by_position() {
        use crate::engine::{check_keystore_identity, KeystoreIdentity};
        let mut m = sample();
        m.validators[2].index = 9;
        let pk = m.validators[2].pubkey.clone();
        // Reaches the RANDAO comparison without panicking, and answers about
        // validator 9's own commitment.
        assert_eq!(
            check_keystore_identity(&m, 9, &pk, [0xEE; 32]),
            KeystoreIdentity::RandaoMismatch,
        );
    }

    // ── Gate 3, against the committed registry (2026-09-02) ────────────────
    //
    // The manifest-based gate above is now a pre-pass; these pin the gate that
    // actually decides. Fixtures build a registry by adding the newcomer to a
    // manifest and taking `genesis_state()` — a registry that carries an index
    // is a registry that carries it, however it got there, and this avoids
    // dragging a whole deposit transaction into a boot-gate test.

    /// A manifest validator whose committed RANDAO commitment really is the
    /// head of the chain `seed` generates — so `RandaoMismatch` in these tests
    /// means what it says, rather than being an artifact of a filler fixture.
    fn validator_with_seed(index: u32, key_seed: u8, randao_seed: [u8; 32]) -> ManifestValidator {
        ManifestValidator {
            index,
            stake_sat: 1_000,
            randao_commitment: bloch_pos_committee::beacon::RandaoChain::generate(randao_seed)
                .commitment(),
            pubkey: shaped_pubkey(key_seed),
            withdrawal_credentials: Vec::new(),
            commission_bps: 0,
        }
    }

    /// A registry that has taken a deposit: genesis indices 0..3, plus one
    /// newcomer at the index a deposit would allocate next.
    fn registry_with_newcomer(seed: [u8; 32]) -> bloch_pos_committee::transition::CommittedState {
        let mut m = sample();
        m.validators.push(validator_with_seed(3, 0x7E, seed));
        m.genesis_state()
    }

    /// The point of the whole exercise: the newcomer's own node boots.
    #[test]
    fn gate3_registry_admits_a_deposit_added_validator() {
        use crate::engine::{check_registry_identity, RegistryIdentity};
        let seed = [0x7Eu8; 32];
        assert_eq!(
            check_registry_identity(&registry_with_newcomer(seed), 3, &shaped_pubkey(0x7E), seed),
            RegistryIdentity::Active,
            "a validator the registry knows must be able to start"
        );
    }

    /// Not an error. This is every deposit-added validator between minting a
    /// keystore and its deposit being applied, and the old gate turned it into
    /// a refusal to boot.
    #[test]
    fn gate3_registry_pends_an_unregistered_validator() {
        use crate::engine::{check_registry_identity, RegistryIdentity};
        let m = sample();
        assert_eq!(
            check_registry_identity(&m.genesis_state(), 3, &shaped_pubkey(0x7E), [0x7E; 32]),
            RegistryIdentity::PendingActivation,
            "an unregistered index is a wait, not a failure"
        );
    }

    /// The safety case the old gate was really buying, kept and aimed
    /// correctly: indices are allocated `next_back() + 1`, so a keystore
    /// minted for an index before depositing can be beaten to it. Booting
    /// there would sign under another validator's identity.
    #[test]
    fn gate3_registry_refuses_an_index_owned_by_another_key() {
        use crate::engine::{check_registry_identity, RegistryIdentity};
        let seed = [0x7Eu8; 32];
        assert_eq!(
            check_registry_identity(
                &registry_with_newcomer(seed),
                3,
                &shaped_pubkey(0x11), // somebody else's key at index 3
                seed
            ),
            RegistryIdentity::WrongValidator,
            "starting here would equivocate as the validator that owns index 3"
        );
    }

    /// Right key, unusable RANDAO chain: every block this node proposed would
    /// carry a reveal the network refuses, so it must not start.
    #[test]
    fn gate3_registry_refuses_a_seed_that_does_not_open_the_commitment() {
        use crate::engine::{check_registry_identity, RegistryIdentity};
        assert_eq!(
            check_registry_identity(
                &registry_with_newcomer([0x7E; 32]),
                3,
                &shaped_pubkey(0x7E),
                [0xFF; 32] // a different seed: different chain head
            ),
            RegistryIdentity::RandaoMismatch,
        );
    }

    /// The two gates disagree, on purpose, and this records the disagreement:
    /// the manifest pre-pass says "not a genesis validator" for exactly the
    /// validator the registry gate admits. Shipping only the pre-pass verdict
    /// is what closed the network.
    #[test]
    fn gate3_the_manifest_prepass_and_the_registry_gate_disagree_by_design() {
        use crate::engine::{
            check_keystore_identity, check_registry_identity, KeystoreIdentity, RegistryIdentity,
        };
        let seed = [0x7Eu8; 32];
        let mut m = sample();
        m.validators.push(validator_with_seed(3, 0x7E, seed));
        // The manifest is consulted for a validator that IS in it — and the
        // pre-pass still cannot be authoritative, because on a real newcomer
        // the manifest file on disk is the genesis one, without index 3.
        let genesis_only = sample();
        assert_eq!(
            check_keystore_identity(&genesis_only, 3, &shaped_pubkey(0x7E), seed),
            KeystoreIdentity::NotInGenesisSet,
            "the pre-pass refuses; it must therefore be advisory only"
        );
        assert_eq!(
            check_registry_identity(&m.genesis_state(), 3, &shaped_pubkey(0x7E), seed),
            RegistryIdentity::Active,
            "the registry admits the same validator"
        );
    }

    // ── Inertness of the registry-reading verifier (2026-09-02) ────────────

    /// THE INERTNESS PROOF, against the real genesis construction.
    ///
    /// The deleted code served consensus signature checks out of
    /// `Manifest::pubkeys()` — a `Vec<Vec<u8>>` indexed by validator index,
    /// built once at boot. The new code resolves the same question from the
    /// committed registry inside `CommittedState`. While the registry still
    /// equals the genesis set, the two must return byte-identical keys for
    /// every index.
    ///
    /// That condition holds on the live chain today: both keyless archivals
    /// report 64 registered / 64 active, every `activation_epoch` 0, no exits,
    /// no slashings — i.e. every validator is a genesis validator and no
    /// deposit has ever landed. So this equality is what licenses shipping and
    /// soaking the change AHEAD of the funded-deposit flag day instead of
    /// bundling the two.
    /// `Manifest::pubkeys()` EXACTLY as the binary the fleet is running today
    /// builds it — copied, not called.
    ///
    /// The inertness claim is about the DEPLOYED code, so the reference has to
    /// be the deployed code. Calling the current `pubkeys()` would prove only
    /// that this build agrees with itself. This body is the one at
    /// `g4-node-20260901:crates/bloch-pos-node/src/genesis.rs`, which is what
    /// every node on the fleet executes, verbatim:
    ///
    /// ```text
    /// let mut pks: Vec<Vec<u8>> = vec![Vec::new(); self.validators.len()];
    /// for v in &self.validators {
    ///     if (v.index as usize) < pks.len() {
    ///         pks[v.index as usize] = v.pubkey.clone();
    ///     }
    /// }
    /// ```
    fn pubkeys_as_the_deployed_binary_builds_them(m: &Manifest) -> Vec<Vec<u8>> {
        let mut pks: Vec<Vec<u8>> = vec![Vec::new(); m.validators.len()];
        for v in &m.validators {
            if (v.index as usize) < pks.len() {
                pks[v.index as usize] = v.pubkey.clone();
            }
        }
        pks
    }

    #[test]
    fn registry_lookup_equals_the_manifest_table_at_genesis() {
        use bloch_pos_committee::attestation::KeyLookup;
        for m in [sample(), mainnet_sample()] {
            let deployed = pubkeys_as_the_deployed_binary_builds_them(&m);
            let table = m.pubkeys();
            let state = m.genesis_state();
            assert!(!deployed.is_empty());
            assert_eq!(deployed.len(), table.len());

            for (i, expected) in deployed.iter().enumerate() {
                let i = i as u32;
                // 1. The old boot-time table and the new committed registry
                //    return the SAME BYTES. This is the whole inertness claim:
                //    a node that resolves keys from the registry answers every
                //    signature question exactly as the deployed one does,
                //    while the registry still equals the genesis set.
                assert_eq!(
                    state.pubkey(i),
                    Some(expected.as_slice()),
                    "validator {i}: the committed registry and the DEPLOYED \
                     boot-time table disagree about the key"
                );
                // 2. And the repaired `pubkeys()` is itself inert: keying by
                //    index changes nothing on a dense, sorted manifest, which
                //    is what genesis is.
                assert_eq!(
                    table.get(&i).map(Vec::as_slice),
                    Some(expected.as_slice()),
                    "validator {i}: repairing pubkeys() changed a genesis key"
                );
            }

            // Past the end all three answer "no such validator". This half
            // decides whether a node behaves identically for indices nobody
            // holds — including the very next index a deposit would allocate.
            for i in deployed.len()..deployed.len() + 8 {
                let i = i as u32;
                assert_eq!(state.pubkey(i), None);
                assert_eq!(table.get(&i), None);
            }
        }
    }

    /// The inertness proof's precondition, stated as a test rather than as
    /// prose: it holds only while the registry equals the genesis set.
    ///
    /// The moment one deposit lands, the two sources diverge — the registry
    /// answers for the new index and the boot-time table cannot. That is the
    /// point at which this change stops being inert and becomes
    /// consensus-visible, and it is why the deposit flag day must not be armed
    /// until the fleet is uniformly on this binary.
    #[test]
    fn inertness_ends_at_the_first_deposit() {
        use bloch_pos_committee::attestation::KeyLookup;
        let m = sample();
        let deployed = pubkeys_as_the_deployed_binary_builds_them(&m);
        let newcomer = deployed.len() as u32; // the next index a deposit takes
        assert_eq!(m.genesis_state().pubkey(newcomer), None);

        // A registry that has taken a deposit resolves the newcomer; the
        // boot-time table still cannot, and never will without a restart.
        let mut with_deposit = sample();
        with_deposit.validators.push(ManifestValidator {
            index: newcomer,
            stake_sat: m.validators[0].stake_sat,
            randao_commitment: [0xAB; 32],
            pubkey: shaped_pubkey(0x7E),
            withdrawal_credentials: m.validators[0].withdrawal_credentials.clone(),
            commission_bps: 0,
        });
        assert_eq!(
            with_deposit.genesis_state().pubkey(newcomer).map(<[u8]>::to_vec),
            Some(shaped_pubkey(0x7E)),
            "a registry carrying the newcomer resolves it"
        );
        assert!(
            deployed.get(newcomer as usize).is_none(),
            "the deployed boot-time table has no entry to return, which is \
             precisely how it reported a good signature as BadSignature"
        );
    }

    /// The manifest table's own latent defect, recorded rather than relied on.
    ///
    /// `Manifest::pubkeys()` allocates `vec![Vec::new(); validators.len()]` and
    /// writes each validator at `pks[v.index]`, dropping any whose index is
    /// past the length. A sparse or non-dense manifest therefore yields an
    /// EMPTY key at some positions — and an empty key silently verifies
    /// nothing while looking like a present entry. The committed registry has
    /// no such failure mode: it is keyed by the index field, so a missing
    /// index is `None`, which is a distinguishable answer.
    ///
    /// This is one more reason the registry is the right source, independent
    /// of the deposit case.
    #[test]
    fn the_manifest_table_no_longer_empties_sparse_indices() {
        let mut m = sample();
        // Three validators, but indexed 0, 1, 9 — dense assumption broken.
        m.validators[2].index = 9;

        // What the deployed binary does, pinned so the fix has something to
        // be a fix OF: validator 9 falls off the end and leaves an empty key
        // behind at position 2. An empty key is the worst answer available —
        // it looks present and verifies nothing.
        let deployed = pubkeys_as_the_deployed_binary_builds_them(&m);
        assert_eq!(deployed.len(), 3);
        assert!(deployed[2].is_empty(), "the deployed table loses validator 9");

        // Keyed by index, nothing is lost and nothing is invented.
        let table = m.pubkeys();
        assert_eq!(table.len(), 3);
        assert_eq!(table.get(&2), None, "there is no validator 2");
        assert_eq!(
            table.get(&9),
            Some(&m.validators[2].pubkey),
            "validator 9 keeps its own key"
        );
        assert!(
            table.values().all(|k| !k.is_empty()),
            "no empty key may survive anywhere in the table"
        );

        // And the committed registry agrees with the repaired table, which is
        // the property that lets one stand in for the other.
        use bloch_pos_committee::attestation::KeyLookup;
        let state = m.genesis_state();
        assert_eq!(state.pubkey(2), None);
        assert_eq!(
            state.pubkey(9).map(<[u8]>::to_vec),
            Some(m.validators[2].pubkey.clone()),
            "validator 9 resolves to its own key"
        );
    }

    // ── C5-genesis-header: genesis identity must follow the ledger ───────

    /// Turn a manifest into the bound format. Nothing else moves: same
    /// validators, same cohort, same carryover, same allocations — so any
    /// difference these tests observe is the binding rule and nothing else.
    fn bound(mut m: Manifest) -> Manifest {
        m.format = ManifestFormat::V2Bound;
        m
    }

    /// **The finding.** Two manifests describing different ledgers must not
    /// share a genesis block id.
    ///
    /// Under the unbound rule they did, always: `genesis_header` was twelve
    /// compile-time constants, so `genesis_id()` was the same 32 bytes for a
    /// devnet with no money and for mainnet with the whole carryover in it. A
    /// substituted manifest — same cohort, different balances — produced a
    /// genesis block that paired at height 0 with the real chain, and the
    /// divergence only surfaced later as a state-root mismatch blamed on some
    /// innocent block.
    ///
    /// Fails without the fix: with `state_root` pinned to `[0u8; 32]` the two
    /// ids are equal by construction and this is the assertion that says so.
    #[test]
    fn bound_genesis_id_differs_for_two_ledgers() {
        let a = bound(mainnet_sample());
        let mut b = bound(mainnet_sample());
        // One satoshi, on one output, out of four. Downward, so the one-sided
        // genesis conservation check cannot be what fails instead.
        b.carryover_entries[0].value -= 1;

        assert_ne!(
            a.genesis_id().as_bytes(),
            b.genesis_id().as_bytes(),
            "two manifests opening different ledgers must not share a genesis block id"
        );
        // And the reason is the header field the finding named, not some
        // incidental difference elsewhere in it.
        assert_ne!(a.genesis_header().state_root, b.genesis_header().state_root);
    }

    /// **The gap the first cut left open.** Two manifests that differ only in
    /// the clock they run describe two different networks, and must not share
    /// a genesis block id.
    ///
    /// `state_root` binds the ledger and the mix binds the carryover artifact,
    /// so before the clock terms went into the mix these two fields were the
    /// entire set of manifest inputs that `genesis_id` did not see. A node on
    /// `slot_ms = 1_000` and one on `slot_ms = 30_000` map the same instant to
    /// different slots, therefore different epochs, committees and duties —
    /// two chains, pairing at height 0. That is the substitution C5 exists to
    /// stop, arriving through the one door it had left open.
    ///
    /// Fails without the two `h.update` calls in `genesis_mix`: both
    /// assertions are equalities by construction then.
    #[test]
    fn bound_genesis_id_follows_the_clock() {
        let a = bound(mainnet_sample());

        // Cadence: the same ledger at a different block time is not the same
        // chain, and consensus reads the difference on every slot.
        let mut faster = bound(mainnet_sample());
        faster.slot_ms += 1;
        assert_ne!(
            a.genesis_id().as_bytes(),
            faster.genesis_id().as_bytes(),
            "a different slot cadence is a different network"
        );

        // Launch instant: two networks opened from the identical ledger at
        // different times are still two networks.
        let mut later = bound(mainnet_sample());
        later.genesis_time_ms += 1;
        assert_ne!(
            a.genesis_id().as_bytes(),
            later.genesis_id().as_bytes(),
            "a different genesis time is a different network"
        );

        // And it arrives through the MIX, which is the field that carries the
        // chain's opening parameters.
        assert_ne!(a.genesis_mix(), faster.genesis_mix());
        assert_ne!(a.genesis_mix(), later.genesis_mix());
        assert_ne!(a.genesis_header().randao_mix, faster.genesis_header().randao_mix);

        // The state root moves too, and that is correct rather than
        // incidental: `CommittedState::genesis` takes the mix as the beacon's
        // opening value, so the mix is a component OF the state and the clock
        // reaches the root through it. Worth asserting rather than assuming —
        // it is what makes the two bindings agree instead of one silently
        // overwriting the other's answer.
        assert_ne!(
            a.genesis_header().state_root,
            faster.genesis_header().state_root,
            "the clock reaches the state root through the mix the state opens on"
        );
        // The ledger binding is undisturbed by all of this: same balances,
        // same registry, and the opening supply still closes.
        assert_eq!(a.genesis_accounted_sat(), faster.genesis_accounted_sat());
    }

    /// The unbound rule ignores the clock, exactly as it always has. Genesis
    /// identity under v1 is frozen and the correction above must not reach it.
    #[test]
    fn unbound_genesis_id_still_ignores_the_clock() {
        let a = mainnet_sample();
        let mut b = mainnet_sample();
        b.slot_ms += 1;
        b.genesis_time_ms += 1;
        assert_eq!(a.genesis_id().as_bytes(), b.genesis_id().as_bytes());
    }

    /// The same claim one level down, and the one that would catch a
    /// `state_root` that commits to the validator set but forgets the money:
    /// the difference is ONLY in the balances.
    #[test]
    fn bound_genesis_state_root_covers_the_opening_balances() {
        let a = bound(mainnet_sample());
        let mut b = bound(mainnet_sample());
        b.carryover_entries[0].value -= 1;
        assert_eq!(
            a.validators.len(),
            b.validators.len(),
            "the fixture must differ in balances alone for this test to mean anything"
        );
        assert_ne!(a.genesis_pre_state_root(), b.genesis_pre_state_root());
        // A changed cohort must move it too — same commitment, other half.
        let mut c = bound(mainnet_sample());
        c.validators[1].stake_sat += 1;
        assert_ne!(a.genesis_pre_state_root(), c.genesis_pre_state_root());
    }

    /// The mix is seeded by the carryover digest, by the same expression
    /// `genesis4-ceremony::genesis_header` publishes:
    /// `SHA3-256(DS_RANDAO ‖ 0 ‖ carryover_digest)`.
    ///
    /// Written out by hand rather than called through `genesis_mix`, so this
    /// pins the formula and not the implementation of it.
    #[test]
    fn bound_genesis_mix_is_seeded_by_the_carryover_digest() {
        let m = bound(mainnet_sample());
        let mut h = Sha3_256::new();
        h.update(bloch_pos_committee::params::DS_RANDAO);
        h.update([0u8; 32]);
        h.update(m.carryover.as_ref().expect("the mainnet fixture commits to a carryover").digest);
        // The clock terms, in the widths and order `Manifest::encode` writes
        // them. Pinned here by hand for the same reason the rest of the
        // expression is: a formula a test derives through the function it is
        // checking pins nothing.
        h.update(m.genesis_time_ms.to_le_bytes());
        h.update(m.slot_ms.to_le_bytes());
        let want: [u8; 32] = h.finalize().into();

        assert_eq!(m.genesis_mix(), want);
        assert_eq!(m.genesis_header().randao_mix, want);
        assert_ne!(m.genesis_mix(), GENESIS_MIX, "a seeded mix is not the zero constant");
        // The state opens on the same mix the header advertises — the duty
        // view and the consensus authority for one quantity. (Read off the
        // state directly, not through `seed_for_epoch`, whose test builds
        // carry the A/B rehearsal's planted mutation.)
        use bloch_pos_committee::interfaces::StateReader;
        assert_eq!(StateReader::randao_mix(&m.genesis_state()), want);
    }

    /// A different carryover artifact, same everything else, moves the mix.
    #[test]
    fn bound_genesis_mix_follows_the_carryover_artifact() {
        let a = bound(mainnet_sample());
        let mut b = bound(mainnet_sample());
        let mut c = b.carryover.clone().expect("fixture commits");
        c.digest[0] ^= 1;
        b.carryover = Some(c);
        assert_ne!(a.genesis_mix(), b.genesis_mix());
    }

    /// **The freeze.** The unbound rule is what the live Genesis-4 chain
    /// launched under, and every block it holds walks its ancestry back to
    /// this id. Changing it under a running fleet breaks every node on its
    /// next restart — genesis identity has no flag day, because the flag day
    /// IS publishing a new manifest.
    ///
    /// So the legacy header is pinned here, field by field, spelled out rather
    /// than called: this test fails if anybody makes the binding
    /// unconditional, which is exactly the review that change deserves.
    #[test]
    fn unbound_genesis_identity_is_frozen() {
        let legacy = BlockHeaderV4 {
            version: VERSION_G4,
            parent: [0u8; 32],
            state_root: [0u8; 32],
            body_root: [0u8; 32],
            slot: 0,
            proposer_index: 0,
            randao_reveal: [0u8; 32],
            randao_mix: [0u8; 32],
            justified_root: [0u8; 32],
            finalized_root: [0u8; 32],
            attestation_root: [0u8; 32],
            coherence_root: [0u8; 32],
        };
        for m in [sample(), mainnet_sample()] {
            assert_eq!(m.format, ManifestFormat::V1Unbound, "the fixtures are v1");
            assert_eq!(
                m.genesis_id().as_bytes(),
                BlockId::of(&legacy).as_bytes(),
                "a v1 manifest's genesis id is consensus-frozen"
            );
        }
    }

    /// The two rules really are two rules: the same manifest under each has a
    /// different genesis. This is the sentence the founder decision is about.
    #[test]
    fn binding_changes_genesis_identity() {
        let unbound = mainnet_sample();
        let bound_m = bound(mainnet_sample());
        assert_ne!(unbound.genesis_id().as_bytes(), bound_m.genesis_id().as_bytes());
    }

    /// The format is carried by the file, not by a local setting: it survives
    /// the round trip, and so therefore does the genesis id.
    #[test]
    fn format_round_trips_through_the_manifest_bytes() {
        for m in [sample(), bound(sample())] {
            let back = Manifest::decode(&m.encode()).expect("a manifest we just encoded decodes");
            assert_eq!(back.format, m.format);
            assert_eq!(back.genesis_id().as_bytes(), m.genesis_id().as_bytes());
        }
        // And the two encodings differ in the magic alone.
        let (v1, v2) = (sample().encode(), bound(sample()).encode());
        assert_eq!(&v1[..8], b"BPOSMAN1");
        assert_eq!(&v2[..8], b"BPOSMAN2");
        assert_eq!(v1[8..], v2[8..], "only the magic distinguishes the two formats");
    }

    /// **The R3-low guarantee, made explicit and pinned:** a
    /// [`ManifestFormat::V2Bound`] genesis header's `state_root` is
    /// something EVERY node computes for itself from the manifest's own
    /// committed fields — never a value one node serialises and another
    /// simply trusts. (The audit's own phrasing: "a v2 genesis header
    /// commits to a root no node holds" — the concern this closes is that
    /// nothing stops that root from being an opaque, untrusted blob; this
    /// proves it is not one.)
    ///
    /// Proven by decoding the SAME bytes into two INDEPENDENT `Manifest`
    /// values — separate `OnceLock` memos, so neither can be silently
    /// reusing the other's cached answer — and confirming both derive the
    /// identical root, and therefore the identical genesis id, from nothing
    /// but the decoded fields. A node that received a substituted manifest
    /// with a forged `state_root` embedded in some OTHER encoding would
    /// simply compute a DIFFERENT id than everyone else — it could never
    /// make its neighbours' nodes agree with the forgery, which is the
    /// property a "root no node holds" would lack.
    ///
    /// **V1 is unaffected** (the finding's own condition): its header
    /// commits to no root at all — `genesis_header` leaves `state_root`
    /// zero — which is exactly the "correctly deferred" shape
    /// `format_round_trips_through_the_manifest_bytes` above already pins
    /// for both formats; this test only sharpens what "commits" means for
    /// the bound one.
    #[test]
    fn v2_bound_state_root_is_independently_recomputed_not_trusted() {
        // `bound(sample())`, not `bound(mainnet_sample())`: the mainnet
        // fixture commits to a carryover that needs `ingest_carryover`
        // before `genesis_pre_state_root` can run at all (see
        // `ingesting_the_carryover_invalidates_the_memoised_root` above) —
        // irrelevant to what THIS test proves, which holds with or without
        // one.
        let encoded = bound(sample()).encode();
        let a = Manifest::decode(&encoded).expect("decode #1");
        let b = Manifest::decode(&encoded).expect("decode #2");
        assert_eq!(a.format, ManifestFormat::V2Bound, "fixture: must be the bound format");
        assert_eq!(
            a.genesis_pre_state_root(),
            b.genesis_pre_state_root(),
            "every node must derive this root itself from the manifest's own fields; \
             it must never be trusted as an opaque given"
        );
        assert_eq!(
            a.genesis_id().as_bytes(),
            b.genesis_id().as_bytes(),
            "an independently-derived root must produce an independently-derived, \
             matching genesis id"
        );

        // V1: unchanged, and unaffected by any of the above.
        let v1 = Manifest::decode(&sample().encode()).expect("decode v1");
        assert_eq!(v1.format, ManifestFormat::V1Unbound, "fixture: must be the unbound format");
        assert_eq!(
            v1.genesis_header().state_root,
            [0u8; 32],
            "V1's header commits to nothing — do not change V1 behaviour"
        );
    }

    /// The memo is a cache of a pure function, so ingesting the balance set —
    /// the one mutation a manifest undergoes — must not leave a root behind
    /// that predates the money.
    #[test]
    fn ingesting_the_carryover_invalidates_the_memoised_root() {
        let mut m = bound(mainnet_sample());
        m.carryover = None;
        m.carryover_entries = Vec::new();
        let before = m.genesis_pre_state_root();
        m.carryover = Some(snapshot_commitment());
        m.ingest_carryover(&snapshot_file("c5-memo", SNAPSHOT)).expect("the fixture ingests");
        assert_ne!(
            before,
            m.genesis_pre_state_root(),
            "the genesis root must follow the balances that were just ingested"
        );
        assert_eq!(m.genesis_pre_state_root(), bound(mainnet_sample()).genesis_pre_state_root());
    }

    #[test]
    fn balances_change_the_genesis_state_root() {
        use bloch_pos_committee::interfaces::StateReader;
        let empty = sample();
        let funded = mainnet_sample();
        assert_ne!(
            empty.genesis_state().state_root(),
            funded.genesis_state().state_root(),
            "a genesis holding allocations must not commit an empty ledger's root"
        );
    }

    // ── Carryover ingestion ─────────────────────────────────────────────

    /// The ingestion itself: the file parses, the count is the file's, and the
    /// entries sum to exactly what the split says they should.
    #[test]
    fn carryover_ingestion_counts_and_sums() {
        let s = read(SNAPSHOT).expect("fixture parses");
        assert_eq!(s.entries.len(), 4);
        assert_eq!(s.g3_total_sat, SNAPSHOT_G3_SAT);
        assert_eq!(s.total_sat, SNAPSHOT_SPLIT_SAT);
        // The claim that matters: the entries the chain will hold add up to
        // the number the commitment is checked against. Summed in u128 —
        // u64 addition of real balances is the wrap this crate is built to
        // avoid.
        let summed: u128 = s.entries.iter().map(|e| u128::from(e.value)).sum();
        assert_eq!(summed, s.total_sat, "entries must sum to the stated total");
        // Order and identity are the file's: the Genesis-3 outpoint crosses
        // unchanged, so a holder can still find their coin.
        assert_eq!(s.entries[0].txid, [0x11; 32]);
        assert_eq!(s.entries[0].vout, 0);
        assert_eq!(s.entries[1].vout, 7, "the second output of the same txid");
        assert_eq!(s.entries[3].txid, [0xAA; 32]);
        // Two outputs of one holder land on one script hash.
        assert_eq!(s.entries[0].script_hash, s.entries[1].script_hash);
        assert_ne!(s.entries[0].script_hash, s.entries[2].script_hash);
    }

    /// The ownership rule, pinned in the only way that catches the failure
    /// that matters: the Genesis-3 address occupies the FIRST 20 bytes and the
    /// LAST 12 are zero.
    ///
    /// A test that checked only the length, or only that the address appears
    /// somewhere, would pass with the padding on the wrong side — and padding
    /// on the wrong side gives every carried output a different owner, which
    /// is a different ledger, launched, with no way back. (Founder decision,
    /// 2026-08-13: zero-extend, do not re-hash, so a holder can compare their
    /// own address against the prefix without a conversion table.)
    #[test]
    fn the_address_is_zero_extended_to_the_right() {
        let s = read(SNAPSHOT).expect("fixture parses");
        let h = s.entries[0].script_hash;
        assert_eq!(&h[..20], &[0xAA; 20], "the G3 hash160 must be the leading 20 bytes");
        assert_eq!(&h[20..], &[0u8; 12], "the trailing 12 bytes must be zero");
        // Explicitly not the left-padded arrangement, spelled out so the
        // wrong one cannot be introduced and still pass by symmetry.
        let mut left_padded = [0u8; 32];
        left_padded[12..].copy_from_slice(&[0xAA; 20]);
        assert_ne!(h, left_padded);
        // And explicitly not a re-hash of the address, the alternative that
        // was weighed and rejected.
        assert_ne!(h, <[u8; 32]>::from(Sha3_256::digest([0xAA; 20])));
        // The second holder differs in the same 20 bytes, so ownership tracks
        // the address rather than the position.
        assert_eq!(&s.entries[2].script_hash[..20], &[0xBB; 20]);
        assert_eq!(&s.entries[2].script_hash[20..], &[0u8; 12]);
    }

    /// An address column of any other width is refused. There is no decided
    /// conversion for it, and the one thing that must not happen is a silent
    /// choice of owner.
    #[test]
    fn a_non_hash160_address_column_is_refused() {
        let base = "1111111111111111111111111111111111111111111111111111111111111111\t0\t5\t";
        for addr in ["aa", &"aa".repeat(32)[..], &"aa".repeat(19)[..]] {
            let err = read(&format!("{base}{addr}\n")).expect_err("only 20 bytes crosses");
            let msg = err.to_string();
            assert!(msg.contains("hash160"), "{msg}");
        }
        assert!(read(&format!("{base}{}\n", "aa".repeat(20))).is_ok());
    }

    /// Both hash conventions, against answers computed outside this crate
    /// (CPython `hashlib`). If the set root fails, the node and the tool that
    /// publishes the root disagree about what "the root" means and the real
    /// snapshot is refused at the ceremony with a mismatch nobody can explain.
    #[test]
    fn carryover_digests_match_the_published_conventions() {
        let s = read(SNAPSHOT).expect("fixture parses");
        assert_eq!(crate::codec::hex32(&s.digest), SNAPSHOT_DIGEST, "SHA3-256 of the bytes");
        assert_eq!(
            crate::codec::hex32(&s.set_root),
            SNAPSHOT_SET_ROOT,
            "SHAKE-256 of the canonical rows — the root bloch-snapshot-utxo prints"
        );
        assert_ne!(s.digest, s.set_root, "two questions, two answers");
    }

    /// The split is applied per output, truncating, and the sub-satoshi
    /// remainders are not dropped: they are gathered and given to the largest
    /// output — the rule `read_carryover_snapshot` states.
    #[test]
    fn split_is_per_output_and_the_dust_lands_somewhere() {
        let s = read(SNAPSHOT).expect("fixture parses");
        assert_eq!(s.dust_sat, 2, "1, 2 and 18 sat truncate; 840e9 does not");
        // The largest output is the one that absorbed it: 4e12 exactly from
        // the split, plus the 2 sat of remainder.
        assert_eq!(s.entries[0].value, 4_000_000_000_002);
        // The three small rows kept their own truncated values.
        assert_eq!(s.entries[1].value, 4);
        assert_eq!(s.entries[2].value, 9);
        assert_eq!(s.entries[3].value, 85);
        // Dropping the dust instead would leave the total two satoshis under
        // the figure the manifest commits to — which is exactly the
        // "truncate-and-hope does not close the accounting" failure.
        let truncated_only: u128 =
            s.entries.iter().map(|e| u128::from(e.value)).sum::<u128>() - s.dust_sat;
        assert_ne!(truncated_only, s.total_sat);
        assert_eq!(
            tokenomics_v4::split_g3_sat(s.g3_total_sat),
            s.total_sat,
            "the ledger is worth the split of the aggregate, whatever the rows rounded to"
        );
    }

    /// The tie-break, on its own, because "the largest output" does not
    /// determine anything when two outputs are the largest — and two nodes
    /// that place the dust on different outputs commit different state roots
    /// from the same file. That is a chain split produced by a rounding
    /// remainder, so the rule is: highest value, ties to the lowest
    /// (txid, vout).
    ///
    /// Two rows of 11 sat (tied maximum after the split, 52 each) and one of
    /// 5; the aggregate splits to 128, the rows to 127, so exactly 1 sat has
    /// to land somewhere and only the tie-break says where.
    #[test]
    fn tied_largest_outputs_break_deterministically_by_outpoint() {
        let text = concat!(
            "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\t0\t11\tcccccccccccccccccccccccccccccccccccccccc\n",
            "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\t0\t11\tcccccccccccccccccccccccccccccccccccccccc\n",
            "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\t0\t5\tcccccccccccccccccccccccccccccccccccccccc\n",
        );
        let s = read(text).expect("parses");
        assert_eq!(s.dust_sat, 1);
        assert_eq!(s.entries[0].value, 53, "the lower outpoint of the tied pair takes it");
        assert_eq!(s.entries[1].value, 52, "the higher outpoint does not");
        assert_eq!(s.entries[2].value, 23);

        // The same three outputs presented with the tied pair's outpoints
        // swapped must move the dust with the outpoint, not keep it on the
        // first line: the rule is about identity, not position.
        let swapped = concat!(
            "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\t0\t5\tcccccccccccccccccccccccccccccccccccccccc\n",
            "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\t0\t11\tcccccccccccccccccccccccccccccccccccccccc\n",
            "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\t0\t11\tcccccccccccccccccccccccccccccccccccccccc\n",
        );
        let t = read(swapped).expect("parses");
        assert_eq!(t.entries[0].value, 23);
        assert_eq!(t.entries[1].value, 53, "still the lowest outpoint among the tied maxima");
        assert_eq!(t.entries[2].value, 52);
    }

    /// The accounting closes at scale, on a file where almost every row
    /// truncates. Four rows can be reasoned about by hand; 20,000 cannot, and
    /// the real snapshot is 452,133 — the case where a per-row dust rule
    /// either closes the total or quietly loses a few hundred thousand
    /// satoshis. Also the shape a streaming reader is for: this file is
    /// ~1.4 MB, the real one is ~54 MB, and neither is ever held as a
    /// `String` inside the reader.
    #[test]
    fn the_total_closes_over_twenty_thousand_rows() {
        const N: u64 = 20_000;
        let mut text = String::with_capacity(N as usize * 72);
        let mut g3_total: u128 = 0;
        for i in 0..N {
            // Ascending txids: a big-endian counter in the leading bytes, so
            // hex order is (txid, vout) order.
            let mut txid = [0u8; 32];
            txid[..8].copy_from_slice(&i.to_be_bytes());
            // Values that mostly are NOT multiples of 21, so per-row
            // truncation is the rule here rather than the exception.
            let value = 8_400_000_000u64 + (i * 7_919) % 1_000_003;
            g3_total += u128::from(value);
            let hex: String = txid.iter().map(|b| format!("{b:02x}")).collect();
            text.push_str(&format!("{hex}\t0\t{value}\t{}\n", "cd".repeat(20)));
        }
        let s = read(&text).expect("generated snapshot parses");
        assert_eq!(s.entries.len() as u64, N);
        assert_eq!(s.g3_total_sat, g3_total);
        assert!(s.dust_sat > 0, "most rows must truncate for this test to mean anything");
        let summed: u128 = s.entries.iter().map(|e| u128::from(e.value)).sum();
        assert_eq!(
            summed,
            tokenomics_v4::split_g3_sat(g3_total),
            "the rows must sum to the split of the aggregate — the whole reason the \
             remainder is placed instead of dropped"
        );
        assert_eq!(summed, s.total_sat);
        // Deterministic: the same bytes give the same digest and the same
        // outputs, which is what lets independent operators compare.
        let again = read(&text).expect("parses again");
        assert_eq!(again.digest, s.digest);
        assert_eq!(again.entries, s.entries);
    }

    /// Ingestion through the checked path, from an actual file.
    #[test]
    fn carryover_loads_from_a_file_against_its_commitment() {
        let path = snapshot_file("good", SNAPSHOT);
        let mut m = sample();
        m.carryover = Some(snapshot_commitment());
        let s = m.ingest_carryover(&path).expect("the committed file is accepted");
        assert_eq!(s.entries.len(), 4);
        assert_eq!(m.carryover_entries.len(), 4);
        let _ = fs::remove_file(&path);
    }

    /// Wrong bytes: the file did not arrive as it was sent.
    #[test]
    fn carryover_wrong_digest_is_refused() {
        let mut c = snapshot_commitment();
        c.digest[0] ^= 1;
        let err = read(SNAPSHOT).unwrap().check_against(&c).expect_err("must refuse");
        assert!(matches!(err, CarryoverError::Digest { .. }), "{err}");
        let msg = err.to_string();
        assert!(msg.contains("FILE-DIGEST mismatch"), "{msg}");
        // The message must carry both values, or an operator cannot tell which
        // artifact they are holding.
        assert!(msg.contains(SNAPSHOT_DIGEST), "{msg}");
        assert!(msg.contains(&crate::codec::hex32(&c.digest)), "{msg}");
    }

    /// Right bytes by the digest's own account, wrong set of outputs. The
    /// fourth check exists because the other three answer different questions:
    /// this is the one independent operators compare across machines.
    #[test]
    fn carryover_wrong_set_root_is_refused() {
        let mut c = snapshot_commitment();
        c.set_root[31] ^= 1;
        let err = read(SNAPSHOT).unwrap().check_against(&c).expect_err("must refuse");
        assert!(matches!(err, CarryoverError::SetRoot { .. }), "{err}");
        let msg = err.to_string();
        assert!(msg.contains("SET-ROOT mismatch"), "{msg}");
        assert!(msg.contains(SNAPSHOT_SET_ROOT), "{msg}");
    }

    /// Right bytes, wrong number of outputs. This is the check that catches a
    /// truncated or padded transfer whose commitment was copied from the
    /// wrong run.
    #[test]
    fn carryover_wrong_count_is_refused() {
        let mut c = snapshot_commitment();
        c.entry_count = 5;
        let err = read(SNAPSHOT).unwrap().check_against(&c).expect_err("must refuse");
        assert!(matches!(err, CarryoverError::Count { found: 4, expected: 5 }), "{err}");
        let msg = err.to_string();
        assert!(msg.contains("ENTRY-COUNT mismatch"), "{msg}");
        // By how much, and in which direction.
        assert!(msg.contains("1 missing"), "{msg}");
    }

    /// Right bytes, right count, wrong money — the failure a digest alone
    /// cannot see. A snapshot from a different height has a valid digest of
    /// itself and can even carry the same number of outputs.
    #[test]
    fn carryover_wrong_total_is_refused() {
        let mut c = snapshot_commitment();
        c.total_sat += 100_000_000;
        let err = read(SNAPSHOT).unwrap().check_against(&c).expect_err("must refuse");
        assert!(matches!(err, CarryoverError::Total { .. }), "{err}");
        let msg = err.to_string();
        assert!(msg.contains("TOTAL mismatch"), "{msg}");
        assert!(msg.contains("100000000"), "the message must say by how much: {msg}");
        assert!(msg.contains("poorer"), "{msg}");
    }

    /// A malformed line stops the ingestion. It is never skipped: a skipped
    /// line is a holder's balance quietly deleted, and the count check would
    /// then be the only thing standing between that and a launched chain.
    #[test]
    fn malformed_lines_are_refused_not_skipped() {
        let good = "1111111111111111111111111111111111111111111111111111111111111111\t0\t840000000000\taaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n";
        let cases: [(&str, &str); 9] = [
            ("2222222222222222222222222222222222222222222222222222222222222222\t0\t7\n", "3 columns"),
            ("2222222222222222222222222222222222222222222222222222222222222222\t0\t7\tbb\tzz\n", "5 columns"),
            ("22222222\t0\t7\tbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\n", "short txid"),
            ("2222222222222222222222222222222222222222222222222222222222222ZZ\t0\t7\tbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\n", "non-hex txid"),
            ("2222222222222222222222222222222222222222222222222222222222222222\t0\t7\tBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB\n", "uppercase script"),
            ("2222222222222222222222222222222222222222222222222222222222222222\t00\t7\tbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\n", "leading zero in vout"),
            ("2222222222222222222222222222222222222222222222222222222222222222\t0\t007\tbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\n", "leading zeros in value"),
            ("2222222222222222222222222222222222222222222222222222222222222222\t0\t-7\tbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\n", "negative value"),
            ("\n", "blank line"),
        ];
        for (bad, what) in cases {
            let text = format!("{good}{bad}");
            let err = read(&text).expect_err(what);
            match err {
                CarryoverError::Line { line, .. } => assert_eq!(line, 2, "{what}"),
                other => panic!("{what}: expected a line error, got {other}"),
            }
        }
        // And the same file without the bad line parses, so each case above
        // failed for its own reason and not because the fixture is broken.
        assert_eq!(read(good).expect("the good line alone parses").entries.len(), 1);
    }

    /// A repeated or out-of-order outpoint is refused. `CommittedState`
    /// stores eUTXOs in a map keyed by (txid, vout), so a duplicate would be
    /// absorbed silently — the file would verify and the ledger would be
    /// short by whatever the dropped copy was worth.
    #[test]
    fn duplicate_and_unsorted_outpoints_are_refused() {
        let line = "1111111111111111111111111111111111111111111111111111111111111111\t0\t5\taaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n";
        let dup = format!("{line}{line}");
        assert!(matches!(read(&dup), Err(CarryoverError::Line { line: 2, .. })));

        let descending = format!(
            "2222222222222222222222222222222222222222222222222222222222222222\t0\t5\taaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n{line}"
        );
        assert!(matches!(read(&descending), Err(CarryoverError::Line { line: 2, .. })));
    }

    /// A manifest with no commitment refuses a snapshot outright: nothing in
    /// the network digest would hold those balances to anything.
    #[test]
    fn a_devnet_manifest_refuses_a_snapshot() {
        let path = snapshot_file("uncommitted", SNAPSHOT);
        let mut m = sample();
        let err = m.ingest_carryover(&path).expect_err("no commitment, no ingestion");
        assert!(matches!(err, CarryoverError::NotCommitted), "{err}");
        let _ = fs::remove_file(&path);
    }

    /// The whole point, at the state root: a genesis that carries the
    /// Genesis-3 balances commits something different from the same genesis
    /// without them. Without this, "the snapshot was ingested" is a claim with
    /// no consequence — which is precisely how a chain launches with every
    /// balance at zero and nobody notices until a holder tries to spend.
    #[test]
    fn a_carried_genesis_commits_a_different_root() {
        use bloch_pos_committee::interfaces::StateReader;
        let with = mainnet_sample();
        // The same manifest in every other respect: same validators, same
        // cohort, same allocations, same clock. Only the carried set differs.
        let mut without = mainnet_sample();
        without.carryover = None;
        without.carryover_entries = Vec::new();
        assert_eq!(with.allocations, without.allocations);
        assert_ne!(
            with.genesis_state().state_root(),
            without.genesis_state().state_root(),
            "452,133 outputs must not be invisible at the state root"
        );
        // And the carried outputs are actually in the committed set, not
        // merely different-looking: carryover first, then allocations.
        let opening = with.opening_balances();
        assert_eq!(opening.len(), 4 + 2);
        assert_eq!(&opening[..4], &with.carryover_entries[..]);
    }

    /// Committing to a carryover and building genesis without ingesting it is
    /// the zero-balance launch. It must be impossible to do quietly.
    #[test]
    #[should_panic(expected = "call Manifest::ingest_carryover")]
    fn a_committed_carryover_without_entries_refuses_to_build_genesis() {
        let mut m = sample();
        m.carryover = Some(snapshot_commitment());
        let _ = m.genesis_state();
    }

    /// A carryover outpoint colliding with an allocation's would vanish into
    /// the state map. Constructed directly, since the file parser's ordering
    /// rule makes it unreachable from a snapshot.
    #[test]
    #[should_panic(expected = "duplicate genesis outpoint")]
    fn duplicate_opening_outpoints_are_refused() {
        let mut m = mainnet_sample();
        let first = m.carryover_entries[0].clone();
        m.carryover_entries.push(first);
        let _ = m.opening_balances();
    }

    /// The measured Genesis-3 snapshot, as published: the numbers this
    /// ingestion will meet on launch day close against the tokenomics
    /// constants. Derived from the constants and the one measured figure, so
    /// the test moves when the terminal snapshot does instead of pinning a
    /// number that was true in August.
    #[test]
    fn the_measured_snapshot_closes_against_tokenomics() {
        use bloch_pos_committee::tokenomics_v4 as t;
        // The G3 total behind `CARRYOVER_TOTAL_BLOCH`, in G3 satoshis.
        let g3_total_sat: u128 = 3_810_744_000 * t::SAT_PER_BLOCH;
        assert_eq!(
            t::split_g3_sat(g3_total_sat),
            t::CARRYOVER_TOTAL_BLOCH * t::SAT_PER_BLOCH,
            "the measured ledger under the split IS the pinned carryover — if this \
             fails, the snapshot and the constants describe different chains"
        );
        // A manifest built the way the ceremony would build it, with the
        // published root, count and post-split total, adds up to §3.
        let mut m = sample();
        m.carryover = Some(CarryoverCommitment {
            // Both are published now. The terminal snapshot was taken on two
            // independently operated nodes and produced byte-identical files —
            // same count, same total, same set root, same file digest. That
            // agreement, not this tool's say-so, is what makes the numbers
            // usable.
            digest: t::CARRYOVER_MEASURED_FILE_SHA3_256,
            set_root: t::CARRYOVER_MEASURED_ROOT,
            entry_count: t::CARRYOVER_MEASURED_UTXOS,
            total_sat: t::CARRYOVER_TOTAL_BLOCH * t::SAT_PER_BLOCH,
        });
        m.allocations = [
            (alloc_purpose::FOUNDER, t::FOUNDER_BLOCH),
            (alloc_purpose::VC, t::VC_BLOCH),
            (alloc_purpose::TEAM, t::TEAM_BLOCH),
            (alloc_purpose::MARKETING, t::MARKETING_BLOCH),
            (alloc_purpose::LIQUIDITY, t::LIQUIDITY_BLOCH),
        ]
        .iter()
        .map(|(p, bloch)| GenesisAllocation {
            purpose: *p,
            script_hash: [*p; 32],
            amount_sat: bloch * t::SAT_PER_BLOCH,
            unlock_epoch: 0,
        })
        .collect();
        m.check_supply().expect("carryover + the five buckets must equal GENESIS_ISSUED_SAT");
        assert_eq!(t::CARRYOVER_MEASURED_UTXOS, 452_726);
        assert_eq!(t::CARRYOVER_MEASURED_HEIGHT, 39_918);
    }

    #[test]
    fn allocation_outputs_are_deterministic_and_distinct() {
        let m = mainnet_sample();
        let a = m.allocation_outputs();
        let b = m.allocation_outputs();
        assert_eq!(a, b, "same manifest must synthesise the same outputs");
        assert_eq!(a.len(), 2);
        assert_ne!(a[0].txid, a[1].txid, "two allocations must not share a txid");
        // Value survives the u128 -> u64 narrowing intact.
        assert_eq!(u128::from(a[0].value), m.allocations[0].amount_sat);
        assert_eq!(a[0].script_hash, m.allocations[0].script_hash);
    }

    /// Reordering the allocation list must not change what genesis commits:
    /// the txid is derived from each allocation's own fields, not its position.
    #[test]
    fn allocation_order_does_not_change_the_outputs() {
        let m = mainnet_sample();
        let mut swapped = clone_of(&m);
        swapped.allocations.reverse();
        let mut a = m.allocation_outputs();
        let mut b = swapped.allocation_outputs();
        a.sort_by_key(|e| e.txid);
        b.sort_by_key(|e| e.txid);
        assert_eq!(a, b);
    }

    #[test]
    fn mainnet_manifest_round_trips() {
        let m = mainnet_sample();
        let back = Manifest::decode(&m.encode()).expect("round trip");
        assert_eq!(back.carryover, m.carryover);
        assert_eq!(back.allocations, m.allocations);
        assert_eq!(back.encode(), m.encode(), "re-encoding must be byte-identical");
    }

    #[test]
    fn devnet_manifest_still_round_trips() {
        // The devnet shape is the same format with the carryover flag clear,
        // not a second format.
        let m = sample();
        let back = Manifest::decode(&m.encode()).expect("round trip");
        assert_eq!(back.carryover, None);
        assert!(back.allocations.is_empty());
    }

    #[test]
    fn carryover_flag_must_be_canonical() {
        let m = sample();
        let mut bytes = m.encode();
        // The flag sits after the cohort; find it by rebuilding a manifest
        // whose only difference is the flag byte.
        let flag_at = bytes.len() - 4 - 1;
        assert_eq!(bytes[flag_at], 0, "test targets the carryover flag");
        bytes[flag_at] = 2;
        assert!(Manifest::decode(&bytes).is_err(), "a third flag value must be refused");
    }

    #[test]
    fn genesis_issuance_is_checked_against_tokenomics() {
        use bloch_pos_committee::tokenomics_v4 as t;
        // A devnet manifest carries no balances and is not held to §3.
        assert!(sample().check_supply().is_ok());

        // A mainnet manifest that does not add up is refused, and the message
        // says by how much rather than just "invalid".
        let bad = mainnet_sample();
        let err = bad.check_supply().expect_err("27.97 B is not the §3 figure");
        assert!(err.contains("tokenomics"), "{err}");

        // And one that does add up passes. Built from the constants, never
        // from a number retyped here — a test that restates the figure would
        // pass while the chain issued something else.
        let mut good = sample();
        good.carryover = Some(CarryoverCommitment {
            digest: [0xC0; 32],
            set_root: [0xC1; 32],
            entry_count: 1,
            total_sat: t::CARRYOVER_TOTAL_BLOCH * t::SAT_PER_BLOCH,
        });
        let rest = t::GENESIS_ISSUED_SAT - t::CARRYOVER_TOTAL_BLOCH * t::SAT_PER_BLOCH;
        good.allocations = vec![GenesisAllocation {
            purpose: alloc_purpose::FOUNDER,
            script_hash: [0xF1; 32],
            amount_sat: rest,
            unlock_epoch: 0,
        }];
        good.check_supply().expect("carryover + allocations must equal GENESIS_ISSUED_SAT");
    }

    /// The manifest's own supply arithmetic equals what the state it builds
    /// actually holds — the claim on [`Manifest::genesis_accounted_sat`], and
    /// the reason that function is allowed to be the figure the ceremony
    /// prints and the genesis checks judge.
    ///
    /// # What would otherwise go unnoticed
    ///
    /// `genesis_accounted_sat` adds two numbers read off the manifest.
    /// `CommittedState::accounted_supply_sat` walks six components of a
    /// committed state built by a different function through a different
    /// path (`allocation_outputs` synthesises txids by hashing, the registry
    /// is keyed by index, the ledger is an SMT). Nothing but a test makes
    /// them the same quantity, and a drift between them is exactly the shape
    /// of the original defect: two supply figures that disagree, each
    /// self-consistent, neither obviously wrong.
    #[test]
    fn genesis_accounting_matches_the_committed_state() {
        use bloch_pos_committee::tokenomics_v4 as t;

        // ── A devnet manifest: bonds only, nothing funded. ────────────────
        let m = sample();
        let bonds: u128 = 1_000 + 2_000 + 3_000;
        assert_eq!(m.genesis_bonded_sat(), bonds);
        assert_eq!(m.genesis_issued_sat(), 0, "a devnet funds nothing");
        assert_eq!(m.genesis_accounted_sat(), bonds);
        assert_eq!(
            m.genesis_state().accounted_supply_sat(),
            m.genesis_accounted_sat(),
            "the manifest's total and the state it builds must be the same number",
        );

        // ── A funded manifest: both pools carry coins. ────────────────────
        //
        // The allocation bucket stands in for the whole funded opening, so
        // the eUTXO half of the committed total is non-empty and the equality
        // above is tested against a state where BOTH terms are live rather
        // than one where the ledger is zero and only the bonds are compared.
        // Built from the constant, never from a retyped figure.
        let mut funded = sample();
        funded.allocations = vec![GenesisAllocation {
            purpose: alloc_purpose::FOUNDER,
            script_hash: [0xF1; 32],
            amount_sat: t::GENESIS_ISSUED_SAT,
            unlock_epoch: 0,
        }];
        assert_eq!(funded.genesis_issued_sat(), t::GENESIS_ISSUED_SAT);
        assert_eq!(funded.genesis_accounted_sat(), t::GENESIS_ISSUED_SAT + bonds);

        let st = funded.genesis_state();
        assert_eq!(
            st.accounted_supply_sat(),
            funded.genesis_accounted_sat(),
            "the manifest and the committed state disagree about the opening supply",
        );
        // And the two halves land where they are supposed to, so the equality
        // above cannot be passing by two errors cancelling.
        assert_eq!(
            st.total_unspent_sat(),
            funded.genesis_issued_sat(),
            "the funded half must be in the ledger",
        );
        assert_eq!(
            st.supply_gap_sat(),
            funded.genesis_unfunded_bonded_sat() as i128,
            "the state's own gap accessor must report the manifest's unfunded bonds",
        );
    }

    /// The genesis bond rule is ENFORCED, and enforced as a ceiling: committed
    /// history passes, anything worse is `Err`.
    ///
    /// This is the test that would have caught the original omission, and it
    /// pins the posture as well as the arithmetic — until 2026-09-04
    /// `check_bonds_are_funded` had exactly one caller and that caller printed
    /// `WARNING (not fatal)` and continued. Both sides of the tightening are
    /// checked here, so the day the cohort is funded and the ceiling drops to
    /// zero, this test moves with it rather than silently passing.
    #[test]
    fn unfunded_genesis_bonds_are_refused_above_the_committed_ceiling() {
        use bloch_pos_committee::tokenomics_v4 as t;

        // A devnet is exempt: it issues nothing, so `GENESIS_ISSUED_SAT` —
        // which describes a network carrying Genesis-3 balances — is not a
        // figure it can be held to.
        assert!(sample().check_bonds_are_funded().is_ok());
        assert!(!sample().bonds_are_fully_funded(), "a devnet funds no bonds");

        // A mainnet-shaped manifest whose funding adds up, bonding exactly the
        // recorded Genesis-4 offset: this is committed history and must
        // regenerate. Anything else makes `genesis-mainnet` a broken tool.
        // A builder, because `Manifest` is deliberately not `Clone` — the
        // three fixtures below are variations on it and each is built fresh.
        let mainnet_at_ceiling = || {
            let mut m = sample();
            m.carryover = Some(CarryoverCommitment {
                digest: [0xC0; 32],
                set_root: [0xC1; 32],
                entry_count: 1,
                total_sat: t::CARRYOVER_TOTAL_BLOCH * t::SAT_PER_BLOCH,
            });
            m.allocations = vec![GenesisAllocation {
                purpose: alloc_purpose::FOUNDER,
                script_hash: [0xF1; 32],
                amount_sat: t::GENESIS_ISSUED_SAT - t::CARRYOVER_TOTAL_BLOCH * t::SAT_PER_BLOCH,
                unlock_epoch: 0,
            }];
            // 64 validators at 25,000 BLOCH — the live cohort, from the constant.
            m.validators = (0..64)
                .map(|i| ManifestValidator {
                    index: i,
                    stake_sat: 25_000 * t::SAT_PER_BLOCH,
                    randao_commitment: [i as u8; 32],
                    pubkey: shaped_pubkey(i as u8),
                    withdrawal_credentials: Vec::new(),
                    commission_bps: 500,
                })
                .collect();
            m
        };
        let at_ceiling = mainnet_at_ceiling();
        at_ceiling.check_supply().expect("the funding half must still add up");
        assert_eq!(
            at_ceiling.genesis_unfunded_bonded_sat(),
            t::GENESIS_UNFUNDED_BONDED_CEILING_SAT,
            "the fixture no longer reproduces the committed Genesis-4 cohort",
        );
        at_ceiling
            .check_bonds_are_funded()
            .expect("committed history must regenerate, or the ceremony tool is broken");
        assert!(
            !at_ceiling.bonds_are_fully_funded(),
            "the live chain is NOT fully funded — if this passes, the clean rule \
             and the ceiling rule have been conflated",
        );

        // One more validator, and it is a hard error. This is the entire
        // class of repeat the warning could only describe: a 65th bond, a
        // raised stake, a second cohort.
        let mut over = mainnet_at_ceiling();
        over.validators.push(ManifestValidator {
            index: 64,
            stake_sat: 25_000 * t::SAT_PER_BLOCH,
            randao_commitment: [0x64; 32],
            pubkey: shaped_pubkey(0x64),
            withdrawal_credentials: Vec::new(),
            commission_bps: 500,
        });
        let err = over
            .check_bonds_are_funded()
            .expect_err("a 65th unfunded bond must be refused, not warned about");
        assert!(err.contains("minted from nothing"), "{err}");
        // The message says by how much, so an operator can act on it.
        assert!(
            err.contains(&(25_000 * t::SAT_PER_BLOCH).to_string()),
            "the error must name the excess: {err}",
        );

        // ── The clean end state, and the coupling it exposes ──────────────
        //
        // Funding the cohort means the ceremony emits that much LESS as
        // outputs and bonds the difference, so the total minted at slot 0 is
        // still `GENESIS_ISSUED_SAT` — it is just split across two pools
        // instead of one. That satisfies the clean rule:
        let mut clean = mainnet_at_ceiling();
        clean.allocations[0].amount_sat -= t::GENESIS_UNFUNDED_BONDED_CEILING_SAT;
        assert!(
            clean.bonds_are_fully_funded(),
            "moving the cohort's stake inside issuance must satisfy the clean rule",
        );
        clean.check_bonds_are_funded().expect("zero unfunded is under any ceiling");

        // And it is refused by `check_supply`, which is not a contradiction
        // but the coupling worth stating out loud: `check_supply` compares
        // the FUNDED half against `GENESIS_ISSUED_SAT`, because that constant
        // is what `CommittedState::genesis` seeds the committed counter with.
        // Adopting the clean rule therefore means deciding what the counter
        // should be seeded with when part of the issuance is bonded rather
        // than emitted — a tokenomics decision about a committed field, which
        // is exactly why the ceiling exists in the meantime instead of a
        // quiet edit to one of these two checks.
        assert!(
            clean.check_supply().is_err(),
            "if this passes, `check_supply` and `check_bonds_are_funded` have \
             stopped measuring different halves and one of them is now decorative",
        );
    }

    #[test]
    fn manifest_round_trips() {
        let m = sample();
        let bytes = m.encode();
        let back = Manifest::decode(&bytes).expect("round trip");
        assert_eq!(back.genesis_time_ms, m.genesis_time_ms);
        assert_eq!(back.slot_ms, m.slot_ms);
        assert_eq!(back.validators.len(), 3);
        assert_eq!(
            back.validators.iter().map(|v| v.commission_bps).collect::<Vec<_>>(),
            m.validators.iter().map(|v| v.commission_bps).collect::<Vec<_>>(),
        );
        assert_eq!(back.cohort, m.cohort);
        // Genesis identity and state are pure functions of the manifest.
        use bloch_pos_committee::interfaces::StateReader;
        assert_eq!(back.genesis_id(), m.genesis_id());
        assert_eq!(back.genesis_state().state_root(), m.genesis_state().state_root());
    }

    #[test]
    fn manifest_decode_rejects_trailing_bytes() {
        let mut bytes = sample().encode();
        bytes.push(0);
        assert!(Manifest::decode(&bytes).is_err());
    }
}

#[cfg(test)]
mod blp02_hybrid_suite {
    use super::*;

    // `Manifest` does not derive Debug, and it is not this test's business to
    // make a consensus type derive one. So: is_ok/is_err plus a match for the
    // message, never expect/expect_err.
    fn decode_err(bytes: &[u8]) -> Option<&'static str> {
        match Manifest::decode(bytes) {
            Ok(_) => None,
            Err(e) => Some(e.0),
        }
    }

    fn hybrid_pk() -> Vec<u8> {
        let mut v = vec![0xB1, 0x0C, 0x01, 0x00];
        v.extend(std::iter::repeat(0x11).take(1952 + 1793));
        v
    }
    fn mldsa_only_pk() -> Vec<u8> {
        let mut v = vec![0xB1, 0x0C, 0x02, 0x00];
        v.extend(std::iter::repeat(0x22).take(1952));
        v
    }
    fn manifest_with(pk: Vec<u8>) -> Manifest {
        Manifest {
            genesis_time_ms: 1_800_000_000_000,
            slot_ms: 30_000,
            validators: vec![ManifestValidator {
                index: 0,
                stake_sat: 25_000 * 100_000_000,
                randao_commitment: [0x44u8; 32],
                pubkey: pk,
                withdrawal_credentials: [0x55u8; 32].to_vec(),
                commission_bps: 0,
            }],
            cohort: vec![0],
            carryover: None,
            allocations: vec![],
            carryover_entries: vec![],
            format: ManifestFormat::V1Unbound,
            pre_state_root: std::sync::OnceLock::new(),
        }
    }

    #[test]
    fn mldsa_only_validator_key_is_refused_at_decode() {
        let bytes = manifest_with(mldsa_only_pk()).encode();
        let msg = decode_err(&bytes).expect("a 0x0002 validator key must not decode");
        assert!(msg.contains("hybrid"), "the refusal must name the reason, got: {msg}");
    }

    #[test]
    fn hybrid_validator_key_still_decodes() {
        let bytes = manifest_with(hybrid_pk()).encode();
        assert!(
            Manifest::decode(&bytes).is_ok(),
            "the hybrid suite is what Genesis-4 runs and must keep decoding"
        );
    }

    #[test]
    fn a_hybrid_claim_with_no_falcon_half_is_refused() {
        // Right suite id, ML-DSA bytes only — the dangerous middle case.
        let mut pk = vec![0xB1, 0x0C, 0x01, 0x00];
        pk.extend(std::iter::repeat(0x33).take(1952));
        let bytes = manifest_with(pk).encode();
        assert!(
            decode_err(&bytes).is_some(),
            "a hybrid claim carrying no Falcon half must not decode"
        );
    }

    #[test]
    fn the_live_mainnet_manifest_still_decodes() {
        // A check that refuses the running chain is worse than the gap it closes.
        // This reads the published artefact, not a fixture this test built.
        let path = concat!(env!("CARGO_MANIFEST_DIR"), "/../../genesis/mainnet.manifest");
        let Ok(bytes) = std::fs::read(path) else { return };
        match Manifest::decode(&bytes) {
            Ok(m) => assert_eq!(m.validators.len(), 64, "the live set is 64 validators"),
            Err(e) => panic!("the live Genesis-4 manifest must decode, got: {}", e.0),
        }
    }
}
