// SPDX-License-Identifier: AGPL-3.0-or-later

//! The production network layer: libp2p + gossipsub, with the Genesis-3
//! incident record carried over rather than re-learned.
//!
//! `net.rs` is the devnet transport — a TCP full mesh with no relay logic, no
//! scoring and no admission control. It proved the consensus (a 64-validator,
//! 5-host devnet finalized on it), and it stays available behind
//! `--transport devnet`. This module is what a public network needs instead.
//!
//! ## What was ported, and from where
//!
//! Everything below that reads like an over-explained constant is a scar. The
//! source is the Genesis-3 node's `src/network/mod.rs` + `src/network/sync_rr.rs`,
//! which run on mainnet:
//!
//! - **No `add_explicit_peer()`, ever** (2026-08-07 mesh defect (a)). An
//!   "explicit peer" in gossipsub is DELIBERATELY EXCLUDED from mesh
//!   construction: libp2p-gossipsub 0.49.5 `behaviour.rs:2224` filters graft
//!   candidates with `!explicit_peers.contains(peer)`, and `:1395` answers an
//!   incoming GRAFT from an explicit peer by PRUNING it on every topic.
//!   Marking every connection explicit made the mesh permanently unbuildable:
//!   "Mesh low. Topic contains: 0" forever, `publish()` →
//!   `NoPeersSubscribedToTopic`, and the producer's blocks never left the box.
//!   The connection handler here therefore does *nothing* to gossipsub — the
//!   behaviour learns about peers by itself.
//!
//! - **No `..Default::default()` in [`TopicScoreParams`]** (2026-08-07 mesh
//!   defect (b)). The default ships P3 `mesh_message_deliveries_weight = -1.0`
//!   with `threshold = 20.0` and `activation = 5s`. Five seconds after a peer
//!   grafts, gossipsub charges `-1.0 × (20 − delivered)² × topic_weight`. A
//!   30 s slot chain delivers 0 in that window, so every peer took ≈ −400
//!   summed across topics — exactly `graylist_threshold`. Every peer that
//!   grafted was guaranteed to be pruned within seconds. [`topic_params`]
//!   therefore writes **every field explicitly**; the struct literal has no
//!   `..Default::default()` tail, so adding a field upstream breaks the build
//!   instead of silently re-arming the penalty. [`score_params_have_no_p3`]
//!   pins it.
//!
//! - **[`MAX_YAMUX_STREAMS`] must exceed [`MAX_CONCURRENT_SYNC_STREAMS`]**.
//!   yamux does not backpressure at its substream cap, it KILLS the connection
//!   ("maximum number of streams reached" → disconnect). A node catching up
//!   opens a burst of sync substreams and the transport drops the very peer it
//!   is syncing from. Pinned by a `const` assertion below.
//!
//! - **[`REGOSSIP_SUPPRESS_TTL`] ≥ [`DUPLICATE_CACHE_TIME`]**. The message id
//!   is a content hash, so a re-publish inside the duplicate window is refused
//!   by gossipsub *locally* anyway — after paying the encode and the hash of a
//!   multi-hundred-KB body. A shorter suppression window is pure waste. Also
//!   pinned by a `const` assertion.
//!
//! ## What is new here, and deliberate
//!
//! - **A protocol prefix of its own.** Genesis-4 speaks
//!   `/bloch-g4/meshsub/1.1.0`, `/bloch-g4/sync/1` and identify
//!   `/bloch-g4/1.0.0`; Genesis-3 speaks `/meshsub/1.1.0`, `/bloch/sync/1` and
//!   `/bloch-sis/1.0.0`. Multistream-select finds no common protocol, so a
//!   Genesis-4 node cannot join a Genesis-3 mesh by accident even if someone
//!   points it at one. The topic names differ too (`bloch-g4/…` vs `bloch/…`),
//!   which is the second, independent barrier.
//!
//! - **`gossip.rs` is wired.** Gossipsub runs with `validate_messages()`, so
//!   nothing is relayed until the node says so. Attestations go to the engine
//!   carrying an [`Origin`]; the engine runs
//!   [`AttestationPool::process`](bloch_pos_committee::gossip::AttestationPool::process)
//!   and maps the returned [`GossipDecision`](bloch_pos_committee::gossip::GossipDecision)
//!   back through [`Handle::report`] onto
//!   `report_message_validation_result`. That is the contract the pure
//!   module's own docs state, and the reason `Ignore` and `Reject` are
//!   different types there: only `Reject` may ever feed a peer penalty.
//!
//! - **Sync is a directed pull, never a broadcast.** `get-blocks` is the one
//!   request the devnet transport had; here it is a `/bloch-g4/sync/1`
//!   request-response to a small set of chosen peers, not a mesh broadcast.
//!   The Genesis-3 root cause is on the record: sweeping IBD fetches onto the
//!   gossip topic produced O(peers × blocks) amplification that saturated the
//!   send queue and stalled the chain. Responses are capped
//!   ([`MAX_SYNC_BLOCKS`], [`MAX_SYNC_FRAME`]) so no peer can answer a small
//!   question with a history dump — the 2026-08-09 backfill flood, where one
//!   stale node pushed 1,270 old blocks and stopped production network-wide,
//!   is structurally unavailable over this path.
//!
//! ## Cold start: a new node builds its own state, from genesis
//!
//! This is a first-class requirement, not a consequence, and it is the
//! question an exchange asks before it will credit a deposit: *can we run a
//! node that verifies the chain itself, or must someone hand us a database?*
//!
//! On Genesis-3 the honest answer is no, permanently: `docs/CARRYOVER.md`
//! states that syncing from genesis is unsupported, and the block bodies a
//! from-scratch sync would need were dropped from the whole network before the
//! retention fix. Nothing can bring them back. A node bootstrapped from the
//! producer's datadir has verified nothing, and its confirmation counts mean
//! nothing.
//!
//! Genesis-4 starts clean, and this transport is built so that stays true:
//!
//! - A node with **only the genesis manifest** and an empty data dir asks its
//!   peers for everything after slot 0 and walks forward. Every block it
//!   receives goes through the same `Transition::apply_block` the producer
//!   ran — signatures, state root, body root, attestation quorum, all of it.
//!   Nothing about "this came from sync" makes validation lighter; the sync
//!   path feeds `NetEvent::Block`, exactly like gossip does (with
//!   `Origin::none`: there is no gossip message to report a verdict on).
//! - Because one answer is capped at [`MAX_SYNC_BLOCKS`], a cold node's
//!   request is **paginated**: a full page is immediately followed by a
//!   request for the next one, from the same peer, until a short page says the
//!   peer has no more. That is what makes "ask from genesis" work rather than
//!   merely be accepted. [`MAX_PAGES_WITHOUT_PROGRESS`] bounds the loop so a
//!   peer feeding blocks the engine will not apply cannot page forever.
//! - The serving side serves its **whole** block log, so a request for
//!   `after_slot = 0` is answered from the beginning of the chain. There is no
//!   "recent blocks only" fast path, and there is no datadir-donation path.
//!   It does not *read* the whole log to do it: `store::Store::blocks_after`
//!   finds the window through the `blocks.idx` slot → offset index, so the
//!   work of answering is proportional to the page served and not to the
//!   length of the chain.
//! - **What one peer may make this node do is bounded on the serving side
//!   too**, by [`SYNC_ANSWERS_PER_SEC`]/[`SYNC_ANSWER_BURST`] and
//!   [`MAX_INFLIGHT_SYNC_PER_PEER`]. Capping the SIZE of an answer
//!   ([`MAX_SYNC_BLOCKS`], [`MAX_SYNC_FRAME`]) never bounded their NUMBER:
//!   before those limits a peer could ask again as fast as it liked, on up to
//!   [`MAX_CONCURRENT_SYNC_STREAMS`] substreams, and each eight-byte question
//!   started a blocking-pool task against the log.
//!
//! **The trust boundary, stated plainly (do not bury this).** Downloading and
//! validating every block proves the chain is *internally* valid; it does not
//! by itself prove it is *the* chain, because a set of validators that has
//! already withdrawn its stake can sign an alternative history at no cost —
//! the long-range problem every proof-of-stake system has. Genesis-4's answer
//! is weak subjectivity (`ws_boot`, `BLOCH-WEAK-SUBJECTIVITY.md`), and it has
//! exactly two regimes:
//!
//! 1. **While the chain is younger than
//!    [`WS_PERIOD_EPOCHS`](bloch_pos_committee::ws::WS_PERIOD_EPOCHS) —
//!    2016 epochs, ≈ 22.4 days at the 30 s cadence — a fresh node needs
//!    nothing but the genesis manifest.** The genesis block is its own
//!    subjectivity anchor, no signature from anyone is required, and cold sync
//!    is fully trustless.
//! 2. **After that, a node with an empty database requires a signed
//!    checkpoint** (`--ws-checkpoint` + `--ws-signer-set`) and refuses to sync
//!    without one. That is a real trust input and it is named as one: the node
//!    trusts the checkpoint signers for the single fact of *which* finalized
//!    root is real at one epoch. It does **not** trust them for state — every
//!    block after the anchor is still downloaded and revalidated locally, and
//!    a checkpoint that contradicts finality this node reached on its own is
//!    an alarm that cannot reorganize it (`enforce_ws_anchor`).
//!
//! The distance between (2) and "copy the producer's datadir" is the whole
//! point: 32 bytes an operator can compare against independent publication
//! channels, versus a database whose contents nobody verified.
//!
//! ## What this module does NOT do (say it here, not in a status meeting)
//!
//! - **The transport handshake is Noise (X25519), not the Genesis-3 Kyber768
//!   upgrade.** `src/transport/` in the Genesis-3 tree implements a hybrid PQ
//!   handshake; porting it means copying ~1,500 lines that depend on that
//!   crate's `crate::crypto`, and doing that badly is worse than not doing it.
//!   Consensus signatures are unaffected — blocks and attestations are hybrid
//!   ML-DSA-65 ‖ Falcon-1024 either way, and this node verifies them itself.
//!   What is exposed is *transport* confidentiality against a
//!   harvest-now-decrypt-later adversary. Named as the next piece of work.
//!
//! - **Transactions are relayed on decodability, not on validity.** That
//!   relay decision is taken at the edge (does it decode?), because gating it
//!   on the full state transition would put a consensus round-trip in front of
//!   every forward.
//!
//!   **Blocks no longer are.** They used to be, and the entry that stood here
//!   said so and named the fix: "closing that needs the engine's verdict on
//!   the block path too, the same shape as the attestation path." That is what
//!   the block arm of [`on_gossip`] now does — it carries an [`Origin`] and
//!   stays silent until `Engine::ingest_judged` answers, so a header that does
//!   not commit to its body, a body this build cannot decode, or a
//!   `header.slot` past the node's horizon is dropped without being amplified
//!   and IS charged to the forwarding peer. The relay condition is still
//!   structural soundness, not full validity: a block on a losing branch or
//!   one whose parent has not landed is honest and must keep propagating.
//!
//! - **Attestations get the full `gossip.rs` treatment** — the pool's own
//!   `GossipDecision`, not merely a structural check.
//!
//! - **No peer persistence, no PEX, no DNS seeds, no mDNS.** Peers come from
//!   `--p2p-peer` and are re-dialled on a timer. `known_peers.json`, peer
//!   exchange and its whole hardening surface (rate limits, address
//!   validation, the canonical-address idempotency fix) are Genesis-3 code
//!   that is not ported yet.
//!
//! - **The channel to the engine is unbounded.** During a cold sync the
//!   in-flight ceiling is roughly `MAX_PAGES_WITHOUT_PROGRESS × MAX_SYNC_BLOCKS`
//!   blocks per serving peer — a real bound, but a generous one (tens of MB),
//!   and it is a bound on *memory*, not backpressure. Genesis-3 learned the
//!   other side of this: a bounded channel that sheds under load dropped the
//!   very sync replies the orphan pool was waiting on, in silence. Neither
//!   answer is free; this one is chosen because a syncing node that stalls is
//!   worse than one that is briefly fat, and it is named rather than assumed.

use std::collections::{HashMap, VecDeque};
use std::io;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};
use std::sync::mpsc::Sender as EngineSender;
use std::sync::Arc;
use std::time::{Duration, Instant};

use async_trait::async_trait;
use futures::prelude::*;
use libp2p::gossipsub::{
    self, IdentTopic, MessageAcceptance, MessageAuthenticity, MessageId, PeerScoreParams,
    PeerScoreThresholds, TopicScoreParams, ValidationMode,
};
use libp2p::request_response::{self, Codec as RrCodec, Config as RrConfig, ProtocolSupport};
use libp2p::swarm::SwarmEvent;
use libp2p::{identify, identity, noise, yamux, PeerId, StreamProtocol, SwarmBuilder};

/// Re-exported so the composition root can parse `--p2p-listen`/`--p2p-peer`
/// without depending on libp2p directly.
pub use libp2p::Multiaddr;

use crate::net::NetEvent;

// ── Protocol identity: a Genesis-4 node must never speak to a Genesis-3 one ──

/// Gossipsub protocol prefix. The negotiated protocol becomes
/// `/bloch-g4/meshsub/1.1.0`; Genesis-3 runs the library default
/// `/meshsub/1.1.0`. Multistream-select finds no overlap, so the two networks
/// cannot form a mesh even when pointed at each other.
pub const GOSSIP_PROTOCOL_PREFIX: &str = "/bloch-g4";

/// Identify protocol. Distinct from Genesis-3's `/bloch-sis/1.0.0`.
pub const IDENTIFY_PROTOCOL: &str = "/bloch-g4/1.0.0";

/// Directed sync protocol. Distinct from Genesis-3's `/bloch/sync/1`.
pub const SYNC_PROTOCOL: StreamProtocol = StreamProtocol::new("/bloch-g4/sync/1");

/// Block gossip topic. Genesis-3 uses `bloch/blocks/1`.
pub const TOPIC_BLOCKS: &str = "bloch-g4/blocks/1";
/// Attestation gossip topic. Genesis-3 has no equivalent — it is proof of work.
pub const TOPIC_ATTESTATIONS: &str = "bloch-g4/attestations/1";
/// Transaction gossip topic. Genesis-3 uses `bloch/txs/1`.
pub const TOPIC_TXS: &str = "bloch-g4/txs/1";

// ── Bounds that are load-bearing, each pinned by an assertion ────────────────

/// Largest gossip frame. A block with the full validator set attesting is
/// dominated by hybrid signatures (~4.6 KB each), so this is generous rather
/// than tight; `codec::MAX_FIELD_LEN` (8 MiB) remains the decoder's own cap.
pub const MAX_GOSSIP_BYTES: usize = 4 * 1024 * 1024;

/// Gossipsub's duplicate-cache retention. See [`REGOSSIP_SUPPRESS_TTL`].
pub const DUPLICATE_CACHE_TIME: Duration = Duration::from_secs(30);

/// How long this node suppresses re-publishing a block it has already
/// published or received.
///
/// MUST be `>= DUPLICATE_CACHE_TIME`. The message id is a content hash, so a
/// re-publish inside the duplicate window is refused by gossipsub locally
/// (`PublishError::Duplicate`) *after* the encode and the hash have been paid.
/// A shorter window is a band of guaranteed waste — Genesis-3 shipped 10 s
/// against a 30 s cache and measured exactly that.
pub const REGOSSIP_SUPPRESS_TTL: Duration = Duration::from_secs(30);

const _: () = assert!(
    REGOSSIP_SUPPRESS_TTL.as_secs() >= DUPLICATE_CACHE_TIME.as_secs(),
    "re-gossip suppression shorter than the duplicate cache is pure waste"
);

/// Concurrent request-response substreams per connection before new inbound
/// streams are dropped. libp2p's default is 100; a node catching up opens a
/// burst well past that and then loses the peer's deliveries.
pub const MAX_CONCURRENT_SYNC_STREAMS: usize = 2048;

/// Yamux substream cap per connection.
///
/// MUST exceed [`MAX_CONCURRENT_SYNC_STREAMS`]. yamux does not backpressure at
/// the cap — it terminates the connection (`Action::Terminate` inbound,
/// `ConnectionError::TooManyStreams` outbound), logged as "maximum number of
/// streams reached" followed by a disconnect. Genesis-3 raised the rr cap to
/// 2048 while leaving `yamux::Config::default` at its 512, and node4 answered
/// with a 0↔3-peer connect/disconnect oscillation.
///
/// KNOWN TRADE-OFF, verified in libp2p-yamux 0.47's own source: any setter —
/// including `set_max_num_streams` — switches the muxer backend from yamux
/// 0.13 to 0.12 (the crate's `config_set_switches_to_v012` test pins this as
/// intended). There is no way to raise the 0.13 cap through the public API.
/// 0.12 speaks the same wire protocol, so this is a local choice, not a fork.
pub const MAX_YAMUX_STREAMS: usize = 4096;

const _: () = assert!(
    MAX_YAMUX_STREAMS > MAX_CONCURRENT_SYNC_STREAMS,
    "yamux would terminate the connection the sync layer is allowed to fill"
);

/// Blocks one sync response may carry. Bounds the answer to a `get-blocks`
/// so a peer cannot turn a small question into a history dump.
pub const MAX_SYNC_BLOCKS: usize = 128;

/// Byte ceiling on a sync frame, checked while building the response and again
/// while reading it.
pub const MAX_SYNC_FRAME: u64 = 8 * 1024 * 1024;

/// Peers a single `get-blocks` is directed at. Not one (a silent peer would
/// stall recovery), not all (that is the broadcast this replaces).
const SYNC_FANOUT: usize = 3;

/// Consecutive **full** sync pages this node will chase from one peer without
/// its own applied head advancing.
///
/// Pagination is what makes cold sync from genesis work: one answer is capped
/// at [`MAX_SYNC_BLOCKS`], so a node 400,000 blocks behind must ask again, and
/// again, and the honest way to do that is to ask the moment a full page
/// arrives rather than on the engine's 2-slot sync timer. The bound exists
/// because the same loop, unbounded, is a free amplifier for a peer serving
/// blocks that never apply: 64 × 128 = 8,192 blocks of no progress is the most
/// this node will pull before it stops asking that peer. Any real progress
/// resets the counter, so a genuine multi-year backfill is unaffected.
///
/// PER PEER (R1 A3-M3): the budget used to be one pair of counters shared by
/// every peer this node ever chased a page from, so a single peer that kept
/// answering full pages that never advanced the applied head (because they
/// were all on a branch this node's transition refuses) spent the ENTIRE
/// budget — the next peer to offer a genuine page found `pages_since_progress`
/// already at the cap and got nothing chased, even though ITS pages were
/// making real progress. [`Loop::may_chase_page`] now keys the counters by
/// [`libp2p::PeerId`] so one stalling peer cannot spend another's budget.
const MAX_PAGES_WITHOUT_PROGRESS: u32 = 64;

/// Distinct `Multiaddr`s [`Loop::dialed`] will remember, FIFO-evicted past the
/// cap (R1 A3-M5).
///
/// Every address is peer-CONTROLLED: it arrives via identify's
/// `info.listen_addrs`, which a peer fills in itself, and there is no cap on
/// how many a well-formed identify message may carry. Without a bound, one
/// peer advertising many addresses — or many short-lived peers advertising a
/// few each — grows this map for the life of the process. "A few hundred" is
/// generous headroom over any real deployment: `--max-peers` defaults to 64
/// connected peers, so 512 is 8 addresses remembered per peer at the current
/// default, and the map is ALSO pruned of a peer's own entries the moment its
/// last connection closes (`Loop::forget_peer`), so a stable mesh never gets
/// close to the cap at all.
const MAX_DIALED_ADDRS: usize = 512;

// ── What one peer may make this node do (the serving side) ──────────────────
//
// [`MAX_PAGES_WITHOUT_PROGRESS`] bounds what this node will PULL. Nothing
// bounded what it would SERVE. `MAX_SYNC_BLOCKS` and `MAX_SYNC_FRAME` cap one
// answer's size, which is not the same thing: a peer could ask again
// immediately, as often as it liked, on up to
// [`MAX_CONCURRENT_SYNC_STREAMS`] substreams per connection, and every one of
// those questions was answered off the block log by a `spawn_blocking` task
// this node started on its behalf. Eight bytes to ask; a disk read and a
// blocking-pool slot to answer. That asymmetry is the amplifier.
//
// Two limits close it, and they close different halves:
//
//   * the **token bucket** bounds the RATE — how many questions a peer may
//     have answered per second, averaged, with a burst for the honest case;
//   * the **in-flight cap** bounds the CONCURRENCY — how many answers this
//     node is building for one peer at one instant, which is what actually
//     consumes blocking-pool threads and memory.
//
// A refused request is answered with an empty page rather than dropped. The
// channel exists either way; an empty answer costs no disk and tells a
// well-behaved peer to come back on its sync timer, while dropping it would
// leave the asker waiting out a protocol timeout for no diagnostic gain.

/// Sustained `get-blocks` answers per peer, per second.
///
/// One answer is up to [`MAX_SYNC_BLOCKS`] blocks, so this is a sustained
/// 1,024 blocks/s to a single peer — comfortably above what a genuine cold
/// sync can apply, which is the number that matters: the limit must not be
/// reachable by an honest catch-up.
pub const SYNC_ANSWERS_PER_SEC: f64 = 8.0;

/// Burst of answers a peer may take before the sustained rate binds. Covers
/// the reconnect flurry (a peer redialling opens a walk per peer) without
/// letting a burst be a strategy.
pub const SYNC_ANSWER_BURST: f64 = 32.0;

/// Answers being built for ONE peer at one instant. Two, not one: a peer may
/// legitimately have its reconnect request and its page-chase request open at
/// the same moment. Anything past that is not a sync pattern.
pub const MAX_INFLIGHT_SYNC_PER_PEER: usize = 2;

const _: () = assert!(
    MAX_INFLIGHT_SYNC_PER_PEER < MAX_CONCURRENT_SYNC_STREAMS,
    "the in-flight cap must bite before the substream cap, or it does nothing"
);

/// Why a `get-blocks` was refused. Carried so the log (and the tests) can
/// tell the two limits apart.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum SyncRefusal {
    /// Over [`SYNC_ANSWERS_PER_SEC`] once the burst is spent.
    RateLimited,
    /// Already [`MAX_INFLIGHT_SYNC_PER_PEER`] answers being built.
    TooManyInFlight,
}

#[derive(Debug)]
struct PeerSync {
    tokens: f64,
    last: Instant,
    inflight: usize,
    /// Set by [`SyncLimiter::forget`] when it ran while an answer was still
    /// being built for this peer (R3 M-7). Production calls `forget` exactly
    /// ONCE, from `ConnectionClosed` — there is no second disconnect event to
    /// retry the removal on. Without this flag the entry survived every
    /// disconnect that happened to race an in-flight answer: `forget` kept it
    /// (correctly, to keep the slot honest) but nothing ever removed it
    /// afterward, so `SyncLimiter::peers` grew by one per such peer for the
    /// life of the process. `release` — the only other thing touching
    /// `inflight` — now finishes the removal `forget` deferred.
    disconnect_pending: bool,
}

/// Proof that one `get-blocks` from one peer was **admitted**, and the only
/// key to the block log on the serving side.
///
/// [`SyncLimiter::begin`] is the only thing that mints one and it has no other
/// constructor, while [`read_sync_page`] — the single place the serving path
/// reads the log — takes one by reference. A future edit that answers a
/// request without going through admission therefore does not compile, which
/// is the property a test alone could not hold: the previous round of this
/// fix tested the limiter in isolation and left the wiring to reviewers'
/// eyes.
///
/// It is also the accounting token. Exactly one permit exists per occupied
/// in-flight slot, it is moved into the blocking task and handed back to the
/// swarm loop with the answer, and [`SyncLimiter::release`] consumes it — so a
/// slot cannot be released twice, and a refused request (which holds no
/// permit) cannot release one at all.
#[derive(Debug)]
#[must_use = "dropping a permit without SyncLimiter::release leaks the peer's in-flight slot"]
pub struct SyncPermit {
    peer: PeerId,
}

/// Per-peer admission for `get-blocks`: a token bucket and an in-flight cap.
///
/// Time is a parameter, not a call to `Instant::now()` inside, so the refill
/// arithmetic is testable without sleeping.
#[derive(Debug, Default)]
pub struct SyncLimiter {
    peers: HashMap<PeerId, PeerSync>,
}

impl SyncLimiter {
    /// Admit one request, or say why not. The [`SyncPermit`] returned on `Ok`
    /// holds the peer's in-flight slot until it is handed to
    /// [`SyncLimiter::release`].
    pub fn begin(&mut self, peer: PeerId, now: Instant) -> Result<SyncPermit, SyncRefusal> {
        let e = self.peers.entry(peer).or_insert(PeerSync {
            tokens: SYNC_ANSWER_BURST,
            last: now,
            inflight: 0,
            disconnect_pending: false,
        });
        // Refill first: `saturating_duration_since` because a caller may hand
        // in a `now` that is not after `last` (it never does in the swarm
        // loop, but a panic here would be a remote kill switch).
        let dt = now.saturating_duration_since(e.last).as_secs_f64();
        e.last = now;
        e.tokens = (e.tokens + dt * SYNC_ANSWERS_PER_SEC).min(SYNC_ANSWER_BURST);
        // The in-flight cap is checked BEFORE a token is spent: a peer that is
        // simply being served slowly should not also lose its budget.
        if e.inflight >= MAX_INFLIGHT_SYNC_PER_PEER {
            return Err(SyncRefusal::TooManyInFlight);
        }
        if e.tokens < 1.0 {
            return Err(SyncRefusal::RateLimited);
        }
        e.tokens -= 1.0;
        // Guarded by `e.inflight >= MAX_INFLIGHT_SYNC_PER_PEER` returning
        // above: `e.inflight` is a small per-peer in-flight counter, always
        // below that cap here — saturating is the intended semantics for a
        // counter regardless.
        e.inflight = e.inflight.saturating_add(1);
        Ok(SyncPermit { peer })
    }

    /// One answer finished (or failed): give the slot back.
    ///
    /// Takes the permit **by value** on purpose. The first cut of this fix
    /// released by `PeerId` from the response channel, which every answer
    /// travels down — including the empty one sent to a REFUSED peer. A peer
    /// that flooded `get-blocks` therefore had a slot freed per refusal it
    /// provoked, so the in-flight cap it had just tripped stopped binding:
    /// the defence paid the attacker. Only a permit can be released now, and
    /// a refusal never gets one.
    pub fn release(&mut self, permit: SyncPermit) {
        let mut remove = false;
        if let Some(e) = self.peers.get_mut(&permit.peer) {
            e.inflight = e.inflight.saturating_sub(1);
            // R3 M-7: finish a removal `forget` deferred because this was the
            // last answer still in flight for a peer that already
            // disconnected. `forget` cannot wait for this itself — it is not
            // called again — so this is the only place left to close the leak.
            remove = e.inflight == 0 && e.disconnect_pending;
        }
        if remove {
            self.peers.remove(&permit.peer);
        }
    }

    /// Peer gone. Dropping the record refunds its burst, which is why it is
    /// only done when the last connection closes — a peer cannot reset its
    /// own bucket without paying for a full reconnect.
    ///
    /// Called exactly once per peer, from `ConnectionClosed` (R3 M-7): if an
    /// answer is still being built, the entry is marked rather than dropped —
    /// dropping it here would refund the peer's budget mid-flight — and
    /// [`SyncLimiter::release`] removes it the moment the last in-flight slot
    /// clears, since no second disconnect event will ever arrive to retry.
    pub fn forget(&mut self, peer: &PeerId) {
        if let Some(e) = self.peers.get_mut(peer) {
            if e.inflight > 0 {
                e.disconnect_pending = true;
                return;
            }
        }
        self.peers.remove(peer);
    }

    /// Peers currently tracked. Bounded by the connected set because
    /// [`SyncLimiter::forget`] runs on the last disconnect.
    pub fn tracked(&self) -> usize {
        self.peers.len()
    }
}

/// How often unconnected configured peers are re-dialled.
const REDIAL_INTERVAL: Duration = Duration::from_secs(10);

// ── The validation verdict the engine hands back ────────────────────────────

/// Where a gossip message came from, opaque to the engine.
///
/// Carried on [`NetEvent::Attestation`] so the engine's decision can be routed
/// back to the exact message and peer. [`Origin::none`] is what the devnet
/// transport supplies and what locally-produced messages carry; reporting on
/// it is a no-op.
#[derive(Clone, Debug, Default)]
pub struct Origin {
    inner: Option<(MessageId, PeerId)>,
}

impl Origin {
    /// No provenance: devnet transport, or a message this node produced.
    pub fn none() -> Self {
        Origin { inner: None }
    }
}

/// The three verbs gossipsub understands, and the only mapping
/// [`GossipDecision`](bloch_pos_committee::gossip::GossipDecision) is allowed.
///
/// The split exists so a caller *cannot* wire an `Ignore` into a peer penalty:
/// `Ignore` drops the message and says nothing about the peer, `Reject` drops
/// it and counts against the peer's P4 score. Confusing the two is how a mesh
/// graylists its honest peers.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Verdict {
    /// Valid: relay it and count the peer's delivery.
    Accept,
    /// Drop without relaying. No penalty — every honest race lands here.
    Ignore,
    /// Provable violation. Drop, and penalize the forwarding peer.
    Reject,
}

impl From<Verdict> for MessageAcceptance {
    fn from(v: Verdict) -> Self {
        match v {
            Verdict::Accept => MessageAcceptance::Accept,
            Verdict::Ignore => MessageAcceptance::Ignore,
            Verdict::Reject => MessageAcceptance::Reject,
        }
    }
}

// ── Directed sync wire format ───────────────────────────────────────────────
//
// Hand-rolled, fixed-order, little-endian — the same discipline `codec.rs`
// states and for the same reason: no serde, no reflection, and a decoder that
// refuses `encode(x) ‖ junk`. Block bytes inside the response are exactly
// `codec::encode_envelope` output, so a synced block and a gossiped block are
// the same object, not two encodings that can disagree.

/// A directed sync request. One variant today; the tag byte is there so a
/// second one does not need a new protocol id.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum SyncRequest {
    /// Every block with `slot > after_slot`, capped at `limit`.
    GetBlocks { after_slot: u64, limit: u32 },
}

/// The answer to a [`SyncRequest`]: encoded block envelopes, in chain order.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum SyncResponse {
    Blocks { envelopes: Vec<Vec<u8>> },
}

const SYNC_TAG_GET_BLOCKS: u8 = 0x01;
const SYNC_TAG_BLOCKS: u8 = 0x01;

pub fn encode_sync_request(req: &SyncRequest) -> Vec<u8> {
    match req {
        SyncRequest::GetBlocks { after_slot, limit } => {
            let mut out = Vec::with_capacity(13);
            out.push(SYNC_TAG_GET_BLOCKS);
            out.extend_from_slice(&after_slot.to_le_bytes());
            out.extend_from_slice(&limit.to_le_bytes());
            out
        }
    }
}

pub fn decode_sync_request(buf: &[u8]) -> Result<SyncRequest, crate::codec::DecodeErr> {
    let mut r = crate::codec::Reader::new(buf);
    match r.u8()? {
        SYNC_TAG_GET_BLOCKS => {
            let after_slot = r.u64()?;
            let limit = r.u32()?;
            r.finish()?;
            Ok(SyncRequest::GetBlocks { after_slot, limit })
        }
        _ => Err(crate::codec::DecodeErr("unknown sync request tag")),
    }
}

pub fn encode_sync_response(resp: &SyncResponse) -> Vec<u8> {
    match resp {
        SyncResponse::Blocks { envelopes } => {
            // Capacity hint only: saturating is the intended semantics.
            let cap = envelopes
                .iter()
                .map(|e| e.len().saturating_add(4))
                .fold(5usize, |acc, n| acc.saturating_add(n));
            let mut out = Vec::with_capacity(cap);
            out.push(SYNC_TAG_BLOCKS);
            out.extend_from_slice(&(envelopes.len() as u32).to_le_bytes());
            for e in envelopes {
                crate::codec::put_bytes(&mut out, e);
            }
            out
        }
    }
}

pub fn decode_sync_response(buf: &[u8]) -> Result<SyncResponse, crate::codec::DecodeErr> {
    let mut r = crate::codec::Reader::new(buf);
    match r.u8()? {
        SYNC_TAG_BLOCKS => {
            let n = r.u32()? as usize;
            if n > MAX_SYNC_BLOCKS {
                return Err(crate::codec::DecodeErr("sync response over the block cap"));
            }
            let mut envelopes = Vec::with_capacity(n);
            for _ in 0..n {
                envelopes.push(r.bytes()?);
            }
            r.finish()?;
            Ok(SyncResponse::Blocks { envelopes })
        }
        _ => Err(crate::codec::DecodeErr("unknown sync response tag")),
    }
}

/// Delimited-by-EOF codec: request-response opens a fresh substream per
/// message and closes the write half, so `read_to_end` frames it exactly.
#[derive(Clone, Default)]
pub struct SyncCodec;

#[async_trait]
impl RrCodec for SyncCodec {
    type Protocol = StreamProtocol;
    type Request = SyncRequest;
    type Response = SyncResponse;

    async fn read_request<T>(&mut self, _: &StreamProtocol, io: &mut T) -> io::Result<SyncRequest>
    where
        T: AsyncRead + Unpin + Send,
    {
        let buf = read_capped(io).await?;
        decode_sync_request(&buf).map_err(bad_data)
    }

    async fn read_response<T>(&mut self, _: &StreamProtocol, io: &mut T) -> io::Result<SyncResponse>
    where
        T: AsyncRead + Unpin + Send,
    {
        let buf = read_capped(io).await?;
        decode_sync_response(&buf).map_err(bad_data)
    }

    async fn write_request<T>(
        &mut self,
        _: &StreamProtocol,
        io: &mut T,
        req: SyncRequest,
    ) -> io::Result<()>
    where
        T: AsyncWrite + Unpin + Send,
    {
        io.write_all(&encode_sync_request(&req)).await
    }

    async fn write_response<T>(
        &mut self,
        _: &StreamProtocol,
        io: &mut T,
        resp: SyncResponse,
    ) -> io::Result<()>
    where
        T: AsyncWrite + Unpin + Send,
    {
        io.write_all(&encode_sync_response(&resp)).await
    }
}

async fn read_capped<T: AsyncRead + Unpin + Send>(io: &mut T) -> io::Result<Vec<u8>> {
    let mut buf = Vec::new();
    // `take(cap)` manufactures EOF at the cap. A valid cap-sized prefix
    // followed by junk would therefore decode successfully. Read one sentinel
    // byte so only actual EOF can terminate an accepted frame.
    io.take(MAX_SYNC_FRAME + 1).read_to_end(&mut buf).await?;
    if buf.len() as u64 > MAX_SYNC_FRAME {
        return Err(io::Error::new(io::ErrorKind::InvalidData, "sync frame over byte cap"));
    }
    Ok(buf)
}

fn bad_data(e: crate::codec::DecodeErr) -> io::Error {
    io::Error::new(io::ErrorKind::InvalidData, e.to_string())
}

// ── Behaviour ───────────────────────────────────────────────────────────────

#[derive(libp2p::swarm::NetworkBehaviour)]
struct G4Behaviour {
    gossipsub: gossipsub::Behaviour,
    identify: identify::Behaviour,
    sync: request_response::Behaviour<SyncCodec>,
    connection_limits: libp2p::connection_limits::Behaviour,
}

/// Yamux config for the swarm. See [`MAX_YAMUX_STREAMS`].
fn yamux_config() -> yamux::Config {
    let mut cfg = yamux::Config::default();
    cfg.set_max_num_streams(MAX_YAMUX_STREAMS);
    cfg
}

/// Per-topic score parameters, **every field written out**.
///
/// The `..Default::default()` this deliberately does not have is mesh defect
/// (b) of 2026-08-07: the default carries P3
/// (`mesh_message_deliveries_weight = -1.0`, threshold 20, activation 5 s) and
/// P3b, which a 30 s slot chain can never satisfy — every grafted peer crossed
/// `graylist_threshold` within seconds and the mesh could not hold anyone.
///
/// P3/P3b are set to `0.0` (the library's documented "disabled" value) and, as
/// importantly, are *visible here*: a reader can see they were decided, not
/// inherited. Because the literal is exhaustive, a new upstream field is a
/// compile error rather than a silently re-armed penalty.
pub fn topic_params(weight: f64, invalid_weight: f64) -> TopicScoreParams {
    TopicScoreParams {
        topic_weight: weight,

        // P1 — time in mesh. Small positive: sticking around is mildly good.
        time_in_mesh_weight: 0.1,
        time_in_mesh_quantum: Duration::from_secs(1),
        time_in_mesh_cap: 100.0,

        // P2 — first deliveries. The reward that actually distinguishes a
        // useful peer on a low-rate chain.
        first_message_deliveries_weight: 1.0,
        first_message_deliveries_decay: 0.97,
        first_message_deliveries_cap: 100.0,

        // P3 — mesh message deliveries: OFF. See the doc comment.
        mesh_message_deliveries_weight: 0.0,
        mesh_message_deliveries_decay: 0.0,
        mesh_message_deliveries_cap: 0.0,
        mesh_message_deliveries_threshold: 0.0,
        mesh_message_deliveries_window: Duration::from_secs(0),
        mesh_message_deliveries_activation: Duration::from_secs(0),

        // P3b — sticky mesh failure penalty: OFF, for the same reason. It
        // only fires on peers already carrying a P3 penalty, which cannot
        // exist now; leaving it armed would be leaving a trap for whoever
        // re-enables P3.
        mesh_failure_penalty_weight: 0.0,
        mesh_failure_penalty_decay: 0.0,

        // P4 — invalid messages. This is the penalty that should exist: it
        // fires only on a `Reject`, which `gossip.rs` reserves for provable
        // violations.
        invalid_message_deliveries_weight: invalid_weight,
        invalid_message_deliveries_decay: 0.5,
    }
}

/// Peer score parameters for the three Genesis-4 topics.
///
/// `behind_proxy` zeroes the IP-colocation weight. Behind a proxy/NAT every
/// inbound peer shares one source IP, and the colocation penalty (−50 ×
/// excess² over the threshold) crosses `graylist_threshold` at six peers — the
/// node then ignores its entire mesh. Off by default: the penalty is the right
/// answer to real sybil colocation, and an operator who knows they are proxied
/// says so.
pub fn peer_score_params(behind_proxy: bool) -> PeerScoreParams {
    let mut params = PeerScoreParams {
        app_specific_weight: 1.0,
        ip_colocation_factor_threshold: 3.0,
        ip_colocation_factor_weight: if behind_proxy { 0.0 } else { -50.0 },
        decay_interval: Duration::from_secs(60),
        decay_to_zero: 0.01,
        ..PeerScoreParams::default()
    };
    // Blocks carry the chain; a peer that lies about one is the worst kind.
    params.topics.insert(IdentTopic::new(TOPIC_BLOCKS).hash(), topic_params(0.5, -100.0));
    // Attestations are the highest-rate topic and the one `gossip.rs` judges.
    params
        .topics
        .insert(IdentTopic::new(TOPIC_ATTESTATIONS).hash(), topic_params(0.4, -100.0));
    params.topics.insert(IdentTopic::new(TOPIC_TXS).hash(), topic_params(0.3, -50.0));
    params
}

/// Score thresholds, as Genesis-3 runs them.
pub fn peer_score_thresholds() -> PeerScoreThresholds {
    PeerScoreThresholds {
        gossip_threshold: -100.0,
        publish_threshold: -200.0,
        graylist_threshold: -400.0,
        opportunistic_graft_threshold: 5.0,
        ..PeerScoreThresholds::default()
    }
}

/// The gossipsub config.
///
/// `validate_messages()` is the switch that makes `gossip.rs` load-bearing:
/// with it on, gossipsub relays nothing until the node reports a verdict, so
/// this node never forwards an attestation it has not judged.
pub fn gossipsub_config() -> Result<gossipsub::Config, String> {
    // Message id = SHA3-256 of the payload, truncated. Deterministic across
    // toolchains (the default hasher is not — two nodes on different Rust
    // versions computed different ids and broke dedup), and sha3 is already
    // this tree's only hash.
    let msg_id_fn = |m: &gossipsub::Message| {
        use sha3::{Digest, Sha3_256};
        let d = Sha3_256::digest(&m.data);
        MessageId::from(&d[..16])
    };
    gossipsub::ConfigBuilder::default()
        .protocol_id_prefix(GOSSIP_PROTOCOL_PREFIX)
        .heartbeat_interval(Duration::from_secs(1))
        .validation_mode(ValidationMode::Strict)
        .validate_messages()
        .message_id_fn(msg_id_fn)
        .max_transmit_size(MAX_GOSSIP_BYTES)
        .duplicate_cache_time(DUPLICATE_CACHE_TIME)
        .build()
        .map_err(|e| format!("gossipsub config: {e}"))
}

// ── Handle ──────────────────────────────────────────────────────────────────

enum Command {
    /// A typed frame from the engine (`net::FRAME_*` byte, then payload),
    /// routed to a topic or to the directed-sync path by that byte.
    Broadcast(Vec<u8>),
    /// The engine's verdict on a gossip message it was handed.
    Report(Origin, Verdict),
}

/// The engine's view of the libp2p stack: publish frames, report verdicts.
pub struct Handle {
    cmd: tokio::sync::mpsc::UnboundedSender<Command>,
    /// This node's libp2p identity. Public information; printed at boot so an
    /// operator can build the `/p2p/<id>` multiaddr peers dial.
    pub peer_id: PeerId,
    /// Peers connected right now, written by the swarm loop. Shared rather
    /// than asked for, because the RPC thread must not block on the swarm's
    /// command channel to answer a status question.
    peers_live: Arc<AtomicUsize>,
}

impl Handle {
    /// Publish one engine frame. Routing is by the leading `net::FRAME_*`
    /// byte, so the engine's call sites are identical on both transports.
    pub fn broadcast(&self, frame: Vec<u8>) {
        let _ = self.cmd.send(Command::Broadcast(frame));
    }

    /// Peers with a live connection right now. `0` on a swarm that is bound
    /// and that nobody has reached — the state a node on the wrong transport
    /// sits in while its log says `applied` and `finalized`.
    pub fn peer_count(&self) -> usize {
        self.peers_live.load(Ordering::Acquire)
    }

    /// Report the engine's decision on a gossip message. A no-op for an
    /// [`Origin::none`].
    pub fn report(&self, origin: &Origin, verdict: Verdict) {
        if origin.inner.is_some() {
            let _ = self.cmd.send(Command::Report(origin.clone(), verdict));
        }
    }
}

/// What `start` needs to bring a node onto the network.
pub struct Config {
    /// Addresses to listen on. `/ip4/0.0.0.0/tcp/16400` is the usual one.
    pub listen: Vec<Multiaddr>,
    /// Peers to dial and keep dialling.
    pub peers: Vec<Multiaddr>,
    /// Where `p2p_identity.bin` lives and where the block log is read from
    /// when serving a sync request.
    pub data_dir: PathBuf,
    /// Connection ceiling, enforced at the transport by `connection_limits`.
    pub max_peers: usize,
    /// Zero the IP-colocation penalty (see [`peer_score_params`]).
    pub behind_proxy: bool,
}

/// Load, or create, this node's libp2p transport identity.
///
/// **This is a transport identity, not a validator key and not a spending
/// key.** It authenticates a socket; it signs no block, no attestation and no
/// value. Validator keys are produced by `keygen` for devnet and by the
/// air-gapped ceremony of BLOCH-GENESIS-KEYS.md for anything real — never
/// here, never as a side effect of starting a node.
fn load_or_create_identity(path: &std::path::Path) -> io::Result<identity::Keypair> {
    match std::fs::read(path) {
        Ok(bytes) => identity::Keypair::from_protobuf_encoding(&bytes)
            .map_err(|e| io::Error::new(io::ErrorKind::InvalidData, format!("p2p identity: {e}"))),
        Err(e) if e.kind() == io::ErrorKind::NotFound => {
            let kp = identity::Keypair::generate_ed25519();
            let bytes = kp
                .to_protobuf_encoding()
                .map_err(|e| io::Error::other(format!("p2p identity: {e}")))?;
            std::fs::write(path, &bytes)?;
            #[cfg(unix)]
            {
                use std::os::unix::fs::PermissionsExt;
                let _ = std::fs::set_permissions(path, std::fs::Permissions::from_mode(0o600));
            }
            Ok(kp)
        }
        Err(e) => Err(e),
    }
}

/// Start the libp2p stack on its own thread and return the engine's handle.
///
/// The swarm runs on a current-thread tokio runtime in a dedicated OS thread;
/// the engine stays synchronous and keeps receiving [`NetEvent`]s on the same
/// `std::sync::mpsc` channel the devnet transport feeds. Nothing about the
/// engine's shape changes with the transport.
pub fn start(
    cfg: Config,
    events: EngineSender<NetEvent>,
    head_slot: Arc<AtomicU64>,
) -> io::Result<Handle> {
    std::fs::create_dir_all(&cfg.data_dir)?;
    let keypair = load_or_create_identity(&cfg.data_dir.join("p2p_identity.bin"))?;
    let peer_id = PeerId::from(keypair.public());

    let (cmd_tx, cmd_rx) = tokio::sync::mpsc::unbounded_channel();
    let (ready_tx, ready_rx) = std::sync::mpsc::channel::<io::Result<()>>();
    let peers_live = Arc::new(AtomicUsize::new(0));
    let peers_live_swarm = peers_live.clone();

    std::thread::Builder::new().name("bloch-p2p".into()).spawn(move || {
        let rt = match tokio::runtime::Builder::new_current_thread().enable_all().build() {
            Ok(rt) => rt,
            Err(e) => {
                let _ = ready_tx.send(Err(e));
                return;
            }
        };
        rt.block_on(async move {
            match build_swarm(&keypair, &cfg) {
                Ok(swarm) => {
                    let _ = ready_tx.send(Ok(()));
                    run_swarm(swarm, cfg, cmd_rx, events, head_slot, peers_live_swarm).await;
                }
                Err(e) => {
                    let _ = ready_tx.send(Err(e));
                }
            }
        });
    })?;

    match ready_rx.recv() {
        Ok(Ok(())) => Ok(Handle { cmd: cmd_tx, peer_id, peers_live }),
        Ok(Err(e)) => Err(e),
        Err(_) => Err(io::Error::other("p2p thread died before it started")),
    }
}

type Swarm = libp2p::Swarm<G4Behaviour>;

fn build_swarm(keypair: &identity::Keypair, cfg: &Config) -> io::Result<Swarm> {
    let gs_cfg = gossipsub_config().map_err(io::Error::other)?;
    let mut gs = gossipsub::Behaviour::new(MessageAuthenticity::Signed(keypair.clone()), gs_cfg)
        .map_err(|e| io::Error::other(format!("gossipsub: {e}")))?;
    if let Err(e) = gs.with_peer_score(peer_score_params(cfg.behind_proxy), peer_score_thresholds()) {
        // Non-fatal, but say it: with scoring off, every `Reject` this node
        // reports is log-only and a hostile peer pays nothing.
        eprintln!("p2p: peer scoring DISABLED ({e}) — rejections carry no penalty");
    }

    let max_peers = cfg.max_peers as u32;
    let mut swarm = SwarmBuilder::with_existing_identity(keypair.clone())
        .with_tokio()
        .with_tcp(libp2p::tcp::Config::default(), noise::Config::new, yamux_config)
        .map_err(|e| io::Error::other(e.to_string()))?
        .with_dns()
        .map_err(|e| io::Error::other(e.to_string()))?
        .with_behaviour(|key| {
            let identify = identify::Behaviour::new(identify::Config::new(
                IDENTIFY_PROTOCOL.into(),
                key.public(),
            ));
            // Hold established-incoming at max_peers so inbound dials cannot
            // fill every slot (eclipse hardening — bounded, not adversarially
            // tested); allow 2× total for churn headroom.
            let limits = libp2p::connection_limits::ConnectionLimits::default()
                .with_max_established(Some(max_peers.saturating_mul(2)))
                .with_max_established_incoming(Some(max_peers))
                .with_max_pending_incoming(Some(max_peers))
                .with_max_pending_outgoing(Some(max_peers.max(1)));
            G4Behaviour {
                gossipsub: gs,
                identify,
                sync: request_response::Behaviour::with_codec(
                    SyncCodec,
                    std::iter::once((SYNC_PROTOCOL, ProtocolSupport::Full)),
                    RrConfig::default()
                        .with_request_timeout(Duration::from_secs(30))
                        .with_max_concurrent_streams(MAX_CONCURRENT_SYNC_STREAMS),
                ),
                connection_limits: libp2p::connection_limits::Behaviour::new(limits),
            }
        })
        .map_err(|e| io::Error::other(e.to_string()))?
        .with_swarm_config(|c| c.with_idle_connection_timeout(Duration::from_secs(300)))
        .build();

    for t in [TOPIC_BLOCKS, TOPIC_ATTESTATIONS, TOPIC_TXS] {
        swarm
            .behaviour_mut()
            .gossipsub
            .subscribe(&IdentTopic::new(t))
            .map_err(|e| io::Error::other(format!("subscribe {t}: {e}")))?;
    }
    for addr in &cfg.listen {
        swarm.listen_on(addr.clone()).map_err(|e| io::Error::other(e.to_string()))?;
    }
    Ok(swarm)
}

/// State the swarm loop owns.
struct Loop {
    events: EngineSender<NetEvent>,
    data_dir: PathBuf,
    head_slot: Arc<AtomicU64>,
    /// Highest block slot each peer has been seen forwarding. A relayer holds
    /// what it relays, so this is a sound (if conservative) hint for choosing
    /// who to ask for missing blocks.
    peer_head: HashMap<PeerId, u64>,
    /// Blocks published or received within [`REGOSSIP_SUPPRESS_TTL`]. Pruned
    /// on insert, so it stays bounded by the TTL and not by uptime.
    recent_blocks: HashMap<[u8; 32], Instant>,
    /// Full sync pages chased since the engine's applied head last moved,
    /// PER PEER (R1 A3-M3 — see [`MAX_PAGES_WITHOUT_PROGRESS`]). Evicted on
    /// disconnect by [`Loop::forget_peer`], so identity churn cannot grow
    /// this past the connected-peer count.
    chase: HashMap<PeerId, PeerChase>,
    /// Address → the peer id reachable there, learned from a successful dial
    /// and from identify's advertised listen addresses. Lets an address-only
    /// `--p2p-peer` be recognised as already connected on the redial tick.
    ///
    /// The identify half matters more than it looks: when a pair of nodes both
    /// list each other, one side's connection is *inbound*, so it never dials
    /// and never learns the mapping from a dial. Without identify it redials
    /// that peer forever — and libp2p's TCP port reuse makes each of those
    /// dials fail with EADDRINUSE against the connection that already exists,
    /// which reads in the log exactly like a peer that cannot be reached.
    ///
    /// Bounded (R1 A3-M5): see [`MAX_DIALED_ADDRS`]. `dialed_order` is the
    /// FIFO eviction queue — same shape as `Engine::orphans` in `engine.rs`,
    /// deliberately: oldest-inserted-address-out, not an access-order LRU,
    /// because the property that matters is "this map cannot outgrow a bound
    /// regardless of what a peer advertises", not recency.
    dialed: HashMap<Multiaddr, PeerId>,
    dialed_order: VecDeque<Multiaddr>,
    /// Per-peer admission for the `get-blocks` requests this node ANSWERS.
    /// See [`SyncLimiter`].
    sync_limiter: SyncLimiter,
    topics: Topics,
    /// Distinct peers with at least one connection up right now, shared with
    /// [`Handle::peer_count`] so the RPC can read it without touching the
    /// swarm. Maintained on `ConnectionEstablished`/`ConnectionClosed` at the
    /// `num_established` boundaries, so a peer holding the usual two
    /// connections (both sides dialled) counts once.
    peers_live: Arc<AtomicUsize>,
}

/// Per-peer sync-chase budget (R1 A3-M3). See [`MAX_PAGES_WITHOUT_PROGRESS`].
#[derive(Default)]
struct PeerChase {
    pages_since_progress: u32,
    head_at_last_page: u64,
}

struct Topics {
    blocks: IdentTopic,
    attestations: IdentTopic,
    txs: IdentTopic,
}

impl Loop {
    fn note_block(&mut self, id: [u8; 32]) -> bool {
        let now = Instant::now();
        self.recent_blocks.retain(|_, t| now.duration_since(*t) < REGOSSIP_SUPPRESS_TTL);
        self.recent_blocks.insert(id, now).is_none()
    }

    fn emit(&self, ev: NetEvent) -> bool {
        self.events.send(ev).is_ok()
    }

    /// May this node chase another full page FROM `peer`? Advancing the
    /// applied head is what buys the next 64 — see
    /// [`MAX_PAGES_WITHOUT_PROGRESS`].
    ///
    /// PER PEER (R1 A3-M3): the counters used to be one shared pair, so a
    /// single peer answering full pages that never advance the applied head
    /// (every one of them on a branch this node's transition refuses) spent
    /// the entire budget, and the very next honest peer's genuine page found
    /// nothing left to chase with. Keying by `peer` means one stalling peer
    /// can only ever exhaust its OWN budget.
    fn may_chase_page(&mut self, peer: PeerId) -> bool {
        let head = self.head_slot.load(Ordering::Relaxed);
        let e = self.chase.entry(peer).or_default();
        if head > e.head_at_last_page {
            e.head_at_last_page = head;
            e.pages_since_progress = 0;
        }
        if e.pages_since_progress >= MAX_PAGES_WITHOUT_PROGRESS {
            return false;
        }
        // Guarded by `>= MAX_PAGES_WITHOUT_PROGRESS` returning `false` above:
        // a small counter, always below that cap here.
        e.pages_since_progress = e.pages_since_progress.saturating_add(1);
        true
    }

    /// Remember `addr` as reachable at `peer`, bounded to
    /// [`MAX_DIALED_ADDRS`] total distinct addresses (R1 A3-M5). A repeat
    /// address is not re-queued — its position in `dialed_order` is already
    /// spent, and re-queuing it would let a peer that keeps re-advertising
    /// the SAME address buy itself a permanent place at the front of the FIFO
    /// forever, which defeats the bound.
    fn note_dialed(&mut self, addr: Multiaddr, peer: PeerId) {
        if self.dialed.insert(addr.clone(), peer).is_none() {
            self.dialed_order.push_back(addr);
            while self.dialed_order.len() > MAX_DIALED_ADDRS {
                if let Some(oldest) = self.dialed_order.pop_front() {
                    self.dialed.remove(&oldest);
                }
            }
        }
    }

    /// A peer's last connection just closed: drop everything keyed by its
    /// identity so churn cannot grow any of these past the connected-peer
    /// count (R1 A3-M3, R1 A3-M5, R3 M-7's counterpart for the pull side).
    ///
    /// One method rather than four inline calls at the `ConnectionClosed`
    /// site so this is directly unit-testable without synthesising a
    /// `SwarmEvent`, and so a future new per-peer map has exactly one place
    /// to be wired into disconnect cleanup.
    fn forget_peer(&mut self, peer: &PeerId) {
        self.peer_head.remove(peer);
        self.chase.remove(peer);
        self.sync_limiter.forget(peer);
        self.dialed.retain(|_, p| p != peer);
        let dialed = &self.dialed;
        self.dialed_order.retain(|a| dialed.contains_key(a));
    }
}

async fn run_swarm(
    mut swarm: Swarm,
    cfg: Config,
    mut cmd_rx: tokio::sync::mpsc::UnboundedReceiver<Command>,
    events: EngineSender<NetEvent>,
    head_slot: Arc<AtomicU64>,
    peers_live: Arc<AtomicUsize>,
) {
    let mut st = Loop {
        events,
        data_dir: cfg.data_dir.clone(),
        head_slot,
        peer_head: HashMap::new(),
        recent_blocks: HashMap::new(),
        chase: HashMap::new(),
        dialed: HashMap::new(),
        dialed_order: VecDeque::new(),
        sync_limiter: SyncLimiter::default(),
        topics: Topics {
            blocks: IdentTopic::new(TOPIC_BLOCKS),
            attestations: IdentTopic::new(TOPIC_ATTESTATIONS),
            txs: IdentTopic::new(TOPIC_TXS),
        },
        peers_live,
    };

    // A node's own listen address commonly appears in a peer list that was
    // written once and handed to every node in a fleet. Dialling yourself is
    // never useful and produces a permanent stream of dial errors, so drop it
    // here rather than making every operator maintain N different lists.
    let peers: Vec<Multiaddr> =
        cfg.peers.iter().filter(|a| !cfg.listen.contains(a)).cloned().collect();
    for addr in &peers {
        if let Err(e) = swarm.dial(addr.clone()) {
            eprintln!("p2p: dial {addr}: {e}");
        }
    }

    // Sync responses are read off disk on a blocking pool, then handed back
    // here to be written to the substream — the swarm loop must never sit in
    // a file read while blocks and attestations wait behind it.
    let (resp_tx, mut resp_rx) = tokio::sync::mpsc::unbounded_channel::<(
        Option<SyncPermit>,
        request_response::ResponseChannel<SyncResponse>,
        SyncResponse,
    )>();

    let mut redial = tokio::time::interval(REDIAL_INTERVAL);
    redial.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Delay);

    loop {
        tokio::select! {
            ev = swarm.select_next_some() => {
                if !handle_swarm_event(&mut swarm, &mut st, &resp_tx, ev) {
                    return; // engine gone
                }
            }
            cmd = cmd_rx.recv() => {
                match cmd {
                    Some(c) => handle_command(&mut swarm, &mut st, c),
                    None => return, // engine dropped the handle
                }
            }
            Some((permit, channel, resp)) = resp_rx.recv() => {
                // The answer is built: release the in-flight slot whether or
                // not the write succeeds, or a peer that hangs up mid-answer
                // would leak its own budget away. `None` is a REFUSED request
                // riding the same channel — it never took a slot, so it must
                // not give one back.
                if let Some(permit) = permit {
                    st.sync_limiter.release(permit);
                }
                let _ = swarm.behaviour_mut().sync.send_response(channel, resp);
            }
            _ = redial.tick() => {
                let connected: Vec<PeerId> = swarm.connected_peers().copied().collect();
                for addr in &peers {
                    // A configured peer may be written with or without its
                    // `/p2p/<id>` suffix — an operator pasting a listen address
                    // has no reason to know the id yet. When it is absent the
                    // id learned from the last successful dial of that exact
                    // address stands in, so an already-connected peer is not
                    // dialled again every tick (which would pile up a second
                    // connection per interval for the whole session).
                    let id = peer_id_of(addr).or_else(|| st.dialed.get(addr).copied());
                    if !id.is_some_and(|p| connected.contains(&p)) {
                        let _ = swarm.dial(addr.clone());
                    }
                }
            }
        }
    }
}

fn peer_id_of(addr: &Multiaddr) -> Option<PeerId> {
    addr.iter().find_map(|p| match p {
        libp2p::multiaddr::Protocol::P2p(id) => Some(id),
        _ => None,
    })
}

fn handle_command(swarm: &mut Swarm, st: &mut Loop, cmd: Command) {
    match cmd {
        Command::Report(origin, verdict) => {
            if let Some((msg_id, source)) = origin.inner {
                swarm
                    .behaviour_mut()
                    .gossipsub
                    .report_message_validation_result(&msg_id, &source, verdict.into());
            }
        }
        Command::Broadcast(frame) => {
            let Some((&tag, payload)) = frame.split_first() else { return };
            match tag {
                crate::net::FRAME_BLOCK => {
                    // Re-gossip suppression. A block this node produced has a
                    // content hash nobody has seen, so its own announcement is
                    // never suppressed; a block that arrived on the mesh in the
                    // last TTL would be refused by gossipsub's duplicate cache
                    // anyway, after paying the hash of the whole body.
                    if let Ok(env) = crate::codec::decode_envelope(payload) {
                        let id = *env.block_id().as_bytes();
                        if !st.note_block(id) {
                            return;
                        }
                    }
                    publish(swarm, st.topics.blocks.clone(), payload.to_vec(), "blocks");
                }
                crate::net::FRAME_ATT => {
                    publish(swarm, st.topics.attestations.clone(), payload.to_vec(), "attestations");
                }
                crate::net::FRAME_TX => {
                    publish(swarm, st.topics.txs.clone(), payload.to_vec(), "txs");
                }
                crate::net::FRAME_GET_BLOCKS => {
                    if payload.len() != 8 {
                        return;
                    }
                    // `payload.len() != 8` already returned above, so this
                    // conversion cannot fail; the `else` arm keeps it
                    // panic-free by construction rather than by an `unwrap`.
                    let Ok(after_bytes) = payload.try_into() else {
                        return;
                    };
                    let after = u64::from_le_bytes(after_bytes);
                    request_blocks(swarm, st, after);
                }
                _ => {}
            }
        }
    }
}

/// Per-message wire tracing, off unless `BLOCH_P2P_TRACE` is set.
///
/// Not `log`/`tracing`: this binary has no logging framework wired, and adding
/// one to get a diagnostic is a bigger decision than the diagnostic. The
/// closure keeps the formatting cost at zero when the switch is off.
fn trace(f: impl FnOnce() -> String) {
    use std::sync::OnceLock;
    static ON: OnceLock<bool> = OnceLock::new();
    if *ON.get_or_init(|| std::env::var_os("BLOCH_P2P_TRACE").is_some()) {
        eprintln!("p2p: {}", f());
    }
}

fn publish(swarm: &mut Swarm, topic: IdentTopic, data: Vec<u8>, name: &str) {
    let n = data.len();
    match swarm.behaviour_mut().gossipsub.publish(topic, data) {
        Ok(_) => trace(|| format!("→ published {n} bytes on {name}")),
        // Duplicate is expected and cheap to reach (we re-publish an
        // attestation released from the pending pool, for instance); it is not
        // an error worth a line per slot.
        Err(gossipsub::PublishError::Duplicate) => {}
        Err(e) => eprintln!("p2p: publish {name}: {e}"),
    }
}

/// Direct a `get-blocks` at the peers most likely to hold what we are missing.
///
/// Not a broadcast: the Genesis-3 root cause was exactly that, and it produced
/// O(peers × blocks) amplification that stalled the chain. Not a single peer
/// either — a silent one would stall recovery — so [`SYNC_FANOUT`] peers,
/// preferring the highest observed head.
fn request_blocks(swarm: &mut Swarm, st: &Loop, after_slot: u64) {
    let mut peers: Vec<PeerId> = swarm.connected_peers().copied().collect();
    if peers.is_empty() {
        return;
    }
    peers.sort_by_key(|p| {
        // Descending by observed head, then by PeerId so ties are stable and
        // the choice is not a function of HashMap iteration order.
        (std::cmp::Reverse(st.peer_head.get(p).copied().unwrap_or(0)), p.to_bytes())
    });
    let req = SyncRequest::GetBlocks { after_slot, limit: MAX_SYNC_BLOCKS as u32 };
    for p in peers.into_iter().take(SYNC_FANOUT) {
        swarm.behaviour_mut().sync.send_request(&p, req.clone());
    }
}

/// Returns false when the engine's receiver is gone (the node is shutting
/// down) — the loop then exits.
fn handle_swarm_event(
    swarm: &mut Swarm,
    st: &mut Loop,
    resp_tx: &tokio::sync::mpsc::UnboundedSender<(
        Option<SyncPermit>,
        request_response::ResponseChannel<SyncResponse>,
        SyncResponse,
    )>,
    ev: SwarmEvent<G4BehaviourEvent>,
) -> bool {
    match ev {
        SwarmEvent::NewListenAddr { address, .. } => {
            println!("p2p: listening on {address}");
        }
        SwarmEvent::ConnectionEstablished { peer_id, ref endpoint, num_established, .. } => {
            println!("p2p: connected {peer_id}");
            if let libp2p::core::ConnectedPoint::Dialer { address, .. } = endpoint {
                st.note_dialed(address.clone(), peer_id);
            }
            // DO NOT call `gossipsub.add_explicit_peer()` here — see this
            // module's header. An explicit peer is excluded from mesh
            // construction and is PRUNED when it GRAFTs; marking every
            // connection explicit is what made the Genesis-3 mesh unbuildable
            // on 2026-08-07. gossipsub learns about the peer on its own.
            //
            // Ask what we are missing, immediately. This is the restart path:
            // a node that comes back with a short log gets the rest from the
            // first peer it reaches, without waiting for the engine's sync
            // timer.
            // ONE WALK PER PEER, NOT PER CONNECTION.
            //
            // libp2p keeps more than one connection to the same peer — when both
            // sides dial, each ends up with an inbound and an outbound — and this
            // event fires once per CONNECTION. Sending the request on every one
            // started the whole sync walk twice against the same peer, so every
            // block arrived twice and each duplicate spent a page of the
            // MAX_PAGES_WITHOUT_PROGRESS budget. Measured on a two-node harness: a
            // restarted node asking for slots 61..200 received 61..188 plus a
            // second copy of 61..72, and never reached the tip.
            //
            // `num_established` counts connections to THIS peer including the one
            // just opened, so `== 1` is the first. ConnectionClosed below already
            // reads the same counter the other way round.
            if num_established.get() == 1 {
                // First connection to this peer: one new peer, counted once.
                // Counting connections instead would double every pair that
                // dialled each other, and `--transport dual`'s whole claim is
                // a number an operator can compare against a peer list.
                st.peers_live.fetch_add(1, Ordering::AcqRel);
                let after = st.head_slot.load(Ordering::Relaxed);
                swarm.behaviour_mut().sync.send_request(
                    &peer_id,
                    SyncRequest::GetBlocks { after_slot: after, limit: MAX_SYNC_BLOCKS as u32 },
                );
            }
        }
        SwarmEvent::ConnectionClosed { peer_id, num_established, cause, .. } => {
            if num_established == 0 {
                // Last connection to this peer gone: symmetric with the
                // `== 1` increment above. `saturating` in effect, via
                // fetch_update, because a counter that wraps to usize::MAX
                // would read as a fully connected node forever.
                let _ = st.peers_live.fetch_update(
                    Ordering::AcqRel,
                    Ordering::Acquire,
                    |n| Some(n.saturating_sub(1)),
                );
                st.forget_peer(&peer_id);
                // The cause is the whole diagnostic value of this line. A bare
                // "disconnected" is what made the Genesis-3 yamux stream-cap
                // failure take days to find: the transport was terminating
                // connections and the log said only that peers came and went.
                match cause {
                    Some(e) => println!("p2p: disconnected {peer_id}: {e}"),
                    None => println!("p2p: disconnected {peer_id} (closed cleanly)"),
                }
            }
        }
        SwarmEvent::OutgoingConnectionError { peer_id, error, .. } => {
            // Loud only while this node has NOBODY, which is the state an
            // operator has to act on. With a peer already established, a failed
            // dial is usually libp2p's TCP port reuse colliding with the
            // connection that exists (EADDRINUSE on the local bind) or a
            // simultaneous dial from both ends — noise that reads exactly like
            // a real outage and would teach an operator to ignore the line.
            if swarm.connected_peers().next().is_none() {
                eprintln!("p2p: NO PEERS — dial failed ({peer_id:?}): {error}");
            } else {
                trace(|| format!("dial failed ({peer_id:?}): {error}"));
            }
        }
        SwarmEvent::IncomingConnectionError { error, send_back_addr, .. } => {
            eprintln!("p2p: inbound connection from {send_back_addr} failed: {error}");
        }
        SwarmEvent::Behaviour(G4BehaviourEvent::Identify(identify::Event::Received {
            peer_id,
            info,
            ..
        })) => {
            for addr in info.listen_addrs {
                st.note_dialed(addr, peer_id);
            }
        }
        SwarmEvent::Behaviour(G4BehaviourEvent::Gossipsub(gossipsub::Event::Message {
            propagation_source,
            message_id,
            message,
        })) => {
            return on_gossip(swarm, st, propagation_source, message_id, message);
        }
        SwarmEvent::Behaviour(G4BehaviourEvent::Sync(request_response::Event::Message {
            peer,
            message,
            ..
        })) => match message {
            request_response::Message::Request { request, channel, .. } => {
                serve_sync(st, resp_tx.clone(), peer, request, channel);
            }
            request_response::Message::Response { response, .. } => {
                let SyncResponse::Blocks { envelopes } = response;
                let was_full = envelopes.len() >= MAX_SYNC_BLOCKS;
                let mut highest = 0u64;
                for bytes in envelopes {
                    match crate::codec::decode_envelope(&bytes) {
                        Ok(env) => {
                            let slot = env.header.slot;
                            highest = highest.max(slot);
                            let e = st.peer_head.entry(peer).or_insert(0);
                            *e = (*e).max(slot);
                            // Directed sync, not gossip: there is no message
                            // id to report a verdict against, so `Origin::none`
                            // and the engine's report is a no-op.
                            if !st.emit(NetEvent::Block(env, Origin::none())) {
                                return false;
                            }
                        }
                        Err(e) => {
                            eprintln!("p2p: undecodable block in sync response from {peer}: {e}");
                        }
                    }
                }
                // Cold start: a full page means the peer has more. Ask for the
                // next one now, from the SAME peer, instead of waiting for the
                // engine's sync timer — that is the difference between "a
                // request from genesis is accepted" and "a node can actually
                // sync from genesis". A short page ends the walk.
                if was_full && highest > 0 && st.may_chase_page(peer) {
                    swarm.behaviour_mut().sync.send_request(
                        &peer,
                        SyncRequest::GetBlocks {
                            after_slot: highest,
                            limit: MAX_SYNC_BLOCKS as u32,
                        },
                    );
                }
            }
        },
        SwarmEvent::Behaviour(G4BehaviourEvent::Sync(request_response::Event::OutboundFailure {
            peer,
            error,
            ..
        })) => {
            // A peer that does not speak /bloch-g4/sync/1 is not a Genesis-4
            // node. Nothing to fall back to — deliberately: Genesis-3
            // compatibility is not a goal, it is the thing the prefix prevents.
            eprintln!("p2p: sync request to {peer} failed: {error}");
        }
        _ => {}
    }
    true
}

/// Map one gossip message onto an engine event, reporting the verdict the edge
/// can already decide.
///
/// Transactions are judged here (does it decode?) and relayed at once. Blocks
/// and attestations are handed to the engine with their [`Origin`] and are
/// **not** relayed until it answers — that is the whole point of
/// `validate_messages()`, and the reason `gossip.rs` can be the admission
/// control rather than a library nobody calls. Undecodable bytes on any of the
/// three topics are still a `Reject` at the edge: there is nothing to hand
/// over.
fn on_gossip(
    swarm: &mut Swarm,
    st: &mut Loop,
    source: PeerId,
    message_id: MessageId,
    message: gossipsub::Message,
) -> bool {
    let topic = message.topic.clone();
    let report = |swarm: &mut Swarm, v: Verdict| {
        swarm
            .behaviour_mut()
            .gossipsub
            .report_message_validation_result(&message_id, &source, v.into());
    };

    if topic == st.topics.blocks.hash() {
        match crate::codec::decode_envelope(&message.data) {
            Ok(env) => {
                // No verdict yet — this is the block half of the same
                // deferred-judgement contract the attestation arm below runs
                // on. Decodability used to be enough to relay, so a block that
                // could not possibly be honest (a header that does not commit
                // to its own body, a `header.slot` from the far future) was
                // still forwarded once by every node that saw it, free of
                // charge to whoever wrote it. `Engine::ingest_judged` answers
                // now, and `Handle::report` is what finally relays it.
                trace(|| {
                    format!("← block slot {} from {source}", env.header.slot)
                });
                let slot = env.header.slot;
                let e = st.peer_head.entry(source).or_insert(0);
                *e = (*e).max(slot);
                st.note_block(*env.block_id().as_bytes());
                let origin = Origin { inner: Some((message_id, source)) };
                return st.emit(NetEvent::Block(env, origin));
            }
            Err(e) => {
                // Undecodable bytes on the block topic cannot come from a
                // compliant node: that is a Reject, and P4 counts it.
                eprintln!("p2p: undecodable block from {source}: {e}");
                report(swarm, Verdict::Reject);
            }
        }
    } else if topic == st.topics.attestations.hash() {
        let mut r = crate::codec::Reader::new(&message.data);
        match crate::codec::decode_attestation(&mut r).and_then(|a| r.finish().map(|()| a)) {
            Ok(att) => {
                // No verdict yet. The engine decides through `gossip.rs` and
                // calls `Handle::report`, which is what finally relays it.
                let origin = Origin { inner: Some((message_id, source)) };
                return st.emit(NetEvent::Attestation(att, origin));
            }
            Err(e) => {
                eprintln!("p2p: undecodable attestation from {source}: {e}");
                report(swarm, Verdict::Reject);
            }
        }
    } else if topic == st.topics.txs.hash() {
        match bloch_pos_committee::transition::PosTransaction::from_canonical_bytes(&message.data) {
            Ok(tx) => {
                // Decode is not authorization. In particular, funded admission
                // needs the engine's UTXO view before gossipsub may relay it.
                let origin = Origin { inner: Some((message_id, source)) };
                return st.emit(NetEvent::Transaction(tx, origin));
            }
            Err(e) => {
                eprintln!("p2p: undecodable transaction from {source}: {e}");
                report(swarm, Verdict::Reject);
            }
        }
    } else {
        // A topic we never subscribed to cannot reach here; if it somehow
        // does, ignoring it is the answer that penalizes nobody.
        report(swarm, Verdict::Ignore);
    }
    true
}

/// Answer a `get-blocks` off the blocking pool, capped in both blocks and
/// bytes, then hand the response back to the swarm loop to write.
fn serve_sync(
    st: &mut Loop,
    resp_tx: tokio::sync::mpsc::UnboundedSender<(
        Option<SyncPermit>,
        request_response::ResponseChannel<SyncResponse>,
        SyncResponse,
    )>,
    peer: PeerId,
    request: SyncRequest,
    channel: request_response::ResponseChannel<SyncResponse>,
) {
    let SyncRequest::GetBlocks { after_slot, limit } = request;
    // Admission BEFORE the blocking task is spawned and before the log is
    // touched: the whole point is that a refused request costs this node a
    // hash lookup, not a disk read and a pool thread. The permit it mints is
    // what `read_sync_page` demands, so this check cannot be edited away
    // without the serving path ceasing to compile.
    let permit = match st.sync_limiter.begin(peer, Instant::now()) {
        Ok(permit) => permit,
        Err(why) => {
            let (permit, answer) = refusal_answer(peer, why);
            let _ = resp_tx.send((permit, channel, answer));
            return;
        }
    };
    let dir = st.data_dir.clone();
    let limit = (limit as usize).min(MAX_SYNC_BLOCKS);
    tokio::task::spawn_blocking(move || {
        let envelopes = read_sync_page(&dir, &permit, after_slot, limit);
        let _ = resp_tx.send((Some(permit), channel, SyncResponse::Blocks { envelopes }));
    });
}

/// What a REFUSED `get-blocks` is answered with: an empty page and **no
/// permit**.
///
/// The `None` is the whole point and is why this is a function rather than two
/// inline lines. Refusals ride the same response channel as real answers, and
/// the swarm loop releases an in-flight slot for whatever comes back down it —
/// so a refusal that carried a releasable token would hand the flooder a slot
/// per refusal it provoked, and the in-flight cap it had just tripped would
/// stop binding. Pinned by `refused_requests_do_not_free_in_flight_slots`.
fn refusal_answer(peer: PeerId, why: SyncRefusal) -> (Option<SyncPermit>, SyncResponse) {
    eprintln!("p2p: refusing get-blocks from {peer}: {why:?}");
    (None, SyncResponse::Blocks { envelopes: Vec::new() })
}

/// Read one answer off the block log: the whole of the serving side's contact
/// with storage, and the reason [`SyncPermit`] exists.
///
/// `after_slot = 0` is the from-genesis case and is served like any other:
/// there is no "recent only" path and no datadir donation. The work is
/// proportional to the page — `Store::blocks_after` finds the window through
/// the `blocks.idx` slot → offset index rather than walking the log to it —
/// so a request that selects nothing (`after_slot = u64::MAX`, the amplifier)
/// opens the log and reads no frames at all.
fn read_sync_page(
    dir: &Path,
    permit: &SyncPermit,
    after_slot: u64,
    limit: usize,
) -> Vec<Vec<u8>> {
    let _ = permit; // held for the whole read; see `SyncPermit`
    match crate::store::Store::blocks_after(dir, after_slot, limit) {
        Ok(all) => {
            let mut out = Vec::new();
            let mut bytes = 0usize;
            for b in all.into_iter() {
                // Byte cap as well as block cap: one answer must never become
                // a history dump. Leave slack for the framing.
                // `bytes` only ever accumulates `b.len() + 4` for blocks that
                // passed this same check, so it stays far below
                // `MAX_SYNC_FRAME` (8 MiB); saturating keeps a pathological
                // single block (larger than `usize::MAX`, impossible in
                // practice) failing this check safely instead of wrapping
                // small and passing it.
                if bytes.saturating_add(b.len()).saturating_add(4)
                    > (MAX_SYNC_FRAME as usize).saturating_sub(1024)
                {
                    break;
                }
                bytes = bytes.saturating_add(b.len()).saturating_add(4);
                out.push(b);
            }
            out
        }
        Err(e) => {
            eprintln!("p2p: serving get-blocks failed: {e}");
            Vec::new()
        }
    }
}

// ── Tests ───────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn audit_sync_cap_requires_actual_eof() {
        futures::executor::block_on(async {
            // A syntactically valid response that ends exactly at the cap.
            // The envelope is opaque at this framing layer (decoded later).
            let response = SyncResponse::Blocks {
                envelopes: vec![vec![0; MAX_SYNC_FRAME as usize - 9]],
            };
            let mut wire = encode_sync_response(&response);
            assert_eq!(wire.len() as u64, MAX_SYNC_FRAME);
            let accepted = read_capped(&mut futures::io::Cursor::new(&wire)).await.unwrap();
            assert!(decode_sync_response(&accepted).is_ok());

            // Previously both distinct streams produced the same accepted
            // bytes: `take(cap)` hid this trailing byte from strict decoding.
            wire.push(0xA5);
            let error = read_capped(&mut futures::io::Cursor::new(&wire)).await.unwrap_err();
            assert_eq!(error.kind(), io::ErrorKind::InvalidData);
        });
    }

    #[test]
    fn audit_sync_short_frames_still_use_strict_decoding() {
        futures::executor::block_on(async {
            let mut wire = encode_sync_response(&SyncResponse::Blocks { envelopes: Vec::new() });
            let accepted = read_capped(&mut futures::io::Cursor::new(&wire)).await.unwrap();
            assert!(decode_sync_response(&accepted).is_ok());
            wire.push(0);
            let accepted = read_capped(&mut futures::io::Cursor::new(&wire)).await.unwrap();
            assert!(decode_sync_response(&accepted).is_err());
        });
    }

    /// THE regression test for mesh defect (b) of 2026-08-07.
    ///
    /// It asserts twice: that the library default really does carry the
    /// poisonous P3/P3b (so the test is testing something), and that no topic
    /// this node configures inherits it. If the first assertion ever fails
    /// upstream, this test should be re-read, not deleted.
    #[test]
    fn score_params_have_no_p3() {
        let d = TopicScoreParams::default();
        assert!(
            d.mesh_message_deliveries_weight < 0.0,
            "upstream default no longer arms P3 — re-read this test before trusting it"
        );
        assert!(
            d.mesh_message_deliveries_threshold > 0.0,
            "upstream default no longer sets a P3 threshold — re-read this test"
        );

        let params = peer_score_params(false);
        assert_eq!(params.topics.len(), 3, "all three Genesis-4 topics must be scored");
        for (topic, t) in &params.topics {
            assert_eq!(
                t.mesh_message_deliveries_weight, 0.0,
                "P3 is armed on {topic:?}: a 30 s slot chain graylists its whole mesh"
            );
            assert_eq!(
                t.mesh_failure_penalty_weight, 0.0,
                "P3b is armed on {topic:?}"
            );
            assert_eq!(t.mesh_message_deliveries_threshold, 0.0, "P3 threshold left set on {topic:?}");
            assert!(
                t.mesh_message_deliveries_activation.is_zero(),
                "P3 activation left set on {topic:?}"
            );
            // The penalty that SHOULD exist, so "disable everything" cannot
            // pass this test.
            assert!(
                t.invalid_message_deliveries_weight < 0.0,
                "P4 disabled on {topic:?}: a Reject would cost the peer nothing"
            );
        }
    }

    /// **The serving-side bound for H5.** One peer must not be able to make
    /// this node answer `get-blocks` as fast as it can ask.
    ///
    /// Asserted against injected time rather than a sleep, so the refill
    /// arithmetic itself is under test and the test does not take a second to
    /// run. Both limits are asserted separately, because they bound different
    /// things and a single one would let the other regress silently: the
    /// in-flight cap bounds concurrent blocking-pool work, the bucket bounds
    /// the sustained rate.
    #[test]
    fn sync_limiter_bounds_in_flight_and_rate() {
        let mut lim = SyncLimiter::default();
        let peer = PeerId::random();
        let t0 = Instant::now();

        // Concurrency: the cap is reached with answers still open, and one
        // finishing frees exactly one slot.
        let mut open = Vec::new();
        for i in 0..MAX_INFLIGHT_SYNC_PER_PEER {
            match lim.begin(peer, t0) {
                Ok(permit) => open.push(permit),
                Err(why) => panic!("in-flight answer {i} refused: {why:?}"),
            }
        }
        assert_eq!(
            lim.begin(peer, t0).err(),
            Some(SyncRefusal::TooManyInFlight),
            "a peer opened more concurrent answers than MAX_INFLIGHT_SYNC_PER_PEER"
        );
        lim.release(open.pop().expect("a permit is open"));
        let regained = lim.begin(peer, t0).expect("finishing an answer freed no slot");
        open.push(regained);
        for permit in open.drain(..) {
            lim.release(permit);
        }

        // Rate: the burst is finite, and it is the burst.
        // Bounded, not `while let`: a limiter with its bucket disarmed would
        // otherwise spin here forever instead of failing.
        let mut answered = MAX_INFLIGHT_SYNC_PER_PEER + 1; // spent above
        while answered < 10_000 {
            match lim.begin(peer, t0) {
                Ok(permit) => {
                    lim.release(permit);
                    answered += 1;
                }
                Err(_) => break,
            }
        }
        assert_eq!(
            lim.begin(peer, t0).err(),
            Some(SyncRefusal::RateLimited),
            "the bucket refused for the wrong reason"
        );
        assert_eq!(
            answered as f64, SYNC_ANSWER_BURST,
            "a peer took {answered} answers with no time passing; the burst is \
             {SYNC_ANSWER_BURST}"
        );

        // And it refills at the stated rate, not faster.
        let later = t0 + Duration::from_secs(1);
        let mut refilled = 0usize;
        while refilled < 10_000 {
            match lim.begin(peer, later) {
                Ok(permit) => {
                    lim.release(permit);
                    refilled += 1;
                }
                Err(_) => break,
            }
        }
        assert_eq!(
            refilled as f64, SYNC_ANSWERS_PER_SEC,
            "one second bought {refilled} answers, not SYNC_ANSWERS_PER_SEC"
        );

        // The limit is PER PEER: one peer spending its budget must not be
        // able to stop this node serving anybody else, which would turn the
        // defence into the denial of service it exists to prevent.
        let honest = PeerId::random();
        let permit = lim.begin(honest, later).expect("one greedy peer starved another");
        lim.release(permit);
    }

    /// The limiter's own memory is bounded by the connected set: a peer is
    /// forgotten when its last connection closes, but not while an answer is
    /// still being built for it (that would refund its budget mid-flight).
    #[test]
    fn sync_limiter_forgets_disconnected_peers() {
        let mut lim = SyncLimiter::default();
        let peer = PeerId::random();
        let now = Instant::now();
        let permit = lim.begin(peer, now).expect("first request");
        assert_eq!(lim.tracked(), 1);
        lim.forget(&peer);
        assert_eq!(lim.tracked(), 1, "forgot a peer with an answer still in flight");
        lim.release(permit);
        lim.forget(&peer);
        assert_eq!(lim.tracked(), 0, "a disconnected peer's bucket is never released");
    }

    /// R3 M-7: production calls `forget` exactly ONCE per peer, from
    /// `ConnectionClosed` — there is no second disconnect event to retry a
    /// deferred removal the way the test above does. This is the shape that
    /// actually occurs on the wire: the peer disconnects while its answer is
    /// still being built (one `forget` call, inflight > 0), and only
    /// afterward does the blocking task finish and call `release`. Before the
    /// `disconnect_pending` fix this left the entry in `SyncLimiter::peers`
    /// forever — one leaked bucket per peer that ever disconnected mid-answer,
    /// unbounded over the life of the process under normal identity churn.
    #[test]
    fn sync_limiter_removes_peer_on_release_after_single_forget() {
        let mut lim = SyncLimiter::default();
        let peer = PeerId::random();
        let now = Instant::now();
        let permit = lim.begin(peer, now).expect("first request");
        assert_eq!(lim.tracked(), 1);
        // The ONE disconnect event, while the answer is still in flight.
        lim.forget(&peer);
        assert_eq!(lim.tracked(), 1, "an in-flight answer's slot must survive the disconnect");
        // The blocking task finishes sometime later; nothing calls `forget`
        // again for this peer.
        lim.release(permit);
        assert_eq!(
            lim.tracked(),
            0,
            "release() must finish the removal forget() deferred, or a peer that \
             disconnects mid-answer leaks its bucket forever (R3 M-7)"
        );
    }

    /// A `Loop` with no swarm attached — every field is a plain value or a
    /// channel, so the per-peer bookkeeping (`may_chase_page`, `note_dialed`,
    /// `forget_peer`) is testable without a real libp2p transport.
    fn test_loop() -> Loop {
        let (events, _rx) = std::sync::mpsc::channel();
        Loop {
            events,
            data_dir: PathBuf::from("/tmp/bloch-p2p-test"),
            head_slot: Arc::new(AtomicU64::new(0)),
            peer_head: HashMap::new(),
            recent_blocks: HashMap::new(),
            chase: HashMap::new(),
            dialed: HashMap::new(),
            dialed_order: VecDeque::new(),
            sync_limiter: SyncLimiter::default(),
            topics: Topics {
                blocks: IdentTopic::new(TOPIC_BLOCKS),
                attestations: IdentTopic::new(TOPIC_ATTESTATIONS),
                txs: IdentTopic::new(TOPIC_TXS),
            },
            peers_live: Arc::new(AtomicUsize::new(0)),
        }
    }

    /// R1 A3-M3: the sync-chase budget is PER PEER. A peer that never lets
    /// this node's head advance exhausts its own [`MAX_PAGES_WITHOUT_PROGRESS`]
    /// budget and is refused further chases — while a second, honest peer
    /// (whose pages DO advance the head) is completely unaffected. Before the
    /// fix both peers shared one pair of counters, so the stalling peer alone
    /// could zero out the budget every peer drew from.
    #[test]
    fn may_chase_page_budget_is_per_peer_not_shared() {
        let mut st = test_loop();
        let stalling = PeerId::random();
        let honest = PeerId::random();
        // The applied head never moves (stays 0), so `stalling` burns its
        // entire budget without ever resetting the counter.
        for _ in 0..MAX_PAGES_WITHOUT_PROGRESS {
            assert!(st.may_chase_page(stalling), "budget spent before the cap");
        }
        assert!(
            !st.may_chase_page(stalling),
            "stalling peer must be refused past MAX_PAGES_WITHOUT_PROGRESS"
        );
        // The honest peer's very next chase — right after the stalling peer
        // hit its cap — must still be granted. Under the old, SHARED counter
        // this would already read false.
        assert!(
            st.may_chase_page(honest),
            "one stalling peer must not be able to exhaust another peer's budget"
        );
        // `honest` being granted a chase must not, by itself, lift the
        // stalling peer's refusal — the applied head (shared, global) has
        // not moved, so nothing legitimately earned it a fresh budget. This
        // is the entry point a shared counter would have gotten wrong: one
        // peer's mere ACTIVITY resetting another's exhausted counter.
        assert!(
            !st.may_chase_page(stalling),
            "another peer being granted a chase must not lift this peer's refusal"
        );
        // Only genuine progress on the applied head — which is shared, by
        // construction: it is this node's own state, not a peer's claim —
        // legitimately grants every peer a fresh look. That is intended
        // (a real backfill must not stay punished forever) and distinct from
        // the bug above: it takes an actual advance of `head_slot`, not
        // merely another peer being served.
        st.head_slot.store(1, Ordering::Relaxed);
        assert!(
            st.may_chase_page(stalling),
            "a genuine advance of the applied head must reset every peer's budget"
        );
    }

    /// R1 A3-M3, continued: `forget_peer` evicts the per-peer chase budget on
    /// disconnect, so a churning identity does not grow `Loop::chase` without
    /// bound and a peer cannot dodge its own refusal by reconnecting under the
    /// SAME id (a fresh entry only appears for a genuinely new `PeerId`).
    #[test]
    fn forget_peer_evicts_chase_entry() {
        let mut st = test_loop();
        let peer = PeerId::random();
        st.may_chase_page(peer);
        assert!(st.chase.contains_key(&peer));
        st.forget_peer(&peer);
        assert!(!st.chase.contains_key(&peer), "disconnect must evict the chase budget");
    }

    /// R1 A3-M5: `Loop::dialed` is bounded to [`MAX_DIALED_ADDRS`] distinct
    /// addresses, FIFO-evicted — identify's `listen_addrs` are peer-supplied,
    /// so without a bound one peer advertising unlimited addresses grows this
    /// map for the life of the process.
    #[test]
    fn dialed_is_bounded_fifo() {
        let mut st = test_loop();
        let peer = PeerId::random();
        for i in 0..MAX_DIALED_ADDRS + 10 {
            let addr: Multiaddr = format!("/ip4/127.0.0.1/tcp/{}", 20_000 + i).parse().unwrap();
            st.note_dialed(addr, peer);
        }
        assert_eq!(
            st.dialed.len(),
            MAX_DIALED_ADDRS,
            "the map must never exceed MAX_DIALED_ADDRS regardless of how many addresses arrive"
        );
        assert_eq!(st.dialed.len(), st.dialed_order.len(), "the two must stay in lockstep");
        // The FIRST ten addresses were evicted to make room for the rest.
        let evicted: Multiaddr = "/ip4/127.0.0.1/tcp/20000".parse().unwrap();
        assert!(!st.dialed.contains_key(&evicted), "oldest address must be evicted, not newest");
    }

    /// R1 A3-M5, continued: a peer's addresses are dropped the moment its
    /// last connection closes — the map does not wait for the FIFO bound to
    /// clear a peer that is already gone.
    #[test]
    fn forget_peer_evicts_dialed_addresses() {
        let mut st = test_loop();
        let peer = PeerId::random();
        let other = PeerId::random();
        let addr_a: Multiaddr = "/ip4/127.0.0.1/tcp/30001".parse().unwrap();
        let addr_b: Multiaddr = "/ip4/127.0.0.1/tcp/30002".parse().unwrap();
        let addr_other: Multiaddr = "/ip4/127.0.0.1/tcp/30003".parse().unwrap();
        st.note_dialed(addr_a.clone(), peer);
        st.note_dialed(addr_b.clone(), peer);
        st.note_dialed(addr_other.clone(), other);
        assert_eq!(st.dialed.len(), 3);
        st.forget_peer(&peer);
        assert!(!st.dialed.contains_key(&addr_a), "peer's address must be dropped");
        assert!(!st.dialed.contains_key(&addr_b), "peer's address must be dropped");
        assert!(st.dialed.contains_key(&addr_other), "another peer's address must survive");
        assert_eq!(
            st.dialed.len(),
            st.dialed_order.len(),
            "the FIFO queue must stay in lockstep with the map after a per-peer eviction"
        );
    }

    /// **THE end-to-end regression test for H5**, over the serving path a
    /// hostile peer actually drives: admission, then the log.
    ///
    /// `GetBlocks { after_slot: u64::MAX }` is eight bytes on the wire and
    /// selects nothing. In a loop, against a node with a chain, it used to buy
    /// one full walk of the block log per request — on up to
    /// [`MAX_CONCURRENT_SYNC_STREAMS`] substreams, each one a `spawn_blocking`
    /// task — because the size caps on an ANSWER never bounded the NUMBER of
    /// answers, and the scan started at byte zero every time.
    ///
    /// Two independent claims, and both are counted rather than timed (a
    /// timing on a shared box cannot separate "we stopped scanning" from "the
    /// box was quieter"):
    ///
    /// 1. **The flood is bounded.** 1,000 requests at one instant get
    ///    [`SYNC_ANSWER_BURST`] answers, not 1,000. The other 968 never reach
    ///    [`read_sync_page`] — which is not a matter of discipline: the permit
    ///    it takes has no constructor but [`SyncLimiter::begin`].
    /// 2. **Even an admitted one is not an amplifier.** Across the whole
    ///    flood, the frames whose header the store parsed is ZERO: the index
    ///    answers "nothing is past the tip" without opening the log.
    ///
    /// It cannot pass vacuously: the same store, asked an honest question,
    /// still serves a full page.
    #[test]
    fn a_hostile_get_blocks_flood_is_bounded_and_reads_no_frames() {
        let dir = tmpdir("hostile-flood");
        let mut store = crate::store::Store::open(&dir, &[9u8; 32]).expect("store");
        for slot in 1..=256u64 {
            store.append(&envelope(slot)).expect("append");
        }

        let mut lim = SyncLimiter::default();
        let hostile = PeerId::random();
        let t0 = Instant::now();
        let before = crate::store::sync_frames_scanned();
        let mut answered = 0usize;
        let mut refused = 0usize;
        for _ in 0..1_000 {
            // Exactly what `serve_sync` does, minus the libp2p response
            // channel (which cannot be constructed outside the swarm).
            match lim.begin(hostile, t0) {
                Ok(permit) => {
                    let page = read_sync_page(&dir, &permit, u64::MAX, MAX_SYNC_BLOCKS);
                    assert!(page.is_empty(), "nothing is past u64::MAX");
                    lim.release(permit);
                    answered += 1;
                }
                Err(_) => refused += 1,
            }
        }
        let scanned = crate::store::sync_frames_scanned() - before;

        assert_eq!(
            answered as f64, SYNC_ANSWER_BURST,
            "a peer got {answered} answers out of 1,000 requests at one instant;              the bucket allows {SYNC_ANSWER_BURST}"
        );
        assert_eq!(refused, 1_000 - answered, "every other request must be refused, not queued");
        assert_eq!(
            scanned, 0,
            "answering {answered} tip-requests parsed {scanned} block headers; with the              slot index it must parse none"
        );

        // Not vacuous: the same code, asked for real blocks, serves them.
        let permit = lim.begin(PeerId::random(), t0).expect("an honest peer is admitted");
        let page = read_sync_page(&dir, &permit, 0, MAX_SYNC_BLOCKS);
        lim.release(permit);
        assert_eq!(page.len(), MAX_SYNC_BLOCKS, "a from-genesis page still comes back full");

        let _ = std::fs::remove_dir_all(&dir);
    }

    /// A REFUSED request must not hand back an in-flight slot it never took.
    ///
    /// This is the hole the first cut of the fix left open, and it is the
    /// reason [`SyncLimiter::release`] consumes a permit instead of taking a
    /// `PeerId`. Refusals travel down the same response channel as answers, so
    /// releasing by peer id there meant a peer that had just tripped the
    /// in-flight cap freed a slot per refusal it provoked — the flood paid for
    /// itself and the cap stopped binding. The loop below mirrors the swarm
    /// loop's drain of that channel exactly.
    #[test]
    fn refused_requests_do_not_free_in_flight_slots() {
        let mut lim = SyncLimiter::default();
        let hostile = PeerId::random();
        let t0 = Instant::now();

        // Slow answers still being built: the cap is full.
        let mut in_flight = Vec::new();
        for _ in 0..MAX_INFLIGHT_SYNC_PER_PEER {
            in_flight.push(lim.begin(hostile, t0).expect("under the cap"));
        }

        // The flood. Each refusal queues an empty answer, permit-less, on the
        // same channel the real answers come back on.
        let mut queued: Vec<Option<SyncPermit>> = Vec::new();
        for _ in 0..64 {
            match lim.begin(hostile, t0) {
                Ok(_) => panic!("admitted a request over the in-flight cap"),
                Err(why) => {
                    assert_eq!(why, SyncRefusal::TooManyInFlight);
                    let (permit, answer) = refusal_answer(hostile, why);
                    let SyncResponse::Blocks { envelopes } = answer;
                    assert!(envelopes.is_empty(), "a refusal must cost no blocks");
                    queued.push(permit);
                }
            }
        }
        // The swarm loop drains it.
        for permit in queued {
            if let Some(permit) = permit {
                lim.release(permit);
            }
        }

        assert_eq!(
            lim.begin(hostile, t0).err(),
            Some(SyncRefusal::TooManyInFlight),
            "64 refusals bought the flooder its in-flight slots back"
        );
        for permit in in_flight {
            lim.release(permit);
        }
        let permit = lim.begin(hostile, t0).expect("the slots come back when the ANSWERS finish");
        lim.release(permit);
    }

    /// The two bounds that killed connections when they drifted apart.
    #[test]
    fn bounds_hold() {
        assert!(MAX_YAMUX_STREAMS > MAX_CONCURRENT_SYNC_STREAMS);
        assert!(REGOSSIP_SUPPRESS_TTL >= DUPLICATE_CACHE_TIME);
    }

    /// A Genesis-4 node must not be able to talk to a Genesis-3 one. The
    /// Genesis-3 values are hard-coded here on purpose: this test fails if
    /// someone ever "simplifies" a prefix back to the default.
    #[test]
    fn protocol_ids_differ_from_genesis3() {
        assert_ne!(GOSSIP_PROTOCOL_PREFIX, "");
        assert_ne!(SYNC_PROTOCOL.as_ref(), "/bloch/sync/1");
        assert_ne!(IDENTIFY_PROTOCOL, "/bloch-sis/1.0.0");
        for t in [TOPIC_BLOCKS, TOPIC_ATTESTATIONS, TOPIC_TXS] {
            assert!(t.starts_with("bloch-g4/"), "{t} is not in the Genesis-4 namespace");
        }
        // The prefix must be a real one and not the library default (which is
        // `/meshsub`, exactly what Genesis-3 negotiates). `Config` exposes no
        // public reader for its protocol ids, so this asserts the input the
        // builder is given; `gossipsub_config` is the single place it is used.
        assert!(
            GOSSIP_PROTOCOL_PREFIX.starts_with("/bloch-g4"),
            "the gossipsub prefix left the Genesis-4 namespace"
        );
        assert_ne!(GOSSIP_PROTOCOL_PREFIX, "/meshsub", "that is the default Genesis-3 speaks");

        let cfg = gossipsub_config().expect("config builds");
        assert!(cfg.validate_messages(), "gossip.rs cannot gate relay without validate_messages");
        assert_eq!(cfg.duplicate_cache_time(), DUPLICATE_CACHE_TIME);
        assert!(
            REGOSSIP_SUPPRESS_TTL >= cfg.duplicate_cache_time(),
            "the suppression window is shorter than the cache it exists to match"
        );
    }

    #[test]
    fn sync_frames_round_trip() {
        let req = SyncRequest::GetBlocks { after_slot: 4242, limit: 64 };
        assert_eq!(decode_sync_request(&encode_sync_request(&req)).unwrap(), req);

        let resp = SyncResponse::Blocks { envelopes: vec![vec![1, 2, 3], vec![], vec![9; 100]] };
        assert_eq!(decode_sync_response(&encode_sync_response(&resp)).unwrap(), resp);
    }

    #[test]
    fn sync_frames_reject_trailing_bytes() {
        let mut b = encode_sync_request(&SyncRequest::GetBlocks { after_slot: 1, limit: 1 });
        b.push(0);
        assert!(decode_sync_request(&b).is_err(), "encode(x) ‖ junk must not decode");

        let mut b = encode_sync_response(&SyncResponse::Blocks { envelopes: vec![vec![7]] });
        b.push(0);
        assert!(decode_sync_response(&b).is_err());
    }

    #[test]
    fn sync_response_block_cap_is_enforced_on_decode() {
        // A hostile peer claiming more blocks than the cap must be refused
        // before the decoder allocates for them.
        let mut b = vec![SYNC_TAG_BLOCKS];
        b.extend_from_slice(&((MAX_SYNC_BLOCKS as u32) + 1).to_le_bytes());
        assert!(decode_sync_response(&b).is_err());
    }

    // ── Two live swarms on localhost ────────────────────────────────────────
    //
    // These bring up real sockets, a real noise handshake, a real gossipsub
    // mesh and the real request-response protocol. They deliberately do NOT
    // run consensus: what is under test is the transport, and a test that also
    // had to wait for sortition, proposals and fork choice would fail for
    // reasons that have nothing to do with the network. Consensus over this
    // transport is covered end-to-end by tests/cold_start.rs.

    use bloch_pos_committee::header::{BlockEnvelope, BlockHeaderV4, Body, VERSION_G4};
    use std::sync::mpsc::Receiver;

    fn envelope(slot: u64) -> BlockEnvelope {
        BlockEnvelope {
            header: BlockHeaderV4 {
                version: VERSION_G4,
                parent: [1; 32],
                state_root: [2; 32],
                body_root: [3; 32],
                slot,
                proposer_index: 0,
                randao_reveal: [4; 32],
                randao_mix: [5; 32],
                justified_root: [6; 32],
                finalized_root: [7; 32],
                attestation_root: [8; 32],
                coherence_root: [9; 32],
            },
            // Non-trivial length so a page is not accidentally tiny, and
            // slot-dependent so every block has a distinct message id.
            proposer_sig: vec![(slot % 251) as u8; 96],
            body: Body { transactions: Vec::new(), attestations: Vec::new() },
        }
    }

    /// A port nobody is listening on right now. Racy in principle; in practice
    /// the window between closing this listener and the swarm binding is
    /// microseconds, and the alternative (fixed ports) collides between
    /// parallel test binaries for certain.
    fn free_port() -> u16 {
        let l = std::net::TcpListener::bind("127.0.0.1:0").expect("bind");
        let p = l.local_addr().expect("addr").port();
        drop(l);
        p
    }

    fn tmpdir(tag: &str) -> PathBuf {
        let d = std::env::temp_dir().join(format!(
            "bloch-pos-p2p-{tag}-{}-{:?}",
            std::process::id(),
            std::thread::current().id()
        ));
        let _ = std::fs::remove_dir_all(&d);
        std::fs::create_dir_all(&d).expect("mkdir");
        d
    }

    struct Node {
        handle: Handle,
        rx: Receiver<NetEvent>,
        head: Arc<AtomicU64>,
        addr: Multiaddr,
        _dir: PathBuf,
    }

    /// Bring up one node's transport over a store seeded with blocks at slots
    /// `1..=blocks`.
    fn node(tag: &str, blocks: u64, peers: &[Multiaddr]) -> Node {
        let dir = tmpdir(tag);
        let mut store = crate::store::Store::open(&dir, &[9u8; 32]).expect("store");
        for slot in 1..=blocks {
            store.append(&envelope(slot)).expect("append");
        }
        let port = free_port();
        let addr: Multiaddr = format!("/ip4/127.0.0.1/tcp/{port}").parse().expect("addr");
        let (tx, rx) = std::sync::mpsc::channel();
        let head = Arc::new(AtomicU64::new(blocks));
        let handle = start(
            Config {
                listen: vec![addr.clone()],
                peers: peers.to_vec(),
                data_dir: dir.clone(),
                max_peers: 16,
                // Every node in these tests shares 127.0.0.1, and the
                // colocation penalty is -50 × (peers_on_ip − 3)². It reaches
                // `graylist_threshold` (-400) at SIX peers on one IP, not four
                // — `peer_score_params` says six and is the number to trust;
                // four scores -50 and graylists nobody. So this flag is not
                // what keeps these tests alive at their current size. It is set
                // because it is the same switch a fleet behind one proxy needs,
                // and because a test that grows two more nodes would otherwise
                // graylist itself with nothing in the output to say so.
                behind_proxy: true,
            },
            tx,
            head.clone(),
        )
        .expect("p2p starts");
        Node { handle, rx, head, addr, _dir: dir }
    }

    /// Collect events until `want` blocks have arrived or the deadline passes.
    fn collect_blocks(rx: &Receiver<NetEvent>, want: usize, secs: u64) -> Vec<u64> {
        let deadline = Instant::now() + Duration::from_secs(secs);
        let mut slots = Vec::new();
        while slots.len() < want && Instant::now() < deadline {
            match rx.recv_timeout(Duration::from_millis(200)) {
                Ok(NetEvent::Block(env, _)) => slots.push(env.header.slot),
                Ok(_) => {}
                Err(_) => {}
            }
        }
        slots
    }

    /// Two nodes must form a mesh and keep it: after the first delivery lands,
    /// every subsequent publish must land too.
    ///
    /// "No `NoPeersSubscribedToTopic` in regime" is asserted by *observation*
    /// rather than by grepping a log: that error is precisely the state in
    /// which a publish reaches nobody, so a run of publishes that all arrive is
    /// the same claim, made where it cannot drift out of date. This is the
    /// regression test for the 2026-08-07 pair of mesh defects — with either of
    /// them present, the mesh never holds a peer and this test never sees a
    /// single block.
    #[test]
    fn two_nodes_form_a_mesh_and_keep_exchanging_blocks() {
        let a = node("mesh-a", 0, &[]);
        let b = node("mesh-b", 0, &[a.addr.clone()]);

        // Gossipsub needs the subscription exchange and a heartbeat before a
        // publish has anywhere to go, so the first block is retried — with
        // DIFFERENT bytes each attempt, which is not a detail. The message id
        // is a content hash and `publish()` inserts into the duplicate cache
        // before it looks for peers, so a retry of the identical block is
        // refused locally for the next 30 s and never leaves the node. That is
        // the same defect Genesis-3 hit twice (a re-announce and an IBD
        // re-request, both silently swallowed as `Duplicate`); a test that
        // re-published one fixed block would hang for reasons it blamed on the
        // mesh.
        let deadline = Instant::now() + Duration::from_secs(30);
        let mut attempt = 0u64;
        let mut connected = false;
        while Instant::now() < deadline && !connected {
            attempt += 1;
            a.handle.broadcast(crate::net::block_frame(&envelope(900 + attempt)));
            connected = !collect_blocks(&b.rx, 1, 1).is_empty();
        }
        assert!(connected, "the mesh never formed: no block ever reached the peer");

        // Drain whatever else the retry loop put in flight, so the next
        // assertion is about the publishes it names and nothing else.
        while b.rx.recv_timeout(Duration::from_millis(300)).is_ok() {}

        // In regime now. Ten distinct blocks, one publish each, all must land.
        for slot in 2..=11u64 {
            a.handle.broadcast(crate::net::block_frame(&envelope(slot)));
        }
        let deadline = Instant::now() + Duration::from_secs(20);
        let mut got: Vec<u64> = Vec::new();
        while got.len() < 10 && Instant::now() < deadline {
            if let Ok(NetEvent::Block(env, _)) = b.rx.recv_timeout(Duration::from_millis(200)) {
                if (2..=11).contains(&env.header.slot) {
                    got.push(env.header.slot);
                }
            }
        }
        got.sort_unstable();
        assert_eq!(
            got,
            (2..=11).collect::<Vec<_>>(),
            "the mesh dropped publishes after it had formed"
        );

        // And it is bidirectional — b was never told about a, it only accepted
        // a's dial, and it must still be able to publish back.
        b.handle.broadcast(crate::net::block_frame(&envelope(500)));
        assert_eq!(collect_blocks(&a.rx, 1, 20), vec![500], "reverse direction never delivered");
    }

    /// The exchange's question, at the transport layer: a node with an EMPTY
    /// store asks from genesis and must receive the whole chain — which means
    /// the answer has to be paginated, because one response is capped at
    /// [`MAX_SYNC_BLOCKS`].
    #[test]
    fn a_cold_node_is_served_the_whole_chain_from_genesis() {
        // Deliberately more than two full pages, so this fails if the
        // page-chasing loop is removed and only the first answer arrives.
        let total = (MAX_SYNC_BLOCKS * 2 + 37) as u64;
        let server = node("cold-server", total, &[]);
        let cold = node("cold-client", 0, &[server.addr.clone()]);
        assert_eq!(cold.head.load(Ordering::Relaxed), 0, "the cold node starts at genesis");

        let mut got = collect_blocks(&cold.rx, total as usize, 60);
        got.sort_unstable();
        assert_eq!(
            got.len(),
            total as usize,
            "a node asking from genesis got {} of {total} blocks — pagination stopped early",
            got.len()
        );
        assert_eq!(got.first(), Some(&1), "the walk did not start at the first block");
        assert_eq!(got.last(), Some(&total), "the walk did not reach the tip");
        assert_eq!(got, (1..=total).collect::<Vec<_>>(), "a block was skipped");
    }

    /// A node that was there, went away, and came back gets exactly the gap.
    #[test]
    fn a_restarted_node_recovers_only_what_it_missed() {
        let total = 200u64;
        let missed_from = 60u64;
        let server = node("restart-server", total, &[]);
        let restarted = node("restart-client", missed_from, &[server.addr.clone()]);
        assert_eq!(restarted.head.load(Ordering::Relaxed), missed_from);

        let want = (total - missed_from) as usize;
        let mut got = collect_blocks(&restarted.rx, want, 60);
        got.sort_unstable();
        assert_eq!(
            got,
            ((missed_from + 1)..=total).collect::<Vec<_>>(),
            "a restarted node did not get exactly the blocks after its head"
        );
    }

    #[test]
    fn verdict_maps_onto_gossipsub_verbs() {
        // Ignore must never become Reject: that mapping is how a mesh
        // graylists its honest peers.
        assert!(matches!(MessageAcceptance::from(Verdict::Accept), MessageAcceptance::Accept));
        assert!(matches!(MessageAcceptance::from(Verdict::Ignore), MessageAcceptance::Ignore));
        assert!(matches!(MessageAcceptance::from(Verdict::Reject), MessageAcceptance::Reject));
    }
}
